<div align="center">

# 🚀 Marvel's Guardians of the Galaxy VR (GOTGVR)

**Play Marvel's Guardians of the Galaxy (PC - Steam, Epic) in VR**

![version](https://img.shields.io/badge/version-0.6.38--alpha-8e44ad) ![game](https://img.shields.io/badge/game-Guardians%20of%20the%20Galaxy-222) ![xr](https://img.shields.io/badge/OpenXR-SteamVR%20%7C%20Pimax%20%7C%20Quest%20%7C%20VDXR%20%7C%20WMR-555)

</div>

---

## 📦 Install

1. Copy `dxgi.dll` and `gotgvr_config.txt` from the `mod` folder into the game folder with `GOTG.exe`
   (Steam: `...\Marvel's Guardians of the Galaxy\bin`, Epic: `...\MarvelGOTG\retail` - Epic has no `bin` folder; the mod goes wherever GOTG.exe is).
   Another mod already named `dxgi.dll` (ReShade, an ASI loader)? Rename it to `dxgi_chain.dll` - GOTGVR chain-loads it.
   Already have your own `gotgvr_config.txt`? Keep yours and copy only `dxgi.dll`.
   Optional: also copy `Start GOTGVR.bat` there and start the game with it (Steam or Epic, found by itself) - straight into the game, no launcher.
2. Start your VR software, then start the game (the .bat, or the normal way from Steam / Epic). VR starts when the game itself starts, never in the launcher.

Works with every store version (Steam, Epic) and with the FuckTAA-patched exe. If the game folder cannot be written
(e.g. under "Program Files"), the settings and logs go to `%LOCALAPPDATA%\GOTGVR`. To uninstall, delete `dxgi.dll`,
the `GOTGVR` folder and `gotgvr_config.txt`.

---

## ✨ Features

- **Stereo 3D with head and position tracking** on the game's own camera - three methods: stereo reconstruction (full frame rate), synchronized (both eyes from the same moment), alternate eye.
- **Any OpenXR headset, set up by itself**: the game renders at your headset's own resolution and shape, with each eye's real field of view - nothing to set.
- **No pop-in at the edges** of your view (wide culling), no extra rendering cost.
- **First person** (`End`) in Star-Lord's head, back to the game camera in cutscenes.
- **Head aim**: weapons aim where you look - always, or only while L2 / right mouse is held; the view never turns with it.
- **HUD scaled into view** (UI scale), kept in the middle of each eye.
- **Comfort**: level horizon, camera shake filter, idle-sway lock (no camera drift when you stand still).
- **Flat virtual screen** for pause menus, loading screens and video cutscenes, switched automatically.
- **Smooth frame pacing** at your headset's refresh rate; the headset's smoothing never halves the fps.
- **Fixed foveated rendering** (RTX 20+, RX 6000+, Arc) for more fps - off by default (Advanced).
- **Edge fill**: no black border where the headset sees past the picture.
- **Your game settings stay yours** - the mod changes no game option unless you choose it in the VR panel.
- **In-headset VR panel** with every setting, in tabs: View, Camera, HUD, Graphics, Screen, Advanced, Hotkeys - with a gamepad, the keyboard, or the **mouse** (point, click, wheel; a neon pointer in the panel).
- **Hotkeys you choose**: any mod function on any key (Ctrl / Shift / Alt too) or gamepad button combination, saved in the config - Xbox pads, PlayStation pads (native or Steam Input) and DirectInput pads.

---

## 🎮 Controls

Defaults below - change or add any of them on the VR panel's **Hotkeys** tab (press the new key or pad buttons).

| Keyboard | Gamepad | Action |
|---|---|---|
| `Insert` | hold `L3 + R3` | VR panel |
| `Space` / `F9` | – | Recentre |
| `End` | – | First person on / off |
| `F8` | – | Stereo method / mono / flat screen |
| `F7` | – | Hide / show the HUD |
| `F6` | – | Flat screen on / off |
| `Delete` | – | Screenshot of the left eye (PNG next to `GOTG.exe`) |

Settings are saved in `gotgvr_config.txt` next to `GOTG.exe` (change them in the VR panel; delete the file for the defaults).

---

## ❓ Problems?

- **No picture in the headset:** start your VR software first and make it the active OpenXR runtime.
- **Double image in alternate eye / synchronized:** set Game anti-aliasing and Game upscaling to Off (Graphics).
- **HUD not scaling:** HUD tab, step **UI element (picker)** 1, 2, 3 … with the HUD on screen; 0 = automatic.
- **Anything else:** send `GOTGVR\gotgvr.log` and `GOTGVR\xrhost.log`.

Source and build notes are in the `source` folder (`scripts/build_mingw.sh`); history in `CHANGELOG.md`.

---

## 🙏 Credits

| Who | What |
|---|---|
| **mark-mon** | Markmons VR framework this mod is built on: XrBridge OpenXR host, vrkit VR panel, proxy loader |
| **DXMDVR** | The Deus Ex: Mankind Divided VR mod (same Dawn engine): render-camera hook, frame pacing, foveation and UI ideas |
| **Otis_Inf** | IGCS GotG Camera Tools: camera chain, game clock, cutscene black bars and focus-pause sites |
| **GotG OpenTrack head-tracking mod** | Notes on the game's camera |
| **praydog / UEVR** | The synchronized-sequential idea behind Synchronized stereo |
| **adderek / vrdual** | The alternate-eye approach |
| **PureDark (AFW) and the Dark Souls III VR mod** | Showed that depth-based eye reconstruction works. Idea only, no code used |
| **Paul44** | GotG Cheat Engine table: pointers used in research |
| **r/FuckTAA (TL431)** | TAA patch research that led to the game's TAA flag |
| **Tsuda Kageyu** | MinHook (BSD 2-Clause) |
| **Omar Cornut** | Dear ImGui (MIT) |
| **Khronos Group** | OpenXR SDK and loader (Apache 2.0) |

<sub>Marvel's Guardians of the Galaxy is a trademark of Marvel / Square Enix / Eidos-Montréal. This is an unofficial fan mod with no game files included. You need your own copy of the game.</sub>
