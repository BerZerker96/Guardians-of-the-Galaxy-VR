@echo off
rem GOTGVR - start Marvel's Guardians of the Galaxy straight into the game (no launcher), Steam or Epic.
rem Put this file next to GOTG.exe and dxgi.dll and double-click it:
rem   Steam: ...\steamapps\common\Marvel's Guardians of the Galaxy\bin\     Epic: ...\Epic Games\MarvelGOTG\retail\
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if not exist "GOTG.exe" (
  echo This file must be next to GOTG.exe: Steam - the game's "bin" folder, Epic - the game's "retail" folder.
  pause
  exit /b 1
)

rem ---- Epic Games Store: the install has an .egstore folder (game folder, one level above retail)
set "EGS="
for %%M in ("..\.egstore\*.mancpn" ".egstore\*.mancpn") do if exist "%%~M" set "EGS=%%~M"
if defined EGS (
  for /f "usebackq delims=" %%U in (`powershell -NoProfile -ExecutionPolicy Bypass -Command "$j = Get-Content -Raw -LiteralPath '%EGS%' | ConvertFrom-Json; 'com.epicgames.launcher://apps/' + $j.CatalogNamespace + '%%3A' + $j.CatalogItemId + '%%3A' + $j.AppName + '?action=launch&silent=true'"`) do set "EGSURL=%%U"
  if defined EGSURL (
    echo Epic Games Store - starting the game through the Epic launcher, no game launcher...
    start "" "!EGSURL!"
    exit /b 0
  )
)

rem ---- Steam: steamapps in the path (or steam_api64.dll next to the exe)
set "ISSTEAM="
echo %~dp0 | find /i "\steamapps\" >nul && set "ISSTEAM=1"
if exist "steam_api64.dll" set "ISSTEAM=1"
if defined ISSTEAM (
  set "STEAMEXE="
  for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Valve\Steam" /v SteamExe 2^>nul ^| find /i "SteamExe"') do set "STEAMEXE=%%B"
  if defined STEAMEXE (
    echo Steam - starting the game with -nolauncher...
    start "" "!STEAMEXE!" -applaunch 1088850 -nolauncher
  ) else (
    start "" "steam://rungameid/1088850"
  )
  exit /b 0
)

rem ---- anything else (e.g. a copy of the game): the exe itself
echo Starting GOTG.exe -nolauncher...
start "" "GOTG.exe" -nolauncher
exit /b 0
