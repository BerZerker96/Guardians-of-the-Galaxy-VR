#!/bin/bash
# Builds the Windows unit tests (run them with wine): build/tests/*.exe
set -e
cd "$(dirname "$0")/.."
CXX=${CXX:-x86_64-w64-mingw32-g++}; CC=${CC:-x86_64-w64-mingw32-gcc}
INC="-Ithird_party/minhook/include -Ithird_party/xrbridge/include -Ithird_party/vrkit -Isrc"
FL="-std=c++17 -O1 -D_CRT_SECURE_NO_WARNINGS -DWIN32_LEAN_AND_MEAN -DNOMINMAX -D_WIN32_WINNT=0x0A00 -w"
O=build/tests/obj; mkdir -p $O
MH=()
for c in third_party/minhook/src/buffer.c third_party/minhook/src/hook.c third_party/minhook/src/trampoline.c third_party/minhook/src/hde/hde64.c; do
  o=$O/$(basename $c .c).o; $CC -O2 -w $INC -c $c -o $o; MH+=($o)
done
t() { local name=$1; shift; $CXX $FL $INC "$@" -static -o build/tests/$name.exe -luser32 -lole32 -lwindowscodecs -ladvapi32; echo "built build/tests/$name.exe"; }
t camera_unittest tools/camera_unittest.cpp src/camera.cpp src/config.cpp
t flatscreen_unittest tools/flatscreen_unittest.cpp src/camera.cpp src/config.cpp
t firstperson_unittest tools/firstperson_unittest.cpp src/firstperson.cpp src/game.cpp src/shot.cpp src/config.cpp
MH=(build/tests/obj/buffer.o build/tests/obj/hook.o build/tests/obj/trampoline.o build/tests/obj/hde64.o)
$CXX $FL $INC tools/window_test.cpp src/window.cpp src/config.cpp "${MH[@]}" -static -o build/tests/window_test.exe -luser32; echo "built build/tests/window_test.exe"
V=third_party/vrkit; I=$V/third_party/imgui
$CXX $FL $INC -I$I tools/hotkey_menu_test.cpp $V/vrkit_options.cpp $V/vrkit_input.cpp $V/vrkit_menu_core.cpp $I/imgui.cpp $I/imgui_draw.cpp $I/imgui_widgets.cpp $I/imgui_tables.cpp "${MH[@]}" -static -o build/tests/hotkey_menu_test.exe; echo "built build/tests/hotkey_menu_test.exe"
# 0.6.36: proxy chain-loading (needs build/dxgi.dll): build/tests/chain/GOTG.exe + dxgi_chain.dll
mkdir -p build/tests/chain
$CXX -O1 -shared -static tools/proxy_chain_fake.cpp -o build/tests/chain/dxgi_chain.dll && $CXX -O1 -static tools/proxy_chain_app.cpp -o build/tests/chain/GOTG.exe && echo "built build/tests/chain (copy build/dxgi.dll in, run GOTG.exe)"
