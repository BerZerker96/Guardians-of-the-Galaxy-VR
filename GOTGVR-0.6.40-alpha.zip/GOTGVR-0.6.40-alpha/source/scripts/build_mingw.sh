#!/bin/bash
# Builds the 64-bit mod with mingw-w64 (Linux: apt install g++-mingw-w64-x86-64):
#   build/dxgi.dll (default install name)   build/winmm.dll (alternative)   build/GOTGVR.asi (for an ASI loader)
# All three are the same code; only the export table differs. The OpenXR host runs inside the game (no exe): it is
# compiled in from third_party/xrbridge/src/host with XRB_IN_PROCESS and the static OpenXR loader (OXR = an
# OpenXR-SDK built for mingw, see scripts/build_host_mingw.sh).
set -e
cd "$(dirname "$0")/.."
CXX=${CXX:-x86_64-w64-mingw32-g++}; CC=${CC:-x86_64-w64-mingw32-gcc}; STRIP=${STRIP:-x86_64-w64-mingw32-strip}
python3 scripts/gen_proxy.py
mkdir -p build/obj
V=third_party/vrkit; I=$V/third_party/imgui
INC="-Ithird_party/minhook/include -Ithird_party/xrbridge/include -I$V -I$I -Isrc"
FL="-O2 -D_CRT_SECURE_NO_WARNINGS -DWIN32_LEAN_AND_MEAN -DNOMINMAX -D_WIN32_WINNT=0x0A00 -Wall -Wno-unused-function -Wno-unknown-pragmas -Wno-misleading-indentation ${EXTRA_FLAGS}"
OBJS=()
OXR=${OXR:-$HOME/oxr}
X=third_party/xrbridge
# the host's own log functions get their own names (the mod has xrb::Log* already: its log shim)
HFL="-std=c++17 -O2 -DXRB_IN_PROCESS -DXR_USE_PLATFORM_WIN32 -DXR_USE_GRAPHICS_API_D3D11 -DNOMINMAX -D_WIN32_WINNT=0x0A00 \
 -DLogInit=HostLogInit -DLogWrite=HostLogWrite -DLogFlush=HostLogFlush -DLogSetLevel=HostLogSetLevel -DLogGetLevel=HostLogGetLevel \
 -I$X/include -I$OXR/include"
for f in $X/src/host/main.cpp $X/src/common/log.cpp $X/src/common/config.cpp; do
  o=build/obj/host_$(basename $f .cpp).o; $CXX $HFL -c $f -o $o; OBJS+=($o)
done
for f in third_party/minhook/src/buffer.c third_party/minhook/src/hook.c third_party/minhook/src/trampoline.c third_party/minhook/src/hde/hde64.c; do
  o=build/obj/$(basename $f .c).o; $CC -O2 -w $INC -c $f -o $o; OBJS+=($o)
done
for f in src/*.cpp third_party/xrbridge/src/client/client.cpp; do
  o=build/obj/$(basename $f .cpp).o; $CXX -std=c++17 $FL $INC -c $f -o $o; OBJS+=($o)
done
for f in $V/vrkit_input.cpp $V/vrkit_menu.cpp $V/vrkit_menu_core.cpp $V/vrkit_options.cpp $I/imgui.cpp $I/imgui_draw.cpp $I/imgui_tables.cpp $I/imgui_widgets.cpp $I/imgui_impl_dx11.cpp; do
  o=build/obj/$(basename $f .cpp).o; $CXX -std=c++17 -O2 -w -D_CRT_SECURE_NO_WARNINGS -DWIN32_LEAN_AND_MEAN -DNOMINMAX $INC -c $f -o $o; OBJS+=($o)
done
LIBS="$OXR/build/src/loader/libopenxr_loader.a -lshlwapi -lpathcch -lcfgmgr32 -lgdi32 -luser32 -ld3d11 -ld3d12 -ldxgi -ldxguid -ldinput8 -ladvapi32 -lshell32 -ld3dcompiler_47 -lkernel32 -lole32 -luuid -lwindowscodecs -lversion -lpsapi"
LD="-shared -static -static-libgcc -static-libstdc++"
$CXX $LD -o build/dxgi.dll src/dxgi.def "${OBJS[@]}" $LIBS
$CXX $LD -o build/winmm.dll src/winmm.def "${OBJS[@]}" $LIBS
$CXX $LD -Wl,--exclude-all-symbols -o build/GOTGVR.asi "${OBJS[@]}" $LIBS
$STRIP build/dxgi.dll build/winmm.dll build/GOTGVR.asi
ls -la build/dxgi.dll build/winmm.dll build/GOTGVR.asi
