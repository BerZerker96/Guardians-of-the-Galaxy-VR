// Unit test of src/camera.cpp: its real hook bodies driven by a fake renderer (view update calls the projection
// getter like exe+990D32 and a post filter like exe+8C6491), fake headset poses and a fake game clock.
#include <windows.h>
#include <cstdio>
#include <cmath>
#include <cstring>
#include "MinHook.h"
#include "camera.h"
#include "settings.h"
#include "game.h"
#include "vrmath.h"
#include "xrbridge/client.h"
#include "firstperson.h"
namespace fp { void GameTick() {} bool EyeBase(const Frame&, const Frame&, Frame&) { return false; } }
VrSettings g_set;
volatile LONG g_presents = 0; DWORD g_presentThread = 0;
void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
static char s_nodeUpd, s_getProj, s_timer;   // fake function addresses
bool PadsLTHeld() { return false; }
namespace game { void* g_nodeUpdate = &s_nodeUpd; void* g_getProj = &s_getProj; void* g_timerUpdate = &s_timer; uintptr_t g_gameTimer = 0; uintptr_t g_cullVpRet = 0; uintptr_t g_cullRecRet = 0; void* g_camApply = nullptr;
  volatile unsigned char* g_taaFlag = nullptr; uintptr_t kNodeTransform = 0x24, kNodeProj = 0xC0, kNodeW = 0x1A8, kNodeH = 0x1AC;
  bool Readable(const void*, size_t) { return true; }
  bool RenderOptionsFound() { return false; } void RenderOptionsApply(bool, int) {}
  volatile float* g_nearOverride = nullptr; float g_nearSet = -1.f; void SetNearClip(float u) { g_nearSet = u; } }
static xrb::IpcPose s_pose[2]; static xrb::IpcFov s_fov[2];
namespace xrb {
bool ClientHostConnected() { return true; }
bool ClientGetLatestPoses(IpcPose* p, IpcFov* f, int64_t* t) { p[0] = s_pose[0]; p[1] = s_pose[1]; f[0] = s_fov[0]; f[1] = s_fov[1]; *t = 7; return true; }
}
typedef uintptr_t(__fastcall* PNode)(void*, void*, void*, uintptr_t);
typedef float*(__fastcall* PProj)(void*, float*, uintptr_t);
typedef void(__fastcall* PTimer)(void*, uintptr_t);
static PNode hNode; static PProj hProj; static PTimer hTimer;
static float g_jit[2] = {};
bool g_videoOn = false; bool VideoActive(unsigned) { return g_videoOn; }
static float s_lastProj[16], s_postProj[16]; static float s_seenT[12];
static float* __fastcall FakeGetProj(void* node, float* out, uintptr_t keep) {
    memset(out, 0, 64); out[0] = 1.2f; out[5] = 1.5f; out[11] = -1.f; out[10] = 0.0001f; out[14] = 0.1f;   // reverse Z
    out[8] = g_jit[0]; out[9] = g_jit[1]; return out;
}
static uintptr_t __fastcall FakeNodeOrig(void* node, void*, void*, uintptr_t) {   // the renderer: reads node+0x24, the getter
    memcpy(s_seenT, (char*)node + 0x24, 48);
    hProj(node, s_lastProj, 0);   // view update (keepDepth 0)
    hProj(node, s_postProj, 1);   // a post filter (keepDepth 1)
    return 0;
}
static void __fastcall FakeTimerOrig(void* t, uintptr_t) {   // advance 1/60 s
    char* p = (char*)t; long long* time = (long long*)(p + 0x20); long long* d = (long long*)(p + 0x30);
    *d = 166666; *time += *d;
}
MH_STATUS WINAPI MH_CreateHook(LPVOID t, LPVOID d, LPVOID* o) {
    if (t == &s_nodeUpd) { hNode = (PNode)d; *o = (void*)FakeNodeOrig; }
    else if (t == &s_getProj) { hProj = (PProj)d; *o = (void*)FakeGetProj; }
    else if (t == &s_timer) { hTimer = (PTimer)d; *o = (void*)FakeTimerOrig; }
    return MH_OK;
}
MH_STATUS WINAPI MH_EnableHook(LPVOID) { return MH_OK; }

static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("  FAIL %s: ", #c); printf(__VA_ARGS__); printf("\n"); } } while (0)
alignas(16) static char g_node[0x400]; alignas(16) static char g_timerObj[0x100];
static float gameT[12];
static void SetGameCam(float yaw, float x) {   // looking along +x turned by yaw, Z up; rows right, up, back, pos
    float c = cosf(yaw), s = sinf(yaw);
    float fwd[3] = { c, s, 0 }, up[3] = { 0, 0, 1 }, right[3] = { s, -c, 0 };
    float T[12] = { right[0], right[1], right[2], up[0], up[1], up[2], -fwd[0], -fwd[1], -fwd[2], x, 0, 170 };
    memcpy(gameT, T, 48); memcpy(g_node + 0x24, T, 48);
}
static float Dist(const float* a, const float* b) { return sqrtf((a[9] - b[9]) * (a[9] - b[9]) + (a[10] - b[10]) * (a[10] - b[10]) + (a[11] - b[11]) * (a[11] - b[11])); }


static bool g_paused = false;
static void TimerOrigPause(void* t, uintptr_t p) { FakeTimerOrig(t, p); }
struct R { int vr = 0, flat = 0, posed = 0; };
// run `ms` of frames at ~120 fps; moving = the game camera moves
static R Run(int ms, bool moving, float& x) {
    R r; long long end = GetTickCount64() + ms;
    while ((long long)GetTickCount64() < end) {
        hTimer(g_timerObj, g_paused ? 1 : 0);
        if (moving) x += 5.f;
        SetGameCam(0.f, x);
        hNode(g_node, nullptr, nullptr, 0);
        if (memcmp(s_seenT, gameT, 48)) r.posed++;
        CameraOnPresent(2000, 2000);
        RenderedEye re; CameraTakeRendered(re);
        g_presents++;
        if (g_cam.flatNow) r.flat++; else r.vr++;
        Sleep(8);
    }
    return r;
}
int main() {
    *(unsigned*)(g_node + 0x1A8) = 2000; *(unsigned*)(g_node + 0x1AC) = 2000;
    game::g_gameTimer = (uintptr_t)g_timerObj;
    for (int e = 0; e < 2; e++) { s_fov[e] = { -0.9f, 0.9f, 0.85f, -0.9f }; s_pose[e] = { e ? 0.032f : -0.032f, 0, 0, 0, 0, 0, 1 }; }
    CameraInstall();
    g_cam.unitsPerMetre = 100.f; g_cam.worldScale = 1.f; g_cam.ipdScale = 1.f; g_cam.cullMargin = 1.f;
    g_cam.mode = VRMODE_STEREO; g_cam.flatMenus = true; g_cam.flatVideos = true; g_cam.flatVideoMinW = 1280;
    float x = 0; R r;
    r = Run(500, true, x);  printf("playing:              vr %3d flat %3d posed %3d\n", r.vr, r.flat, r.posed);
    CHECK(r.flat == 0 && r.posed > 0, "playing is VR");
    g_paused = true;
    r = Run(1200, false, x); printf("pause menu:           vr %3d flat %3d posed %3d  reason %d\n", r.vr, r.flat, r.posed, g_cam.flatReason);
    CHECK(g_cam.flatNow && g_cam.flatReason == 2, "paused + still -> flat");
    { R t = Run(300, false, x); CHECK(t.posed == 0, "flat: the renderer gets the game's own camera (posed %d)", t.posed); }
    g_paused = false;
    r = Run(800, true, x);  printf("unpaused:             vr %3d flat %3d\n", r.vr, r.flat);
    CHECK(!g_cam.flatNow, "unpaused -> VR");
    g_paused = true;
    r = Run(200, false, x);
    r = Run(1500, true, x);  printf("photo mode (moving):  vr %3d flat %3d\n", r.vr, r.flat);
    CHECK(!g_cam.flatNow, "paused but the camera moves (photo mode) -> stays VR");
    r = Run(1000, false, x); CHECK(!g_cam.flatNow, "photo mode, camera stopped -> still VR until unpaused");
    g_paused = false; r = Run(500, true, x);
    g_videoOn = true;
    r = Run(1500, false, x); printf("video cutscene:       vr %3d flat %3d reason %d\n", r.vr, r.flat, g_cam.flatReason);
    CHECK(g_cam.flatNow && g_cam.flatReason == 3, "video + still camera -> flat");
    r = Run(1500, true, x);  printf("video, camera moving: vr %3d flat %3d\n", r.vr, r.flat);
    CHECK(!g_cam.flatNow, "in-world video while playing -> VR");
    g_videoOn = false; r = Run(2500, false, x);
    // 0.6.36: a real-time cutscene with a video decoding: every shot a still camera, cuts between shots
    g_videoOn = true;
    r = Run(1500, false, x); printf("real-time cutscene, first shot (still): vr %3d flat %3d\n", r.vr, r.flat);
    int switches = 0; bool last = g_cam.flatNow;
    for (int shot = 0; shot < 4; shot++) {
        x += 400.f;   // camera cut
        R s = Run(1500, false, x);
        if (g_cam.flatNow != last) switches++; last = g_cam.flatNow;
        printf("   shot %d after a cut: vr %3d flat %3d\n", shot + 2, s.vr, s.flat);
        CHECK(s.flat == 0 || shot == 0, "after the first cut the scene stays VR (shot %d: flat %d)", shot + 2, s.flat);
    }
    CHECK(!g_cam.flatNow && switches <= 1, "real-time cutscene: VR, no flipping (%d switches)", switches);
    g_videoOn = false; r = Run(2500, false, x);
    g_videoOn = true; r = Run(1500, false, x);
    CHECK(g_cam.flatNow && g_cam.flatReason == 3, "the next video with a still camera (a pre-rendered cutscene) -> flat again");
    g_videoOn = false;
    g_cam.flatHold = true; r = Run(100, true, x); CHECK(g_cam.flatNow && g_cam.flatReason == 1, "F6 -> flat at once");
    g_cam.flatHold = false; r = Run(600, true, x); CHECK(!g_cam.flatNow, "F6 released -> VR");
    g_cam.flatMenus = false; g_paused = true; r = Run(1200, false, x); CHECK(!g_cam.flatNow, "flat_pause_menus off -> paused stays VR");
    g_cam.flatMenus = true; r = Run(1200, false, x); CHECK(g_cam.flatNow, "on again -> flat");
    g_paused = false; g_cam.flatVideos = false; g_videoOn = true; r = Run(1500, false, x); CHECK(!g_cam.flatNow, "flat_videos off -> video stays VR");
    printf(fails ? "%d FAILURES\n" : "flat screen test: all checks passed\n", fails);
    return fails ? 1 : 0;
}
