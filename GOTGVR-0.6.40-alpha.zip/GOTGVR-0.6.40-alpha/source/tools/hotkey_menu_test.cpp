// Bindings parse / print, and the menu (with a Hotkeys page, mouse pointer, capture prompt) built headless.
#include <windows.h>
#include <cstdio>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include "vrkit_options.h"
#include "vrkit_input.h"
#include "vrkit_menu_core.h"
#include "imgui.h"
using namespace vrkit;
static int fails = 0;
static void Check(bool c, const char* what) { printf("%s %s\n", c ? "OK  " : "FAIL", what); if (!c) fails++; }
int main() {
    auto B = [](const char* t) { return input::BindingText(input::ParseBinding(t)); };
    Check(B("F8") == "F8 | none", "F8");
    Check(B("ctrl+f1 | lb+dpad_up") == "CTRL+F1 | LB+DPAD UP", "ctrl+f1 | lb+dpad_up");
    Check(B("none | L3+R3") == "none | L3+R3", "L3+R3");
    Check(B("PAD:BACK+Y") == "none | Y+BACK", "PAD:BACK+Y");
    Check(B("LT+RT") == "none | LT+RT", "LT+RT lone");
    Check(B("SPACE") == "SPACE | none", "SPACE");
    Check(B("DELETE | A") == "DELETE | A", "DELETE | A");
    Check(B("A") == "A | none", "lone A = keyboard A");
    Check(B("none | none") == "none | none", "none");
    Check(B(B("SHIFT+ALT+NUMPAD5 | X+RB").c_str()) == "SHIFT+ALT+NUMPAD5 | X+RB", "round trip");
    // other controllers (PlayStation / DirectInput) merged into the same bits
    static unsigned fake = 0;
    input::SetExtraPads([](unsigned* b, int* x, int* y) { *b = fake; *x = 0; *y = 0; return true; });
    fake = 0x1000 | input::PadLT;
    Check(input::ReadPadsAll() == (0x1000u | input::PadLT), "extra pad: A + LT read");
    input::Binding cb; input::CaptureBegin();             // A still held: waits for the release first
    Check(input::CaptureStep(cb) == 0, "capture waits while the opening button is held");
    fake = 0; input::CaptureStep(cb);
    fake = 0x0100; input::CaptureStep(cb); fake = 0x0100 | 0x8000; input::CaptureStep(cb);
    fake = 0; int cr = input::CaptureStep(cb);
    Check(cr == 2 && cb.pad == (0x0100u | 0x8000u), "capture LB+Y from another controller");
    unsigned hc[1] = { 0x0100u | 0x8000u }; input::SetHiddenCombos(hc, 1);
    Check(input::HiddenFromGame(0x0100 | 0x8000 | 0x1000) == (0x0100u | 0x8000u), "held combination hidden from the game");
    Check(input::HiddenFromGame(0x0100) == 0, "half a combination is not hidden");
    input::SetExtraPads(nullptr);
    // menu, headless
    static bool bv = true; static float fv = 1.f; static std::string hk = "END | none", hk2 = "none | none";
    Options& o = Options::Get();
    o.AddBool("Hotkeys", "b", "A switch", &bv);
    o.AddFloat("Hotkeys", "f", "A slider", &fv, 0.f, 2.f, 0.1f, 2);
    o.AddHotkey("Hotkeys", "hotkey_first_person", "First person on / off", &hk).group = "Mod";
    o.AddHotkey("Hotkeys", "hotkey_x", "Unbound", &hk2).group = "Mod";
    static std::string hk3 = "F8 | LB+DPAD UP"; o.AddHotkey("Hotkeys", "hotkey_vr_mode", "Cycle stereo method", &hk3).group = "Stereo";
    o.AddBool("View", "c", "Other page", &bv);
    menu::Settings s; s.fontPx = 26.f; s.texH = 860;
    Check(menu::core::InitImGui(s), "imgui init");
    unsigned char* px; int w, h; ImGui::GetIO().Fonts->GetTexDataAsRGBA32(&px, &w, &h);
    menu::core::SetOpen(true);
    input::MouseFeed(200, 50, 0);
    for (int i = 0; i < 12; i++) { Sleep(30); if (i == 6) input::MouseFeed(150, 60, 0); menu::core::UpdateInput(); menu::core::BuildFrame(); }
    Check(ImGui::GetDrawData() && ImGui::GetDrawData()->TotalVtxCount > 1000, "page 1 drawn (with pointer)");
    {   // software raster of the draw data -> menu.ppm (to look at)
        ImDrawData* dd = ImGui::GetDrawData(); int W = 1280, H = 860;
        std::vector<float> img(W * H * 3, 0.f); for (int i = 0; i < W * H; i++) { img[i*3] = 0.25f; img[i*3+1] = 0.3f; img[i*3+2] = 0.25f; }
        for (int l = 0; l < dd->CmdListsCount; l++) {
            const ImDrawList* cl = dd->CmdLists[l];
            for (auto& cmd : cl->CmdBuffer) {
                int cx0 = (int)cmd.ClipRect.x, cy0 = (int)cmd.ClipRect.y, cx1 = (int)cmd.ClipRect.z, cy1 = (int)cmd.ClipRect.w;
                for (unsigned e = 0; e + 2 < cmd.ElemCount; e += 3) {
                    const ImDrawVert* v[3]; for (int k = 0; k < 3; k++) v[k] = &cl->VtxBuffer[cmd.VtxOffset + cl->IdxBuffer[cmd.IdxOffset + e + k]];
                    float minx = std::min({v[0]->pos.x, v[1]->pos.x, v[2]->pos.x}), maxx = std::max({v[0]->pos.x, v[1]->pos.x, v[2]->pos.x});
                    float miny = std::min({v[0]->pos.y, v[1]->pos.y, v[2]->pos.y}), maxy = std::max({v[0]->pos.y, v[1]->pos.y, v[2]->pos.y});
                    int x0 = std::max((int)minx, std::max(cx0, 0)), x1 = std::min((int)maxx + 1, std::min(cx1, W)), y0 = std::max((int)miny, std::max(cy0, 0)), y1 = std::min((int)maxy + 1, std::min(cy1, H));
                    float d = (v[1]->pos.x - v[0]->pos.x) * (v[2]->pos.y - v[0]->pos.y) - (v[2]->pos.x - v[0]->pos.x) * (v[1]->pos.y - v[0]->pos.y);
                    if (fabsf(d) < 1e-6f) continue;
                    for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) {
                        float px_ = x + 0.5f, py_ = y + 0.5f;
                        float a = ((v[1]->pos.x - px_) * (v[2]->pos.y - py_) - (v[2]->pos.x - px_) * (v[1]->pos.y - py_)) / d;
                        float b = ((v[2]->pos.x - px_) * (v[0]->pos.y - py_) - (v[0]->pos.x - px_) * (v[2]->pos.y - py_)) / d;
                        float c = 1.f - a - b;
                        if (a < 0 || b < 0 || c < 0) continue;
                        float u = a * v[0]->uv.x + b * v[1]->uv.x + c * v[2]->uv.x, vv = a * v[0]->uv.y + b * v[1]->uv.y + c * v[2]->uv.y;
                        int tx = std::min(w - 1, std::max(0, (int)(u * w))), ty = std::min(h - 1, std::max(0, (int)(vv * h)));
                        float ta = px[(ty * w + tx) * 4 + 3] / 255.f;
                        float col[4]; for (int k = 0; k < 4; k++) { float s0 = ((v[0]->col >> (8*k)) & 255) / 255.f, s1 = ((v[1]->col >> (8*k)) & 255) / 255.f, s2 = ((v[2]->col >> (8*k)) & 255) / 255.f; col[k] = a * s0 + b * s1 + c * s2; }
                        float al = col[3] * ta; float* o = &img[(y * W + x) * 3];
                        for (int k = 0; k < 3; k++) o[k] = o[k] * (1 - al) + col[k] * al;
                    }
                }
            }
        }
        FILE* fo = fopen("menu.ppm", "wb"); fprintf(fo, "P6 %d %d 255\n", W, H);
        for (int i = 0; i < W * H * 3; i++) fputc((int)(std::min(1.f, img[i]) * 255), fo); fclose(fo);
    }
    o.Reset(o.All()[2]);
    Check(hk == "none | none", "reset clears a hotkey");
    o.SetValueText(o.All()[2], o.All()[2].defaultText);
    Check(hk == "END | none", "default restored");
    o.SetNumber(o.All()[1], 1.234f);
    Check(fv == 1.2f, "slider snaps to the step");
    printf(fails ? "%d FAILED\n" : "hotkey / menu test: all checks passed\n", fails);
    return fails;
}
