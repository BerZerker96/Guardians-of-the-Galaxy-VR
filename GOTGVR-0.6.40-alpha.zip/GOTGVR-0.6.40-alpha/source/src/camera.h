#pragma once
#include "xrbridge/ipc.h"

// STEREO = alternate-eye (AER, each eye drawn at its own game tick), SYNCED = synchronized sequential (UEVR-style:
// both eyes drawn from the SAME game tick - the game clock does not advance for the second eye)
// RECON = stereo reconstruction: one eye drawn per frame, the other rebuilt from that frame's picture + depth (recon.cpp)
enum VrMode { VRMODE_SCREEN = 0, VRMODE_HEAD = 1, VRMODE_STEREO = 2, VRMODE_SYNCED = 3, VRMODE_RECON = 4 };
inline bool IsStereoMode(int m) { return m == VRMODE_STEREO || m == VRMODE_SYNCED || m == VRMODE_RECON; }

// One rendered game frame as it leaves the camera hook: which eye it is, the pose and frustum it was drawn with.
struct RenderedEye {
    long seq = -1;
    int eye = 0;                 // 0 left, 1 right (stereo); head mode: 0
    bool mono = false;           // head mode: the same image goes to both eyes
    xrb::IpcPose pose = {};      // the pose the camera was given (OpenXR, recentred reference space)
    xrb::IpcFov fov = {};        // the frustum the projection was given (radians, image aspect + margin applied)
    long long time = 0;          // predicted display time of that pose (XrTime)
    long long tick = 0;          // when it was rendered (100 ns, interrupt time) - for the host's reprojection
    float angVel[3] = {};        // game camera rotation rate (rad/s, reference space) - camera_reprojection
    bool synced = false;         // synchronized sequential frame
    bool pairEnd = true;         // last image of a stereo pair (synced: the second eye; AER: every frame)
    // stereo reconstruction: everything needed to build the other eye from this frame
    bool recon = false;
    int physEye = 0;             // the eye whose pose was drawn (swap_eyes: the other one)
    int drawEye = 0;             // 0.6.33: the eye whose frustum the image is drawn with (UI placement), all methods
    bool drawMono = false;       //         the head-centre view (head mode / reconstruction's centre view)
    xrb::IpcPose poseO = {};     // the other eye's pose / frustum, from the SAME head pose
    xrb::IpcFov fovO = {};
    float nodeD[12] = {}, nodeO[12] = {};   // node matrices (right, up, back, position) of the drawn / other eye
    float tanD[4] = {}, tanO[4] = {};       // their frusta (l, r, u, d tangents)
    float proj[16] = {};         // the projection the renderer got for this frame (depth rows, jitter included)
    bool projOk = false;
    // recon_eye = centre (0.6.8): the head-centre view was drawn and BOTH eyes are rebuilt from it. The *O fields above
    // are the left eye, these the right eye.
    bool centre = false;
    xrb::IpcPose poseO1 = {}; xrb::IpcFov fovO1 = {}; float nodeO1[12] = {}; float tanO1[4] = {};
};

struct CamState {
    volatile int mode = VRMODE_SCREEN;
    float worldScale = 1.f, unitsPerMetre = 1.f, ipdScale = 1.f;
    // render frustum per eye (left, right, up, down tangents; eye image aspect + cull margin applied), and the
    // symmetric frustum that covers both eyes (head mode)
    float eyeTan[2][4] = {};
    float drawTan[2][4] = {};      // what the engine draws for each eye: symmetric about the view axis, covering eyeTan (see CameraUpdateFrustum)
    bool symmetricView = true;     // symmetric_view
    float monoTan[4] = {};
    unsigned nodeProjWrites = 0, nodeProjRebuilt = 0;   // 0.6.14: node+0xC0 patched / rebuilt by the game after the patch
    float eyeAspect = 0.f;         // 0 = the headset's own field of view (no padding to an image shape)
    float cullMargin = 1.f;
    bool wideCull = true;          // wide_cull: culling / LOD get a symmetric frustum covering the eye (0.6.17)
    unsigned wideCullCalls = 0;
    unsigned nearWrites = 0;
    unsigned cullVpCalls = 0, screenProjCalls = 0;
    // 0.6.37: game_aa / game_upscaling as numbers - the game thread read the option STRINGS while the panel (Present
    // thread) could be assigning them (a string reallocated under a reader can crash)
    volatile int gameAaWant = -1;          // -1 the game's own, 0 off, 1 on
    volatile bool upscaleNative = false;   // game_upscaling = off
    // 0.6.37: every call of the game's frustum-culling record (exe+8CA170) and why the culling help did not act on it
    unsigned cullAll = 0, cullOtherNode = 0, cullNotPosed = 0, cullGameCam = 0, cullNotPersp = 0, cullOk = 0;
    float camOffset[3] = {};       // camera_offset_*: third person only
    // first person (End): the eye base at the player's head (firstperson.cpp). Its offsets are its own.
    volatile bool firstPerson = false;
    float fpOffset[3] = { 0.f, 0.07f, 0.1f };   // fp_offset_x / _y / _z (metres: right, up, forward of the head bone)
    float fpSmooth = 0.6f;         // fp_smooth: head bob filter (0 off .. 1 strong)
    bool fpHideBody = true;        // fp_hide_body
    float fpMaxDist = 6.f;         // fp_max_distance: farther = not the gameplay camera (cutscene) - suspended
    volatile bool fpActive = false;   // first person was applied to the last VR frame
    float settle = 0.f;            // camera_settle: idle-sway lock (0 off .. 1 = 2.5 deg / 6 cm of slack)
    float stabilize = 0.f;         // camera_stabilize: game camera shake filter (0 off .. 1 strong)
    float nearClip = 0.f;          // near_clip (metres, 0 = the game's)
    float nodeNear = 0.f, nodeFar = 0.f;   // the main camera's near / far planes (node+0x1D0 / 0x1D4), for the log
    volatile bool decoupledPitch = true;
    int axisRow[3] = { 0, 1, 2 }; float axisSign[3] = { 1, 1, 1 };
    bool swapEyes = false, cameraReprojection = false;
    int frameDelay = 0;
    bool syncPairSubmit = true;    // sync_submit = pair: the headset gets both eyes of a tick together
    bool reconCentre = true;       // recon_eye = centre: the head-centre view is drawn, both eyes rebuilt
    bool reconAlternate = true;    // recon_eye = alternate (each eye drawn every second frame) | left (always the left eye)
    bool reconShared = true;       // recon_shared_frustum: the drawn eye covers both eyes' views (no strip the other eye lacks)
    float reconTan[2][4] = {};     // that shared frustum, per drawn eye (image aspect kept)
    // flat screen for game states without a usable 3D view: the game paused (pause / settings / map menus), a
    // full-size pre-rendered video, or held by the user (F6). Screens with no camera update at all (title, loading)
    // are always flat.
    bool flatMenus = true;         // flat_pause_menus
    bool flatVideos = true;        // flat_videos
    unsigned flatVideoMinW = 1280; // flat_video_min_width
    volatile bool flatHold = false;   // F6
    volatile bool flatNow = false;    // decided at each Present
    volatile int flatReason = 0;      // 0 none, 1 held, 2 paused menu, 3 video
    int syncLag = -1;              // sync_lag: -1 auto, 0 / 1 / 2 = render frames behind the game clock            // aer_frame_delay: Presents between a frame's view update and its Present (0 = same frame)
    xrb::IpcFov fov[2] = {};       // headset FOV (as reported)
    xrb::IpcPose pose[2] = {};     // latest headset eye poses
    bool havePose = false;
    volatile int headAim = 0;
    float headAimSmooth = 0.3f;     // head_aim_smoothing 0..1: head tremor filter on the aim (time constant up to 0.15 s)
    bool headAimFromEyes = true;    // head_aim_origin = eyes: the shot starts at the drawn eyes (first person: the head)   // head_aim: 0 off, 1 always, 2 while aiming (L2 / LT / right mouse)
    volatile unsigned uiEyeAhead = 0;   // 0.6.33: UI / 3D recorded while a later frame's camera was already set
    volatile int curEye = 0;       // eye of the frame being recorded right now (UI placement)
    volatile bool curMono = false;
    volatile long lastVrSeq = -1000;
    // stats
    unsigned heldTicks = 0, syncPairs = 0, syncLagNow = 0;
    unsigned nodeUpdates = 0, mainUpdates = 0, posesApplied = 0, projPatched = 0, resyncs = 0, badMatrix = 0, nodeSwitches = 0;
};
extern CamState g_cam;

bool CameraInstall();
void CameraOnPresent(unsigned bbW, unsigned bbH);    // Present thread: pick the main camera node, update the frustum
bool CameraTakeRendered(RenderedEye& out);           // Present thread: the frame being presented (FIFO, see camera.cpp)
// 0.6.33: the eye (frustum) of the image the NEXT Present shows - the frame whose UI / 3D is being recorded now.
// false: no VR frame waiting (use g_cam.curEye / curMono). Counts how often it differs from the last camera update.
bool CameraRecordingEye(int& eye, bool& mono);
bool CameraFrameIsVR();                              // a VR pose was applied to the frame(s) being shown
const float* CameraDrawTan(int eye);                 // the frustum eye `eye`'s rendered image uses (l, r, u, d tangents)
float CameraDrawGrowth();                             // rendered frustum width / the headset's own (>= 1)
void CameraDrawGrowthXY(float& gx, float& gy);
void CameraStableGrowthXY(float& gx, float& gy);
float CameraDrawAspect();   // width / height of the drawn view (tangents)   // the largest of all stereo methods: the render size (no resize on a method switch)        // the same per axis (width, height)
void CameraUpdateFrustum();
void CameraReport();
