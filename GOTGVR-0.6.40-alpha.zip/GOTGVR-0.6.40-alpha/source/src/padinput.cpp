// Controllers other than XInput, for the VR panel, its open / close combination and the hotkeys.
//   * PlayStation pads (DualSense, DualShock 4) used natively: the game reads them through Sony's libScePad
//     (libscepad.dll, scePadRead). scePadRead is hooked: its buttons / triggers / left stick feed the panel and the
//     hotkeys, and while the panel is open (or a hidden hotkey combination is held) the game gets a neutral pad.
//   * DirectInput game controllers (generic USB / Bluetooth pads, a PlayStation pad without libScePad): polled here,
//     in the background. Pads that are XInput devices (seen through XInput already) are skipped - their raw input
//     device path has "IG_" - and so are Sony pads while libScePad reports.
// Every source is turned into the XInput layout (A B X Y LB RB LT RT L3 R3 START BACK D-pad): a binding made with
// one controller works with another. PlayStation: Cross = A, Circle = B, Square = X, Triangle = Y, L1 = LB, R1 = RB,
// L2 = LT, R2 = RT, Options = START, touch pad = BACK. Generic DirectInput pads: buttons 1-10 as A B X Y LB RB
// BACK START L3 R3, buttons 7 / 8 of 12+ button pads as the triggers, the hat as the d-pad (names may not match the
// labels on such a pad, but a binding is made by pressing the buttons, so it always matches what it was made with).
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>
#include <dinput.h>
#include <vector>
#include <string>
#include <cstring>
#include "MinHook.h"
#include "log.h"
#include "vrkit_input.h"

namespace {
inline LONG NowMs() { ULONGLONG t = 0; QueryUnbiasedInterruptTime(&t); return (LONG)(t / 10000); }

// ---------------------------------------------------------------- libScePad
// ScePadData begins: uint32 buttons; uint8 lx, ly, rx, ry; uint8 l2, r2 (Sony SDK layout)
enum : unsigned {
    SCE_L3 = 0x2, SCE_R3 = 0x4, SCE_OPTIONS = 0x8, SCE_UP = 0x10, SCE_RIGHT = 0x20, SCE_DOWN = 0x40, SCE_LEFT = 0x80,
    SCE_L2 = 0x100, SCE_R2 = 0x200, SCE_L1 = 0x400, SCE_R1 = 0x800, SCE_TRIANGLE = 0x1000, SCE_CIRCLE = 0x2000,
    SCE_CROSS = 0x4000, SCE_SQUARE = 0x8000, SCE_TOUCH = 0x100000
};
struct SceMap { unsigned sce, xb; };
const SceMap kSce[] = {
    { SCE_CROSS, 0x1000 }, { SCE_CIRCLE, 0x2000 }, { SCE_SQUARE, 0x4000 }, { SCE_TRIANGLE, 0x8000 },
    { SCE_L1, 0x0100 }, { SCE_R1, 0x0200 }, { SCE_L3, 0x0040 }, { SCE_R3, 0x0080 }, { SCE_OPTIONS, 0x0010 }, { SCE_TOUCH, 0x0020 },
    { SCE_UP, 0x0001 }, { SCE_DOWN, 0x0002 }, { SCE_LEFT, 0x0004 }, { SCE_RIGHT, 0x0008 },
};
typedef int (*PFN_scePadRead)(int handle, void* data, int count);
PFN_scePadRead o_scePadRead = nullptr;
volatile LONG g_sceButtons = 0, g_sceLX = 0, g_sceLY = 0, g_sceAt = -100000;
volatile LONG g_sceReads = 0, g_sceBlocked = 0; bool g_sceMulti = false;

unsigned SceToBits(unsigned b, unsigned char l2, unsigned char r2) {
    unsigned x = 0;
    for (auto& m : kSce) if (b & m.sce) x |= m.xb;
    if (l2 > 150 || (b & SCE_L2)) x |= vrkit::input::PadLT;
    if (r2 > 150 || (b & SCE_R2)) x |= vrkit::input::PadRT;
    return x;
}
int H_scePadRead(int handle, void* data, int count) {
    int n = o_scePadRead(handle, data, count);
    if (n <= 0 || !data) return n;
    unsigned char* d = (unsigned char*)data;
    unsigned b = *(unsigned*)d;
    unsigned bits = SceToBits(b, d[8], d[9]);
    g_sceButtons = (LONG)bits; g_sceLX = ((int)d[4] - 128) * 256; g_sceLY = (128 - (int)d[5]) * 256; g_sceAt = NowMs();
    InterlockedIncrement(&g_sceReads);
    if (n > 1 && !g_sceMulti) { g_sceMulti = true; LOGI("pad: libScePad returns %d entries per read - the first is used", n); }
    if (vrkit::input::GameInputBlocked()) {   // panel open: a neutral pad (one entry, so no older entry acts)
        *(unsigned*)d = 0; d[4] = d[5] = d[6] = d[7] = 128; d[8] = d[9] = 0;
        InterlockedIncrement(&g_sceBlocked);
        return 1;
    }
    if (unsigned hide = vrkit::input::HiddenFromGame(bits)) {   // a held hotkey combination is not seen by the game
        unsigned nb = b;
        for (auto& m : kSce) if (hide & m.xb) nb &= ~m.sce;
        if (hide & vrkit::input::PadLT) { nb &= ~SCE_L2; d[8] = 0; }
        if (hide & vrkit::input::PadRT) { nb &= ~SCE_R2; d[9] = 0; }
        *(unsigned*)d = nb;
    }
    return n;
}

// ---------------------------------------------------------------- DirectInput controllers
IDirectInput8W* g_di = nullptr;
struct DiPad { IDirectInputDevice8W* dev; DWORD vidpid; bool sony; int buttons; std::wstring name; };
std::vector<DiPad> g_pads;
std::vector<DWORD> g_xinputIds;   // VID/PID of XInput devices ("IG_" in the raw input path)
volatile LONG g_diButtons = 0, g_diLX = 0, g_diLY = 0, g_diAt = -100000;
LONG g_nextScan = 0;

void FindXInputDevices() {
    g_xinputIds.clear();
    UINT n = 0;
    if (GetRawInputDeviceList(nullptr, &n, sizeof(RAWINPUTDEVICELIST)) != 0 || !n) return;
    std::vector<RAWINPUTDEVICELIST> list(n);
    if (GetRawInputDeviceList(list.data(), &n, sizeof(RAWINPUTDEVICELIST)) == (UINT)-1) return;
    for (UINT i = 0; i < n; i++) {
        if (list[i].dwType != RIM_TYPEHID) continue;
        wchar_t name[512]; UINT len = 512;
        if (GetRawInputDeviceInfoW(list[i].hDevice, RIDI_DEVICENAME, name, &len) == (UINT)-1) continue;
        if (!wcsstr(name, L"IG_") && !wcsstr(name, L"ig_")) continue;
        const wchar_t* v = wcsstr(name, L"VID_"); if (!v) v = wcsstr(name, L"vid_");
        const wchar_t* p = wcsstr(name, L"PID_"); if (!p) p = wcsstr(name, L"pid_");
        if (!v || !p) continue;
        DWORD vid = wcstoul(v + 4, nullptr, 16), pid = wcstoul(p + 4, nullptr, 16);
        g_xinputIds.push_back(MAKELONG(vid, pid));
    }
}
HWND OurWindow() {
    struct F { static BOOL CALLBACK cb(HWND h, LPARAM l) {
        DWORD pid = 0; GetWindowThreadProcessId(h, &pid);
        if (pid == GetCurrentProcessId() && IsWindowVisible(h) && !GetWindow(h, GW_OWNER)) { *(HWND*)l = h; return FALSE; }
        return TRUE; } };
    HWND h = nullptr; EnumWindows(F::cb, (LPARAM)&h); return h;
}
BOOL CALLBACK EnumPad(const DIDEVICEINSTANCEW* inst, void* ctx) {
    DWORD vidpid = inst->guidProduct.Data1;   // MAKELONG(VID, PID)
    for (DWORD x : g_xinputIds) if (x == vidpid) return DIENUM_CONTINUE;   // XInput reads it
    for (auto& p : g_pads) if (p.vidpid == vidpid && p.name == inst->tszInstanceName) return DIENUM_CONTINUE;
    IDirectInputDevice8W* dev = nullptr;
    if (FAILED(g_di->CreateDevice(inst->guidInstance, &dev, nullptr)) || !dev) return DIENUM_CONTINUE;
    HWND w = (HWND)ctx;
    if (FAILED(dev->SetDataFormat(&c_dfDIJoystick2)) || FAILED(dev->SetCooperativeLevel(w, DISCL_BACKGROUND | DISCL_NONEXCLUSIVE))) { dev->Release(); return DIENUM_CONTINUE; }
    DIPROPRANGE r = {}; r.diph.dwSize = sizeof(r); r.diph.dwHeaderSize = sizeof(DIPROPHEADER); r.diph.dwHow = DIPH_BYOFFSET;
    r.lMin = -32768; r.lMax = 32767;
    r.diph.dwObj = DIJOFS_X; dev->SetProperty(DIPROP_RANGE, &r.diph);
    r.diph.dwObj = DIJOFS_Y; dev->SetProperty(DIPROP_RANGE, &r.diph);
    DIDEVCAPS caps = {}; caps.dwSize = sizeof(caps); dev->GetCapabilities(&caps);
    dev->Acquire();
    DiPad p{ dev, vidpid, LOWORD(vidpid) == 0x054C, (int)caps.dwButtons, inst->tszInstanceName };
    char nm[260]; WideCharToMultiByte(CP_UTF8, 0, inst->tszInstanceName, -1, nm, sizeof nm, nullptr, nullptr);
    LOGI("pad: DirectInput controller '%s' (VID %04X PID %04X, %d buttons)%s", nm, LOWORD(vidpid), HIWORD(vidpid), p.buttons, p.sony ? " - PlayStation layout" : "");
    g_pads.push_back(p);
    return DIENUM_CONTINUE;
}
unsigned DiToBits(const DIJOYSTATE2& s, const DiPad& p) {
    auto B = [&](int i) { return i < 128 && (s.rgbButtons[i] & 0x80); };
    unsigned x = 0;
    if (p.sony) {   // DirectInput order of DualShock 4 / DualSense: Square Cross Circle Triangle L1 R1 L2 R2 Share Options L3 R3 PS Touch
        if (B(1)) x |= 0x1000; if (B(2)) x |= 0x2000; if (B(0)) x |= 0x4000; if (B(3)) x |= 0x8000;
        if (B(4)) x |= 0x0100; if (B(5)) x |= 0x0200; if (B(6)) x |= vrkit::input::PadLT; if (B(7)) x |= vrkit::input::PadRT;
        if (B(8) || B(13)) x |= 0x0020; if (B(9)) x |= 0x0010; if (B(10)) x |= 0x0040; if (B(11)) x |= 0x0080;
    } else {        // common DirectInput order: A B X Y LB RB BACK START L3 R3 (12+ buttons: 7 / 8 = LT / RT, then BACK START L3 R3)
        if (B(0)) x |= 0x1000; if (B(1)) x |= 0x2000; if (B(2)) x |= 0x4000; if (B(3)) x |= 0x8000;
        if (B(4)) x |= 0x0100; if (B(5)) x |= 0x0200;
        if (p.buttons >= 12) { if (B(6)) x |= vrkit::input::PadLT; if (B(7)) x |= vrkit::input::PadRT; if (B(8)) x |= 0x0020; if (B(9)) x |= 0x0010; if (B(10)) x |= 0x0040; if (B(11)) x |= 0x0080; }
        else { if (B(6)) x |= 0x0020; if (B(7)) x |= 0x0010; if (B(8)) x |= 0x0040; if (B(9)) x |= 0x0080; }
    }
    DWORD pov = s.rgdwPOV[0];
    if (LOWORD(pov) != 0xFFFF) {
        unsigned a = pov / 100;   // degrees, 0 = up, clockwise
        if (a >= 315 || a <= 45) x |= 0x0001; if (a >= 45 && a <= 135) x |= 0x0008;
        if (a >= 135 && a <= 225) x |= 0x0002; if (a >= 225 && a <= 315) x |= 0x0004;
    }
    return x;
}
void PollDi() {
    LONG now = NowMs();
    if (now - g_nextScan >= 0) {   // new / removed controllers: every 3 s
        g_nextScan = now + 3000;
        if (!g_di) {
            wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH);
            HMODULE m = LoadLibraryW((std::wstring(sys) + L"\\dinput8.dll").c_str());
            typedef HRESULT(WINAPI * PFN)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
            PFN create = m ? (PFN)GetProcAddress(m, "DirectInput8Create") : nullptr;
            if (!create || FAILED(create(GetModuleHandleW(nullptr), DIRECTINPUT_VERSION, IID_IDirectInput8W, (void**)&g_di, nullptr))) { g_di = nullptr; g_nextScan = now + 60000; return; }
        }
        HWND w = OurWindow();
        if (w) { FindXInputDevices(); g_di->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumPad, (void*)w, DIEDFL_ATTACHEDONLY); }
    }
    unsigned bits = 0; int lx = 0, ly = 0; bool any = false;
    bool sceLive = now - g_sceAt < 500;
    for (size_t i = 0; i < g_pads.size();) {
        DiPad& p = g_pads[i];
        DIJOYSTATE2 s = {};
        p.dev->Poll();
        HRESULT hr = p.dev->GetDeviceState(sizeof(s), &s);
        if (hr == (HRESULT)DIERR_INPUTLOST || hr == (HRESULT)DIERR_NOTACQUIRED) { p.dev->Acquire(); hr = p.dev->GetDeviceState(sizeof(s), &s); }
        if (hr == (HRESULT)DIERR_UNPLUGGED) {   // gone (other failures: try again next time)
            LOGI("pad: DirectInput controller removed"); p.dev->Unacquire(); p.dev->Release(); g_pads.erase(g_pads.begin() + i); continue;
        }
        i++;
        if (FAILED(hr) || (p.sony && sceLive)) continue;   // libScePad already reports this pad
        any = true;
        bits |= DiToBits(s, p);
        if (abs(s.lX) > abs(lx)) lx = s.lX;
        if (abs(s.lY) > abs(ly)) ly = -s.lY;
    }
    g_diButtons = (LONG)bits; g_diLX = lx; g_diLY = ly;
    if (any) g_diAt = now;
}

// vrkit: the other controllers' state (XInput layout)
bool ExtraPads(unsigned* buttons, int* lx, int* ly) {
    LONG now = NowMs();
    bool sce = now - g_sceAt < 500, di = now - g_diAt < 500;
    if (!sce && !di) return false;
    unsigned b = 0; int x = 0, y = 0;
    if (sce) { b |= (unsigned)g_sceButtons; x = g_sceLX; y = g_sceLY; }
    if (di) { b |= (unsigned)g_diButtons; if (abs(g_diLX) > abs(x)) x = g_diLX; if (abs(g_diLY) > abs(y)) y = g_diLY; }
    *buttons = b; *lx = x; *ly = y;
    return true;
}
// 0.6.37: libscepad.dll is loaded by the game when it sets up its input - often after the mod's start. Hooked as soon
// as it is there (0.6.36 and older checked once at start: a later load left PlayStation pads out of the panel / hotkeys)
volatile LONG g_sceHooked = 0;
bool TryHookScePad(bool logMissing) {
    if (g_sceHooked) return true;
    HMODULE m = GetModuleHandleW(L"libscepad.dll");
    void* f = m ? (void*)GetProcAddress(m, "scePadRead") : nullptr;
    if (f && MH_CreateHook(f, (void*)H_scePadRead, (void**)&o_scePadRead) == MH_OK && MH_EnableHook(f) == MH_OK) {
        g_sceHooked = 1; LOGI("pad: libScePad hooked - PlayStation controllers work in the VR panel and for hotkeys"); return true;
    }
    if (logMissing) LOGI("pad: libScePad not loaded yet - checked again in the background (PlayStation pads through Steam Input / DirectInput meanwhile)");
    return false;
}
DWORD WINAPI DiThread(LPVOID) {
    Sleep(3000);
    LONG nextSce = 0;
    for (;;) {
        PollDi();
        LONG now = NowMs();
        if (!g_sceHooked && now - nextSce >= 0) { nextSce = now + 2000; TryHookScePad(false); }
        Sleep(8);
    }
}
} // namespace

void PadInputInstall() {
    vrkit::input::SetExtraPads(ExtraPads);
    TryHookScePad(true);
    CreateThread(nullptr, 0, DiThread, nullptr, 0, nullptr);
}
void PadInputReport() {
    LONG r = InterlockedExchange(&g_sceReads, 0), b = InterlockedExchange(&g_sceBlocked, 0);
    if (r) LOGI("pad: libScePad reads %ld (neutral for the game while the panel was open: %ld), DirectInput controllers %zu", r, b, g_pads.size());
}

// camera.cpp (head aim "while aiming"): L2 / LT held on any controller
bool PadsLTHeld() { return (vrkit::input::ReadPadsAll() & vrkit::input::PadLT) != 0; }
