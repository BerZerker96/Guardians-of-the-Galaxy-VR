#include "modtime.h"
// First person: the VR camera attached to the player character's head.
//
// GOTG is a third-person game; the only first-person camera it has (ZCameraBehavior_FirstPerson, used in a few scripted
// moments) does exactly two things on activation (exe+154EF80 / exe+15540B0 -> exe+1569400): it takes the character
// it follows, asks it for its animated entity (ZCharacter vtable slot 80, exe+17425C0: the ref at ZCharacter+0x2308)
// and hides it (ZAnimatedEntity slot 76, exe+593760: SetVisible, m_bVisible at +0x2C) - the body would be in the way.
// The mod does the same, with the player's character and the head bone:
//
//   player character  exe+1784E90 (ZPlayerManager, instance exe+3E41B58): the local player's character entity
//                     (an entity ref; its type lists the interfaces as {type info, offset} at type+0x18)
//   ZCharacter        the interface whose type info is ZCharacter's (read from ZCharacter's own QueryInterface,
//                     vtable slot 4 exe+1756650: lea rax, [interfaces]; lea r8, [type info])
//   animated entity   ZCharacter slot 80 (out = { ref, ZAnimatedEntity* })
//   head bone         exe+81E740 ZAnimatedEntity::GetBoneWorldTransformQV(this, out QV, bone id): the native behind
//                     the script function of that name. Bone id = CRC-32 of the lower-case bone name (exe+1093B0,
//                     table exe+243D800; the skeleton's joint names "jntbd_head", "jntbd_neck" ... are at exe+2445998).
//                     Unknown bone: the entity's own world transform (the character root) - used as the root.
//                     out = quaternion (16 bytes), position (x, y, z, 0), world, metres, Z up.
//
// All of it runs on the game thread (the game clock hook, once per frame, before the frame's simulation), where the
// game itself calls these functions - nothing is read while the game changes it. The render thread only reads the
// result (head position, root position) under a lock.
//
// The eye: head position + offsets (fp_offset_*: right / up / forward along the camera heading), orientation = the game
// camera's heading (decoupled pitch as set) + your head. The head bob of the walk / run animation is filtered relative
// to the root (fp_smooth), so walking speed is never delayed. When the game camera does not follow the player (a
// cutscene, a scripted camera: the head is more than fp_max_distance away or not in front of the camera) first person is
// suspended and the game's camera is used - and the body shown again.
#include <windows.h>
#include <cstring>
#include <cstdio>
#include <cstdarg>
#include <cstdint>
#include "log.h"
#include "game.h"
#include "camera.h"
#include "fpmath.h"
#include "firstperson.h"
#include "settings.h"

namespace fp {

typedef void*(__fastcall* PFN_GetLocalChar)(void* mgr, void* out2);
typedef void*(__fastcall* PFN_BoneQV)(void* anim, float* outQV, uint32_t boneId);
typedef void*(__fastcall* PFN_GetAnim)(void* zchar, void* out2);
typedef void(__fastcall* PFN_SetVisible)(void* anim, uintptr_t visible);
typedef void*(__fastcall* PFN_GetLocalPlayer)(void* out2);

static PFN_GetLocalChar g_getLocalChar = nullptr;
// 0.6.15: exe+17850D0 - calls GetLocalCharacter (exe+1784E90; on this build that gives the player CONTROLLER entity),
// finds the controller interface (type exe+3DF4D08), asks it (vtable +0x3A8, then the result's slot 1) for what it
// controls and returns that as an entity reference - the hero character, the same {ref, object} form
static PFN_GetLocalChar g_getLocalHero = nullptr;
static PFN_BoneQV g_boneQV = nullptr;
static PFN_GetLocalPlayer g_getLocalPlayer = nullptr;   // exe+1785560: the controllers' list (fallback)
static void* g_playerMgr = nullptr;
static uintptr_t g_playerMgrVt = 0;
static uintptr_t g_zcharTI = 0;
static bool g_installed = false;

static const uint32_t kHead = 0x2A4C5889u;   // crc32("jntbd_head")
static const uint32_t kNeck = 0xADAE7846u;   // crc32("jntbd_neck")
static const uint32_t kNone = 0x0BADB0E5u;   // no such bone: the character root
// SetVisible's start (exe+593760: mov [rsp+10h], dl; push rbx; sub rsp, 40h; mov rbx, rcx; cmp [rcx+2Ch], dl)
static const unsigned char kSetVisible[] = { 0x88, 0x54, 0x24, 0x10, 0x53, 0x48, 0x83, 0xEC, 0x40, 0x48, 0x8B, 0xD9, 0x38, 0x51, 0x2C };
// ZCharacter slot 80 start (exe+17425C0: push rbx; sub rsp, 20h; mov rax, [rcx + 2308h])
static const unsigned char kGetAnim[] = { 0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8B, 0x81 };

// shared with the render thread
static SRWLOCK g_lock = SRWLOCK_INIT;
static V3 g_head = {}, g_headRaw = {}; static long long g_headT = 0; static bool g_headOk = false;
static volatile long long g_appliedT = 0;   // render thread: first person was used for a frame at this time
static volatile int g_state = 0;            // 0 off, 1 on, 2 player not found, 3 suspended (camera not following), 4 unavailable
static unsigned g_found = 0, g_lost = 0, g_noHead = 0, g_frames = 0, g_suspended = 0, g_held = 0, g_rootEye = 0;
static fpm::BobFilter g_bob; static long long g_bobT = 0;
static void* g_hidden = nullptr;            // the animated entity the mod hid (to show it again)
static void* g_lastAnim = nullptr;

static bool Ptr(const void* p, size_t n) { return p && (uintptr_t)p > 0x10000 && game::Readable(p, n); }

void Install() {
    g_installed = false;
    uintptr_t f = game::Scan("GetLocalCharacter", "48 89 5C 24 10 48 89 6C 24 18 56 57 41 56 48 83 EC 50 33 FF 4C 8D 71 18 48 8D 44 24 20 48 89 7C 24 20 48 8B F2 8B CF 49 3B C6");
    uintptr_t q = game::Scan("BoneWorldTransformQV", "48 89 5C 24 10 57 48 83 EC 60 48 83 B9 48 03 00 00 00 48 8B FA 48 8B D9 0F 84 ?? ?? ?? ?? 41 8B D0 48 8D 0D");
    g_getLocalPlayer = (PFN_GetLocalPlayer)game::Scan("GetLocalPlayer", "40 55 57 41 57 48 83 EC 30 48 8B 2D ?? ?? ?? ?? 33 FF 48 89 39 4C 8B F9 48 89 79 08 48 85 ED 0F 84 ?? ?? ?? ?? 48 89 5C 24 50 8B 9D 80 00 00 00");
    uintptr_t s = game::Scan("PlayerManagerInit", "4C 8D 35 ?? ?? ?? ?? 49 8B CE E8 ?? ?? ?? ?? 48 8B 4B 40 4C 89 74 24 78");
    g_playerMgrVt = game::VtableByRtti(".?AVZPlayerManager@@");
    uintptr_t cvt = game::VtableByRtti(".?AVZCharacter@@");
    if (cvt && Ptr((void*)cvt, 8 * 81)) {   // slot 4 = QueryInterface: lea rax, [rip + interfaces]; lea r8, [rip + type info]
        const unsigned char* qi = (const unsigned char*)((uintptr_t*)cvt)[4];
        if (game::InCode((uintptr_t)qi) && Ptr(qi, 14) && qi[0] == 0x48 && qi[1] == 0x8D && qi[2] == 0x05 && qi[7] == 0x4C && qi[8] == 0x8D && qi[9] == 0x05)
            g_zcharTI = (uintptr_t)qi + 14 + *(const int32_t*)(qi + 10);
        const unsigned char* ga = (const unsigned char*)((uintptr_t*)cvt)[80];
        if (!(game::InCode((uintptr_t)ga) && Ptr(ga, sizeof kGetAnim) && !memcmp(ga, kGetAnim, sizeof kGetAnim))) {
            LOGW("firstperson: ZCharacter slot 80 is not GetAnimatedEntity on this build"); g_zcharTI = 0;
        }
    }
    if (s) { g_playerMgr = (void*)(s + 7 + *(const int32_t*)(s + 3)); }
    g_getLocalChar = (PFN_GetLocalChar)f; g_boneQV = (PFN_BoneQV)q;
    if (f) {
        uintptr_t h = game::Scan("GetLocalHero", "48 89 5C 24 08 57 48 83 EC 50 48 8B DA 48 8D 54 24 40 E8 ?? ?? ?? ?? 48 8B 7C 24 40 48 85 FF 0F 84");
        if (h && h + 23 + *(const int32_t*)(h + 19) == f) g_getLocalHero = (PFN_GetLocalChar)h;   // its call must be GetLocalCharacter
        else if (h) LOGW("firstperson: GetLocalHero does not call GetLocalCharacter on this build - not used");
    }
    g_installed = f && q && s && g_playerMgrVt && g_zcharTI;
    if (g_installed)
        LOGI("firstperson: available (player manager exe+%llx, ZCharacter type info exe+%llx, head bone 0x%08X)",
             (unsigned long long)((uintptr_t)g_playerMgr - game::g_base), (unsigned long long)(g_zcharTI - game::g_base), kHead);
    else {
        LOGW("firstperson: NOT available on this build (local character %d, bone transform %d, player manager %d/%d, ZCharacter %d)",
             f != 0, q != 0, s != 0, g_playerMgrVt != 0, g_zcharTI != 0);
        g_state = 4;
    }
}
bool Available() { return g_installed; }

// where the search for the player stopped (logged when it changes: the log tells which step a game version breaks)
static int g_failStep = -1; static char g_failInfo[160] = "";
static void* Fail(int step, const char* fmt, ...) {
    char b[160]; va_list a; va_start(a, fmt); vsnprintf(b, sizeof b, fmt, a); va_end(a);
    if (step != g_failStep || strcmp(b, g_failInfo)) { g_failStep = step; strcpy(g_failInfo, b); LOGI("firstperson: player search stops at step %d: %s", step, b); }
    return nullptr;
}
static bool InImage(uintptr_t a) { return a > game::g_base && a < game::g_base + 0x20000000; }

// the ZCharacter interface of a character entity: by ZCharacter's type info, or (other builds / a derived character
// type) the interface whose vtable has ZCharacter's GetAnimatedEntity in slot 80
// MSVC RTTI: the object's class or one of its base classes has this decorated name (".?AVZCharacter@@")
static const char* RttiName(const void* obj, int baseIdx);   // baseIdx -1 = the class itself
static bool RttiIsA(const void* obj, const char* name) {
    for (int b = -1; b < 64; b++) { const char* n = RttiName(obj, b); if (!n) return false; if (!strcmp(n, name)) return true; }
    return false;
}
static const char* RttiName(const void* obj, int baseIdx) {
    if (!Ptr(obj, 8)) return nullptr;
    uintptr_t vt = *(const uintptr_t*)obj;
    if (!InImage(vt) || !Ptr((void*)(vt - 8), 8)) return nullptr;
    const uint32_t* col = *(const uint32_t* const*)(vt - 8);   // complete object locator: sig, off, cd, type, hierarchy, self
    if (!InImage((uintptr_t)col) || !Ptr(col, 24) || col[0] != 1) return nullptr;
    uintptr_t base = game::g_base;
    uintptr_t td = 0;
    if (baseIdx < 0) td = base + col[3];
    else {
        const uint32_t* chd = (const uint32_t*)(base + col[4]);   // sig, attributes, numBaseClasses, base class array
        if (!Ptr(chd, 16) || baseIdx >= (int)chd[2]) return nullptr;
        const uint32_t* arr = (const uint32_t*)(base + chd[3]);
        if (!Ptr(arr + baseIdx, 4)) return nullptr;
        const uint32_t* bcd = (const uint32_t*)(base + arr[baseIdx]);   // base class descriptor: type descriptor first
        if (!Ptr(bcd, 4)) return nullptr;
        td = base + bcd[0];
    }
    const char* n = (const char*)(td + 0x10);
    return Ptr(n, 4) ? n : nullptr;
}
static bool g_animDirect = false;   // CharacterOf returned the animated entity itself (no ZCharacter interface)
static char* CharacterOf(char* ent, int& tried) {
    g_animDirect = false;
    tried = 0;
    if (!Ptr(ent, 8)) return nullptr;
    char* type = *(char**)ent;
    if (!Ptr(type + 0x18, 8)) return nullptr;
    char* list = *(char**)(type + 0x18);
    if (!Ptr(list, 12)) return nullptr;
    char* arr = *(char**)list; uint32_t n = *(uint32_t*)(list + 8);
    if (n == 0 || n > 4096 || !Ptr(arr, (size_t)n * 16)) return nullptr;
    tried = (int)n;
    for (uint32_t i = 0; i < n; i++) if (*(uintptr_t*)(arr + 16 * i) == g_zcharTI) return ent + *(intptr_t*)(arr + 16 * i + 8);
    for (uint32_t i = 0; i < n; i++) {
        char* o = ent + *(intptr_t*)(arr + 16 * i + 8);
        if (!Ptr(o, 8)) continue;
        uintptr_t* vt = *(uintptr_t**)o;
        if (!InImage((uintptr_t)vt) || !Ptr(vt, 8 * 81)) continue;
        const void* f = (const void*)vt[80];
        if (game::InCode((uintptr_t)f) && Ptr(f, sizeof kGetAnim) && !memcmp(f, kGetAnim, sizeof kGetAnim)) return o;
    }
    // 0.6.6: by RTTI - a class derived from ZCharacter (the player's own type), or the animated entity itself
    for (uint32_t i = 0; i < n; i++) {
        char* o = ent + *(intptr_t*)(arr + 16 * i + 8);
        if (RttiIsA(o, ".?AVZCharacter@@")) return o;
    }
    for (uint32_t i = 0; i < n; i++) {
        char* o = ent + *(intptr_t*)(arr + 16 * i + 8);
        if (RttiIsA(o, ".?AVZAnimatedEntity@@")) { g_animDirect = true; return o; }
    }
    static void* s_logged = nullptr;   // what the player entity is made of (once per entity)
    if (s_logged != ent) {
        s_logged = ent;
        char line[1200]; int k = snprintf(line, sizeof line, "firstperson: player entity %p interfaces:", (void*)ent);
        for (uint32_t i = 0; i < n && k < (int)sizeof line - 80; i++) {
            const char* nm = RttiName(ent + *(intptr_t*)(arr + 16 * i + 8), -1);
            k += snprintf(line + k, sizeof line - k, " %s", nm ? nm : "?");
        }
        LOGI("%s", line);
    }
    return nullptr;
}

// the entity a player controller controls (as exe+1785024 does: controller+0x20 interface, slot 0xB0), or null
static char* ControlledBy(char* ctl) {
    if (!Ptr(ctl + 0x20, 8)) return nullptr;
    char* iface = ctl + 0x20; uintptr_t* ivt = *(uintptr_t**)iface;
    if (!Ptr(ivt, 0xB8) || !game::InCode(ivt[0xB0 / 8])) return nullptr;
    typedef void**(__fastcall * PFN_Ctl)(void*);
    void** rr = ((PFN_Ctl)ivt[0xB0 / 8])(iface);
    return Ptr(rr, 8) ? (char*)*rr : nullptr;
}
// the complete object of an interface (MSVC RTTI: the complete object locator's offset)
static char* CompleteObject(char* o) {
    if (!Ptr(o, 8)) return nullptr;
    uintptr_t vt = *(uintptr_t*)o;
    if (!InImage(vt) || !Ptr((void*)(vt - 8), 8)) return nullptr;
    const uint32_t* col = *(const uint32_t* const*)(vt - 8);
    if (!InImage((uintptr_t)col) || !Ptr(col, 24) || col[0] != 1) return nullptr;
    return o - col[1];
}

// the player's ZAnimatedEntity, or null
static void* PlayerAnim() {
    if (!Ptr(g_playerMgr, 0x40)) return Fail(1, "player manager exe+%llx not readable", (unsigned long long)((uintptr_t)g_playerMgr - game::g_base));
    uintptr_t vt = *(uintptr_t*)g_playerMgr;
    if (vt != g_playerMgrVt && !InImage(vt)) return Fail(2, "player manager not set up yet (vtable %p)", (void*)vt);
    char* ent = nullptr;
    alignas(16) void* ref[2] = {};
    g_getLocalChar(g_playerMgr, ref);
    ent = (char*)ref[0];
    if (!ent && g_getLocalPlayer) {   // the local player controller (exe+1785560) -> its controlled character (as exe+1785024 does)
        alignas(16) void* r2[2] = {}; g_getLocalPlayer(r2);
        char* ctl = (char*)r2[1];
        if (r2[0] && Ptr(ctl + 0x20, 8)) {
            char* iface = ctl + 0x20; uintptr_t* ivt = *(uintptr_t**)iface;
            if (Ptr(ivt, 0xB8) && game::InCode(ivt[0xB0 / 8])) {
                typedef void**(__fastcall * PFN_Ctl)(void*);
                void** rr = ((PFN_Ctl)ivt[0xB0 / 8])(iface);
                if (Ptr(rr, 8)) ent = (char*)*rr;
            }
        }
    }
    if (!Ptr(ent, 8)) return Fail(3, "no local player entity (manager +0x18 = %p)", *(void**)((char*)g_playerMgr + 0x18));
    int tried = 0;
    char* zc = CharacterOf(ent, tried);
    if (!Ptr(zc, 8) && g_getLocalHero) {   // 0.6.15: the hero the local controller drives, as the game itself gets it
        alignas(16) void* hr[2] = {};
        g_getLocalHero(g_playerMgr, hr);
        char* he = (char*)hr[0];
        if (Ptr(he, 8) && he != ent) {
            int t2 = 0; char* z2 = CharacterOf(he, t2);
            static void* s_said = nullptr;
            if (Ptr(z2, 8)) { zc = z2; ent = he; if (s_said != he) { s_said = he; LOGI("firstperson: the hero character entity %p (from the local controller, exe+17850D0)", (void*)he); } }
        }
    }
    if (!Ptr(zc, 8)) {
        // 0.6.12 log: the local "character" is the player CONTROLLER entity on this build (its 10 interfaces are all
        // ZPlayerController) - the character is the entity it controls
        char* ctl = nullptr;
        if (RttiIsA(ref[1], ".?AVZPlayerController@@")) ctl = (char*)ref[1];
        if (!ctl && Ptr(ent, 8)) {
            char* type = *(char**)ent; char* list = Ptr(type + 0x18, 8) ? *(char**)(type + 0x18) : nullptr;
            if (Ptr(list, 12)) {
                char* arr = *(char**)list; uint32_t n = *(uint32_t*)(list + 8);
                for (uint32_t i = 0; i < n && i < 64 && !ctl && Ptr(arr + 16 * i, 16); i++) {
                    char* o = CompleteObject(ent + *(intptr_t*)(arr + 16 * i + 8));
                    if (o && RttiIsA(o, ".?AVZPlayerController@@")) ctl = o;
                }
            }
        }
        char* ent2 = ctl ? ControlledBy(ctl) : nullptr;
        static void* s_said = nullptr;
        if (ent2 && ent2 != s_said) { s_said = ent2; LOGI("firstperson: the local player entity is the controller %p - its character entity %p", (void*)ctl, (void*)ent2); }
        if (Ptr(ent2, 8) && ent2 != ent) {
            int t2 = 0; zc = CharacterOf(ent2, t2);
            if (Ptr(zc, 8)) ent = ent2;
            else {
                // 0.6.14 log: the controlled entity was found (00000000345fbac8) but not as an entity reference: try it
                // as the object itself, as a pointer to one, and the pointers in its first 0x40 bytes
                char* cand[10] = { ent2, CompleteObject(ent2), nullptr };
                int nc = 2;
                if (Ptr(ent2, 0x40)) for (int k = 0; k < 8 && nc < 10; k++) cand[nc++] = *(char**)(ent2 + 8 * k);
                for (int k = 0; k < nc && !Ptr(zc, 8); k++) {
                    char* o = cand[k]; if (!Ptr(o, 8)) continue;
                    if (RttiIsA(o, ".?AVZCharacter@@")) { zc = o; break; }
                    if (RttiIsA(o, ".?AVZAnimatedEntity@@")) { zc = o; g_animDirect = true; break; }
                    int t3 = 0; char* z3 = CharacterOf(o, t3); if (Ptr(z3, 8)) { zc = z3; ent = o; break; }
                }
                static void* s_dumped = nullptr;
                if (!Ptr(zc, 8) && s_dumped != ent2 && Ptr(ent2, 0x40)) {
                    s_dumped = ent2;
                    char line[900]; int n = snprintf(line, sizeof line, "firstperson: controlled entity %p - class %s; its first pointers:", (void*)ent2, RttiName(ent2, -1) ? RttiName(ent2, -1) : "?");
                    for (int k = 0; k < 8 && n < (int)sizeof line - 90; k++) {
                        char* o = *(char**)(ent2 + 8 * k); const char* nm = Ptr(o, 8) ? RttiName(o, -1) : nullptr;
                        n += snprintf(line + n, sizeof line - n, " [%d] %p %s", k * 8, (void*)o, nm ? nm : "-");
                    }
                    LOGI("%s", line);
                }
                if (!Ptr(zc, 8)) tried += t2;
                else { static void* s_logged = nullptr;   // 0.6.17: once per character (was every lookup: 5000 lines a session)
                       if (s_logged != zc) { s_logged = zc; LOGI("firstperson: character found through the controller (%p)", (void*)zc); } }
            }
        }
    }
    if (!Ptr(zc, 8)) return Fail(4, "player entity %p: no ZCharacter among its %d interfaces", ent, tried);
    char* anim = nullptr;
    alignas(16) void* a[2] = {};
    if (g_animDirect) anim = zc;   // the animated entity is an interface of the player itself
    else {
        uintptr_t* zvt = *(uintptr_t**)zc;
        if (!Ptr(zvt, 8 * 81) || !game::InCode(zvt[80])) return Fail(5, "ZCharacter %p: slot 80 not code", zc);
        ((PFN_GetAnim)zvt[80])(zc, a);
        anim = (char*)a[1];
    }
    if (!Ptr(anim, 0x350)) return Fail(6, "ZCharacter %p: no animated entity (%p %p)", zc, a[0], a[1]);
    uintptr_t* avt = *(uintptr_t**)anim;
    if (!Ptr(avt, 8 * 77) || !game::InCode(avt[76])) return Fail(7, "animated entity %p: vtable %p not the expected", anim, (void*)avt);
    if (!Ptr(*(void**)(anim + 0x348), 0xA0) || !Ptr(*(void**)(anim + 0x340), 16))
        return Fail(8, "animated entity %p: no skeleton / pose yet (%p %p)", anim, *(void**)(anim + 0x348), *(void**)(anim + 0x340));
    if (g_failStep != 0) { g_failStep = 0; g_failInfo[0] = 0; }
    return anim;
}

static bool Bone(void* anim, uint32_t id, V3& p) {
    alignas(16) float qv[8] = {};
    g_boneQV(anim, qv, id);
    p = { qv[4], qv[5], qv[6] };
    float s = fabsf(p.x) + fabsf(p.y) + fabsf(p.z);
    return s == s && s < 1e7f;
}

static void SetBodyVisible(void* anim, bool v) {
    uintptr_t fn = (*(uintptr_t**)anim)[76];
    if (!Ptr((void*)fn, sizeof kSetVisible) || memcmp((void*)fn, kSetVisible, sizeof kSetVisible)) {
        static bool warned = false; if (!warned) { warned = true; LOGW("firstperson: this character's SetVisible is not the known one - body stays visible"); }
        return;
    }
    ((PFN_SetVisible)fn)(anim, v ? 1 : 0);
}

void GameTick() {
    if (!g_installed) return;
    long long now = (long long)modtime::Now100ns();
    bool on = g_cam.firstPerson;
    bool applied = on && now - g_appliedT < 3000000;   // used for a VR frame in the last 0.3 s
    if (!on && !g_hidden) { g_headOk = false; g_bob.have = false; return; }
    void* anim = PlayerAnim();
    if (anim != g_lastAnim) {
        if (anim) { g_found++; LOGI("firstperson: player character found (animated entity %p)", anim); }
        else { g_lost++; LOGI("firstperson: player character gone"); }
        if (g_hidden && g_hidden != anim) g_hidden = nullptr;   // a new level / character: the old one is gone
        g_lastAnim = anim; g_bob.have = false;
    }
    // the body: hidden while first person is in use (as the game's own first-person camera does)
    bool hide = anim && applied && g_cam.fpHideBody;
    if (anim && hide && !g_hidden && *((volatile unsigned char*)anim + 0x2C)) { SetBodyVisible(anim, false); if (!*((volatile unsigned char*)anim + 0x2C)) g_hidden = anim; }
    if (g_hidden && !hide) { if (g_hidden == anim && !*((volatile unsigned char*)anim + 0x2C)) SetBodyVisible(anim, true); g_hidden = nullptr; }
    if (!on) { g_headOk = false; return; }
    if (!anim) { AcquireSRWLockExclusive(&g_lock); g_headOk = false; ReleaseSRWLockExclusive(&g_lock); g_state = 2; return; }
    V3 head, root;
    bool okH = Bone(anim, kHead, head), okR = Bone(anim, kNone, root);
    if (okH && okR && Len(head - root) < 0.2f * g_cam.unitsPerMetre) {   // no head bone: the root came back
        V3 neck; okH = Bone(anim, kNeck, neck) && Len(neck - root) > 0.2f * g_cam.unitsPerMetre;
        if (okH) head = neck + V3{ 0, 0, 0.1f * g_cam.unitsPerMetre };
        else g_noHead++;
    }
    // 0.6.35: no head / neck bone this frame (the tester's 0.6.25 log, 1505-1528 s: every bone read gave the root, 723
    // frames in 10 s - first person dropped to "player not found" and the toggle could not bring it back): the eye at
    // standing eye height above the character's root instead, until the bones come back
    if (!okH && okR) {
        head = root + V3{ 0, 0, 1.62f * g_cam.unitsPerMetre }; okH = true; g_rootEye++;
        static long long s_said = 0;
        if (now - s_said > 100000000ll) { s_said = now; LOGI("firstperson: the head bone is not readable now - the eye at standing height above the character (until it is back)"); }
    }
    float dt = g_bobT ? (float)(now - g_bobT) * 1e-7f : 0.f; g_bobT = now;
    V3 f = okH ? (okR ? g_bob.Step(root, head, dt, g_cam.fpSmooth) : head) : head;
    AcquireSRWLockExclusive(&g_lock);
    g_headOk = okH; g_head = f; g_headRaw = head; g_headT = now;
    ReleaseSRWLockExclusive(&g_lock);
}

bool EyeBase(const Frame& cam, const Frame& game, Frame& out) {
    if (!g_cam.firstPerson) { g_state = g_installed ? 0 : 4; return false; }
    if (!g_installed) { g_state = 4; return false; }
    V3 h, raw; bool ok; long long t;
    AcquireSRWLockShared(&g_lock); h = g_head; raw = g_headRaw; ok = g_headOk; t = g_headT; ReleaseSRWLockShared(&g_lock);
    long long now = (long long)modtime::Now100ns();
    if (!ok || now - t > 2500000) { if (g_state != 2) g_state = 2; return false; }
    // 0.6.33: the check uses the game camera as the game set it. It used the decoupled-pitch camera (levelled): with
    // the game camera pitched down / up more than ~60 degrees (the right stick - invisible in the headset with
    // decoupled pitch) Star-Lord was "out of view", first person stayed suspended and the toggle seemed to do nothing
    static fpm::FollowHold s_hold; static long long s_holdT = 0;
    if (g_state != 1 && g_state != 3) s_hold.Reset();   // turned on / player found again: decide afresh
    bool follows = fpm::FollowsPlayer(game, raw, g_cam.fpMaxDist * g_cam.unitsPerMetre);
    double hdt = s_holdT ? (double)(now - s_holdT) * 1e-7 : 0.0; s_holdT = now;
    if (!follows && s_hold.inUse) g_held++;
    if (!s_hold.Step(follows, hdt)) {
        if (g_state != 3) {
            g_suspended++;
            V3 d = raw - game.pos; float l = Len(d), c = l > 1e-4f ? Dot(game.axis[2] * -1.f, d * (1.f / l)) : 1.f;
            LOGI("firstperson: suspended - the game camera is not following the player (cutscene / scripted camera): "
                 "head %.1f m from the camera (limit %.1f), %.0f deg off its view centre (limit 60)",
                 l / g_cam.unitsPerMetre, g_cam.fpMaxDist, acosf(fmaxf(-1.f, fminf(1.f, c))) * 57.2958f);
        }
        g_state = 3; return false;
    }
    if (g_state != 1) LOGI("firstperson: in use");
    g_state = 1;
    out = fpm::AtHead(cam, h, g_cam.fpOffset, g_cam.unitsPerMetre);
    g_appliedT = now; g_frames++;
    return true;
}

void Toggle() {
    g_cam.firstPerson = !g_cam.firstPerson; g_set.firstPerson = g_cam.firstPerson;
    LOGI("keys: first person %s%s", g_cam.firstPerson ? "on" : "off", g_installed ? "" : " (not available on this build)");
}

const char* Status() {
    switch (g_state) {
    case 1: return "in Star-Lord's head";
    case 2: return "player not found (menu / loading?) - game camera";
    case 3: return "suspended: cutscene / scripted camera";
    case 4: return "not available on this game build";
    default: return g_cam.firstPerson ? "waiting for a VR frame" : "off (third person)";
    }
}

void Report() {
    if (!g_installed && !g_cam.firstPerson) return;
    LOGI("firstperson: %s - %u frames, player found %u / lost %u, no head bone %u, suspended %u (frames kept through a short miss %u), eye from the root %u, body %s%s%s",
         Status(), g_frames, g_found, g_lost, g_noHead, g_suspended, g_held, g_rootEye, g_hidden ? "hidden" : "visible", g_failStep > 0 ? " | search stops at: " : "", g_failStep > 0 ? g_failInfo : "");
    g_frames = g_noHead = g_suspended = g_held = g_rootEye = 0;
}

} // namespace fp

void FpReport() { fp::Report(); }
void FpToggleFromMenu() { fp::Toggle(); }
