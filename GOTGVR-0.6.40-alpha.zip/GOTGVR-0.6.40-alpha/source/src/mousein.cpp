// Mouse for the VR panel, and the game kept from seeing mouse / keyboard while the panel is open.
//
// The game reads the mouse and keyboard through DirectInput 8 (GOTG.exe imports DirectInput8Create, no raw input).
// A short-lived DirectInput device of our own gives the device method addresses (one implementation for every
// device, as with the D3D12 hooks); GetDeviceState / GetDeviceData are hooked for the A and W interfaces.
// While the panel is open:
//   * mouse: the motion, wheel and buttons the game asks for are handed to the panel (vrkit::input::MouseFeed) and
//     the game gets "no movement, nothing pressed" - the camera does not turn and clicks do not shoot,
//   * keyboard: the game gets "nothing pressed" (Enter / Backspace / arrows in the panel do not act in the game).
// If the game's DirectInput mouse is not delivering (another input path), the desktop pointer's motion is used.
#include <windows.h>
#include <cstring>
#include <string>
#include "MinHook.h"
#include "log.h"
#include "vrkit_input.h"
#include "vrkit_menu.h"

namespace {
typedef HRESULT(WINAPI* PFN_DI8Create)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
typedef HRESULT(STDMETHODCALLTYPE* PFN_GetState)(void* self, DWORD cb, void* data);
typedef HRESULT(STDMETHODCALLTYPE* PFN_GetData)(void* self, DWORD cbObj, void* rgdod, DWORD* inout, DWORD flags);
typedef HRESULT(STDMETHODCALLTYPE* PFN_GetCaps)(void* self, void* caps);

const GUID kIID_DI8W = { 0xBF798031, 0x483A, 0x4DA2, { 0xAA, 0x99, 0x5D, 0x64, 0xED, 0x36, 0x97, 0x00 } };
const GUID kIID_DI8A = { 0xBF798030, 0x483A, 0x4DA2, { 0xAA, 0x99, 0x5D, 0x64, 0xED, 0x36, 0x97, 0x00 } };
const GUID kSysMouse = { 0x6F1D2B60, 0xD5A0, 0x11CF, { 0xBF, 0xC7, 0x44, 0x45, 0x53, 0x54, 0x00, 0x00 } };

struct HookSet { void* stateTarget = nullptr; void* dataTarget = nullptr; PFN_GetState oState = nullptr; PFN_GetData oData = nullptr; };
HookSet g_h[2];   // [0] W, [1] A (often the same code: then only [0] is used)

// device -> 0x12 mouse, 0x13 keyboard, other (cached; the game makes a few devices once)
struct DevType { void* dev; int type; };
DevType g_types[16]; volatile LONG g_typesN = 0;
int TypeOf(void* dev) {
    LONG n = g_typesN;
    for (LONG k = 0; k < n && k < 16; k++) if (g_types[k].dev == dev) return g_types[k].type;
    DWORD caps[11] = {}; caps[0] = sizeof(caps);
    PFN_GetCaps gc = (PFN_GetCaps)(*(void***)dev)[3];
    int t = SUCCEEDED(gc(dev, caps)) ? (int)(caps[2] & 0xFF) : 0;
    LONG i = InterlockedIncrement(&g_typesN) - 1;
    if (i < 16) { g_types[i].dev = dev; g_types[i].type = t; }
    else InterlockedDecrement(&g_typesN);
    return t;
}

volatile LONG g_diMouseAt = 0;   // ms of the last mouse report the game read (DirectInput delivers)
volatile LONG g_mouseReads = 0, g_mouseBlocked = 0, g_keyBlocked = 0;
inline bool PanelOpen() { return vrkit::menu::IsOpen(); }
inline LONG NowMs() { ULONGLONG t = 0; QueryUnbiasedInterruptTime(&t); return (LONG)(t / 10000); }

HRESULT State(int k, void* self, DWORD cb, void* data) {
    HRESULT hr = g_h[k].oState(self, cb, data);
    if (FAILED(hr) || !data) return hr;
    int t = TypeOf(self);
    if (t == 0x12 && cb >= 16) {   // DIMOUSESTATE / DIMOUSESTATE2: lX lY lZ, then buttons
        InterlockedIncrement(&g_mouseReads);
        g_diMouseAt = NowMs();
        if (PanelOpen()) {
            const LONG* a = (const LONG*)data; const BYTE* b = (const BYTE*)data + 12;
            vrkit::input::MouseFeed((int)a[0], (int)a[1], (int)a[2]);
            vrkit::input::MouseButtonsFeed(((b[0] & 0x80) ? 1 : 0) | ((b[1] & 0x80) ? 2 : 0));
            memset(data, 0, cb);
            InterlockedIncrement(&g_mouseBlocked);
        }
    } else if (t == 0x13 && cb >= 256 && PanelOpen()) {
        memset(data, 0, cb); InterlockedIncrement(&g_keyBlocked);
    }
    return hr;
}
HRESULT Data(int k, void* self, DWORD cbObj, void* rg, DWORD* inout, DWORD flags) {
    HRESULT hr = g_h[k].oData(self, cbObj, rg, inout, flags);
    if (FAILED(hr) || !inout) return hr;
    int t = TypeOf(self);
    if (t != 0x12 && t != 0x13) return hr;
    if (t == 0x12) { g_diMouseAt = NowMs(); InterlockedIncrement(&g_mouseReads); }
    if (!PanelOpen()) return hr;
    if (t == 0x12 && rg && cbObj >= 8) {   // DIDEVICEOBJECTDATA: dwOfs, dwData, ...
        static int btn = 0;
        int dx = 0, dy = 0, dz = 0;
        for (DWORD i = 0; i < *inout; i++) {
            const DWORD* o = (const DWORD*)((const BYTE*)rg + (size_t)i * cbObj);
            switch (o[0]) {
            case 0: dx += (LONG)o[1]; break;   // DIMOFS_X
            case 4: dy += (LONG)o[1]; break;   // DIMOFS_Y
            case 8: dz += (LONG)o[1]; break;   // DIMOFS_Z (wheel)
            case 12: btn = (btn & ~1) | ((o[1] & 0x80) ? 1 : 0); break;   // DIMOFS_BUTTON0
            case 13: btn = (btn & ~2) | ((o[1] & 0x80) ? 2 : 0); break;   // DIMOFS_BUTTON1
            }
        }
        vrkit::input::MouseFeed(dx, dy, dz);
        vrkit::input::MouseButtonsFeed(btn);
        InterlockedIncrement(&g_mouseBlocked);
    } else if (t == 0x13) InterlockedIncrement(&g_keyBlocked);
    // the game gets no events, except releases (a key / button held when the panel opened and let go while it is open
    // must not stay "held" in the game afterwards): key-ups and button-ups are kept, packed to the front
    DWORD kept = 0;
    if (rg && cbObj >= 8) {
        for (DWORD i = 0; i < *inout; i++) {
            BYTE* o = (BYTE*)rg + (size_t)i * cbObj;
            DWORD ofs = ((DWORD*)o)[0], data = ((DWORD*)o)[1];
            bool release = !(data & 0x80) && (t == 0x13 || (ofs >= 12 && ofs < 20));   // keyboard keys / mouse buttons 0-7
            if (!release) continue;
            if (kept != i) memmove((BYTE*)rg + (size_t)kept * cbObj, o, cbObj);
            kept++;
        }
    }
    *inout = kept;
    return hr;
}
HRESULT STDMETHODCALLTYPE StateW(void* s, DWORD cb, void* d) { return State(0, s, cb, d); }
HRESULT STDMETHODCALLTYPE StateA(void* s, DWORD cb, void* d) { return State(1, s, cb, d); }
HRESULT STDMETHODCALLTYPE DataW(void* s, DWORD c, void* r, DWORD* io, DWORD f) { return Data(0, s, c, r, io, f); }
HRESULT STDMETHODCALLTYPE DataA(void* s, DWORD c, void* r, DWORD* io, DWORD f) { return Data(1, s, c, r, io, f); }

bool HookOne(int k, const GUID& iid, PFN_DI8Create create) {
    void* di = nullptr;
    if (FAILED(create(GetModuleHandleW(nullptr), 0x0800, iid, &di, nullptr)) || !di) return false;
    typedef HRESULT(STDMETHODCALLTYPE * PFN_CreateDevice)(void*, REFGUID, void**, void*);
    void* dev = nullptr;
    bool ok = false;
    if (SUCCEEDED(((PFN_CreateDevice)(*(void***)di)[3])(di, kSysMouse, &dev, nullptr)) && dev) {
        void** vt = *(void***)dev;
        void* st = vt[9]; void* da = vt[10];
        bool sameAsW = k == 1 && st == g_h[0].stateTarget && da == g_h[0].dataTarget;
        if (!sameAsW) {
            bool a = MH_CreateHook(st, k ? (void*)StateA : (void*)StateW, (void**)&g_h[k].oState) == MH_OK && MH_EnableHook(st) == MH_OK;
            bool b = MH_CreateHook(da, k ? (void*)DataA : (void*)DataW, (void**)&g_h[k].oData) == MH_OK && MH_EnableHook(da) == MH_OK;
            if (a) g_h[k].stateTarget = st;
            if (b) g_h[k].dataTarget = da;
            ok = a && b;
        } else ok = true;
        ((ULONG(STDMETHODCALLTYPE*)(void*))vt[2])(dev);
    }
    ((ULONG(STDMETHODCALLTYPE*)(void*))(*(void***)di)[2])(di);
    return ok;
}
} // namespace

void MouseInputInstall() {
    wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH);
    HMODULE m = LoadLibraryW((std::wstring(sys) + L"\\dinput8.dll").c_str());
    PFN_DI8Create create = m ? (PFN_DI8Create)GetProcAddress(m, "DirectInput8Create") : nullptr;
    if (!create) { LOGW("mouse: DirectInput 8 not available - the VR panel uses the desktop pointer"); return; }
    bool w = HookOne(0, kIID_DI8W, create), a = HookOne(1, kIID_DI8A, create);
    LOGI("mouse: DirectInput mouse / keyboard hooks %s (W %d, A %d) - the mouse drives the VR panel while it is open", (w || a) ? "in place" : "FAILED", (int)w, (int)a);
}

// Present thread, while the panel is open: when the game's DirectInput mouse has not reported for a while, the
// desktop pointer's motion feeds the panel (the pointer is held in the middle of the screen so it never stops at an edge)
void MouseInputFrame(bool open) {
    static bool was = false; static POINT centre = {};
    if (!open) { was = false; return; }
    POINT p; if (!GetCursorPos(&p)) return;
    if (!was) {
        was = true;
        centre.x = GetSystemMetrics(SM_CXSCREEN) / 2; centre.y = GetSystemMetrics(SM_CYSCREEN) / 2;
        if (NowMs() - g_diMouseAt >= 400) SetCursorPos(centre.x, centre.y);
        return;
    }
    if (NowMs() - g_diMouseAt < 400) return;   // DirectInput delivers: it feeds the panel
    DWORD pid = 0; GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    if (pid != GetCurrentProcessId()) return;   // not ours to move
    int dx = p.x - centre.x, dy = p.y - centre.y;
    if (dx || dy) { vrkit::input::MouseFeed(dx, dy, 0); SetCursorPos(centre.x, centre.y); }
}
// window procedure (window.cpp): the wheel, when DirectInput does not report it
bool MouseInputWheel(int delta) {
    if (!vrkit::menu::IsOpen()) return false;
    if (NowMs() - g_diMouseAt < 400) return true;   // DirectInput reports the wheel (and the game must not get it)
    vrkit::input::MouseFeed(0, 0, delta);
    return true;
}
void MouseInputReport() {
    LONG r = InterlockedExchange(&g_mouseReads, 0), b = InterlockedExchange(&g_mouseBlocked, 0), k = InterlockedExchange(&g_keyBlocked, 0);
    if (r || b || k) LOGI("mouse: game mouse reads %ld, kept from the game while the VR panel was open: mouse %ld, keyboard %ld", r, b, k);
}
