#include "modtime.h"
// Camera: head / eye pose and the headset frustum on GOTG's render camera node.
//
// Where: ZRenderGraphNodeCamera's per-frame view update (game.h). It builds the frame's view, culling and every
// matrix the renderer uses from the node's own copy of the camera transform (node+0x24) and from the projection the
// getter returns (node+0xC0 + depth + jitter). This is render-side only: game logic, aiming and audio keep the
// game's camera (the same split DXMDVR found in DXMD's exe+5A5FC0).
//
// Stereo = alternate-eye rendering (AER). GOTG has no side-by-side renderer (DXMD's Stereoscopic3DMode is gone; only
// the launcher's AMD HD3D mode list survived). Each game frame is drawn for ONE eye: the camera gets that eye's full
// pose (position incl. half the IPD, orientation incl. canting) and the projection gets that eye's own asymmetric
// frustum. The next frame is the other eye. The host shows every eye image with the pose it was drawn with, so the
// headset runtime reprojects each eye on its own: the game's full frame rate goes to the headset, each eye is updated
// every second frame (as vrdual / other AER mods do).
//
// Transform: the game writes node+0x24 when its camera moves. The mod keeps that as the "clean" base and writes
// base x (decoupled pitch, offsets) x eye pose. If what is in the node is what the mod wrote last, the game did not
// move the camera and the old base is used again (no accumulation).
//
// Which frame is which eye: every main-node view update pushes (eye, pose, fov) into a FIFO; every Present takes one.
// When the view update runs on the Present thread (the usual case) at most one entry is waiting at a Present.
#include <windows.h>
#include <cmath>
#include <cstring>
#include <cstdint>
#include <climits>
#include "log.h"
#include "MinHook.h"
#include "vrmath.h"
#include "camera.h"
#include "game.h"
#include "settings.h"
#include "config.h"
#include "xrbridge/client.h"
#include "firstperson.h"
bool PadsLTHeld();   // padinput.cpp: L2 / LT held on any controller

CamState g_cam;
extern volatile LONG g_presents;
extern DWORD g_presentThread;

typedef uintptr_t(__fastcall* PFN_NodeUpdate)(void* node, void* ctx, void* view, uintptr_t n);
typedef float*(__fastcall* PFN_GetProj)(void* node, float* out, uintptr_t keepDepth);
static PFN_NodeUpdate o_NodeUpdate = nullptr;
static PFN_GetProj o_GetProj = nullptr;

// ---------------------------------------------------------------- main node selection
// Several camera nodes render each frame (the gameplay view, render-to-texture cameras of screens / holograms, the
// photo mode preview ...). The main one is the node whose render size is the back buffer's and that updates every
// frame; ties go to the one seen most.
struct NodeTally { void* node; unsigned n; unsigned w, h; };
static NodeTally g_tally[16];
static SRWLOCK g_tallyLock = SRWLOCK_INIT;
static void* volatile g_mainNode = nullptr;
static unsigned g_bbW = 0, g_bbH = 0;

static void Tally(void* node) {
    unsigned w = 0, h = 0;
    char* c = (char*)node;
    if (game::Readable(c + game::kNodeW, 8)) { w = *(unsigned*)(c + game::kNodeW); h = *(unsigned*)(c + game::kNodeH); }
    AcquireSRWLockExclusive(&g_tallyLock);
    bool done = false;
    for (auto& t : g_tally) if (t.node == node) { t.n++; t.w = w; t.h = h; done = true; break; }
    if (!done) for (auto& t : g_tally) if (!t.node) { t = { node, 1, w, h }; done = true; break; }
    ReleaseSRWLockExclusive(&g_tallyLock);
}

bool VideoActive(unsigned minW);   // video.cpp
typedef void(__fastcall* PFN_TimerUpdate)(void* t, uintptr_t paused);
static PFN_TimerUpdate o_TimerUpdate = nullptr;
static volatile bool g_gamePaused = false; static volatile long long g_pausedSeen = 0;
static volatile long long g_lastMove100ns = 0;   // when the game last moved its camera
static volatile long long g_gameRecMove100ns = 0;   // 0.6.38: when the game's own camera record last changed (head aim excluded)
static float* g_aimPrevWritten = nullptr;
static long long g_aimLastTurned = 0;
// Flat screen decision (once per Present). Paused: the game's pause flag (the clock call at exe+D2488 gets it from the
// pause manager) and the game camera still for 0.3 s - the pause menu, its settings / map / gear screens. If the camera
// moves while paused (photo mode) it stays 3D until the game runs again. Video: a full-size Bink video decoding while
// the game camera stands still (0.5 s) or the game is paused - a pre-rendered cutscene. 0.25 s either way before a
// change, so a single frame never flips the view.
static void FlatDecide() {
    long long now = (long long)modtime::Now100ns();
    bool paused = g_gamePaused && o_TimerUpdate && now - g_pausedSeen < 5000000;   // clock ticked in the last 0.5 s
    static bool photo = false;
    static long long pauseStart = 0;
    if (!paused) { photo = false; pauseStart = 0; }
    else {
        if (!pauseStart) pauseStart = now;
        if (g_lastMove100ns > pauseStart + 1000000) photo = true;   // the camera moved after the pause began
    }
    long long still = now - g_lastMove100ns;
    // 0.6.36: a video during which the 3D camera moves or cuts (a new shot) belongs to a REAL-TIME scene - an in-world
    // screen, a video behind a real-time cutscene - and stays in VR until that video ends. A tester's log: a real-time
    // cutscene with a 1920x1080 video decoding, every shot a still camera - the view switched flat / VR nine times in a
    // minute. A pre-rendered cutscene never moves the 3D camera while it plays (three in another log, 40 s each).
    static long long vidStart = 0, vidLast = 0; static bool vid3D = false;
    bool vid = g_cam.flatVideos && VideoActive(g_cam.flatVideoMinW);
    if (vid) {
        if (!vidStart || now - vidLast > 20000000) { vidStart = now; vid3D = false; }   // a new video (2 s without one)
        vidLast = now;
        if (!vid3D && g_lastMove100ns > vidStart + 3000000) { vid3D = true; LOGI("view: the 3D camera moved while a video plays - a real-time scene, stays VR until the video ends"); }
    }
    int want = g_cam.flatHold ? 1 : (g_cam.flatMenus && paused && !photo && still > 3000000) ? 2 :
               (vid && !vid3D && (still > 5000000 || paused)) ? 3 : 0;
    static int pending = 0; static long long since = 0;
    if (want != pending) { pending = want; since = now; }
    bool cur = g_cam.flatNow;
    if ((want != 0) != cur && (want == 1 || now - since > 2500000)) {
        g_cam.flatNow = want != 0; g_cam.flatReason = want;
        static const char* why[] = { "", "held (F6)", "game paused (menu)", "pre-rendered video" };
        if (want) LOGI("view: flat screen - %s", why[want]); else LOGI("view: back to VR");
    } else if (cur && want && want != g_cam.flatReason) g_cam.flatReason = want;
}

void CameraOnPresent(unsigned bbW, unsigned bbH) {
    g_bbW = bbW; g_bbH = bbH;
    FlatDecide();
    // near clip (metres -> engine units) only while VR frames are made; the game's own otherwise
    // 0.6.20: the projection getter's near override is never set any more. Since 0.6.14 the picture is drawn from the
    // node's own projection, so the override only changed the depth scale stereo reconstruction reads its depth with
    // (0.6.19 log: depth terms [14] -0.30 = near_clip, the picture drawn with the game's ~0.09) - every distance was
    // taken ~3x too far, the rebuilt eyes had a third of the depth. The near clip is set on the camera node instead.
    game::SetNearClip(0.f);
    if (char* c = (char*)g_mainNode) if (game::Readable(c + 0x1D0, 8)) { g_cam.nodeNear = *(float*)(c + 0x1D0); g_cam.nodeFar = *(float*)(c + 0x1D4); }
    // 0.6.12: the eye frustum is NOT padded to the back buffer's shape any more. 0.6.11 log: the back buffer grows to
    // the wide symmetric view, its shape padded the eye frustum wider, which grew the view again (1.70 -> 2.05 ->
    // 1.99) - and the render size was computed against the padded frustum, so the picture had 1.21 x wider pixels
    // than tall: everything in VR stretched sideways ("very wide"). Shape only from eye_aspect (default: none).
    (void)bbW; (void)bbH;
    AcquireSRWLockExclusive(&g_tallyLock);
    void* best = nullptr; long long bestScore = 0;
    for (auto& t : g_tally) {
        if (!t.node) continue;
        long long s = (long long)t.n + ((t.w == bbW && t.h == bbH) ? 1000000 : 0) + (t.w * (long long)t.h) / 4096;
        if (t.node == g_mainNode) s += 2;   // keep the current one on a tie
        if (s > bestScore) { bestScore = s; best = t.node; }
    }
    memset(g_tally, 0, sizeof g_tally);
    ReleaseSRWLockExclusive(&g_tallyLock);
    if (best && best != g_mainNode) {
        g_cam.nodeSwitches++;
        LOGI("camera: main render camera node %p", best);
        g_mainNode = best;
    }
}

// ---------------------------------------------------------------- headset pose / frustum
static bool FetchPoses() {
    xrb::IpcPose pose[2]; xrb::IpcFov fov[2]; int64_t t = 0;
    if (!xrb::ClientGetLatestPoses(pose, fov, &t) || (pose[0].qw == 0 && pose[0].qx == 0 && pose[0].qy == 0 && pose[0].qz == 0)) {
        g_cam.havePose = false; return false;
    }
    bool fovChanged = false;
    for (int e = 0; e < 2; e++) {
        if (fabsf(fov[e].left - g_cam.fov[e].left) > 1e-4f || fabsf(fov[e].right - g_cam.fov[e].right) > 1e-4f ||
            fabsf(fov[e].up - g_cam.fov[e].up) > 1e-4f || fabsf(fov[e].down - g_cam.fov[e].down) > 1e-4f) fovChanged = true;
        g_cam.pose[e] = pose[e]; g_cam.fov[e] = fov[e];
    }
    g_cam.havePose = true;
    // 0.6.10: the frusta also depend on the angle between the eyes (canted displays: the head-centre view must cover
    // both turned eyes). Pimax reports the eyes turned apart (0.6.8 log: the centre view's right eye had a constant
    // 22 % band outside the drawn picture). Recomputed when that angle changes, from live poses only.
    {
        static float s_cant = -1.f;
        const xrb::IpcPose& a0 = pose[0]; const xrb::IpcPose& a1 = pose[1];
        float n0 = a0.qx * a0.qx + a0.qy * a0.qy + a0.qz * a0.qz + a0.qw * a0.qw, n1 = a1.qx * a1.qx + a1.qy * a1.qy + a1.qz * a1.qz + a1.qw * a1.qw;
        if (fabsf(n0 - 1.f) < 0.05f && fabsf(n1 - 1.f) < 0.05f) {
            float d = fabsf(a0.qx * a1.qx + a0.qy * a1.qy + a0.qz * a1.qz + a0.qw * a1.qw) / sqrtf(n0 * n1);
            float cant = 2.f * acosf(fminf(1.f, d)) * 57.2957795f;
            if (fabsf(cant - s_cant) > 0.3f) { s_cant = cant; if (!fovChanged) CameraUpdateFrustum(); }
        }
    }
    if (fovChanged) {
        const float d = 57.2957795f;
        float ipd = sqrtf((pose[0].px - pose[1].px) * (pose[0].px - pose[1].px) + (pose[0].py - pose[1].py) * (pose[0].py - pose[1].py) +
                          (pose[0].pz - pose[1].pz) * (pose[0].pz - pose[1].pz));
        LOGI("headset: left eye FOV L%.1f R%.1f U%.1f D%.1f, right eye L%.1f R%.1f U%.1f D%.1f deg, IPD %.1f mm",
             fov[0].left * d, fov[0].right * d, fov[0].up * d, fov[0].down * d, fov[1].left * d, fov[1].right * d, fov[1].up * d, fov[1].down * d, ipd * 1000.f);
        CameraUpdateFrustum();
    }
    return true;
}

// Each eye's own asymmetric frustum from the headset, widened about its centre to the eye image's aspect (square
// pixels, nothing stretched - 1:1, 5:4 or the headset's own shape), then by the cull margin. Head mode: one
// symmetric frustum that covers both eyes.
static float g_baseW[2] = { 2.f, 2.f }, g_baseH[2] = { 2.f, 2.f };
// 0.6.9: the head's orientation = halfway between the two eyes' (canted displays: Pimax and others turn each eye a few
// degrees outwards). Head mode and reconstruction's centre view are drawn with it, so neither eye is favoured; the
// eyes are rebuilt / shown with their own orientation.
static void HeadQuat(const xrb::IpcPose* p, float q[4]) {
    float a[4] = { p[0].qx, p[0].qy, p[0].qz, p[0].qw }, b[4] = { p[1].qx, p[1].qy, p[1].qz, p[1].qw };
    float dot = a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3], sg = dot < 0.f ? -1.f : 1.f;
    float n = 0.f; for (int i = 0; i < 4; i++) { q[i] = a[i] + sg * b[i]; n += q[i] * q[i]; }
    n = sqrtf(n);
    if (n < 1e-6f) { for (int i = 0; i < 4; i++) q[i] = a[i]; return; }
    for (int i = 0; i < 4; i++) q[i] /= n;
}
void CameraUpdateFrustum() {
    const xrb::IpcFov* f = g_cam.fov;
    float a = g_cam.eyeAspect;   // 0 = the headset's own field of view, no padding
    float m = g_cam.cullMargin < 1.f ? 1.f : g_cam.cullMargin;
    auto tn = [](float x) { return tanf(x < -1.5f ? -1.5f : x > 1.5f ? 1.5f : x); };
    for (int e = 0; e < 2; e++) {
        float l = tn(f[e].left), r = tn(f[e].right), u = tn(f[e].up), d = tn(f[e].down);
        if (!(r - l > 0.05f) || !(u - d > 0.05f)) { l = -1; r = 1; u = 1; d = -1; }
        float cx = 0.5f * (r + l), cy = 0.5f * (u + d), w = r - l, h = u - d;
        if (a > 0.1f) { if (w / h < a) w = h * a; else h = w / a; }
        g_baseW[e] = w; g_baseH[e] = h;   // the headset's own field of view (image shape), before the margin
        w *= m; h *= m;
        // 0.6.13: picture width / height above 1 show more than the headset's field of view, eye align moves the shown
        // window - the rendered view covers both (the compositor cuts the window out: CropToHeadset)
        float sx = g_set.viewWidth, sy = g_set.viewHeight;
        if (!(sx >= 0.5f && sx <= 2.f)) sx = 1.f; if (!(sy >= 0.5f && sy <= 2.f)) sy = 1.f;
        if (sx > m) w *= sx / m; if (sy > m) h *= sy / m;
        auto tn1 = [](float deg) { return fabsf(tanf(fminf(fabsf(deg), 20.f) * 0.0174533f)); };
        float ax = fmaxf(tn1(g_set.reconShiftH), tn1(g_set.aerShiftH)), ay = fmaxf(tn1(g_set.reconShiftV), tn1(g_set.aerShiftV));
        g_cam.eyeTan[e][0] = cx - 0.5f * w - ax; g_cam.eyeTan[e][1] = cx + 0.5f * w + ax;
        g_cam.eyeTan[e][2] = cy + 0.5f * h + ay; g_cam.eyeTan[e][3] = cy - 0.5f * h - ay;
    }
    float hx = 1.f, hy = 1.f;
    {
        // 0.6.8: from the eyes' own frusta (their image shape and cull margin included), so the head-centre view covers
        // every pixel of both eyes - reconstruction's centre view rebuilds them from it; +2 % for the half-IPD parallax.
        // No padding to the eye image's shape (the render size follows each axis: CameraDrawGrowthXY) - the both-eye view
        // is wider than tall, padding it to the eye shape cost ~1.8x the pixels instead of ~1.3x
        // 0.6.9: each eye's frustum corners turned into the head's frame first (canted displays: an eye turned outwards
        // sees further to its side than its own tangents say - the centre view missed that edge, the rebuilt eye had
        // a stretched band there)
        const float (*t)[4] = g_cam.eyeTan;
        float hq[4]; HeadQuat(g_cam.pose, hq);
        bool rot = g_cam.pose[0].qw != 0 || g_cam.pose[0].qx != 0 || g_cam.pose[0].qy != 0 || g_cam.pose[0].qz != 0;
        float Rh[3][3]; QuatToMat(hq[0], hq[1], hq[2], hq[3], Rh);
        hx = hy = 0.f;
        for (int e = 0; e < 2; e++) {
            float Re[3][3]; const xrb::IpcPose& pe = g_cam.pose[e]; QuatToMat(pe.qx, pe.qy, pe.qz, pe.qw, Re);
            for (int c = 0; c < 4; c++) {
                float v[3] = { c & 1 ? t[e][1] : t[e][0], c & 2 ? t[e][2] : t[e][3], -1.f }, w[3] = { v[0], v[1], v[2] };
                if (rot) {   // w = Rh^T * Re * v
                    float u[3]; for (int i = 0; i < 3; i++) u[i] = Re[i][0] * v[0] + Re[i][1] * v[1] + Re[i][2] * v[2];
                    for (int i = 0; i < 3; i++) w[i] = Rh[0][i] * u[0] + Rh[1][i] * u[1] + Rh[2][i] * u[2];
                }
                if (w[2] > -0.05f) { w[0] = v[0]; w[1] = v[1]; w[2] = -1.f; }
                hx = fmaxf(hx, fabsf(w[0] / -w[2])); hy = fmaxf(hy, fabsf(w[1] / -w[2]));
            }
        }
        hx *= 1.02f; hy *= 1.02f;
        hx = fminf(hx, 3.7f); hy = fminf(hy, 3.7f);   // 75 deg: beyond that the pixels are too stretched to be worth it
        if (!(hx > 0.05f) || !(hy > 0.05f)) { hx = 1.f; hy = 1.f; }
        if (rot) {   // log the cant once per change
            float Ro[3][3]; QuatToMat(g_cam.pose[1].qx, g_cam.pose[1].qy, g_cam.pose[1].qz, g_cam.pose[1].qw, Ro);
            float Rl[3][3]; QuatToMat(g_cam.pose[0].qx, g_cam.pose[0].qy, g_cam.pose[0].qz, g_cam.pose[0].qw, Rl);
            float tr = 0.f; for (int i = 0; i < 3; i++) for (int k = 0; k < 3; k++) tr += Rl[k][i] * Ro[k][i];
            float ang = acosf(fmaxf(-1.f, fminf(1.f, (tr - 1.f) * 0.5f))) * 57.2957795f;
            // 0.6.35: only when it changes (the tester's log: 872 identical lines - every frustum update logged it)
            static float s_ang = -1.f, s_hx = -1.f, s_hy = -1.f;
            if (fabsf(ang - s_ang) > 0.05f || fabsf(hx - s_hx) > 0.002f || fabsf(hy - s_hy) > 0.002f) {
                s_ang = ang; s_hx = hx; s_hy = hy;
                LOGI("headset: the eyes are turned %.1f deg apart (canted displays when > 0.5) - head view %.3f x %.3f", ang, hx, hy);
            }
        }
    }
    g_cam.monoTan[0] = -hx; g_cam.monoTan[1] = hx; g_cam.monoTan[2] = hy; g_cam.monoTan[3] = -hy;
    // stereo reconstruction: the drawn eye's frustum widened to also hold everything the other eye sees, so the rebuilt
    // eye has a source for every pixel except what is hidden behind close objects. The other eye's frustum corners are
    // turned into the drawn eye's frame (canted displays: Pimax, some WMR) and projected; 3 % for the eyes' parallax.
    // Only the directions that need it grow: the two eyes differ mostly sideways, so the view gets wider but hardly
    // taller (it used to keep the eye image's shape - about 1.3 x wider made it 1.3 x taller too, ~1.7 x the pixels;
    // now ~1.3 x). The render size follows per axis (CameraDrawGrowthXY), so the pixels stay square.
    // 0.6.6 log: the engine renders a SYMMETRIC projection whatever the off-centre terms say (its projection is
    // rebuilt after the getter: depth rows, TAA jitter in [8] / [9]) - the eye screenshots of alternate-eye mode showed
    // both eyes centred on the same point while the Dream Air's eyes look 13 % of the image to the side, so in the
    // headset the two pictures sat side by side and never merged. The engine now always draws a symmetric frustum that
    // covers the eye's own (the AC mods' "symmetric view"), and the compositor cuts the eye's real view out of it.
    auto sym = [&](const float* in, float* out) {
        if (!g_cam.symmetricView) { memcpy(out, in, 16); return; }
        float hx = fmaxf(-in[0], in[1]), hy = fmaxf(in[2], -in[3]);
        out[0] = -hx; out[1] = hx; out[2] = hy; out[3] = -hy;
    };
    for (int e = 0; e < 2; e++) sym(g_cam.eyeTan[e], g_cam.drawTan[e]);
    for (int e = 0; e < 2; e++) {
        const float* ta = g_cam.eyeTan[e]; const float* b = g_cam.eyeTan[e ^ 1];
        float l = ta[0], r = ta[1], u = ta[2], d = ta[3];
        const xrb::IpcPose& pe = g_cam.pose[e]; const xrb::IpcPose& po = g_cam.pose[e ^ 1];
        float Re[3][3], Ro[3][3];
        bool rot = pe.qw != 0 || pe.qx != 0 || pe.qy != 0 || pe.qz != 0;
        QuatToMat(pe.qx, pe.qy, pe.qz, pe.qw, Re); QuatToMat(po.qx, po.qy, po.qz, po.qw, Ro);
        for (int c = 0; c < 4; c++) {
            float v[3] = { c & 1 ? b[1] : b[0], c & 2 ? b[2] : b[3], -1.f }, w[3] = { v[0], v[1], v[2] };
            if (rot) {   // w = Re^T * Ro * v
                float t[3]; for (int i = 0; i < 3; i++) t[i] = Ro[i][0] * v[0] + Ro[i][1] * v[1] + Ro[i][2] * v[2];
                for (int i = 0; i < 3; i++) w[i] = Re[0][i] * t[0] + Re[1][i] * t[1] + Re[2][i] * t[2];
            }
            if (w[2] > -0.05f) continue;   // more than ~87 degrees off: cannot be covered, keep the eye's own
            float tx = w[0] / -w[2], ty = w[1] / -w[2];
            l = fminf(l, tx); r = fmaxf(r, tx); u = fmaxf(u, ty); d = fminf(d, ty);
        }
        float cx = 0.5f * (r + l), cy = 0.5f * (u + d), W = (r - l) * 1.03f, H = (u - d) * 1.03f;
        g_cam.reconTan[e][0] = cx - 0.5f * W; g_cam.reconTan[e][1] = cx + 0.5f * W;
        g_cam.reconTan[e][2] = cy + 0.5f * H; g_cam.reconTan[e][3] = cy - 0.5f * H;
        float tmp[4]; memcpy(tmp, g_cam.reconTan[e], 16); sym(tmp, g_cam.reconTan[e]);
    }
    // 0.6.11: ONE frustum for every stereo method (symmetric view): the widest of the eyes' own and the head-centre
    // view. The render size is made from it (CameraStableGrowthXY), so the picture's shape always equals the render
    // size's shape - square pixels whether the engine takes the projection's x scale from us or works it out from
    // its window shape (a mismatch there is what stretches the 3D "wide"), and no resize when the method changes.
    if (g_cam.symmetricView) {
        float HX = g_cam.monoTan[1], HY = g_cam.monoTan[2];
        for (int e = 0; e < 2; e++) { HX = fmaxf(HX, g_cam.drawTan[e][1]); HY = fmaxf(HY, g_cam.drawTan[e][2]); }
        const float u[4] = { -HX, HX, HY, -HY };
        for (int e = 0; e < 2; e++) { memcpy(g_cam.drawTan[e], u, 16); memcpy(g_cam.reconTan[e], u, 16); }
        memcpy(g_cam.monoTan, u, 16);
    }
}
const float* CameraDrawTan(int e) {
    e &= 1;
    if (g_cam.mode == VRMODE_RECON && g_cam.reconCentre) return g_cam.monoTan;   // the head-centre view (both eyes rebuilt)
    return (g_cam.mode == VRMODE_RECON && g_cam.reconShared) ? g_cam.reconTan[e] : g_cam.drawTan[e];
}

// how much wider than the headset's own field of view the rendered image is (cull margin, the shared frustum of
// stereo reconstruction, head mode's both-eyes view): the render size is grown by this so the headset still gets its
// own pixel density in the part it shows
void CameraDrawGrowthXY(float& gx, float& gy) {
    gx = gy = 1.f;
    for (int e = 0; e < 2; e++) {
        const float* t = g_cam.mode == VRMODE_HEAD ? g_cam.monoTan : CameraDrawTan(e);
        if (g_baseW[e] > 0.05f) gx = fmaxf(gx, (t[1] - t[0]) / g_baseW[e]);
        if (g_baseH[e] > 0.05f) gy = fmaxf(gy, (t[2] - t[3]) / g_baseH[e]);
    }
    if (gx > 3.f) gx = 3.f; if (gy > 3.f) gy = 3.f;
}
// 0.6.9: the largest view any stereo method draws (eye views, the head / centre view; the shared reconstruction view)
// - the render size is set from this ONCE and does not change when the method is switched (manual 7.3: a resize
// recreates every render target - a hitch, and the UI picker lost its target)
void CameraStableGrowthXY(float& gx, float& gy) {
    gx = gy = 1.f;
    for (int e = 0; e < 2; e++) {
        const float* ts[3] = { g_cam.drawTan[e], g_cam.monoTan, (g_cam.reconShared && !g_cam.reconCentre) ? g_cam.reconTan[e] : g_cam.drawTan[e] };
        for (const float* t : ts) {
            if (g_baseW[e] > 0.05f) gx = fmaxf(gx, (t[1] - t[0]) / g_baseW[e]);
            if (g_baseH[e] > 0.05f) gy = fmaxf(gy, (t[2] - t[3]) / g_baseH[e]);
        }
    }
    if (gx > 3.f) gx = 3.f; if (gy > 3.f) gy = 3.f;
}
// width / height of the drawn view (tangents): the render size is made this shape (square pixels)
float CameraDrawAspect() {
    float w = g_cam.monoTan[1] - g_cam.monoTan[0], h = g_cam.monoTan[2] - g_cam.monoTan[3];
    return (w > 0.05f && h > 0.05f) ? w / h : 0.f;
}
float CameraDrawGrowth() { float gx, gy; CameraDrawGrowthXY(gx, gy); return fmaxf(gx, gy); }

static xrb::IpcFov TanToFov(const float* t) { return { atanf(t[0]), atanf(t[1]), atanf(t[2]), atanf(t[3]) }; }

// ---------------------------------------------------------------- transform
static Frame ReadFrame(const float* T) {
    Frame f;
    const float* row[4] = { T, T + 3, T + 6, T + 9 };
    for (int k = 0; k < 3; k++) {
        const float* r = row[g_cam.axisRow[k]]; float s = g_cam.axisSign[k];
        f.axis[k] = { r[0] * s, r[1] * s, r[2] * s };
    }
    f.pos = { T[9], T[10], T[11] };
    return f;
}
static void WriteFrame(float* T, const Frame& f) {
    for (int k = 0; k < 3; k++) {
        float* r = T + 3 * g_cam.axisRow[k]; float s = g_cam.axisSign[k];
        r[0] = f.axis[k].x * s; r[1] = f.axis[k].y * s; r[2] = f.axis[k].z * s;
    }
    T[9] = f.pos.x; T[10] = f.pos.y; T[11] = f.pos.z;
}

// the game camera with the menu's adjustments. World is Z-up (Dawn engine).
static Frame CameraBase(Frame f) {
    const Frame game = f;   // the game camera as the game set it (first person's cutscene check)
    if (g_cam.decoupledPitch) {   // keep yaw only: the horizon stays level, the head pitches / rolls the view
        V3 fwd = f.axis[2] * -1.f;
        V3 h = { fwd.x, fwd.y, 0.f };
        if (Len(h) < 1e-3f) { float sg = f.axis[2].z > 0.f ? 1.f : -1.f; h = { f.axis[1].x * sg, f.axis[1].y * sg, 0.f }; }
        if (Len(h) > 1e-6f) {
            h = Norm(h);
            V3 up = { 0, 0, 1 }, back = h * -1.f, right = Cross(up, back);
            if (Dot(right, f.axis[0]) < 0.f) right = right * -1.f;
            f.axis[0] = right; f.axis[1] = up; f.axis[2] = back;
        }
    }
    // first person: the eye at the head, with its own offsets (camera_offset_* are third person only)
    Frame h;
    if (fp::EyeBase(f, game, h)) { g_cam.fpActive = true; return h; }
    g_cam.fpActive = false;
    // offsets are metres of the game world: world_scale (your size in it) does not change them
    float u = g_cam.unitsPerMetre;
    float ox = g_cam.camOffset[0] * u, oy = g_cam.camOffset[1] * u, oz = g_cam.camOffset[2] * u;
    f.pos = f.pos + f.axis[0] * ox + f.axis[1] * oy - f.axis[2] * oz;
    return f;
}

// Camera stabilizer (camera_stabilize 0..1): the game's camera shakes (jumps, landings, hits, explosions) and bobs -
// on a monitor that sells impact, in a headset it is uncomfortable. A critically damped follower on the camera's
// position and heading removes the fast part and keeps the motion: time constant up to ~120 ms at 1.0. Cuts (the
// camera jumps more than 2 m or turns more than 40 degrees in a frame) are taken at once.
static Frame g_stab; static bool g_stabHave = false; static long long g_stabTick = 0;
static Frame Stabilize(Frame f, bool sameTick) {
    float k = g_cam.stabilize;
    if (!(k > 0.01f)) { g_stabHave = false; return f; }
    long long now = (long long)modtime::Now100ns();
    float dt = g_stabTick ? (float)(now - g_stabTick) * 1e-7f : 0.f;
    if (sameTick && g_stabHave) return g_stab;              // the second eye of a tick: the same camera
    g_stabTick = now;
    float s = g_cam.unitsPerMetre;   // a cut = 2 m of the game world
    V3 d = f.pos - (g_stabHave ? g_stab.pos : f.pos);
    float turn = g_stabHave ? acosf(fmaxf(-1.f, fminf(1.f, Dot(f.axis[2], g_stab.axis[2])))) : 0.f;
    if (!g_stabHave || !(dt > 0.f && dt < 0.25f) || Len(d) > 2.f * s || turn > 0.7f) { g_stab = f; g_stabHave = true; return f; }
    float tau = 0.12f * k, a = 1.f - expf(-dt / tau);
    g_stab.pos = g_cam.fpActive ? f.pos : g_stab.pos + d * a;   // first person: the head is filtered on its own (no lag)
    for (int i = 0; i < 3; i++) g_stab.axis[i] = Norm(g_stab.axis[i] + (f.axis[i] - g_stab.axis[i]) * a);
    // re-orthonormalise (back, then up, then right)
    V3 b = Norm(g_stab.axis[2]), r = Norm(Cross(g_stab.axis[1], b)), u = Cross(b, r);
    if (Dot(r, f.axis[0]) < 0.f) r = r * -1.f;
    g_stab.axis[0] = r; g_stab.axis[1] = u; g_stab.axis[2] = b;
    return g_stab;
}

// 0.6.17 idle-sway lock (camera_settle 0..1): standing still, the game's camera still sways (third person: the idle
// camera drift / breathing; first person: the head bone's idle animation) - small, slow movements the shake filter
// cannot remove (it only takes out fast ones) and that, in a headset, feel like the floor moving. A "rope with
// slack": the camera only moves once the game's moves further than the slack (up to 2.5 degrees / 6 cm at 1.0) and
// then follows 1:1 - real turns and walking pass through, the sway inside the slack is gone.
static Frame g_settle; static bool g_settleHave = false; static bool g_settleFlip = false;
static float g_settleAng[3];
static float WrapPi(float a) { while (a > 3.14159265f) a -= 6.2831853f; while (a < -3.14159265f) a += 6.2831853f; return a; }
static Frame Settle(Frame f, bool sameTick) {
    float k = g_cam.settle;
    if (!(k > 0.01f)) { g_settleHave = false; return f; }
    if (sameTick && g_settleHave) return g_settle;
    const V3 Z = { 0, 0, 1 };
    V3 back = Norm(f.axis[2]), fwd = back * -1.f;
    if (fabsf(fwd.z) > 0.97f) { g_settleHave = false; return f; }   // looking straight up / down: no stable heading
    V3 r0 = Norm(Cross(Z, back)); bool flip = Dot(r0, f.axis[0]) < 0.f; if (flip) r0 = r0 * -1.f;
    V3 u0 = Cross(back, r0);
    float ang[3] = { atan2f(fwd.y, fwd.x), asinf(fmaxf(-1.f, fminf(1.f, fwd.z))), atan2f(Dot(f.axis[0], u0), Dot(f.axis[0], r0)) };
    float dzA = 2.5f * 0.0174533f * k, dzP = 0.06f * k * g_cam.unitsPerMetre;
    if (!g_settleHave || flip != g_settleFlip) { for (int i = 0; i < 3; i++) g_settleAng[i] = ang[i]; g_settle = f; g_settleHave = true; g_settleFlip = flip; return f; }
    for (int i = 0; i < 3; i++) {
        float d = WrapPi(ang[i] - g_settleAng[i]);
        if (d > dzA) g_settleAng[i] = WrapPi(ang[i] - dzA); else if (d < -dzA) g_settleAng[i] = WrapPi(ang[i] + dzA);
    }
    V3 dp = f.pos - g_settle.pos; float L = Len(dp);
    Frame o = f;
    o.pos = L > dzP ? f.pos - dp * (dzP / L) : g_settle.pos;
    float cy = cosf(g_settleAng[0]), sy = sinf(g_settleAng[0]), cp = cosf(g_settleAng[1]), sp = sinf(g_settleAng[1]);
    V3 nb = { -cp * cy, -cp * sy, -sp };
    V3 nr0 = Norm(Cross(Z, nb)); if (flip) nr0 = nr0 * -1.f;
    V3 nu0 = Cross(nb, nr0);
    V3 nr = nr0 * cosf(g_settleAng[2]) + nu0 * sinf(g_settleAng[2]);
    o.axis[0] = Norm(nr); o.axis[2] = nb; o.axis[1] = Cross(nb, o.axis[0]);
    if (Dot(o.axis[1], f.axis[1]) < 0.f) o.axis[1] = o.axis[1] * -1.f;   // keep the game's handedness
    g_settle = o;
    return o;
}

struct NodeRec { void* node = nullptr; float clean[12]; float written[12]; bool have = false; };
static NodeRec g_rec;

// ---------------------------------------------------------------- frame FIFO (view update -> Present)
static RenderedEye g_fifo[8];
static volatile LONG g_fifoHead = 0, g_fifoTail = 0;   // head: next to write, tail: next to read
static SRWLOCK g_fifoLock = SRWLOCK_INIT;
static long g_seq = 0;
static volatile LONG g_presentAtLastPush = -1;
static int g_lastEye = 1;
static unsigned g_fifoDropped = 0, g_fifoReplaced = 0, g_fifoEmpty = 0;
static float g_prevBase[3][3]; static long long g_prevBaseTick = 0; static float g_angVel[3] = {};

// the eye for the frame starting now. Same thread as Present and no Present since the last push: this is the same
// frame updating again - keep its eye.
// Updates of the main node between two Presents: normally 1. If (nearly) every frame updates it twice on the Present
// thread, the second one is the same frame again (keep its eye); a single extra update is the next frame's, which
// can come before this frame's Present (pipelined renderer) - the FIFO keeps it for the next Present.
static volatile LONG g_updatesSincePresent = 0;
static unsigned g_multiHist = 0; static bool g_multiUpdate = false;
static void CountPresent() {
    LONG n = InterlockedExchange(&g_updatesSincePresent, 0);
    g_multiHist = (g_multiHist << 1) | (n >= 2 ? 1u : 0u);
    int c = 0; for (unsigned b = g_multiHist; b; b &= b - 1) c++;
    bool m = c >= 26;
    if (m != g_multiUpdate) { g_multiUpdate = m; LOGI("camera: %s view updates per frame", m ? "two or more" : "one"); }
}
static int NextEye(bool& replace) {
    InterlockedIncrement(&g_updatesSincePresent);
    replace = g_multiUpdate && GetCurrentThreadId() == g_presentThread && g_presentAtLastPush == g_presents && g_fifoHead != g_fifoTail;
    if (replace) return g_lastEye;
    g_lastEye ^= 1;
    return g_lastEye;
}

static void Push(const RenderedEye& r, bool replace) {
    AcquireSRWLockExclusive(&g_fifoLock);
    if (replace && g_fifoHead != g_fifoTail) { g_fifo[(g_fifoHead - 1) & 7] = r; g_fifoReplaced++; }
    else {
        if (g_fifoHead - g_fifoTail >= 4) { g_fifoTail = g_fifoHead - 3; g_fifoDropped++; }   // nobody presented: keep the newest
        g_fifo[g_fifoHead & 7] = r; g_fifoHead++;
    }
    g_presentAtLastPush = g_presents;
    ReleaseSRWLockExclusive(&g_fifoLock);
}

bool CameraTakeRendered(RenderedEye& out) {
    CountPresent();
    AcquireSRWLockExclusive(&g_fifoLock);
    bool ok = g_fifoHead - g_fifoTail > g_cam.frameDelay;
    if (ok) {
        // more than one waiting while the producer runs on another thread: the oldest is the one this Present shows
        out = g_fifo[g_fifoTail & 7]; g_fifoTail++;
    } else g_fifoEmpty++;
    ReleaseSRWLockExclusive(&g_fifoLock);
    return ok;
}

bool CameraRenderSize(unsigned& w, unsigned& h) {
    char* c = (char*)g_mainNode;
    if (!c || !game::Readable(c + game::kNodeW, 8)) return false;
    w = *(unsigned*)(c + game::kNodeW); h = *(unsigned*)(c + game::kNodeH);
    return w >= 64 && h >= 64 && w <= 16384 && h <= 16384;
}

bool CameraRecordingEye(int& eye, bool& mono) {
    AcquireSRWLockShared(&g_fifoLock);
    bool ok = g_fifoHead != g_fifoTail;
    if (ok) { const RenderedEye& r = g_fifo[g_fifoTail & 7]; eye = r.drawEye & 1; mono = r.drawMono; }
    ReleaseSRWLockShared(&g_fifoLock);
    if (!ok) { eye = g_cam.curEye & 1; mono = g_cam.curMono; return false; }
    if (eye != (g_cam.curEye & 1) || mono != g_cam.curMono) g_cam.uiEyeAhead++;   // the camera of a later frame was already set
    return true;
}

bool CameraFrameIsVR() { return g_presents - g_cam.lastVrSeq <= 3; }

// ---------------------------------------------------------------- synchronized sequential (same game tick)
// UEVR's "Synchronized Sequential": two frames on the same engine tick, the game world does not advance between them.
// Here: the game clock step (exe+42E890 on the game timer) is held on every second tick - delta 0, the time stays -
// and the held delta is added to the next tick, so game speed is unchanged. The render frame of a held tick draws the
// second eye from the same camera base as the first; everything the game simulates (characters, physics, particles,
// animation) is in the same state for both eyes. World motion then updates at half the frame rate (as in UEVR).
// Ticks -> render frames: the main loop ticks the clock once per frame and the renderer draws each tick once, so
// render frame r shows tick r + c. c is the smallest (ticks - render frames) seen at the main node's view update (the
// renderer can never be ahead of the tick it draws; the main thread may be one tick ahead).

static volatile LONG g_tick = 0;
static volatile unsigned char g_holdRing[64];
static long long g_heldDelta = 0;
// the game's render options (game thread), only as the player chose them in game_aa / game_upscaling.
static void RenderOptionsTick() {
    if (!game::RenderOptionsFound()) return;
    // only what the player chose (game_aa / game_upscaling) - "game" = never touched
    bool native = g_cam.upscaleNative;   // 0.6.37: numbers set by the panel's thread, not its strings
    int aa = g_cam.gameAaWant;
    static bool pn = false, init = false; static int pa = -2; static ULONGLONG since = 0;
    ULONGLONG now = ModTick64();
    if (!init || native != pn || aa != pa) { pn = native; pa = aa; since = now; init = true; }
    if (now - since < 500) return;   // menu clicking: settle first
    game::RenderOptionsApply(native, aa);
}
static void __fastcall H_TimerUpdate(void* t, uintptr_t paused) {
    char* p = (char*)t;
    bool already = p[0x78] != 0;
    o_TimerUpdate(t, paused);
    if ((uintptr_t)t != game::g_gameTimer || already) return;
    g_gamePaused = (paused & 0xFF) != 0;   // the game's own pause (pause menu and its screens, photo mode)
    g_pausedSeen = (long long)modtime::Now100ns();
    LONG n = InterlockedIncrement(&g_tick);
    bool hold = g_cam.mode == VRMODE_SYNCED && CameraFrameIsVR() && (n & 1) && !(paused & 0xFF);
    long long* time = (long long*)(p + 0x20); long long* delta = (long long*)(p + 0x30);
    // 0.6.28: the held tick keeps 1/32 of its time instead of none. A tick of exactly 0 made the character controller
    // drop its momentum (a jump / dodge / boost animated but the hero stayed in place - Dante727, synchronized mode):
    // speed worked out as distance / time is lost when time is 0. 1/32 of a frame (~0.3 ms) is not visible between the eyes.
    if (hold && *delta > 0 && *delta < (1ll << 40)) {
        long long keep = *delta / 32; if (keep < 1) keep = 1;
        long long held = *delta - keep;
        g_heldDelta += held; *time -= held; *delta = keep; g_cam.heldTicks++;
    }
    else { hold = false; if (g_heldDelta) { *delta += g_heldDelta; *time += g_heldDelta; g_heldDelta = 0; } }
    g_holdRing[n & 63] = hold ? 1 : 0;
    fp::GameTick();   // game thread, once per frame: the player's head for first person
    RenderOptionsTick();
}
static unsigned g_syncAltFrames = 0;   // 0.6.40: synchronized frames drawn alternating (no clock to pair with)
static long g_renderSeq = 0;
static int g_lagC = INT_MIN, g_lagWinMin = INT_MAX, g_lagWinN = 0, g_lagHigh = 0;
static float g_lagScore[3] = {}; static int g_lagAuto = 0;
// held tick for the frame drawn now (render thread, main node). moved = the game moved its camera since the last frame.
// The counters give the tick up to a constant; which constant is found from the picture: on a held tick the game
// clock stands still, so the game camera does not move (stick / keyboard turning and walking are time based) -
// the right offset k is the one whose held frames are the frames where the camera stood still while it otherwise
// moves. Scores decay so a change (loading screen, a new level) is followed.
static bool RenderFrameIsHeld(bool moved) {
    long r = ++g_renderSeq;
    int d = (int)(g_tick - r);
    if (g_lagC == INT_MIN || d < g_lagC) g_lagC = d;
    if (d > g_lagC + 3) { if (++g_lagHigh > 10) { g_lagC = d; g_lagHigh = 0; } } else g_lagHigh = 0;   // ticks without frames (loading)
    if (d < g_lagWinMin) g_lagWinMin = d;
    if (++g_lagWinN >= 240) { g_lagC = g_lagWinMin; g_lagWinMin = INT_MAX; g_lagWinN = 0; }
    static unsigned motion = 0; motion = (motion << 1) | (moved ? 1u : 0u);
    bool active = (motion & 0xFF) && __builtin_popcount(motion & 0xFF) >= 2;   // the camera is moving these frames
    for (int k = 0; k < 3; k++) {
        g_lagScore[k] *= 0.995f;
        if (active && g_holdRing[(r + g_lagC - k) & 63]) g_lagScore[k] += moved ? -1.f : 1.f;
    }
    int best = 0; for (int k = 1; k < 3; k++) if (g_lagScore[k] > g_lagScore[best] + 2.f) best = k;
    if (g_lagScore[best] > 4.f && best != g_lagAuto && g_lagScore[best] > g_lagScore[g_lagAuto] + 3.f) { g_lagAuto = best; LOGI("camera: synchronized stereo: clock offset %d", best); }
    int k = g_cam.syncLag >= 0 ? g_cam.syncLag : g_lagAuto;
    g_cam.syncLagNow = (unsigned)k;
    return g_holdRing[(r + g_lagC - k) & 63] != 0;
}

// ---------------------------------------------------------------- head aim (0.6.30)
// Weapons aim where the head looks; the view does not turn. The aim follows the game's camera ENTITY (ZCameraEntity),
// whose transform the camera manager sets from a camera record (game::g_camApply, record+0x20 4x4, rows 1 / 2 used for
// the orientation, row 3 = position). The hook turns that record to the direction the player actually sees (the
// rendered base frame + the head's orientation, roll removed) before the entity gets it. The render camera node is
// copied from the entity, so the node then carries the turned camera too: the view update takes it back out (the
// record it came from is remembered) before the head pose is applied as always - the picture is exactly what it was.
typedef void(__fastcall* PFN_CamApply)(void* mgr, char* rec);
static PFN_CamApply o_CamApply = nullptr;
struct AimEntry { float rot[12]; float clean[12]; long long t; bool turned; };   // record rows 0-2 (xyz) + position
static AimEntry g_aim[8]; static int g_aimN = 0; static SRWLOCK g_aimLock = SRWLOCK_INIT;
// record row -> frame axis (right, up, back): learned from the game (record row, sign); default rows right / forward / up
static int g_recRow[3] = { 0, 2, 1 }; static float g_recSign[3] = { 1.f, 1.f, -1.f }; static bool g_recMapLearned = false;
static float g_aimRel[3][3] = { { 1, 0, 0 }, { 0, 1, 0 }, { 0, 0, 1 } };   // render base axes in the camera frame (render thread)
static float g_aimRelPos[3] = { 0, 0, 0 };                                 // render base position in the camera frame
static V3 g_aimSmoothDir = { 0, 0, -1 }; static bool g_aimSmoothHave = false;   // head forward, smoothed (tracking space)
static volatile LONG g_aimApplied = 0, g_aimExact = 0, g_aimDelta = 0, g_aimMiss = 0;
static float g_aimBlend = 0.f; static long long g_aimBlendT = 0;

static void RecRows(const char* rec, float o[12]) {   // rows 0..2 xyz, then the position
    const float* m = (const float*)(rec + 0x20);
    for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) o[r * 3 + c] = m[r * 4 + c];
    o[9] = m[12]; o[10] = m[13]; o[11] = m[14];
}
static Frame RecFrame(const float* r) {
    Frame f;
    for (int k = 0; k < 3; k++) { const float* v = r + 3 * g_recRow[k]; f.axis[k] = Norm(V3{ v[0], v[1], v[2] } * g_recSign[k]); }
    f.pos = { r[9], r[10], r[11] };
    return f;
}
static float FrameMatch(const Frame& a, const Frame& b) {   // smallest axis agreement (1 = identical orientation)
    float m = 1.f; for (int k = 0; k < 3; k++) m = fminf(m, Dot(a.axis[k], b.axis[k])); return m;
}
static bool HeadAimWanted() {
    int m = g_cam.headAim;
    if (m == 1) return true;
    if (m != 2) return false;
    if (PadsLTHeld()) return true;
    DWORD pid = 0; GetWindowThreadProcessId(GetForegroundWindow(), &pid);
    bool swap = GetSystemMetrics(SM_SWAPBUTTON) != 0;
    return pid == GetCurrentProcessId() && (GetAsyncKeyState(swap ? VK_LBUTTON : VK_RBUTTON) & 0x8000);
}
static void __fastcall H_CamApply(void* mgr, char* rec) {
    AimEntry e = {}; bool keep = false;
    if (rec && game::Readable(rec + 0x20, 0x54)) {
        RecRows(rec, e.clean); memcpy(e.rot, e.clean, sizeof e.rot); e.t = (long long)modtime::Now100ns(); keep = true;
        // 0.6.38: did the GAME move its camera? The record as the game handed it over, compared with the last one and
        // with what the head aim wrote into it last time (a record the game did not rewrite still holds our turn).
        // The flat-screen rules (pause menu, video) use this while the head aim turns the camera - the node's camera
        // follows the head then, and a pause menu read as "the camera moves" (photo mode) and stayed in VR: the
        // headset showed the paused world frozen while the desktop showed the menu.
        {
            static float s_prevClean[12], s_prevWritten[12]; static bool s_have = false;
            if (s_have && memcmp(e.clean, s_prevClean, sizeof s_prevClean) && memcmp(e.clean, s_prevWritten, sizeof s_prevWritten))
                g_gameRecMove100ns = e.t;
            memcpy(s_prevClean, e.clean, sizeof s_prevClean); s_have = true;
            g_aimPrevWritten = s_prevWritten;
        }
        // blend in / out over ~0.12 s (no snap when L2 is pressed or released)
        bool vr = g_cam.mode != VRMODE_SCREEN && !g_cam.flatNow && g_cam.havePose && xrb::ClientHostConnected();
        float target = vr && HeadAimWanted() ? 1.f : 0.f;
        float dt = g_aimBlendT ? (float)(e.t - g_aimBlendT) * 1e-7f : 0.f; g_aimBlendT = e.t;
        if (!(dt > 0.f && dt < 0.25f)) dt = 0.f;
        float a = 1.f - expf(-dt / 0.04f);
        g_aimBlend += (target - g_aimBlend) * a;
        if (target == 0.f && g_aimBlend < 0.01f) { g_aimBlend = 0.f; g_aimSmoothHave = false; }
        xrb::IpcPose pose[2]; xrb::IpcFov fov[2]; int64_t pt = 0;
        if (g_aimBlend > 0.f && xrb::ClientGetLatestPoses(pose, fov, &pt) && (pose[0].qw || pose[0].qx || pose[0].qy || pose[0].qz)) {
            Frame cam = RecFrame(e.clean);
            if (g_recMapLearned && FrameValid(cam)) {
                Frame base;   // the rendered base frame (decoupled pitch, first person, offsets) for this camera
                float rel[3][3], relP[3];
                AcquireSRWLockShared(&g_aimLock); memcpy(rel, g_aimRel, sizeof rel); memcpy(relP, g_aimRelPos, sizeof relP); ReleaseSRWLockShared(&g_aimLock);
                for (int k = 0; k < 3; k++) base.axis[k] = cam.axis[0] * rel[0][k] + cam.axis[1] * rel[1][k] + cam.axis[2] * rel[2][k];
                base.pos = cam.pos + cam.axis[0] * relP[0] + cam.axis[1] * relP[1] + cam.axis[2] * relP[2];
                float hq[4]; HeadQuat(pose, hq);
                float R[3][3]; QuatToMat(hq[0], hq[1], hq[2], hq[3], R);
                // the head's forward in its own (tracking) space, smoothed there - a stick turn of the camera is never
                // lagged, only head tremor is filtered (time based: the same feel at any frame rate)
                V3 hf = { -R[0][2], -R[1][2], -R[2][2] };
                float sm = g_cam.headAimSmooth;
                if (sm > 0.01f && g_aimSmoothHave) {   // no time passed (same clock tick): keep the filtered value
                    if (dt > 0.f) { float k = 1.f - expf(-dt / (0.15f * sm)); g_aimSmoothDir = Norm(g_aimSmoothDir + (hf - g_aimSmoothDir) * k); }
                } else g_aimSmoothDir = hf;
                g_aimSmoothHave = true;
                V3 lf = g_aimSmoothDir;
                V3 fwd = Norm(base.axis[0] * lf.x + base.axis[1] * lf.y + base.axis[2] * lf.z), camFwd = cam.axis[2] * -1.f;
                fwd = Norm(camFwd * (1.f - g_aimBlend) + fwd * g_aimBlend);
                V3 up0 = { 0, 0, 1 };   // world up (Z): the aim keeps the horizon level (no head roll)
                V3 right = Cross(fwd, up0);
                if (Len(right) < 1e-3f) right = cam.axis[0]; else right = Norm(right);
                if (Dot(right, cam.axis[0]) < -0.5f && Dot(fwd, camFwd) > 0.f) right = right * -1.f;   // never flip sides
                V3 up = Norm(Cross(right, fwd));
                // aim from the eyes: the shot starts where the player's eyes are drawn (first person: in the head), so
                // it hits exactly what the player looks at - not from the third-person camera behind
                V3 aimPos = cam.pos;
                if (g_cam.headAimFromEyes) {
                    float s = g_cam.unitsPerMetre * g_cam.worldScale;
                    V3 hp = { 0.5f * (pose[0].px + pose[1].px) * s, 0.5f * (pose[0].py + pose[1].py) * s, 0.5f * (pose[0].pz + pose[1].pz) * s };
                    V3 eyes = base.pos + base.axis[0] * hp.x + base.axis[1] * hp.y + base.axis[2] * hp.z;
                    // first person: the eyes are inside Star-Lord's head - start 0.25 m further along the aim, clear of
                    // his own head / collision (the same ray: what is hit does not change, except within 25 cm)
                    if (g_cam.fpActive) eyes = eyes + fwd * (0.25f * g_cam.unitsPerMetre);
                    aimPos = cam.pos + (eyes - cam.pos) * g_aimBlend;
                }
                Frame aim; aim.axis[0] = right; aim.axis[1] = up; aim.axis[2] = fwd * -1.f; aim.pos = aimPos;
                if (FrameValid(aim)) {
                    float* m = (float*)(rec + 0x20);
                    for (int k = 0; k < 3; k++) {
                        int r = g_recRow[k]; float s = g_recSign[k];
                        float len = sqrtf(m[r * 4] * m[r * 4] + m[r * 4 + 1] * m[r * 4 + 1] + m[r * 4 + 2] * m[r * 4 + 2]); if (!(len > 1e-6f)) len = 1.f;
                        m[r * 4] = aim.axis[k].x * s * len; m[r * 4 + 1] = aim.axis[k].y * s * len; m[r * 4 + 2] = aim.axis[k].z * s * len;
                    }
                    m[12] = aim.pos.x; m[13] = aim.pos.y; m[14] = aim.pos.z;
                    RecRows(rec, e.rot); e.turned = true; g_aimLastTurned = e.t;
                    InterlockedIncrement(&g_aimApplied);
                }
            }
        }
    }
    if (keep && g_aimPrevWritten) memcpy(g_aimPrevWritten, e.rot, sizeof e.rot);   // what the game's record holds now
    if (keep) {
        AcquireSRWLockExclusive(&g_aimLock);
        memmove(&g_aim[1], &g_aim[0], sizeof(AimEntry) * 7); g_aim[0] = e; if (g_aimN < 8) g_aimN++;
        ReleaseSRWLockExclusive(&g_aimLock);
    }
    o_CamApply(mgr, rec);
}
// render thread, when the game wrote a new camera into the node: the camera without the head aim turn (clean = T as
// read; replaced when the node carries a turned record). Also learns how the record's rows map onto the node's axes.
static void HeadAimUnturn(float* clean) {
    if (!o_CamApply) return;
    AimEntry ring[8]; int n;
    AcquireSRWLockShared(&g_aimLock); n = g_aimN; memcpy(ring, g_aim, sizeof(AimEntry) * n); ReleaseSRWLockShared(&g_aimLock);
    if (!n) return;
    Frame t = ReadFrame(clean);
    if (!g_recMapLearned) {   // from an unturned record that is what the node shows: which row is which axis
        for (int i = 0; i < n; i++) {
            if (ring[i].turned) continue;
            int row[3]; float sg[3]; bool ok = true;
            for (int k = 0; k < 3 && ok; k++) {
                float best = 0.f; row[k] = -1;
                for (int r = 0; r < 3; r++) {
                    V3 v = Norm(V3{ ring[i].clean[r * 3], ring[i].clean[r * 3 + 1], ring[i].clean[r * 3 + 2] });
                    float d = Dot(v, t.axis[k]);
                    if (fabsf(d) > fabsf(best)) { best = d; row[k] = r; }
                }
                sg[k] = best < 0.f ? -1.f : 1.f;
                ok = row[k] >= 0 && fabsf(best) > 0.999f;
            }
            if (ok && row[0] != row[1] && row[1] != row[2] && row[0] != row[2]) {
                for (int k = 0; k < 3; k++) { g_recRow[k] = row[k]; g_recSign[k] = sg[k]; }
                g_recMapLearned = true;
                LOGI("camera: head aim - camera record rows -> view axes: right = %crow %d, up = %crow %d, back = %crow %d",
                     sg[0] < 0 ? '-' : '+', row[0], sg[1] < 0 ? '-' : '+', row[1], sg[2] < 0 ? '-' : '+', row[2]);
                break;
            }
        }
    }
    if (!g_aimLastTurned || (long long)modtime::Now100ns() - g_aimLastTurned > 5000000) return;   // head aim not used lately
    int best = -1; float bm = 0.f;
    for (int i = 0; i < n; i++) {
        Frame r = RecFrame(ring[i].rot);
        float m = FrameMatch(r, t);
        if (Len(r.pos - t.pos) > 1e-3f * (1.f + Len(t.pos))) m -= 1.f;   // the position must match too
        if (m > bm) { bm = m; best = i; }
    }
    if (best >= 0 && bm > 0.99995f) {   // the node shows this record exactly
        if (!ring[best].turned) return;
        Frame c = RecFrame(ring[best].clean), r = RecFrame(ring[best].rot);
        c.pos = t.pos + (c.pos - r.pos);   // aim from the eyes moved the camera too: back by the same amount
        WriteFrame(clean, c); InterlockedIncrement(&g_aimExact); return;
    }
    // not exact (the engine may add to the record on the way): take the newest turn back in the camera's own frame
    for (int i = 0; i < n; i++) {
        if (!ring[i].turned) continue;
        Frame fr = RecFrame(ring[i].rot), fc = RecFrame(ring[i].clean);
        if (FrameMatch(fr, t) < 0.95f) break;   // too far from what the node shows - leave it
        float D[3][3]; for (int j = 0; j < 3; j++) for (int k = 0; k < 3; k++) D[j][k] = Dot(fr.axis[j], fc.axis[k]);
        Frame c; for (int k = 0; k < 3; k++) c.axis[k] = t.axis[0] * D[0][k] + t.axis[1] * D[1][k] + t.axis[2] * D[2][k];
        c.pos = t.pos + (fc.pos - fr.pos);
        if (FrameValid(c)) { WriteFrame(clean, c); InterlockedIncrement(&g_aimDelta); return; }
        break;
    }
    InterlockedIncrement(&g_aimMiss);
}
// render thread: how the drawn base frame sits in the game camera's frame (decoupled pitch, first person, ...)
static void HeadAimNoteBase(const float* clean, const Frame& base) {
    if (!o_CamApply) return;
    Frame c = ReadFrame(clean);
    float rel[3][3]; for (int j = 0; j < 3; j++) for (int k = 0; k < 3; k++) rel[j][k] = Dot(c.axis[j], base.axis[k]);
    V3 d = base.pos - c.pos; float rp[3] = { Dot(d, c.axis[0]), Dot(d, c.axis[1]), Dot(d, c.axis[2]) };
    AcquireSRWLockExclusive(&g_aimLock); memcpy(g_aimRel, rel, sizeof rel); memcpy(g_aimRelPos, rp, sizeof rp); ReleaseSRWLockExclusive(&g_aimLock);
}

// ---------------------------------------------------------------- hooks
// the eye whose pose is in the main node right now. Besides the view update, three more passes read node+0x24 with
// the getter (keepDepth = 1): the skin blur post filter (exe+8C6350), a post filter pass (exe+8CA170) and exe+9B3137.
// They get the same eye frustum, so screen-space work matches the picture (DXMDVR 0.5.5 lesson).
static volatile int g_nodeEye = 0; static volatile bool g_nodeMono = false; static volatile bool g_nodePosed = false;

static bool s_moved = false;
// stereo reconstruction: the projection the view update gets from the getter (keepDepth = 0) - the depth buffer's
static thread_local bool tl_capProj = false, tl_projGot = false;
static thread_local float tl_proj[16];
// 0.6.14: the node's own projection (node+0xC0). The 0.6.13 log + exe: the renderer builds the main view from it in
// TWO places - the view update (exe+990CB0, through the getter exe+972270, which the mod patched) and the render-view
// setup exe+98DC70 (called from exe+A703BD / A71CAC), which copies node+0xC0 directly and only adds the TAA jitter.
// That second copy is the game's own projection: its field of view and its symmetric frustum - why the picture never
// matched the headset ("wide", "weird", the off-centre terms ignored) and a 10 % larger FOV setting felt right.
// The node's projection itself now carries the eye's frustum (x / y terms; depth rows kept), so every path agrees.
static float s_nodeProjClean[16]; static float s_nodeProjWritten[16]; static void* s_nodeProjNode = nullptr; static bool s_nodeProjHave = false;
static void NodeProjPatch(void* node, const float* t) {
    float* P = (float*)((char*)node + game::kNodeProj);
    if (!game::Readable(P, 64)) return;
    if (s_nodeProjNode != node || !s_nodeProjHave || memcmp(P, s_nodeProjWritten, 64)) {   // the game's own (new) one
        memcpy(s_nodeProjClean, P, 64); s_nodeProjNode = node; s_nodeProjHave = true;
    }
    if (!(fabsf(s_nodeProjClean[11] + 1.f) < 1e-3f && s_nodeProjClean[0] > 0.f && s_nodeProjClean[5] > 0.f)) return;   // perspective only
    float w = t[1] - t[0], h = t[2] - t[3];
    if (!(w > 0.05f && h > 0.05f)) return;
    float Q[16]; memcpy(Q, s_nodeProjClean, 64);
    Q[0] = 2.f / w; Q[5] = 2.f / h; Q[1] = Q[4] = 0.f;
    Q[8] = (t[1] + t[0]) / w; Q[9] = (t[2] + t[3]) / h;
    memcpy(P, Q, 64); memcpy(s_nodeProjWritten, Q, 64);
    g_cam.nodeProjWrites++;
}
static void NodeProjRestore(void* node) {
    if (!s_nodeProjHave || s_nodeProjNode != node) return;
    float* P = (float*)((char*)node + game::kNodeProj);
    if (game::Readable(P, 64) && !memcmp(P, s_nodeProjWritten, 64)) memcpy(P, s_nodeProjClean, 64);
    s_nodeProjHave = false;
}

static uintptr_t __fastcall H_NodeUpdate(void* node, void* ctx, void* view, uintptr_t n) {
    g_cam.nodeUpdates++;
    RenderedEye reconRec; bool reconPush = false, reconReplace = false;
    Tally(node);
    bool vr = node == g_mainNode && g_cam.mode != VRMODE_SCREEN && !g_cam.flatNow && xrb::ClientHostConnected() && FetchPoses();
    float* T = (float*)((char*)node + game::kNodeTransform);
    if (node == g_mainNode && game::Readable(T, 48)) {
        if (g_rec.node != node || !g_rec.have || memcmp(T, g_rec.written, 48)) {   // the game wrote a new camera
            memcpy(g_rec.clean, T, 48); HeadAimUnturn(g_rec.clean); g_rec.node = node; g_rec.have = true; g_cam.resyncs++;
        }
        static float s_lastClean[12];
        s_moved = memcmp(g_rec.clean, s_lastClean, 48) != 0;
        {   // 0.6.38: while the head aim turns the camera (last 1 s), the node follows the head - the game's own record says
            // whether the GAME moved it
            long long nw = (long long)modtime::Now100ns();
            bool aimTurning = o_CamApply && g_aimLastTurned && nw - g_aimLastTurned < 10000000;
            if (aimTurning) { if (g_gameRecMove100ns > g_lastMove100ns) g_lastMove100ns = g_gameRecMove100ns; }
            else if (s_moved) g_lastMove100ns = nw;
        }
        memcpy(s_lastClean, g_rec.clean, 48);
        if (!vr) { g_nodePosed = false; NodeProjRestore(node);   // VR off: give the game's own camera back (once)
            if (memcmp(T, g_rec.clean, 48)) memcpy(T, g_rec.clean, 48);
            memcpy(g_rec.written, T, 48);
        }
    }
    if (vr && g_rec.have && g_rec.node == node) {
        g_cam.mainUpdates++;
        bool reconC = g_cam.mode == VRMODE_RECON && g_cam.reconCentre;   // drawn like head mode, both eyes rebuilt
        bool mono = g_cam.mode == VRMODE_HEAD || reconC;
        bool synced = g_cam.mode == VRMODE_SYNCED && game::g_gameTimer && o_TimerUpdate;
        bool replace = false;
        int eye = NextEye(replace);
        if (mono) eye = 0;
        bool held = false;
        if (synced) {   // eye from the clock: a fresh tick = first eye, its held twin = second eye
            bool clockHeld = RenderFrameIsHeld(s_moved);
            // 0.6.40: no clock to pair with - the game paused its clock (inventory with its 3D character models, photo
            // mode) or stopped ticking, while VR frames are still drawn. Every frame was a first eye then: the headset
            // waited for pairs that never came (0.6.39 log, inventory: "eyes drawn LLLLLLLL", 685 first eyes held, 93
            // pairs in 10 s - frozen in VR, fine on the desktop). The world is frozen anyway, so the eyes alternate
            // frame by frame and every second one completes the pair. Also taken when 4 first eyes in a row found no
            // held twin (any other cause); back to the clock as soon as it holds a tick again.
            long long nw = (long long)modtime::Now100ns();
            bool noClock = g_gamePaused || nw - g_pausedSeen > 1000000;
            static int s_firstRun = 0; static bool s_alt = false;
            if (clockHeld) s_firstRun = 0; else s_firstRun++;
            bool want = noClock || (s_alt && !clockHeld) || s_firstRun >= 4;
            if (want != s_alt) {
                s_alt = want;
                LOGI("camera: synchronized stereo: %s", want ? (noClock ? "the game clock is paused / stopped while VR is drawn (inventory, photo mode) - the eyes alternate frame by frame"
                                                                      : "no held twin for 4 frames - the eyes alternate frame by frame")
                                                          : "the game clock runs again - eyes paired by the clock");
            }
            held = s_alt ? eye == 1 : clockHeld;   // NextEye above already alternated the eye
            if (s_alt) g_syncAltFrames++;
            eye = held ? 1 : 0; g_lastEye = eye;
            if (held) g_cam.syncPairs++;
        }
        bool reconm = g_cam.mode == VRMODE_RECON;
        if (reconm && !g_cam.reconAlternate) { eye = 0; g_lastEye = 0; }   // recon_eye = left: always draw the left eye
        int pe = g_cam.swapEyes ? eye ^ 1 : eye;    // swap: the left image is drawn from the right eye
        auto eyePose = [&](int e) {
            xrb::IpcPose p = g_cam.pose[e];
            if (mono) {   // head = midpoint of the eyes, orientation halfway between them (HeadQuat)
                p.px = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px); p.py = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py);
                p.pz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                float hq[4]; HeadQuat(g_cam.pose, hq); p.qx = hq[0]; p.qy = hq[1]; p.qz = hq[2]; p.qw = hq[3];
            } else if (g_cam.ipdScale != 1.f) {   // ipd_scale: eye position moved towards / away from the head centre
                float cx = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px), cy = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py), cz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                p.px = cx + (p.px - cx) * g_cam.ipdScale; p.py = cy + (p.py - cy) * g_cam.ipdScale; p.pz = cz + (p.pz - cz) * g_cam.ipdScale;
            }
            return p;
        };
        xrb::IpcPose p = eyePose(pe);
        // what the headset gets with the image: the real eye pose (ipd_scale changes how the game draws, not where your
        // eyes are - the runtime must reproject from where the eyes really were)
        auto realPose = [&](int e) {
            xrb::IpcPose q = g_cam.pose[e];
            if (mono) { q.px = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px); q.py = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py); q.pz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                        float hq[4]; HeadQuat(g_cam.pose, hq); q.qx = hq[0]; q.qy = hq[1]; q.qz = hq[2]; q.qw = hq[3]; }
            return q;
        };
        static float s_pairBase[12]; static bool s_havePair = false;
        if (synced && !held) { memcpy(s_pairBase, g_rec.clean, 48); s_havePair = true; }
        // the second eye of a tick: the first eye's camera (input can still turn the camera on a held tick)
        Frame base = CameraBase(ReadFrame(synced && held && s_havePair ? s_pairBase : g_rec.clean));
        base = Stabilize(base, synced && held);
        base = Settle(base, synced && held);
        HeadAimNoteBase(synced && held && s_havePair ? s_pairBase : g_rec.clean, base);
        float R[3][3]; QuatToMat(p.qx, p.qy, p.qz, p.qw, R);
        float s = g_cam.unitsPerMetre * g_cam.worldScale;
        Frame fr = Compose(base, R, V3{ p.px * s, p.py * s, p.pz * s });
        if (FrameValid(fr) && FrameValid(base)) {
            WriteFrame(T, fr); memcpy(g_rec.written, T, 48);
            g_cam.posesApplied++;
            g_nodeEye = pe; g_nodeMono = mono; g_nodePosed = true;
            NodeProjPatch(node, mono ? g_cam.monoTan : CameraDrawTan(pe));
            g_cam.curEye = pe; g_cam.curMono = mono;
            // the game camera's own rotation rate (camera_reprojection): R_prev^T R_cur as axis-angle / dt, in the
            // camera's frame = the head reference space
            long long now = (long long)modtime::Now100ns();
            if (g_prevBaseTick && now > g_prevBaseTick) {
                float M[3][3];   // relative rotation in the previous camera frame
                for (int i = 0; i < 3; i++) for (int j = 0; j < 3; j++) {
                    V3 a = { g_prevBase[i][0], g_prevBase[i][1], g_prevBase[i][2] };
                    M[i][j] = Dot(a, base.axis[j]);
                }
                float tr = M[0][0] + M[1][1] + M[2][2], ang = acosf(fmaxf(-1.f, fminf(1.f, (tr - 1.f) * 0.5f)));
                float dt = (float)(now - g_prevBaseTick) * 1e-7f;
                float ax[3] = { M[2][1] - M[1][2], M[0][2] - M[2][0], M[1][0] - M[0][1] };
                float al = sqrtf(ax[0] * ax[0] + ax[1] * ax[1] + ax[2] * ax[2]);
                for (int k = 0; k < 3; k++) g_angVel[k] = (al > 1e-6f && dt > 1e-4f && dt < 0.2f) ? -ax[k] / al * ang / dt : 0.f;
            }
            for (int k = 0; k < 3; k++) { g_prevBase[k][0] = base.axis[k].x; g_prevBase[k][1] = base.axis[k].y; g_prevBase[k][2] = base.axis[k].z; }
            g_prevBaseTick = now;
            RenderedEye r;
            r.seq = ++g_seq; r.eye = eye; r.mono = mono && !reconC; r.pose = realPose(pe);
            r.drawEye = pe; r.drawMono = mono;
            r.synced = synced; r.pairEnd = !synced || held || !g_cam.syncPairSubmit;
            r.fov = TanToFov(mono ? g_cam.monoTan : CameraDrawTan(pe));
            { int64_t t = 0; xrb::IpcPose tmp[2]; xrb::IpcFov tf[2]; xrb::ClientGetLatestPoses(tmp, tf, &t); r.time = t; }
            r.tick = now;
            for (int k = 0; k < 3; k++) r.angVel[k] = g_cam.cameraReprojection ? g_angVel[k] : 0.f;
            if (reconC) {   // both eyes from the same head pose, rebuilt from the centre view
                r.recon = true; r.centre = true; r.physEye = 0; r.eye = 1;   // eye 1 "drawn" -> the first rebuild is eye 0
                memcpy(r.nodeD, T, 48);
                memcpy(r.tanD, g_cam.monoTan, 16);
                for (int e = 0; e < 2; e++) {
                    xrb::IpcPose pd = g_cam.pose[e];
                    // ipd_scale x recon_parallax (0.6.13): the rebuilt eyes moved towards / away from the head centre
                    float ks = g_cam.ipdScale * (g_set.reconParallax >= 0.f && g_set.reconParallax <= 3.f ? g_set.reconParallax : 1.f);
                    if (ks != 1.f) {
                        float cx = 0.5f * (g_cam.pose[0].px + g_cam.pose[1].px), cy = 0.5f * (g_cam.pose[0].py + g_cam.pose[1].py), cz = 0.5f * (g_cam.pose[0].pz + g_cam.pose[1].pz);
                        pd.px = cx + (pd.px - cx) * ks; pd.py = cy + (pd.py - cy) * ks; pd.pz = cz + (pd.pz - cz) * ks;
                    }
                    float Re[3][3]; QuatToMat(pd.qx, pd.qy, pd.qz, pd.qw, Re);
                    Frame fe = Compose(base, Re, V3{ pd.px * s, pd.py * s, pd.pz * s });
                    float Te[12]; memcpy(Te, T, 48); WriteFrame(Te, fe);
                    if (e == 0) { memcpy(r.nodeO, Te, 48); memcpy(r.tanO, g_cam.eyeTan[0], 16); r.poseO = g_cam.pose[0]; r.fovO = TanToFov(g_cam.eyeTan[0]); }
                    else { memcpy(r.nodeO1, Te, 48); memcpy(r.tanO1, g_cam.eyeTan[1], 16); r.poseO1 = g_cam.pose[1]; r.fovO1 = TanToFov(g_cam.eyeTan[1]); }
                }
                r.fov = TanToFov(g_cam.monoTan);
                reconRec = r; reconPush = true; reconReplace = replace;
            } else if (reconm) {   // the other eye from the same head pose, and (below) the projection the renderer gets
                r.recon = true; r.physEye = pe;
                memcpy(r.nodeD, T, 48);
                xrb::IpcPose po = eyePose(pe ^ 1);   // drawn with (ipd_scale) ...
                r.poseO = realPose(pe ^ 1);          // ... shown with (the real eye)
                float Ro[3][3]; QuatToMat(po.qx, po.qy, po.qz, po.qw, Ro);
                Frame fo = Compose(base, Ro, V3{ po.px * s, po.py * s, po.pz * s });
                float To[12]; memcpy(To, T, 48); WriteFrame(To, fo); memcpy(r.nodeO, To, 48);
                memcpy(r.tanD, CameraDrawTan(pe), 16); memcpy(r.tanO, g_cam.eyeTan[pe ^ 1], 16);
                r.fovO = TanToFov(g_cam.eyeTan[pe ^ 1]);
                reconRec = r; reconPush = true; reconReplace = replace;
            } else Push(r, replace);
            g_cam.lastVrSeq = g_presents;
        } else g_cam.badMatrix++;
    }
    // 0.6.19: the near clip also on the camera node itself (+0x1D0): since 0.6.14 the picture is drawn from the node's
    // own projection, which the getter's near override never reached (the 0.6.18 log: near_clip 0.30 set, the node
    // kept the game's 0.05-0.15 m). Only ever made closer than the game's, so nothing near you is cut
    // 0.6.25: OFF. The Epic / SteamVR log with near_clip 0.05 shows the node near written every frame and the player
    // reports "lighting destroyed": the game also keeps the near plane elsewhere (its lighting / depth reconstruction),
    // so a near plane changed only here makes the picture's depth and the lighting disagree. The game's own near plane
    // (0.05 - 0.15 m) is used.
    if (false && vr && node == g_mainNode && g_cam.nearClip > 0.f) {
        float* nn = (float*)((char*)node + 0x1D0);
        float want = g_cam.nearClip * g_cam.unitsPerMetre;
        if (game::Readable(nn, 8) && *nn > want && *nn < 10.f * g_cam.unitsPerMetre && nn[1] > *nn) { *nn = want; g_cam.nearWrites++; }
    }
    tl_capProj = reconPush; tl_projGot = false;
    uintptr_t ret = o_NodeUpdate(node, ctx, view, n);
    tl_capProj = false;
    if (g_nodePosed && node == g_mainNode && s_nodeProjHave && s_nodeProjNode == node) {   // the update may rebuild it
        float* P = (float*)((char*)node + game::kNodeProj);
        if (game::Readable(P, 64) && memcmp(P, s_nodeProjWritten, 64)) {
            memcpy(s_nodeProjClean, P, 64);
            NodeProjPatch(node, g_nodeMono ? g_cam.monoTan : CameraDrawTan(g_nodeEye));
            g_cam.nodeProjRebuilt++;
        }
    }
    if (reconPush) {
        if (tl_projGot) { memcpy(reconRec.proj, tl_proj, 64); reconRec.projOk = true; }
        Push(reconRec, reconReplace);
    }
    return ret;
}

// x / y terms of the projection = the eye's frustum; the game's depth rows and TAA jitter are kept
static float* __fastcall H_GetProj(void* node, float* out, uintptr_t keep) {
    float* r = o_GetProj(node, out, keep);
    // 0.6.37 (culling notes, every VR mod: "log whether the culling help is active and WHY not"): the frustum-culling
    // record's calls are counted by outcome - head-turned + covered, or the reason it got the game's own frustum
    uintptr_t ra0 = (uintptr_t)__builtin_return_address(0);
    bool cullRec = game::g_cullRecRet && ra0 == game::g_cullRecRet;
    if (cullRec) g_cam.cullAll++;
    if (!out) return r;
    if (node != g_mainNode) { if (cullRec) g_cam.cullOtherNode++; return r; }   // another camera (shadow, reflection, UI 3D)
    if (!g_nodePosed || !g_rec.have) { if (cullRec) g_cam.cullNotPosed++; return r; }   // flat / not VR this frame
    if (memcmp((char*)node + game::kNodeTransform, g_rec.written, 48)) { if (cullRec) g_cam.cullGameCam++; return r; }   // the game's own camera is back in the node
    if (!(fabsf(out[11] + 1.f) < 1e-3f && out[0] > 0.f && out[5] > 0.f)) { if (cullRec) g_cam.cullNotPersp++; return r; }   // perspective only
    if (cullRec) g_cam.cullOk++;
    const float* t = g_nodeMono ? g_cam.monoTan : CameraDrawTan(g_nodeEye);
    // 0.6.17 wide culling: the picture is drawn from the node's projection (node+0xC0, set per eye in NodeProjPatch);
    // this getter feeds the rest (visibility / shadow-caster culling, LOD), which takes a SYMMETRIC frustum from the x / y
    // scale and ignores the off-centre terms - an eye's outer side was culled (pop-in at the sides). Those get one
    // symmetric frustum that covers the eye's own; the render stays at the headset's size and shape.
    float tc[4];
    // 0.6.27: every getter call of the camera gets the covering frustum again (as 0.6.17-0.6.23, the versions without
    // pop-in). 0.6.24 kept it for keep = 0 only, on the guess that the keep = 1 callers were screen-space passes - but
    // exe+8CA170 is the frustum-culling record the render lists cull with (0.6.25 / 0.6.26: pop-in back). The picture
    // itself is drawn from node+0xC0 (exact per eye), not from this getter.
    uintptr_t ra = (uintptr_t)__builtin_return_address(0);
    if (game::g_cullRecRet && ra == game::g_cullRecRet) g_cam.cullVpCalls++; else if (keep) g_cam.screenProjCalls++;
    if (g_cam.wideCull && !g_cam.symmetricView) {
        float X = fmaxf(-t[0], t[1]), Y = fmaxf(t[2], -t[3]);
        tc[0] = -X; tc[1] = X; tc[2] = Y; tc[3] = -Y; t = tc;
        g_cam.wideCullCalls++;
    }
    float w = t[1] - t[0], h = t[2] - t[3];
    if (!(w > 0.05f && h > 0.05f)) return r;
    out[0] = 2.f / w; out[5] = 2.f / h;
    out[8] += (t[1] + t[0]) / w;
    out[9] += (t[2] + t[3]) / h;
    out[4] = out[1] = 0.f;
    g_cam.projPatched++;
    if (tl_capProj && !keep && !tl_projGot) { memcpy(tl_proj, out, 64); tl_projGot = true; }
    return r;
}

bool CameraInstall() {
    bool ok = true;
    if (game::g_nodeUpdate && MH_CreateHook(game::g_nodeUpdate, (void*)H_NodeUpdate, (void**)&o_NodeUpdate) == MH_OK &&
        MH_EnableHook(game::g_nodeUpdate) == MH_OK) LOGI("camera: view update hooked");
    else { LOGE("camera: view update hook FAILED - no head tracking"); ok = false; }
    if (game::g_timerUpdate && game::g_gameTimer && MH_CreateHook(game::g_timerUpdate, (void*)H_TimerUpdate, (void**)&o_TimerUpdate) == MH_OK &&
        MH_EnableHook(game::g_timerUpdate) == MH_OK) LOGI("camera: game clock hooked (synchronized stereo available)");
    else LOGW("camera: game clock hook not in place - synchronized stereo works as alternate-eye");
    if (game::g_camApply && MH_CreateHook(game::g_camApply, (void*)H_CamApply, (void**)&o_CamApply) == MH_OK && MH_EnableHook(game::g_camApply) == MH_OK)
        LOGI("camera: camera record hook in place (head aim available)");
    else LOGW("camera: camera record not found - head aim off");
    if (game::g_getProj && MH_CreateHook(game::g_getProj, (void*)H_GetProj, (void**)&o_GetProj) == MH_OK && MH_EnableHook(game::g_getProj) == MH_OK)
        LOGI("camera: projection getter hooked");
    else LOGE("camera: projection hook FAILED - the game's own FOV is used (stereo will be wrong)");
    return ok;
}

void CameraReport() {
    LOGI("camera: node updates %u, main %u, poses applied %u, projections patched %u (wide culling %u calls: frustum-culling records %u, other keep=1 calls %u), game camera writes %u, bad matrices %u, node switches %u",
         g_cam.nodeUpdates, g_cam.mainUpdates, g_cam.posesApplied, g_cam.projPatched, g_cam.wideCullCalls, g_cam.cullVpCalls, g_cam.screenProjCalls, g_cam.resyncs, g_cam.badMatrix, g_cam.nodeSwitches);
    g_cam.wideCullCalls = 0; g_cam.cullVpCalls = 0; g_cam.screenProjCalls = 0;
    if (g_cam.cullAll) {
        const char* why = g_cam.cullOk ? "" : !CameraFrameIsVR() ? " - flat screen / not in VR (expected)" :
                          g_cam.cullOtherNode == g_cam.cullAll ? " - the frustum culling runs on a camera the mod does not track (main camera lost?)" :
                          g_cam.cullGameCam ? " - the game's own camera was back in the render node" : " - see the counts";
        LOGI("culling: frustum-culling calls %u - head-turned + covering frustum %u%s | not: other camera nodes %u, VR not posing %u, game camera back %u, not perspective %u%s",
             g_cam.cullAll, g_cam.cullOk, g_cam.symmetricView ? " (symmetric view: both eyes draw one covering frustum)" : g_cam.wideCull ? "" : " (wide culling off: the eye's own frustum)",
             g_cam.cullOtherNode, g_cam.cullNotPosed, g_cam.cullGameCam, g_cam.cullNotPersp, why);
    } else if (game::g_cullRecRet && CameraFrameIsVR()) LOGW("culling: the frustum-culling record was not called this period (VR on) - the culling help cannot act");
    else if (!game::g_cullRecRet) { static bool said = false; if (!said) { said = true; LOGW("culling: the frustum-culling call site was not found on this exe - the culling help still acts (every main-camera projection call), only this count is missing"); } }
    g_cam.cullAll = g_cam.cullOtherNode = g_cam.cullNotPosed = g_cam.cullGameCam = g_cam.cullNotPersp = g_cam.cullOk = 0;
    if (g_cam.headAim || g_aimApplied)
        LOGI("camera: head aim %s - aim turned %ld times, taken out of the view %ld exact / %ld from the turn, not found %ld",
             g_cam.headAim == 1 ? "always" : g_cam.headAim == 2 ? "while aiming" : "off", InterlockedExchange(&g_aimApplied, 0), InterlockedExchange(&g_aimExact, 0), InterlockedExchange(&g_aimDelta, 0), InterlockedExchange(&g_aimMiss, 0));
    if (s_nodeProjHave) LOGI("camera: node projection (what every render path uses) set %u times, rebuilt by the game after the mod %u | the game's own: x %.3f y %.3f -> FOV %.1f x %.1f deg; the mod's: x %.3f y %.3f off-centre %.3f %.3f | depth terms [10] %.4g [14] %.4g",
         g_cam.nodeProjWrites, g_cam.nodeProjRebuilt, s_nodeProjClean[0], s_nodeProjClean[5], 2.f * atanf(1.f / s_nodeProjClean[0]) * 57.2958f,
         2.f * atanf(1.f / s_nodeProjClean[5]) * 57.2958f, s_nodeProjWritten[0], s_nodeProjWritten[5], s_nodeProjWritten[8], s_nodeProjWritten[9], s_nodeProjClean[10], s_nodeProjClean[14]);
    LOGI("camera: main camera near %.4g far %.6g (engine units; near ~0.05-0.3 = metres)%s (node near written %u)", g_cam.nodeNear, g_cam.nodeFar,
         g_cam.nearClip > 0.f && CameraFrameIsVR() ? " - near clip set by the mod" : "", g_cam.nearWrites);
    g_cam.nearWrites = 0;
    LOGI("camera: frame FIFO: dropped %u, same-frame updates %u, Presents without a new frame %u | eye frusta L %.3f %.3f %.3f %.3f R %.3f %.3f %.3f %.3f",
         g_fifoDropped, g_fifoReplaced, g_fifoEmpty, g_cam.eyeTan[0][0], g_cam.eyeTan[0][1], g_cam.eyeTan[0][2], g_cam.eyeTan[0][3],
         g_cam.eyeTan[1][0], g_cam.eyeTan[1][1], g_cam.eyeTan[1][2], g_cam.eyeTan[1][3]);
    if (g_cam.mode == VRMODE_SYNCED)
        LOGI("camera: synchronized stereo: held ticks %u, second-eye frames %u, clock offset %u (base %d, scores %.0f %.0f %.0f)",
             g_cam.heldTicks, g_cam.syncPairs, g_cam.syncLagNow, g_lagC, g_lagScore[0], g_lagScore[1], g_lagScore[2]);
    if (g_syncAltFrames) LOGI("camera: synchronized stereo: %u frames with the eyes alternating (game clock paused / stopped - inventory, photo mode)", g_syncAltFrames);
    g_syncAltFrames = 0;
    g_cam.heldTicks = g_cam.syncPairs = 0;
    g_cam.nodeProjWrites = g_cam.nodeProjRebuilt = 0;
    g_cam.nodeUpdates = g_cam.mainUpdates = g_cam.posesApplied = g_cam.projPatched = g_cam.resyncs = g_cam.badMatrix = g_cam.nodeSwitches = 0;
    g_fifoDropped = g_fifoReplaced = g_fifoEmpty = 0;
}
