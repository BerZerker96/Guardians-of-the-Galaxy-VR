#include "modtime.h"
// 100 ms housekeeping thread: hotkeys, trigger files (<game>\GOTGVR\*.trigger), periodic stats.
#include <windows.h>
#include <string>
#include <cctype>
#include <cstdlib>
#include "log.h"
#include "camera.h"
#include "config.h"
#include "settings.h"
#include "firstperson.h"

extern std::wstring g_modDir, g_gameDir;
extern volatile LONG g_presents;
void XrReport();
void XrRequestRecenter();
void XrSetMode(int mode);
void MenuNoteFps(float fps);
void MenuSetOpen(bool open);
void ScreenshotRequest();
void SettingsApplyGame();

static bool Trigger(const wchar_t* name) {
    std::wstring p = g_modDir + L"\\" + name;
    if (GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) return false;
    DeleteFileW(p.c_str());
    return true;
}

// 0.6.28: the keys (recenter, screenshot, first person, F6 / F7 / F8) are hotkeys now - hotkeys.cpp, VR panel tab "Hotkeys"

void ModTick() {
    static DWORD last = (DWORD)ModTick64();
    static LONG lastPresents = 0;
    if (Trigger(L"mode_head.trigger")) XrSetMode(VRMODE_HEAD);
    if (Trigger(L"mode_screen.trigger")) XrSetMode(VRMODE_SCREEN);
    if (Trigger(L"mode_stereo.trigger")) XrSetMode(VRMODE_STEREO);
    if (Trigger(L"mode_synced.trigger")) XrSetMode(VRMODE_SYNCED);
    if (Trigger(L"mode_recon.trigger")) XrSetMode(VRMODE_RECON);
    if (Trigger(L"recenter.trigger")) XrRequestRecenter();
    if (Trigger(L"flat_hold.trigger")) g_cam.flatHold = !g_cam.flatHold;
    if (Trigger(L"first_person.trigger")) fp::Toggle();
    if (Trigger(L"screenshot.trigger")) ScreenshotRequest();
    if (Trigger(L"menu_open.trigger")) MenuSetOpen(true);
    if (Trigger(L"menu_close.trigger")) MenuSetOpen(false);
    DWORD now = (DWORD)ModTick64();
    if (now - last >= 10000) {
        LONG p = g_presents;
        float fps = (float)((p - lastPresents) * 1000.0 / (now - last));
        LOGI("stats: %.1f presents/s (%.1f per eye in stereo)", fps, (IsStereoMode(g_cam.mode) && g_cam.mode != VRMODE_RECON) ? fps * 0.5f : fps);
        MenuNoteFps(fps);
        lastPresents = p; last = now;
        XrReport();
        { extern void MouseInputReport(); MouseInputReport(); extern void PadInputReport(); PadInputReport(); }
    }
}
