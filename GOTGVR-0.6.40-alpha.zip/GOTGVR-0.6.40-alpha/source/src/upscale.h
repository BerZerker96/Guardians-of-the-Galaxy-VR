#pragma once
// 0.6.35: the game's upscalers, as dismantled from GOTG.exe (Steam / Epic / FuckTAA builds alike).
//
//   PC settings block (exe+3E603A0 Steam, exe+3E750E0 Epic), with the game's own option ids:
//     +0x24 DynResType   0x51B  dynamic resolution (menu row UI_OPTION_DISPLAY_DYNAMIC_RESOLUTION)
//     +0x28 DlssQuality  0x51D  DLSS: 0 DLSS_OFF, then the quality modes (row UI_OPTION_DISPLAY_DLSS) - TEMPORAL
//     +0x30 DlssSharpening
//     +0x38 ResScale     0x51A  resolution scale, percent (float)
//     +0x64 FSRQuality   0x520  AMD FSR 1.0 (ZRenderPostfilterPassFSR + RCAS): 0 off - SPATIAL, no history
//   Renderer: ZRenderDLSS / ZRenderPostfilterPassDLSS (NGX, nvngx_dlss.dll shipped with the game - an old 2.x DLSS),
//   ZRenderPostfilterPassFSR / FSRRCAS, ZRenderPostfilterPassUpscaling (plain resolution scale). No XeSS, no FSR 2.
//
// What it means in VR: a TEMPORAL upscaler (DLSS - and the game's TAA) builds each picture from the frames before it.
// In synchronized / alternate eye those are the OTHER eye's: ghosting, flicker, things fading. Stereo reconstruction
// draws the same view every frame - it works with it. FSR 1.0 and the resolution scale are spatial: fine everywhere.
#include <string>
#include <cstdio>

namespace upscale {

struct Settings {
    bool known = false;
    int dlss = 0, fsr = 0, dyn = 0;
    float scale = 100.f;
};

inline bool Same(const Settings& a, const Settings& b) {
    return a.dlss == b.dlss && a.fsr == b.fsr && a.dyn == b.dyn && a.scale == b.scale;
}
// game_upscaling = off: the eye at its full size, nothing upscaled
inline Settings Native(Settings s) { s.dlss = 0; s.fsr = 0; s.dyn = 0; s.scale = 100.f; return s; }
inline bool Temporal(const Settings& s) { return s.known && s.dlss > 0; }
inline bool Any(const Settings& s) { return s.known && (s.dlss > 0 || s.fsr > 0 || s.dyn > 0 || (s.scale > 0.f && s.scale < 99.5f)); }

inline const char* DlssName(int q) {
    static const char* n[] = { "off", "ultra quality", "quality", "balanced", "performance", "ultra performance" };
    return q >= 0 && q <= 5 ? n[q] : "on";
}
inline std::string Describe(const Settings& s) {
    if (!s.known) return "unknown";
    std::string r;
    char b[64];
    if (s.dlss > 0) { snprintf(b, sizeof b, "DLSS %s (temporal)", DlssName(s.dlss)); r += b; }
    if (s.fsr > 0) { snprintf(b, sizeof b, "%sFSR 1.0 mode %d (spatial)", r.empty() ? "" : ", ", s.fsr); r += b; }
    if (s.dyn > 0) { snprintf(b, sizeof b, "%sdynamic resolution %d", r.empty() ? "" : ", ", s.dyn); r += b; }
    if (s.scale > 0.f && s.scale < 99.5f) { snprintf(b, sizeof b, "%sresolution scale %.0f %%", r.empty() ? "" : ", ", s.scale); r += b; }
    return r.empty() ? "native (no upscaler)" : r;
}
// the panel's status line: short, and whether it mixes the eyes in the current stereo method
inline std::string Status(const Settings& s, int measuredPct, bool alternatingEyes) {
    std::string r;
    char b[64];
    if (Temporal(s)) r = "DLSS";
    else if (s.known && s.fsr > 0) r = "FSR";
    else if (Any(s) || measuredPct < 100) r = "upscaled";
    else return "";
    if (measuredPct < 100) { snprintf(b, sizeof b, " %d %%", measuredPct); r += b; }
    if (Temporal(s) && alternatingEyes) r += " - mixes eyes";
    return r;
}

// game_upscaling = off / game, against what the game holds now. Step returns true when `write` must be set in the
// game: forced native values while off (and again when the player changes a setting in the game's menu meanwhile -
// that becomes the value restored later), the player's own values once when switched back to game.
struct Forcer {
    bool forcing = false; Settings saved;
    bool Step(bool native, const Settings& now, Settings& write) {
        if (native) {
            bool playerChanged = forcing && !Same(now, Native(saved));
            if (forcing && !playerChanged) return false;
            saved = now; forcing = true; write = Native(saved); return true;
        }
        if (!forcing) return false;
        forcing = false; write = saved; return true;
    }
};

} // namespace upscale
