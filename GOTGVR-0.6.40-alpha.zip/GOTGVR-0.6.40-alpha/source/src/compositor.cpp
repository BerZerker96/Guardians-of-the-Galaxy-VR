#include "modtime.h"
// VR output: the game's D3D12 back buffer -> the headset through XrBridge (XrBridgeHost.exe, the DXMDVR / DA2VR OpenXR
// host: any OpenXR runtime, any headset, OpenXR API layers pass through the Khronos loader).
//
// The host takes D3D11 keyed-mutex textures, so the mod runs a small D3D11 device of its own on the game's GPU:
//   game queue (D3D12):  back buffer -> shared texture (ring of 3, D3D12 shared heap)      signal fence A
//                        [mirror: left eye kept, copied back into the back buffer on right-eye frames]
//   mod (D3D11):         wait A -> shared texture -> eye image (format / HDR conversion, sharpening)   signal fence B
//                        (the game queue waits for B before it reuses that shared texture)
//                        both eye images + the menu / flat screen -> atlas (keyed mutex) -> host
// Alternate-eye rendering: each game frame is one eye; the other eye's last image stays in the atlas with the pose it
// was drawn with. The host's projection layer carries a pose per eye, so the runtime reprojects each eye on its own
// (and the runtime's motion smoothing / ASW / Smart Smoothing sees one fresh application frame per headset frame).
// Atlas: left eye (0,0,W,H) | right eye (W,0,W,H); HUD / menu / flat screen (0,H,W,H).
#include "d3d.h"
#include <d3d11_4.h>
#include <d3dcompiler.h>
#include <cmath>
#include <string>
#include <vector>
#include "log.h"
#include "config.h"
#include "camera.h"
#include "settings.h"
#include "game.h"
#include "xrbridge/client.h"
#include "recon.h"
#include "../third_party/xrbridge/src/common/bmp.h"

extern std::wstring g_gameDir, g_modDir, g_shotDir;
ID3D11Device* g_dev11 = nullptr;
ID3D11DeviceContext* g_ctx11 = nullptr;
static ID3D11Device5* g_dev5 = nullptr;
static ID3D11DeviceContext4* g_ctx4 = nullptr;
ID3D11Texture2D* MenuUpdate();
void ResolutionSaveHeadset(unsigned w, unsigned h);
void ModCopyResource(ID3D12GraphicsCommandList* l, ID3D12Resource* dst, ID3D12Resource* src);
void FpsLimitReport();
void UiReport();
void SmoothingSet(const std::string& m);

template <class T> static void Rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

// ---------------------------------------------------------------- D3D11 device + shaders
static ID3D11VertexShader* g_vs = nullptr;
static ID3D11PixelShader* g_ps = nullptr;
static ID3D11Buffer* g_cb = nullptr;
static ID3D11SamplerState* g_smp = nullptr;
static ID3D11BlendState* g_blendOpaque = nullptr, * g_blendPremul = nullptr;
static ID3D11RasterizerState* g_rs = nullptr;
struct CB { float uv[4]; float p[4]; float q[4]; };

static const char* kHlsl = R"(
Texture2D t0 : register(t0); SamplerState s0 : register(s0);
cbuffer C : register(b0) { float4 uv; float4 p; float4 q; };   // p: sharpen, hdr mode, paper white nits, keep alpha
struct V { float4 pos : SV_Position; float2 uv : TEXCOORD0; };
V vs(uint id : SV_VertexID) {
    float2 k = float2((id << 1) & 2, id & 2);
    V o; o.pos = float4(k * float2(2, -2) + float2(-1, 1), 0, 1); o.uv = lerp(uv.xy, uv.zw, k); return o;
}
float3 FromPQ(float3 n) {   // ST.2084 -> linear nits
    const float m1 = 0.1593017578125, m2 = 78.84375, c1 = 0.8359375, c2 = 18.8515625, c3 = 18.6875;
    float3 e = pow(max(n, 0), 1.0 / m2);
    return 10000.0 * pow(max(e - c1, 0) / (c2 - c3 * e), 1.0 / m1);
}
float3 ToSrgb(float3 l) { l = saturate(l); return l <= 0.0031308 ? l * 12.92 : 1.055 * pow(l, 1.0 / 2.4) - 0.055; }
float3 Tone(float3 l) { float m = max(l.r, max(l.g, l.b)); return m > 0.8 ? l * ((0.8 + (1 - 0.8) * (1 - exp(-(m - 0.8) / (1 - 0.8)))) / m) : l; }
float4 Load(float2 t) { return t0.SampleLevel(s0, t, 0); }
// 0.6.14 edge fill (q.y = 1): where the eye image reaches past the drawn picture, its rim is stretched outward and
// blurred more the further out (no black border); q.y = 0: black there
float4 EdgeFill(float2 u) {
    float2 c = saturate(u); float d = length(u - c);
    if (q.y < 0.5) return float4(0, 0, 0, 1);
    float r = d * 0.7 + 0.003;
    float4 acc = Load(c) * 2.0;
    [unroll] for (int k = 0; k < 10; k++) {
        float a = k * 0.6283185; float2 o = float2(cos(a), sin(a)) * r;
        acc += Load(saturate(c + o));
    }
    acc /= 12.0;
    acc.rgb *= 1.0 / (1.0 + d * 1.5);
    acc.a = 1;
    return acc;
}
float4 ps(V i) : SV_Target {
    if (any(i.uv < -0.0005) || any(i.uv > 1.0005)) return EdgeFill(i.uv) * q.x;
    float4 c = Load(i.uv);
    if (p.x > 0) {   // luma sharpen (cross pattern, clamped)
        float w, h; t0.GetDimensions(w, h); float2 d = float2(1.0 / w, 1.0 / h);
        float3 b = (Load(i.uv + float2(d.x, 0)).rgb + Load(i.uv - float2(d.x, 0)).rgb + Load(i.uv + float2(0, d.y)).rgb + Load(i.uv - float2(0, d.y)).rgb) * 0.25;
        float l = dot(c.rgb - b, float3(0.2126, 0.7152, 0.0722));
        c.rgb += clamp(l * p.x * 1.5, -0.035, 0.035);
    }
    if (p.y > 0.5 && p.y < 1.5) {   // HDR10: PQ, BT.2020 -> BT.709, paper white, soft knee, sRGB
        float3 n = FromPQ(c.rgb) / p.z;
        n = mul(float3x3(1.6605, -0.5876, -0.0728, -0.1246, 1.1329, -0.0083, -0.0182, -0.1006, 1.1187), n);
        c.rgb = ToSrgb(Tone(n));
    } else if (p.y > 1.5) {         // scRGB: linear, 1.0 = 80 nits
        c.rgb = ToSrgb(Tone(c.rgb * 80.0 / p.z));
    }
    if (p.w < 0.5) c.a = 1;
    return c * q.x;
}
)";

static bool CompileShaders() {
    ID3DBlob* b = nullptr, * err = nullptr;
    if (FAILED(D3DCompile(kHlsl, strlen(kHlsl), "gotgvr", nullptr, nullptr, "vs", "vs_5_0", 0, 0, &b, &err))) {
        LOGE("xr: VS compile failed: %s", err ? (const char*)err->GetBufferPointer() : "?"); return false;
    }
    g_dev11->CreateVertexShader(b->GetBufferPointer(), b->GetBufferSize(), nullptr, &g_vs); b->Release();
    if (FAILED(D3DCompile(kHlsl, strlen(kHlsl), "gotgvr", nullptr, nullptr, "ps", "ps_5_0", 0, 0, &b, &err))) {
        LOGE("xr: PS compile failed: %s", err ? (const char*)err->GetBufferPointer() : "?"); return false;
    }
    g_dev11->CreatePixelShader(b->GetBufferPointer(), b->GetBufferSize(), nullptr, &g_ps); b->Release();
    D3D11_BUFFER_DESC bd = { sizeof(CB), D3D11_USAGE_DEFAULT, D3D11_BIND_CONSTANT_BUFFER, 0, 0, 0 };
    g_dev11->CreateBuffer(&bd, nullptr, &g_cb);
    D3D11_SAMPLER_DESC sd = {}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR; sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.MaxLOD = D3D11_FLOAT32_MAX; g_dev11->CreateSamplerState(&sd, &g_smp);
    D3D11_BLEND_DESC bl = {}; bl.RenderTarget[0].RenderTargetWriteMask = 15;
    g_dev11->CreateBlendState(&bl, &g_blendOpaque);
    bl.RenderTarget[0].BlendEnable = TRUE;
    bl.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE; bl.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA; bl.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    bl.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE; bl.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA; bl.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    g_dev11->CreateBlendState(&bl, &g_blendPremul);
    D3D11_RASTERIZER_DESC rd = {}; rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.ScissorEnable = FALSE; rd.DepthClipEnable = TRUE;
    g_dev11->CreateRasterizerState(&rd, &g_rs);
    return g_vs && g_ps && g_cb && g_smp;
}

// src (sub-rect in uv) -> dst rectangle in pixels
static float g_blitEdge = 0.f;   // edge fill for the eye images (set around their blits)
static void Blit(ID3D11ShaderResourceView* src, ID3D11RenderTargetView* dst, int x, int y, int w, int h,
                 float u0, float v0, float u1, float v1, float sharpen, int hdr, bool premulBlend, bool keepAlpha, float opacity = 1.f) {
    CB c = { { u0, v0, u1, v1 }, { sharpen, (float)hdr, g_set.hdrNits > 10.f ? g_set.hdrNits : 200.f, keepAlpha ? 1.f : 0.f }, { opacity, g_blitEdge, 0, 0 } };
    g_ctx11->UpdateSubresource(g_cb, 0, nullptr, &c, 0, 0);
    D3D11_VIEWPORT vp = { (float)x, (float)y, (float)w, (float)h, 0, 1 };
    g_ctx11->OMSetRenderTargets(1, &dst, nullptr);
    g_ctx11->RSSetViewports(1, &vp);
    g_ctx11->RSSetState(g_rs);
    float bf[4] = {};
    g_ctx11->OMSetBlendState(premulBlend ? g_blendPremul : g_blendOpaque, bf, 0xffffffff);
    g_ctx11->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_ctx11->IASetInputLayout(nullptr);
    g_ctx11->VSSetShader(g_vs, nullptr, 0);
    g_ctx11->PSSetShader(g_ps, nullptr, 0);
    g_ctx11->PSSetConstantBuffers(0, 1, &g_cb);
    g_ctx11->VSSetConstantBuffers(0, 1, &g_cb);
    g_ctx11->PSSetSamplers(0, 1, &g_smp);
    g_ctx11->PSSetShaderResources(0, 1, &src);
    g_ctx11->Draw(3, 0);
    ID3D11ShaderResourceView* none = nullptr; g_ctx11->PSSetShaderResources(0, 1, &none);
    g_ctx11->OMSetRenderTargets(0, nullptr, nullptr);
}

static bool g_devFailed = false;
static bool InitDevice11() {
    if (g_dev11) return true;
    if (g_devFailed || !g_dev12) return false;
    g_devFailed = true;
    LUID luid = g_dev12->GetAdapterLuid();
    IDXGIFactory4* f4 = nullptr; IDXGIAdapter1* ad = nullptr;
    typedef HRESULT(WINAPI * PFN_CF2)(UINT, REFIID, void**);
    HMODULE dx = GetModuleHandleW(L"dxgi.dll");
    PFN_CF2 cf2 = dx ? (PFN_CF2)GetProcAddress(dx, "CreateDXGIFactory2") : nullptr;
    if (!cf2 || FAILED(cf2(0, __uuidof(IDXGIFactory4), (void**)&f4)) || FAILED(f4->EnumAdapterByLuid(luid, __uuidof(IDXGIAdapter1), (void**)&ad))) {
        LOGE("xr: the game's GPU was not found by its LUID"); if (f4) f4->Release(); return false;
    }
    DXGI_ADAPTER_DESC1 add = {}; ad->GetDesc1(&add);
    D3D_FEATURE_LEVEL fls[] = { D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0 }, fl;
    HRESULT hr = D3D11CreateDevice(ad, D3D_DRIVER_TYPE_UNKNOWN, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT, fls, 2, D3D11_SDK_VERSION, &g_dev11, &fl, &g_ctx11);
    ad->Release(); f4->Release();
    if (FAILED(hr)) { LOGE("xr: D3D11CreateDevice failed %08lx", (unsigned long)hr); return false; }
    if (FAILED(g_dev11->QueryInterface(__uuidof(ID3D11Device5), (void**)&g_dev5)) || FAILED(g_ctx11->QueryInterface(__uuidof(ID3D11DeviceContext4), (void**)&g_ctx4))) {
        LOGE("xr: D3D11.4 fences not available (Windows 10 1703 or newer needed)");
        Rel(g_ctx4); Rel(g_dev5); Rel(g_ctx11); Rel(g_dev11); return false;
    }
    if (!CompileShaders()) { Rel(g_ctx4); Rel(g_dev5); Rel(g_ctx11); Rel(g_dev11); return false; }
    uint64_t want = xrb::ClientAdapterLuid(), have = ((uint64_t)(uint32_t)luid.HighPart << 32) | luid.LowPart;
    LOGI("xr: interop device on %ls (LUID %08lx:%08lx)%s", add.Description, (unsigned long)luid.HighPart, luid.LowPart,
         want && want != have ? "  ** the VR runtime uses ANOTHER GPU - connect the headset / monitor to the game's GPU **" : "");
    g_devFailed = false;
    return true;
}

// ---------------------------------------------------------------- D3D12 side: shared ring, fences, copy list
static const int kRing = 4;   // 0.6.8: one more, so a slot whose copy the GPU has not run yet is skipped, never waited for
struct Shared {
    ID3D12Resource* r12 = nullptr; ID3D11Texture2D* t11 = nullptr; ID3D11ShaderResourceView* srv = nullptr;
    ID3D12CommandAllocator* alloc = nullptr; UINT64 doneA = 0;   // fence A value after the copy into it
    UINT64 needB = 0;                                            // fence B value after D3D11 read it
};
static Shared g_ring[kRing];
static int g_ringNext = 0;
static UINT g_rw = 0, g_rh = 0; static DXGI_FORMAT g_rfmt = DXGI_FORMAT_UNKNOWN;   // the game's back buffer (ring)
static UINT g_ew = 0, g_eh = 0;   // 0.6.9: the eye images / atlas: the headset's recommended size (HeadsetEyeSize)
bool HeadsetEyeSize(unsigned& w, unsigned& h);
static ID3D12GraphicsCommandList* g_list = nullptr;
static ID3D12Fence* g_fA12 = nullptr, * g_fB12 = nullptr;
static ID3D11Fence* g_fA11 = nullptr, * g_fB11 = nullptr;
static UINT64 g_vA = 0, g_vB = 0;
static HANDLE g_evt = nullptr;
static ID3D12Resource* g_mirror = nullptr; static bool g_mirrorValid = false;
// D3D11 eye images (RGBA8) and what they show
static ID3D11Texture2D* g_eye[2] = {}; static ID3D11RenderTargetView* g_eyeRtv[2] = {}; static ID3D11ShaderResourceView* g_eyeSrv[2] = {};
static ID3D11Texture2D* g_flat = nullptr; static ID3D11RenderTargetView* g_flatRtv = nullptr; static ID3D11ShaderResourceView* g_flatSrv = nullptr;
static RenderedEye g_eyeMeta[2]; static bool g_eyeHave[2] = {};


static bool InitFences() {
    if (g_fA11) return true;
    HANDLE h = nullptr;
    if (FAILED(g_dev12->CreateFence(0, D3D12_FENCE_FLAG_SHARED, __uuidof(ID3D12Fence), (void**)&g_fA12)) ||
        FAILED(g_dev12->CreateSharedHandle(g_fA12, nullptr, GENERIC_ALL, nullptr, &h)) ||
        FAILED(g_dev5->OpenSharedFence(h, __uuidof(ID3D11Fence), (void**)&g_fA11))) { LOGE("xr: shared fence A failed"); if (h) CloseHandle(h); return false; }
    CloseHandle(h); h = nullptr;
    if (FAILED(g_dev12->CreateFence(0, D3D12_FENCE_FLAG_SHARED, __uuidof(ID3D12Fence), (void**)&g_fB12)) ||
        FAILED(g_dev12->CreateSharedHandle(g_fB12, nullptr, GENERIC_ALL, nullptr, &h)) ||
        FAILED(g_dev5->OpenSharedFence(h, __uuidof(ID3D11Fence), (void**)&g_fB11))) { LOGE("xr: shared fence B failed"); if (h) CloseHandle(h); return false; }
    CloseHandle(h);
    g_evt = CreateEventW(nullptr, FALSE, FALSE, nullptr);
    LOGI("xr: D3D12 <-> D3D11 shared fences ready");
    return true;
}

static void ReleaseRing() {
    if (g_fA12 && g_vA && g_fA12->GetCompletedValue() < g_vA) { g_fA12->SetEventOnCompletion(g_vA, g_evt); WaitForSingleObject(g_evt, 2000); }
    for (auto& s : g_ring) { Rel(s.srv); Rel(s.t11); Rel(s.r12); Rel(s.alloc); s.doneA = s.needB = 0; }
    Rel(g_list); Rel(g_mirror); g_mirrorValid = false;
    for (int e = 0; e < 2; e++) { Rel(g_eyeSrv[e]); Rel(g_eyeRtv[e]); Rel(g_eye[e]); g_eyeHave[e] = false; }
    Rel(g_flatSrv); Rel(g_flatRtv); Rel(g_flat);
    g_rw = g_rh = 0;
}

static bool MakeTex11(UINT w, UINT h, ID3D11Texture2D*& t, ID3D11RenderTargetView*& rtv, ID3D11ShaderResourceView*& srv) {
    D3D11_TEXTURE2D_DESC d = {}; d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    d.SampleDesc.Count = 1; d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_RENDER_TARGET | D3D11_BIND_SHADER_RESOURCE;
    return SUCCEEDED(g_dev11->CreateTexture2D(&d, nullptr, &t)) && SUCCEEDED(g_dev11->CreateRenderTargetView(t, nullptr, &rtv)) &&
           SUCCEEDED(g_dev11->CreateShaderResourceView(t, nullptr, &srv));
}

static DXGI_FORMAT SrvFormat(DXGI_FORMAT f) {
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_TYPELESS: return DXGI_FORMAT_R8G8B8A8_UNORM;
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: return DXGI_FORMAT_B8G8R8A8_UNORM;
    case DXGI_FORMAT_R10G10B10A2_TYPELESS: return DXGI_FORMAT_R10G10B10A2_UNORM;
    case DXGI_FORMAT_R16G16B16A16_TYPELESS: return DXGI_FORMAT_R16G16B16A16_FLOAT;
    default: return f;
    }
}

static bool EnsureRing(UINT w, UINT h, DXGI_FORMAT fmt) {
    if (g_ring[0].t11 && w == g_rw && h == g_rh && fmt == g_rfmt) return true;
    ReleaseRing();
    if (!InitFences()) return false;
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC rd = {}; rd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; rd.Width = w; rd.Height = h; rd.DepthOrArraySize = 1;
    rd.MipLevels = 1; rd.Format = fmt; rd.SampleDesc.Count = 1; rd.Layout = D3D12_TEXTURE_LAYOUT_UNKNOWN; rd.Flags = D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET;
    for (int i = 0; i < kRing; i++) {
        Shared& s = g_ring[i];
        HANDLE hd = nullptr;
        HRESULT hr = g_dev12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_SHARED, &rd, D3D12_RESOURCE_STATE_COMMON, nullptr, __uuidof(ID3D12Resource), (void**)&s.r12);
        if (SUCCEEDED(hr)) hr = g_dev12->CreateSharedHandle(s.r12, nullptr, GENERIC_ALL, nullptr, &hd);
        if (SUCCEEDED(hr)) hr = g_dev5->OpenSharedResource1(hd, __uuidof(ID3D11Texture2D), (void**)&s.t11);
        if (hd) CloseHandle(hd);
        if (SUCCEEDED(hr)) {
            D3D11_SHADER_RESOURCE_VIEW_DESC sv = {}; sv.Format = SrvFormat(fmt); sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
            hr = g_dev11->CreateShaderResourceView(s.t11, &sv, &s.srv);
        }
        if (SUCCEEDED(hr)) hr = g_dev12->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, __uuidof(ID3D12CommandAllocator), (void**)&s.alloc);
        if (FAILED(hr)) { LOGE("xr: shared texture %d (%ux%u fmt %d) failed %08lx", i, w, h, (int)fmt, (unsigned long)hr); ReleaseRing(); return false; }
    }
    if (FAILED(g_dev12->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, g_ring[0].alloc, nullptr, __uuidof(ID3D12GraphicsCommandList), (void**)&g_list))) {
        LOGE("xr: command list failed"); ReleaseRing(); return false;
    }
    g_list->Close();
    rd.Flags = D3D12_RESOURCE_FLAG_NONE;
    if (FAILED(g_dev12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, __uuidof(ID3D12Resource), (void**)&g_mirror))) g_mirror = nullptr;
    if (!MakeTex11(w, h, g_flat, g_flatRtv, g_flatSrv)) { ReleaseRing(); return false; }
    g_rw = w; g_rh = h; g_rfmt = fmt;
    LOGI("xr: interop ring %d x %ux%u fmt %d (%s)", kRing, w, h, (int)fmt, fmt == DXGI_FORMAT_R16G16B16A16_FLOAT ? "FP16" : fmt == DXGI_FORMAT_R10G10B10A2_UNORM ? "10-bit" : "8-bit");
    return true;
}

static void Barrier(ID3D12Resource* r, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b) {
    D3D12_RESOURCE_BARRIER br = {}; br.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    br.Transition.pResource = r; br.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES; br.Transition.StateBefore = a; br.Transition.StateAfter = b;
    g_list->ResourceBarrier(1, &br);
}

// GPU timing (manual 4): a timestamp at the start of the mod's copy each frame - the moment the game's frame is done on
// the GPU. Read back when that ring slot is reused (its fence passed: nothing is ever waited for); the interval
// between two frames' timestamps is the GPU frame time when the GPU is the limit.
static ID3D12QueryHeap* g_tsHeap = nullptr; static ID3D12Resource* g_tsBuf = nullptr; static UINT64 g_tsFreq = 0;
static UINT64 g_tsLast = 0; static double g_gpuSum = 0, g_gpuMax = 0; static unsigned g_gpuN = 0;
static unsigned g_ringBusy = 0;
static bool TimestampsInit() {
    if (g_tsHeap) return true;
    if (!g_dev12 || FAILED(g_queue->GetTimestampFrequency(&g_tsFreq)) || !g_tsFreq) return false;
    D3D12_QUERY_HEAP_DESC qd = {}; qd.Type = D3D12_QUERY_HEAP_TYPE_TIMESTAMP; qd.Count = kRing;
    if (FAILED(g_dev12->CreateQueryHeap(&qd, __uuidof(ID3D12QueryHeap), (void**)&g_tsHeap))) { g_tsHeap = nullptr; return false; }
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_READBACK;
    D3D12_RESOURCE_DESC rd = {}; rd.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; rd.Width = 8 * kRing; rd.Height = 1; rd.DepthOrArraySize = 1;
    rd.MipLevels = 1; rd.SampleDesc.Count = 1; rd.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    if (FAILED(g_dev12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, __uuidof(ID3D12Resource), (void**)&g_tsBuf))) {
        g_tsHeap->Release(); g_tsHeap = nullptr; g_tsBuf = nullptr; return false;
    }
    return true;
}
static void TimestampRead(int k) {   // slot k's last copy has run: its timestamp is in the buffer
    if (!g_tsBuf) return;
    UINT64* p = nullptr; D3D12_RANGE r = { (SIZE_T)k * 8, (SIZE_T)k * 8 + 8 };
    if (FAILED(g_tsBuf->Map(0, &r, (void**)&p)) || !p) return;
    UINT64 t = p[k]; D3D12_RANGE w = { 0, 0 }; g_tsBuf->Unmap(0, &w);
    if (t && g_tsLast && t > g_tsLast) {
        double ms = (double)(t - g_tsLast) * 1000.0 / (double)g_tsFreq;
        if (ms < 1000.0) { g_gpuSum += ms; g_gpuN++; if (ms > g_gpuMax) g_gpuMax = ms; }
    }
    if (t) g_tsLast = t;
}
// game queue: back buffer -> ring[k] (+ mirror). Returns the fence A value to wait for on the D3D11 side, 0 on failure.
// The caller picked a slot whose last copy has run (RingFree) - nothing here waits on the CPU.
static UINT64 CopyOut(ID3D12Resource* bb, int k, int mirrorOp) {
    Shared& s = g_ring[k];
    if (s.doneA && g_fA12->GetCompletedValue() < s.doneA) return 0;   // never reset an allocator the GPU still reads
    if (FAILED(s.alloc->Reset()) || FAILED(g_list->Reset(s.alloc, nullptr))) return 0;
    if (TimestampsInit()) {
        g_list->EndQuery(g_tsHeap, D3D12_QUERY_TYPE_TIMESTAMP, (UINT)k);
        g_list->ResolveQueryData(g_tsHeap, D3D12_QUERY_TYPE_TIMESTAMP, (UINT)k, 1, g_tsBuf, (UINT64)k * 8);
    }
    Barrier(bb, D3D12_RESOURCE_STATE_PRESENT, D3D12_RESOURCE_STATE_COPY_SOURCE);
    Barrier(s.r12, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    ModCopyResource(g_list, s.r12, bb);
    Barrier(s.r12, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    if (g_mirror && mirrorOp == 1) {   // keep this (left eye) frame for the monitor
        ModCopyResource(g_list, g_mirror, bb); g_mirrorValid = true;
        Barrier(bb, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_PRESENT);
    } else if (g_mirror && mirrorOp == 2 && g_mirrorValid) {   // right eye frame: the monitor gets the last left eye
        Barrier(bb, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
        Barrier(g_mirror, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COPY_SOURCE);
        ModCopyResource(g_list, bb, g_mirror);
        Barrier(g_mirror, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COPY_DEST);
        Barrier(bb, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_PRESENT);
    } else Barrier(bb, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_PRESENT);
    { extern void FovPrepare(ID3D12GraphicsCommandList*, UINT, UINT); FovPrepare(g_list, g_rw, g_rh); }
    if (FAILED(g_list->Close())) return 0;
    if (s.needB) g_queue->Wait(g_fB12, s.needB);   // D3D11 has finished reading this texture's last frame
    ID3D12CommandList* lists[] = { g_list };
    g_queue->ExecuteCommandLists(1, lists);
    { extern void FovCommit(); FovCommit(); }
    g_queue->Signal(g_fA12, ++g_vA);
    s.doneA = g_vA;
    return g_vA;
}

// ---------------------------------------------------------------- atlas ring (XrBridge, keyed mutex)
struct Slot { ID3D11Texture2D* tex = nullptr; IDXGIKeyedMutex* mx = nullptr; ID3D11RenderTargetView* rtv = nullptr; };
static Slot g_slots[xrb::kSlots];
static int g_nextSlot = 0;
static UINT g_aw = 0, g_ah = 0;
static unsigned g_reconPairs = 0, g_reconSingle = 0;
static unsigned g_submitted = 0, g_busy = 0, g_noHost = 0, g_vrFrames = 0, g_screenFrames = 0, g_copyFail = 0, g_noFrame = 0, g_pairHeld = 0;

// the eye images at the headset's size (independent of the game's render size)
static bool EnsureEyes(UINT w, UINT h) {
    if (g_eye[0] && w == g_ew && h == g_eh) return true;
    for (int e = 0; e < 2; e++) { Rel(g_eyeSrv[e]); Rel(g_eyeRtv[e]); Rel(g_eye[e]); g_eyeHave[e] = false; }
    for (int e = 0; e < 2; e++) if (!MakeTex11(w, h, g_eye[e], g_eyeRtv[e], g_eyeSrv[e])) { LOGE("xr: eye texture failed"); return false; }
    g_ew = w; g_eh = h;
    LOGI("xr: eye images %ux%u - the headset's own size and shape; each eye is cut 1:1 from the game's %ux%u render", w, h, g_rw, g_rh);
    return true;
}
static bool EnsureAtlases(UINT w, UINT h) {
    if (g_slots[0].tex && w == g_aw && h == g_ah) return true;
    for (auto& s : g_slots) { Rel(s.rtv); Rel(s.mx); Rel(s.tex); }
    D3D11_TEXTURE2D_DESC d = {};
    d.Width = w * 2; d.Height = h * 2; d.MipLevels = 1; d.ArraySize = 1; d.Format = DXGI_FORMAT_R8G8B8A8_UNORM; d.SampleDesc.Count = 1;
    d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_SHADER_RESOURCE | D3D11_BIND_RENDER_TARGET; d.MiscFlags = D3D11_RESOURCE_MISC_SHARED_KEYEDMUTEX;
    xrb::TextureSet ts;
    ts.atlasWidth = d.Width; ts.atlasHeight = d.Height; ts.dxgiFormat = d.Format; ts.sync = xrb::SYNC_KEYED_MUTEX;
    ts.eyeRect[0] = { 0, 0, (int)w, (int)h }; ts.eyeRect[1] = { (int)w, 0, (int)w, (int)h }; ts.hudRect = { 0, (int)h, (int)w, (int)h };
    for (int i = 0; i < xrb::kSlots; i++) {
        if (FAILED(g_dev11->CreateTexture2D(&d, nullptr, &g_slots[i].tex))) { LOGE("xr: atlas %ux%u failed", d.Width, d.Height); return false; }
        g_slots[i].tex->QueryInterface(__uuidof(IDXGIKeyedMutex), (void**)&g_slots[i].mx);
        g_dev11->CreateRenderTargetView(g_slots[i].tex, nullptr, &g_slots[i].rtv);
        IDXGIResource* r = nullptr; HANDLE sh = nullptr;
        if (SUCCEEDED(g_slots[i].tex->QueryInterface(__uuidof(IDXGIResource), (void**)&r))) { r->GetSharedHandle(&sh); r->Release(); }
        ts.handles[i] = (uint64_t)(uintptr_t)sh;
    }
    xrb::ClientPublishTextures(ts);
    g_aw = w; g_ah = h;
    LOGI("xr: atlases %ux%u (eye %ux%u)", d.Width, d.Height, w, h);
    return true;
}
static int AcquireSlot() {
    int last = xrb::ClientLastSubmittedSlot();
    for (int k = 0; k < xrb::kSlots; k++) {
        int s = (g_nextSlot + k) % xrb::kSlots;
        if (g_slots[s].mx->AcquireSync(0, 0) == S_OK || (s != last && g_slots[s].mx->AcquireSync(1, 0) == S_OK)) { g_nextSlot = (s + 1) % xrb::kSlots; return s; }
    }
    return -1;
}

// ---------------------------------------------------------------- host
static SRWLOCK g_hostLock = SRWLOCK_INIT;
static bool g_hostStarted = false;
extern "C" int XrbHostRunInProcess(const wchar_t* name, unsigned long pid, const wchar_t* logPath);
bool XrStartHost() {
    { extern bool ResolutionHostAllowed(); if (!ResolutionHostAllowed()) return false; }   // 0.6.28: not before the game's swap chain
    AcquireSRWLockExclusive(&g_hostLock);
    if (!g_hostStarted) {
        g_hostStarted = true;
        xrb::ClientSettings s;
        s.instanceName = "GOTGVR";
        s.appName = "Guardians of the Galaxy VR";
        // 0.6.6: no XrBridgeHost.exe - the OpenXR host runs as a thread inside the game (linked into this DLL)
        s.inProcessHost = XrbHostRunInProcess;
        s.hostLogPath = g_modDir + L"\\xrhost.log";
        s.menuDistance = g_set.screenDistance; s.menuWidth = g_set.screenWidth;
        s.hudDistance = g_set.menuDistance; s.hudWidth = g_set.menuPanelWidth; s.hudOffsetY = -0.05f; s.hudFollowHead = true;
        s.hudPremultiplied = true;
        xrb::ClientInit(s);
        extern void SettingsApply(); SettingsApply();
    }
    ReleaseSRWLockExclusive(&g_hostLock);
    return true;
}

// Headset frame pacing (the host's xrWaitFrame loop). None of the three ever slows the GAME: the game never waits for
// the host (slots are skipped, not waited for) and the FPS limiter uses the headset's real refresh rate.
//   full (1):    a fresh image every headset frame, never late - the runtime's motion smoothing (Pimax Smart Smoothing,
//                SteamVR Motion Smoothing, Meta ASW, Virtual Desktop SSW, WMR reprojection, OpenXR Toolkit) never sees
//                "app too slow", so the headset never drops to half rate either.
//   runtime (2): when the game is slower than the headset, the host hands each game frame over as it comes and the
//                headset's own smoothing fills in (it may run its display loop at half rate; the game keeps its rate).
//   repeat (0):  the newest frame on every headset frame.
// Synchronized stereo with sync_submit = pair hands over a pair every second game frame: the host would take that as
// a slow game and "runtime" would keep the headset's smoothing on for good - it runs as full rate there.
static int g_pacingNow = -1;
static int PacingFor(const std::string& m) {
    int mode = m == "runtime" ? 2 : m == "repeat" ? 0 : 1;
    if (mode == 2 && g_cam.mode == VRMODE_SYNCED && g_cam.syncPairSubmit) mode = 1;
    return mode;
}
void SmoothingSet(const std::string& m) {
    int mode = PacingFor(m);
    if (mode == g_pacingNow) return;
    g_pacingNow = mode;
    xrb::ClientSetFramePacing(mode, (unsigned)(g_set.pacedTimeoutMs > 5 ? g_set.pacedTimeoutMs : 100));
    LOGI("headset smoothing: %s%s", mode == 1 ? "full rate - a fresh image every headset frame, the headset's smoothing never halves it" :
                                    mode == 2 ? "runtime - the headset's own smoothing fills in when the game is slower (the game keeps its rate)" :
                                                "repeat newest frame",
         m == "runtime" && mode == 1 ? " (runtime asked: synchronized pairs would keep the headset's smoothing on - full rate instead)" : "");
}

static volatile LONG g_recenterReq = 0, g_shotReq = 0;
void XrRequestRecenter() { g_recenterReq = 1; }
void ScreenshotRequest() { g_shotReq = 1; }

// Screenshot (screenshot_key, Delete): the left eye exactly as the headset gets it - the eye image the headset is sent,
// cut to the headset's own field of view for that eye (screenshot_view = headset; "full" = the whole rendered image
// with its margin), pixels 1:1, saved as a PNG next to the game's exe. Frame 1 copies the eye into a staging texture;
// the next Present reads it (no GPU stall) and a worker thread encodes the PNG (no hitch in the headset).
bool ShotSaveAsync(const std::wstring& path, const uint8_t* rgba, unsigned pitch, unsigned x0, unsigned y0, unsigned w, unsigned h);
void ShotCrop(const float img[4], const float eye[4], unsigned W, unsigned H, unsigned& x0, unsigned& y0, unsigned& w, unsigned& h);
static ID3D11Texture2D* g_shotStage = nullptr; static int g_shotWait = 0; static unsigned g_shotRect[4];
// Delete: both eyes as they go to the headset (0.6.6: the right eye too - in alternate-eye / synchronized modes the
// pair shows what each eye really gets), saved as ..._left.png / ..._right.png next to the game exe
static ID3D11Texture2D* g_shotStageE[2] = {}; static unsigned g_shotRectE[2][4];
static void Screenshot() {
    if (g_shotWait > 0) {   // copied on an earlier frame: read it now
        if (--g_shotWait > 0) return;
        SYSTEMTIME t; GetLocalTime(&t);
        bool again = false;
        for (int e = 0; e < 2; e++) {
            if (!g_shotStageE[e]) continue;
            D3D11_MAPPED_SUBRESOURCE m;
            if (SUCCEEDED(g_ctx11->Map(g_shotStageE[e], 0, D3D11_MAP_READ, D3D11_MAP_FLAG_DO_NOT_WAIT, &m))) {
                wchar_t p[MAX_PATH];
                swprintf(p, MAX_PATH, L"%ls\\GOTGVR_%04u%02u%02u_%02u%02u%02u_%03u_%ls.png", (g_shotDir.empty() ? g_gameDir : g_shotDir).c_str(), t.wYear, t.wMonth, t.wDay, t.wHour,
                         t.wMinute, t.wSecond, t.wMilliseconds, e ? L"right" : L"left");
                bool ok = ShotSaveAsync(p, (const uint8_t*)m.pData, m.RowPitch, g_shotRectE[e][0], g_shotRectE[e][1], g_shotRectE[e][2], g_shotRectE[e][3]);
                g_ctx11->Unmap(g_shotStageE[e], 0);
                if (!ok) LOGE("screenshot: %ls FAILED", p);
                g_shotStageE[e]->Release(); g_shotStageE[e] = nullptr;
            } else again = true;   // the GPU is not done: next frame
        }
        if (again) { g_shotWait = 1; return; }
        g_shotReq = 0;
        return;
    }
    g_shotReq = 0;
    if (!g_eye[0] || !g_eyeHave[0] || !CameraFrameIsVR()) { LOGW("screenshot: no VR view right now (the eyes of the 3D view are saved)"); return; }
    for (int e = 0; e < 1; e++) {   // 0.6.20: the left eye only
        if (!g_eye[e] || !g_eyeHave[e]) continue;
        D3D11_TEXTURE2D_DESC d; g_eye[e]->GetDesc(&d);
        d.Usage = D3D11_USAGE_STAGING; d.BindFlags = 0; d.CPUAccessFlags = D3D11_CPU_ACCESS_READ; d.MiscFlags = 0;
        if (FAILED(g_dev11->CreateTexture2D(&d, nullptr, &g_shotStageE[e]))) { g_shotStageE[e] = nullptr; LOGE("screenshot: staging texture failed"); continue; }
        g_ctx11->CopyResource(g_shotStageE[e], g_eye[e]);
        const xrb::IpcFov& fi = g_eyeMeta[e].fov; const xrb::IpcFov& fe = g_cam.fov[e];
        float img[4] = { tanf(fi.left), tanf(fi.right), tanf(fi.up), tanf(fi.down) }, eye[4] = { tanf(fe.left), tanf(fe.right), tanf(fe.up), tanf(fe.down) };
        unsigned x0 = 0, y0 = 0, w = d.Width, h = d.Height;
        if (g_set.screenshotView != "full") ShotCrop(img, eye, d.Width, d.Height, x0, y0, w, h);
        g_shotRectE[e][0] = x0; g_shotRectE[e][1] = y0; g_shotRectE[e][2] = w; g_shotRectE[e][3] = h;
        LOGI("screenshot: %s eye %ux%u of the %ux%u eye image (%s), drawn seq %u eye %d", e ? "right" : "left", w, h, d.Width, d.Height,
             g_set.screenshotView == "full" ? "full image" : "the headset's view", (unsigned)g_eyeMeta[e].seq, g_eyeMeta[e].eye);
    }
    g_shotWait = 1;
    g_shotReq = 1;   // keeps Screenshot() called on the next Present
}

// ---------------------------------------------------------------- per frame
void XrReleaseForResize() { ReleaseRing(); recon::Release(); }

// submit_view = headset (default): each eye image is cut to the headset's own field of view for that eye before it
// goes to the runtime, and sent with exactly that field of view. The game draws wider than the headset shows (cull
// margin, stereo reconstruction's shared view: 1.3 x 1.08 on the Pimax Dream Air) and that wider field of view used
// to go to the runtime with the image. A runtime that does not honour a projection layer's own field of view shows
// that whole picture inside its own - everything smaller and wider. Cut to the headset's own view, every runtime shows
// it at the right scale. submit_view = rendered sends the whole image as before.
static bool CropToHeadset(const xrb::IpcFov& drawn, int phys, float uv[4], xrb::IpcFov& out) {
    if (g_set.submitView != "headset") return false;
    const xrb::IpcFov& h = g_cam.fov[phys & 1];
    float l = tanf(drawn.left), r = tanf(drawn.right), u = tanf(drawn.up), d = tanf(drawn.down);
    float hl = tanf(h.left), hr = tanf(h.right), hu = tanf(h.up), hd = tanf(h.down);
    if (!(r - l > 0.05f && u - d > 0.05f && hr - hl > 0.05f && hu - hd > 0.05f)) return false;
    // 0.6.13: the window cut out = the headset's field of view, scaled (picture width / height) and moved (eye align
    // of the current stereo method); it is sent as the headset's own field of view - so the user can fix the
    // picture's size and the eyes' alignment
    float sx = g_set.viewWidth, sy = g_set.viewHeight;
    if (!(sx >= 0.5f && sx <= 2.f)) sx = 1.f; if (!(sy >= 0.5f && sy <= 2.f)) sy = 1.f;
    bool recon = g_cam.mode == VRMODE_RECON;
    float shH = recon ? g_set.reconShiftH : g_set.aerShiftH, shV = recon ? g_set.reconShiftV : g_set.aerShiftV;
    shH = fmaxf(-20.f, fminf(20.f, shH)); shV = fmaxf(-20.f, fminf(20.f, shV));
    float side = (phys & 1) ? -1.f : 1.f;   // left eye: + moves its picture left (the window right)
    float dx = side * tanf(shH * 0.0174533f), dy = -side * tanf(shV * 0.0174533f);
    float cx = 0.5f * (hl + hr), cy = 0.5f * (hu + hd);
    float wl = cx + (hl - cx) * sx + dx, wr = cx + (hr - cx) * sx + dx, wu = cy + (hu - cy) * sy + dy, wd = cy + (hd - cy) * sy + dy;
    bool plain = sx == 1.f && sy == 1.f && dx == 0.f && dy == 0.f;
    if (plain && wr - wl >= (r - l) * 0.995f && wu - wd >= (u - d) * 0.995f) return false;   // nothing to cut
    // 0.6.14: not clamped to the drawn picture - a window reaching past it gets the edge fill (or black)
    if (!(wr - wl > 0.05f && wu - wd > 0.05f)) return false;
    uv[0] = (wl - l) / (r - l); uv[1] = (u - wu) / (u - d); uv[2] = (wr - l) / (r - l); uv[3] = (u - wd) / (u - d);
    out = h;
    return true;
}
static unsigned g_cropped = 0;
static char g_eyeSeq[33]; static int g_eyeSeqN = 0;   // the last 32 eyes sent (L / R / M = mono), for the report
static double g_presentSum = 0, g_presentMax = 0, g_frameMax = 0; static unsigned g_presentN = 0; static LONGLONG g_lastPresentQpc = 0;
static void XrOnPresentImpl(UINT idx);
// 0.6.11: where the time at Present goes (CPU): before the eyes (camera, menu), the eyes (copy out, reconstruction,
// blits), sending (atlas, submit)
static double g_tCam = 0, g_tMenu = 0, g_tRes = 0;   // 0.6.14: the camera / menu part split further
static inline double MsSince(LONGLONG t0) { LARGE_INTEGER q; ModQpc(&q); return (q.QuadPart - t0) / 10000.0; }
static LONGLONG g_markA = 0, g_markB = 0; static double g_tPrep = 0, g_tEyes = 0, g_tSend = 0; static unsigned g_tN = 0;
static inline void Mark(LONGLONG& m) { LARGE_INTEGER q; ModQpc(&q); m = q.QuadPart; }
// the mod's work at Present, measured (manual 4 / 12): average and maximum, and the longest game frame (hitches)
void XrOnPresent(UINT idx) {
    LARGE_INTEGER t0, t1; ModQpc(&t0);
    if (g_lastPresentQpc) { double fm = (double)(t0.QuadPart - g_lastPresentQpc) * 1000.0 / 1e7; if (fm > g_frameMax && fm < 5000.0) g_frameMax = fm; }
    g_lastPresentQpc = t0.QuadPart;
    g_markA = g_markB = 0;
    XrOnPresentImpl(idx);
    ModQpc(&t1);
    if (g_markA && g_markB) {
        g_tPrep += (g_markA - t0.QuadPart) / 10000.0; g_tEyes += (g_markB - g_markA) / 10000.0; g_tSend += (t1.QuadPart - g_markB) / 10000.0; g_tN++;
    }
    double ms = (double)(t1.QuadPart - t0.QuadPart) / 10000.0;
    g_presentSum += ms; g_presentN++; if (ms > g_presentMax) g_presentMax = ms;
}
static void XrOnPresentImpl(UINT idx) {
    if (!g_dev12 || !g_queue || idx >= g_bbCount || !g_bb[idx]) return;
    LARGE_INTEGER q0; ModQpc(&q0);
    { extern void ResolutionFollowView(); ResolutionFollowView(); }
    XrStartHost();
    g_tRes += MsSince(q0.QuadPart);
    if (!InitDevice11()) return;
    if (g_recenterReq) { g_recenterReq = 0; xrb::ClientRequestRecenter(); LOGI("xr: recenter"); }
    {   // temporal AA off while 3D frames are made (the game sets the flag from its settings; put back when off)
        static int orig = -1;
        if (game::g_taaFlag) {
            // stereo reconstruction drawing only the left eye keeps TAA's history valid (same eye every frame)
            // 0.6.17: "On" also turns TAA back on in an exe that has it patched off (the FuckTAA exe: no TAA = the
            // game's dithered shadows, hair, reflections and AO are never resolved - they look broken / missing and
            // the picture is over-sharp and shimmers)
            int want = g_cam.gameAaWant;   // only when the player chose it
            // 0.6.35: the flag is the camera JITTER switch (exe+979FE0 returns at once when it is 0). DLSS needs that
            // jitter to build its picture - with DLSS on, "Off" would leave DLSS without it (blurry, aliased). Kept on
            // then; DLSS replaces the game's TAA anyway (Game upscaling: Off turns DLSS off first).
            if (want == 0 && upscale::Temporal(game::RenderUpscale())) {
                static bool said = false; if (!said) { said = true; LOGI("taa: Game anti-aliasing = Off is not applied while DLSS is on - DLSS needs the camera jitter (Game upscaling: Off turns DLSS off)"); }
                want = -1;
            }
            if (want >= 0) { if (orig < 0) { orig = *game::g_taaFlag; LOGI("taa: renderer flag was %d - kept at %d", orig, want); } *game::g_taaFlag = (unsigned char)want; }
            else if (orig >= 0) { *game::g_taaFlag = (unsigned char)orig; orig = -1; LOGI("taa: renderer flag restored"); }
        }
    }
    { LARGE_INTEGER q1; ModQpc(&q1); CameraOnPresent(g_bbW, g_bbH); g_tCam += MsSince(q1.QuadPart); }
    if (g_hostStarted && xrb::ClientHostConnected()) SmoothingSet(g_set.smoothing);   // follows mode / pair changes
    LARGE_INTEGER q2; ModQpc(&q2);
    ID3D11Texture2D* menu = MenuUpdate();
    g_tMenu += MsSince(q2.QuadPart);
    static bool savedSize = false;
    if (!savedSize && xrb::ClientHostConnected()) {
        unsigned rw = 0, rh = 0; savedSize = true;
        if (xrb::ClientWaitRecommendedSize(&rw, &rh, 5) && rw && rh) ResolutionSaveHeadset(rw, rh);
    }
    RenderedEye re;
    bool got = CameraTakeRendered(re);
    Mark(g_markA);
    if (!xrb::ClientHostConnected()) { g_noHost++; return; }
    UINT ew = g_bbW, eh = g_bbH;
    { unsigned hw = 0, hh = 0; if (HeadsetEyeSize(hw, hh)) { ew = hw; eh = hh; } }
    if (!EnsureRing(g_bbW, g_bbH, g_bbFmt) || !EnsureEyes(ew, eh) || !EnsureAtlases(ew, eh)) return;
    recon::OnPresent(g_dev12, g_dev5, g_bbW, g_bbH, g_bbFmt);
    // stereo reconstruction: the next frame's depth / picture copies reuse a slot D3D11 may still read - the game queue
    // waits for it (here, so no early return below skips it)
    if (UINT64 nb = recon::NeedBForNextFrame()) g_queue->Wait(g_fB12, nb);
    bool vrRunning = CameraFrameIsVR() && g_cam.mode != VRMODE_SCREEN;
    if (!got && vrRunning) { g_noFrame++; return; }   // a Present without a new eye image: nothing new for the headset
    bool vr = got && vrRunning;
    // the next ring slot whose last copy the GPU has run (manual 9.5: skip and count, never wait)
    int k = -1;
    for (int t = 0; t < kRing; t++) {
        int c = (g_ringNext + t) % kRing;
        if (!g_ring[c].doneA || g_fA12->GetCompletedValue() >= g_ring[c].doneA) { k = c; break; }
    }
    if (k < 0) { g_ringBusy++; return; }
    if (g_ring[k].doneA) TimestampRead(k);
    g_ringNext = (k + 1) % kRing;
    int mirrorOp = 0;
    if (vr && !re.mono && g_set.mirror == "left") mirrorOp = re.eye == 0 ? 1 : 2;
    UINT64 a = CopyOut(g_bb[idx], k, mirrorOp);
    if (!a) { g_copyFail++; return; }
    g_ctx4->Wait(g_fA11, a);
    int hdr = g_set.hdrInput == "pq" ? 1 : g_set.hdrInput == "scrgb" ? 2 : g_set.hdrInput == "off" ? 0 : g_colorSpace;
    if (g_bbFmt == DXGI_FORMAT_R16G16B16A16_FLOAT && g_set.hdrInput == "auto") hdr = 2;
    float sharpen = g_set.sharpen;
    g_blitEdge = g_set.edgeFill ? 1.f : 0.f;
    if (vr && re.recon && re.centre) {
        // recon_eye = centre: the head-centre view was drawn; BOTH eyes are rebuilt from it (half the eye distance each:
        // half the gaps behind close objects), each at its own view only
        if (g_eyeSeqN < 32) g_eyeSeq[g_eyeSeqN++] = 'C';
        bool both = true;
        for (int e = 0; e < 2; e++) {
            RenderedEye q = re;
            q.eye = e ^ 1; q.physEye = e ^ 1;   // Reconstruct builds the eye "other than the drawn one": e
            if (e == 1) { memcpy(q.nodeO, re.nodeO1, 48); memcpy(q.tanO, re.tanO1, 16); q.poseO = re.poseO1; q.fovO = re.fovO1; }
            int slot = g_cam.swapEyes ? e ^ 1 : e;
            ID3D11ShaderResourceView* rb = nullptr;
            RenderedEye o = re; o.eye = slot; o.mono = false;
            if (recon::Reconstruct(g_ctx11, q, g_ring[k].t11, g_ring[k].srv, &rb) && rb) {
                float uo[4] = { 0, 0, 1, 1 }; xrb::IpcFov co;
                bool c = CropToHeadset(q.fovO, e, uo, co);
                Blit(rb, g_eyeRtv[slot], 0, 0, g_ew, g_eh, uo[0], uo[1], uo[2], uo[3], sharpen, hdr, false, false);
                o.pose = q.poseO; o.fov = c ? co : q.fovO;
                if (c) g_cropped++;
            } else {   // not rebuilt this frame (no depth yet): the centre view itself, flat
                both = false;
                Blit(g_ring[k].srv, g_eyeRtv[slot], 0, 0, g_ew, g_eh, 0, 0, 1, 1, sharpen, hdr, false, false);
            }
            g_eyeMeta[slot] = o; g_eyeHave[slot] = true;
        }
        if (both) g_reconPairs++; else g_reconSingle++;
    } else if (vr) {
        int e = re.eye & 1;
        if (g_eyeSeqN < 32) g_eyeSeq[g_eyeSeqN++] = re.mono ? 'M' : e ? 'R' : 'L';
        int pe = g_cam.swapEyes ? e ^ 1 : e;   // the eye whose frustum the image was drawn with
        float uv[4] = { 0, 0, 1, 1 }; xrb::IpcFov cf;
        bool crop = !re.mono && CropToHeadset(re.fov, pe, uv, cf);
        Blit(g_ring[k].srv, g_eyeRtv[e], 0, 0, g_ew, g_eh, uv[0], uv[1], uv[2], uv[3], sharpen, hdr, false, false);
        g_eyeMeta[e] = re; g_eyeHave[e] = true;
        if (crop) { g_eyeMeta[e].fov = cf; g_cropped++; }
        if (re.mono || !g_eyeHave[e ^ 1]) {   // head mode (and the very first stereo frame): the same image for both
            g_ctx11->CopyResource(g_eye[e ^ 1], g_eye[e]); g_eyeMeta[e ^ 1] = g_eyeMeta[e]; g_eyeHave[e ^ 1] = true;
        }
        // stereo reconstruction: the other eye rebuilt from this frame's picture + depth, with its pose of the same moment
        ID3D11ShaderResourceView* rebuilt = nullptr;
        if (re.recon && recon::Reconstruct(g_ctx11, re, g_ring[k].t11, g_ring[k].srv, &rebuilt) && rebuilt) {
            float uo[4] = { 0, 0, 1, 1 }; xrb::IpcFov co;
            bool cropO = CropToHeadset(re.fovO, pe ^ 1, uo, co);
            Blit(rebuilt, g_eyeRtv[e ^ 1], 0, 0, g_ew, g_eh, uo[0], uo[1], uo[2], uo[3], sharpen, hdr, false, false);
            RenderedEye o = re; o.eye = e ^ 1; o.pose = re.poseO; o.fov = cropO ? co : re.fovO;
            g_eyeMeta[e ^ 1] = o; g_eyeHave[e ^ 1] = true; g_reconPairs++;
        } else if (re.recon) g_reconSingle++;
    } else { g_blitEdge = 0.f; Blit(g_ring[k].srv, g_flatRtv, 0, 0, g_rw, g_rh, 0, 0, 1, 1, 0.f, hdr, false, false); }
    g_blitEdge = 0.f;
    Mark(g_markB);
    g_ctx4->Signal(g_fB11, ++g_vB);
    g_ring[k].needB = g_vB;
    recon::AfterSignal(g_vB);
    g_ctx11->Flush();
    if (g_shotReq) Screenshot();
    if (vr && !re.pairEnd) { g_pairHeld++; return; }   // synchronized, first eye: sent together with its twin

    int slot = AcquireSlot();
    if (slot < 0) { g_busy++; return; }
    Slot& S = g_slots[slot];
    ID3D11Texture2D* at = S.tex;
    uint32_t flags = 0;
    xrb::IpcPose poses[2]; xrb::IpcFov fovs[2]; int64_t time = 0;
    xrb::IpcMotion mo = {};
    const float clear[4] = { 0, 0, 0, 0 };
    D3D11_BOX hb = { 0, 0, 0, g_ew, g_eh, 1 };
    float mw = g_set.menuWidth < 0.3f ? 0.3f : g_set.menuWidth > 1.f ? 1.f : g_set.menuWidth;
    auto drawMenu = [&]() {
        if (!menu) return;
        ID3D11ShaderResourceView* ms = nullptr;
        D3D11_SHADER_RESOURCE_VIEW_DESC sv = {}; sv.Format = DXGI_FORMAT_R8G8B8A8_UNORM; sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
        static ID3D11Texture2D* lastMenu = nullptr; static ID3D11ShaderResourceView* menuSrv = nullptr;
        if (menu != lastMenu) { Rel(menuSrv); g_dev11->CreateShaderResourceView(menu, &sv, &menuSrv); lastMenu = menu; }
        ms = menuSrv;
        D3D11_TEXTURE2D_DESC md; menu->GetDesc(&md);
        float ma = (float)md.Width / (float)md.Height;
        int w = (int)(g_ew * mw), h = (int)(w / ma);
        if (h > (int)g_eh) { h = g_eh; w = (int)(h * ma); }
        Blit(ms, S.rtv, (g_ew - w) / 2, g_eh + (g_eh - h) / 2, w, h, 0, 0, 1, 1, 0.f, 0, true, true);
    };
    // the HUD rect: transparent, then the menu (VR) or the flat image + menu (screen)
    {
        D3D11_RECT r = { 0, (LONG)g_eh, (LONG)g_ew, (LONG)(g_eh * 2) };
        ID3D11DeviceContext1* c1 = nullptr;
        if (SUCCEEDED(g_ctx11->QueryInterface(__uuidof(ID3D11DeviceContext1), (void**)&c1))) { c1->ClearView(S.rtv, clear, &r, 1); c1->Release(); }
    }
    if (vr) {
        g_ctx11->CopySubresourceRegion(at, 0, 0, 0, 0, g_eye[0], 0, &hb);
        g_ctx11->CopySubresourceRegion(at, 0, g_ew, 0, 0, g_eye[1], 0, &hb);
        for (int e = 0; e < 2; e++) {
            poses[e] = g_eyeMeta[e].pose; fovs[e] = g_eyeMeta[e].fov;
            mo.contentTime[e] = g_eyeMeta[e].tick * 100;
        }
        // head mode: the image is the head's view (not an eye's): both eyes get the head pose
        time = g_eyeMeta[0].time > g_eyeMeta[1].time ? g_eyeMeta[0].time : g_eyeMeta[1].time;
        for (int c = 0; c < 3; c++) mo.angVel[c] = re.angVel[c];
        if (menu) { drawMenu(); flags |= xrb::SLOT_HUD_VISIBLE; }
        if (g_cam.cameraReprojection) flags |= xrb::SLOT_REPROJECT;
        g_vrFrames++;
    } else {
        // flat screen: the game image in the screen rect at its own shape
        float ia = (float)g_rw / (float)g_rh;   // the game image at its own shape, fitted into the screen rect
        int fw = g_ew, fh = (int)(g_ew / ia);
        if (fh > (int)g_eh) { fh = g_eh; fw = (int)(g_eh * ia); }
        Blit(g_flatSrv, S.rtv, (g_ew - fw) / 2, g_eh + (g_eh - fh) / 2, fw, fh, 0, 0, 1, 1, 0.f, 0, false, false);
        drawMenu();
        flags = xrb::SLOT_MENU_MODE | xrb::SLOT_HUD_VISIBLE;
        for (int e = 0; e < 2; e++) { poses[e] = g_cam.pose[e]; fovs[e] = g_cam.fov[e]; }
        g_screenFrames++;
    }
    S.mx->ReleaseSync(1);
    xrb::ClientSubmitSlot(slot, poses, fovs, time, flags, (flags & xrb::SLOT_REPROJECT) ? &mo : nullptr);
    g_submitted++;
}

void FrameTimingReport() {}
void CameraReport();

static const char* ModeName(int m) { return m == VRMODE_HEAD ? "head" : m == VRMODE_STEREO ? "alternate eye" : m == VRMODE_SYNCED ? "synchronized" : m == VRMODE_RECON ? "stereo reconstruction" : "screen"; }
void XrSetMode(int mode) {
    if (g_cam.mode == mode) return;
    g_cam.mode = mode;
    LOGI("xr: mode -> %s", ModeName(mode));
}
void XrApplyConfig();

void XrReport() {
    FpsLimitReport();
    { extern void PostFxReport(); PostFxReport(); }
    { extern void FovReport(); FovReport(); }
    UiReport();
    CameraReport();
    { extern void FpReport(); FpReport(); }
    recon::Report();
    if (g_cam.mode == VRMODE_RECON) LOGI("recon: frames with both eyes new %u, with the drawn eye only %u", g_reconPairs, g_reconSingle);
    g_reconPairs = g_reconSingle = 0;
    if (g_presentN) LOGI("perf: mod work at Present %.2f ms avg, %.2f max | longest game frame %.1f ms | GPU frame interval %.2f ms avg, %.2f max | ring busy (skipped, not waited) %u",
                         g_presentSum / g_presentN, g_presentMax, g_frameMax, g_gpuN ? g_gpuSum / g_gpuN : 0.0, g_gpuMax, g_ringBusy);
    if (g_tN) {
        long long vq = 0, vh = 0; game::ReadableStats(vq, vh);
        LOGI("perf: at Present (CPU, avg) - camera / menu %.2f ms (camera %.2f, menu + input %.2f, start-up checks %.2f), eyes (copy, reconstruction, blits) %.2f ms, send %.2f ms | memory checks %lld, from cache %lld",
             g_tPrep / g_tN, g_tCam / g_tN, g_tMenu / g_tN, g_tRes / g_tN, g_tEyes / g_tN, g_tSend / g_tN, vq, vh);
    }
    g_tCam = g_tMenu = g_tRes = 0;
    g_tPrep = g_tEyes = g_tSend = 0; g_tN = 0;
    g_presentSum = g_presentMax = g_frameMax = 0; g_presentN = 0; g_gpuSum = g_gpuMax = 0; g_gpuN = 0; g_ringBusy = 0;
    if (g_eyeSeqN) { g_eyeSeq[g_eyeSeqN] = 0; LOGI("xr: eyes drawn (first 32 of the last 10 s): %s%s", g_eyeSeq, g_cam.swapEyes ? " (swap eyes on)" : ""); g_eyeSeqN = 0; }
    if (g_cropped) LOGI("xr: eye images cut to the headset's own field of view: %u (submit_view = headset)", g_cropped);
    g_cropped = 0;
    LOGI("xr: host %s, submitted %u (vr %u, screen %u, first eyes held for their pair %u), atlas busy %u, no host %u, copy failed %u, no new eye image %u | mode %s, eye %ux%u fmt %d, color space %d",
         xrb::ClientHostConnected() ? "connected" : "not connected", g_submitted, g_vrFrames, g_screenFrames, g_pairHeld, g_busy, g_noHost, g_copyFail, g_noFrame,
         ModeName(g_cam.mode), g_bbW, g_bbH, (int)g_bbFmt, (int)g_colorSpace);
    if (*xrb::ClientHostError()) LOGW("xr: host error: %s", xrb::ClientHostError());
    g_submitted = g_vrFrames = g_screenFrames = g_busy = g_noHost = g_copyFail = g_noFrame = g_pairHeld = 0;
}
