// XrBridgeHost.exe - shared 64-bit OpenXR compositor bridge for VR mods.
//
// A game-side mod DLL (usually in a 32-bit game) renders both eyes + HUD into shared textures and talks to this
// process through shared memory (include/xrbridge/ipc.h). This process owns the OpenXR session, publishes predicted
// eye poses, and submits the game's frames to the runtime as a projection layer plus a HUD/menu quad layer.
//
// Command line:  XrBridgeHost.exe --name <instance> [--pid <game pid>] [--log <log file path>]
// Normally started by the mod (xrb::ClientInit), never by the user.
//
// Derived from AmalurVR_XrHost (Amalur VR mod). Additions in v4: per-instance names, D3D9Ex producers
// (slot-state sync, no keyed mutex), BGRA/RGBA format handling with a shader-blit fallback, separate HUD size.

#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <d3dcompiler.h>

#include <openxr/openxr.h>
#include <openxr/openxr_platform.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <string>
#include <vector>
#include "xrbridge/ipc.h"
#include "xrbridge/names.h"
#include "../common/log.h"
#include "../common/bmp.h"

static bool g_inProcess = false;   // XRB_IN_PROCESS: the host is a thread of the game (see HostMain)

using namespace xrb;

#define XRC(x) do { XrResult _r = (x); if (XR_FAILED(_r)) { LOGE("%s failed: %d (line %d)", #x, (int)_r, __LINE__); return false; } } while (0)

static IpcShared* g_shm = nullptr;
static HANDLE g_game = nullptr;
static HANDLE g_evtHostFrame = nullptr;
static HANDLE g_evtGameFrame = nullptr;   // the game signals it after every submitted frame
static uint32_t g_pacingLogged = 99;
static std::string g_name;
static std::wstring g_dumpDir;            // folder of the host log
static uint32_t g_lastDump = 0;
static uint32_t g_dumpNow = 0;            // != 0 while capturing the current fetch

// ------------------------------------------------------------------ pose math
struct Quat { float x, y, z, w; };
struct Vec3 { float x, y, z; };
static Quat QMul(Quat a, Quat b) {
    return {a.w * b.x + a.x * b.w + a.y * b.z - a.z * b.y, a.w * b.y - a.x * b.z + a.y * b.w + a.z * b.x,
            a.w * b.z + a.x * b.y - a.y * b.x + a.z * b.w, a.w * b.w - a.x * b.x - a.y * b.y - a.z * b.z};
}
static Quat QConj(Quat q) { return {-q.x, -q.y, -q.z, q.w}; }
static Vec3 QRot(Quat q, Vec3 v) {
    Quat p{v.x, v.y, v.z, 0};
    Quat r = QMul(QMul(q, p), QConj(q));
    return {r.x, r.y, r.z};
}
static XrPosef PoseMul(const XrPosef& a, const XrPosef& b) {   // a * b : b expressed in a's frame
    Quat qa{a.orientation.x, a.orientation.y, a.orientation.z, a.orientation.w};
    Quat qb{b.orientation.x, b.orientation.y, b.orientation.z, b.orientation.w};
    Vec3 pb = QRot(qa, {b.position.x, b.position.y, b.position.z});
    Quat q = QMul(qa, qb);
    XrPosef r;
    r.orientation = {q.x, q.y, q.z, q.w};
    r.position = {a.position.x + pb.x, a.position.y + pb.y, a.position.z + pb.z};
    return r;
}
static XrPosef PoseInv(const XrPosef& a) {
    Quat qi = QConj({a.orientation.x, a.orientation.y, a.orientation.z, a.orientation.w});
    Vec3 p = QRot(qi, {-a.position.x, -a.position.y, -a.position.z});
    XrPosef r;
    r.orientation = {qi.x, qi.y, qi.z, qi.w};
    r.position = {p.x, p.y, p.z};
    return r;
}
static XrPosef Identity() { XrPosef p{}; p.orientation.w = 1; return p; }

// ------------------------------------------------------------------ formats
enum Family { FAM_NONE, FAM_RGBA, FAM_BGRA };
static Family FormatFamily(int64_t f) {
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_TYPELESS: case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: return FAM_RGBA;
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: return FAM_BGRA;
    default: return FAM_NONE;
    }
}
static DXGI_FORMAT Unorm(Family f) { return f == FAM_BGRA ? DXGI_FORMAT_B8G8R8A8_UNORM : DXGI_FORMAT_R8G8B8A8_UNORM; }
static DXGI_FORMAT Srgb(Family f) { return f == FAM_BGRA ? DXGI_FORMAT_B8G8R8A8_UNORM_SRGB : DXGI_FORMAT_R8G8B8A8_UNORM_SRGB; }
static bool IsSrgb(int64_t f) { return f == DXGI_FORMAT_R8G8B8A8_UNORM_SRGB || f == DXGI_FORMAT_B8G8R8A8_UNORM_SRGB; }

// ------------------------------------------------------------------ state
struct Swap {
    XrSwapchain sc = XR_NULL_HANDLE;
    std::vector<XrSwapchainImageD3D11KHR> images;
    std::vector<ID3D11RenderTargetView*> rtv;   // blit mode only, created lazily
    bool rtvSrgb = false;
    uint32_t w = 0, h = 0;
    int last = -1;                              // image index of the last picture put into this swapchain
};

static XrInstance g_inst = XR_NULL_HANDLE;
static XrSystemId g_sys = XR_NULL_SYSTEM_ID;
static XrSession g_sess = XR_NULL_HANDLE;
static XrSpace g_local = XR_NULL_HANDLE, g_view = XR_NULL_HANDLE;
static XrSessionState g_state = XR_SESSION_STATE_UNKNOWN;
static bool g_running = false;
static ID3D11Device* g_dev = nullptr;
static ID3D11DeviceContext* g_ctx = nullptr;
static ID3D11Query* g_copyDone = nullptr;
static XrViewConfigurationView g_vcv[2] = {{XR_TYPE_VIEW_CONFIGURATION_VIEW}, {XR_TYPE_VIEW_CONFIGURATION_VIEW}};
static std::vector<int64_t> g_runtimeFormats;
static Swap g_eye[2], g_hud;
static int64_t g_swapFormat = 0;
static bool g_blit = false;
static char g_runtimeName[128] = "";

// Panels drawn into the projection layer ("composite"): the HUD / VR menu / flat screen drawn by the host into the eye
// images instead of submitted as a quad layer. Some runtimes show quad layers badly or not at all (Pimax OpenXR: the
// flat screen black, the VR menu missing), and some show nothing for a frame without a projection layer. Composite
// works everywhere; quad layers are a bit sharper where they work.
static ID3D11Texture2D* g_hudTex = nullptr;       // copy of the atlas' HUD rectangle (the panel's picture)
static ID3D11ShaderResourceView* g_hudSrv = nullptr;
static ID3D11Texture2D* g_clean[2] = {};          // the eye images without the panel (redrawn on each headset frame)
static ID3D11VertexShader* g_ovVs = nullptr;
static ID3D11PixelShader* g_ovPs = nullptr;
static ID3D11Buffer* g_ovCb = nullptr;
static ID3D11SamplerState* g_ovSmp = nullptr;
static ID3D11BlendState* g_ovBlendPre = nullptr, *g_ovBlendStraight = nullptr;
static ID3D11RasterizerState* g_ovRs = nullptr;
static bool g_ovFailed = false;
static int g_panelModeLogged = -1;

struct SharedTex { ID3D11Texture2D* tex = nullptr; IDXGIKeyedMutex* mutex = nullptr; ID3D11ShaderResourceView* srv = nullptr; };
static SharedTex g_tex[kSlots];
static uint32_t g_texGen = 0, g_syncMode = SYNC_KEYED_MUTEX;
static IpcRect g_eyeRect[2], g_hudRect;

// shader blit (only when the runtime offers no swapchain format in the game's format family)
static ID3D11VertexShader* g_vs = nullptr;
static ID3D11PixelShader* g_ps = nullptr;
static ID3D11Buffer* g_cb = nullptr;
static ID3D11RasterizerState* g_rs = nullptr;

static XrPosef g_base = Identity();       // recenter reference (in LOCAL space)
static XrPosef g_menuBase = Identity();   // where the flat screen / VR panel is: in front of the head when it appeared
static bool g_menuBaseSet = false, g_menuWas = false, g_recenteredNow = false;
static uint32_t g_lastRecenter = 0;
static bool g_needRecenter = true;

static bool g_haveFrame = false;          // swapchains hold a valid image
static bool g_forceResync = false;        // a swapchain went bad: recreate everything on the next frame
static int g_releasePending = -1;         // slot-state mode: slot still READING until our copy fence completes
static XrTime g_spaceChangeTime = 0;      // pending LOCAL space change (recenter once it takes effect)
static bool g_spaceChangePending = false;
static IpcPose g_shownPose[2];
static IpcFov g_shownFov[2];
static uint32_t g_shownFlags = 0;
static IpcMotion g_shownMotion{};
static bool g_shownNew = false;           // the shown frame was fetched this headset frame (first display)
static uint32_t g_lastSubmitSeq = 0;

// ------------------------------------------------------------------ camera-aware reprojection (SLOT_REPROJECT)
// A game running below the headset rate shows each frame for one or more headset frames; while its camera pans the
// image stands still and then jumps (60 fps on 90 Hz: 2,1,2,1). Here each eye layer is rotated by the camera's
// rotation since the frame's content time, so the scene keeps moving at every headset frame. Only rotation can be
// corrected; near objects that move with the camera (the character it orbits) wobble slightly instead.
// The game's content times are on its own clock: the offset to XrTime is learned as the minimum of (display time -
// content time) over recent frames at their first display, i.e. the shortest path from game frame to the display.
static int64_t g_rpOffsets[90];
static int g_rpCount = 0, g_rpNext = 0;
static struct { uint32_t frames; double dtMs, dtMaxMs, speedDeg; } g_rpStats{};
static const double kRpMaxDt = 0.05;      // s: never extrapolate further (a stalled game keeps its last image)

static XrQuaternionf QuatFromRotVec(const float v[3], double dt) {
    double x = v[0] * dt, y = v[1] * dt, z = v[2] * dt;
    double a = sqrt(x * x + y * y + z * z);
    if (a < 1e-9) return {0, 0, 0, 1};
    double s = sin(a / 2) / a;
    return {(float)(x * s), (float)(y * s), (float)(z * s), (float)cos(a / 2)};
}

// Rotation for eye e at display time `display`, or false (no reprojection).
static bool ReprojectRotation(XrTime display, XrQuaternionf q[2]) {
    if (!(g_shownFlags & SLOT_REPROJECT) || (g_shownFlags & SLOT_MENU_MODE)) return false;
    const IpcMotion& m = g_shownMotion;
    int64_t newest = m.contentTime[0] > m.contentTime[1] ? m.contentTime[0] : m.contentTime[1];
    if (!newest) return false;
    if (g_shownNew) {
        g_rpOffsets[g_rpNext] = display - newest;
        g_rpNext = (g_rpNext + 1) % 90;
        if (g_rpCount < 90) g_rpCount++;
    }
    if (!g_rpCount) return false;
    int64_t off = g_rpOffsets[0];
    for (int i = 1; i < g_rpCount; ++i) if (g_rpOffsets[i] < off) off = g_rpOffsets[i];
    for (int e = 0; e < 2; ++e) {
        double dt = (double)(display - off - (m.contentTime[e] ? m.contentTime[e] : newest)) / 1e9;
        if (dt < 0) dt = 0;
        if (dt > kRpMaxDt) dt = kRpMaxDt;
        q[e] = QuatFromRotVec(m.angVel, dt);
        if (e == 0) {
            g_rpStats.frames++;
            g_rpStats.dtMs += dt * 1000;
            if (dt * 1000 > g_rpStats.dtMaxMs) g_rpStats.dtMaxMs = dt * 1000;
            g_rpStats.speedDeg += sqrt(m.angVel[0] * m.angVel[0] + m.angVel[1] * m.angVel[1] + m.angVel[2] * m.angVel[2]) * 57.2958;
        }
    }
    return true;
}
static struct {
    uint32_t frames, shouldRender, fetched, busy, layersProj, layersQuad; DWORD t0;
    uint32_t pacedTimeouts, pacedFast; double pacedWaitMs;
    double waitMs, fetchMs, fetchMaxMs, endMs, intervalMaxMs;   // frame timing (QPC)
    uint32_t late;                                              // frames that came > 1.5 display periods after the previous one
} g_stats{};
static LARGE_INTEGER g_qpf{}, g_lastWaitDone{};
static double QpcMs(LONGLONG a, LONGLONG b) { return (double)(b - a) * 1000.0 / (double)g_qpf.QuadPart; }
static LONGLONG QpcNow() { LARGE_INTEGER t; QueryPerformanceCounter(&t); return t.QuadPart; }

// ------------------------------------------------------------------ D3D11 device on the runtime's adapter
static bool CreateDevice(LUID luid) {
    IDXGIFactory1* fac = nullptr;
    {   // the system dxgi.dll's own factory (in-process the mod itself may be loaded as dxgi.dll)
        wchar_t sys[MAX_PATH]; GetSystemDirectoryW(sys, MAX_PATH);
        HMODULE dx = LoadLibraryW((std::wstring(sys) + L"\\dxgi.dll").c_str());
        typedef HRESULT(WINAPI* PFN_CF1)(REFIID, void**);
        PFN_CF1 cf1 = dx ? (PFN_CF1)GetProcAddress(dx, "CreateDXGIFactory1") : nullptr;
        if (!cf1 || FAILED(cf1(__uuidof(IDXGIFactory1), (void**)&fac))) return false;
    }
    IDXGIAdapter1* chosen = nullptr;
    IDXGIAdapter1* ad = nullptr;
    for (UINT i = 0; fac->EnumAdapters1(i, &ad) != DXGI_ERROR_NOT_FOUND; ++i) {
        DXGI_ADAPTER_DESC1 d; ad->GetDesc1(&d);
        if (d.AdapterLuid.LowPart == luid.LowPart && d.AdapterLuid.HighPart == luid.HighPart) { chosen = ad; LOGI("Using adapter: %S", d.Description); break; }
        ad->Release();
    }
    fac->Release();
    D3D_FEATURE_LEVEL fl[] = {D3D_FEATURE_LEVEL_11_1, D3D_FEATURE_LEVEL_11_0};
    HRESULT hr = D3D11CreateDevice(chosen, chosen ? D3D_DRIVER_TYPE_UNKNOWN : D3D_DRIVER_TYPE_HARDWARE, nullptr,
                                   D3D11_CREATE_DEVICE_BGRA_SUPPORT, fl, 2, D3D11_SDK_VERSION, &g_dev, nullptr, &g_ctx);
    if (chosen) chosen->Release();
    if (FAILED(hr)) { LOGE("D3D11CreateDevice failed %08X", hr); return false; }
    {   // GPU scheduling priority. The game fills the GPU; the host's per-frame copy and the runtime's compositor queue
        // up behind its passes, the headset frame is finished late and the runtime's motion smoothing reads that as
        // "app too slow" (half rate). With a higher GPU priority the host's small copy is scheduled ahead of the
        // game's work (what VR compositors and capture tools do).
        int cls = -1; long st = -1;
        if (HMODULE gdi = LoadLibraryW(L"gdi32.dll")) {
            typedef long (WINAPI* PFN)(HANDLE, int);
            if (PFN f = g_inProcess ? nullptr : (PFN)GetProcAddress(gdi, "D3DKMTSetProcessSchedulingPriorityClass")) {
                for (int c : { 5 /* realtime */, 4 /* high */ }) { st = f(GetCurrentProcess(), c); if (st == 0) { cls = c; break; } }
            }
        }
        HRESULT hp = E_FAIL;
        IDXGIDevice* dd = nullptr;
        if (SUCCEEDED(g_dev->QueryInterface(__uuidof(IDXGIDevice), (void**)&dd)) && dd) { hp = dd->SetGPUThreadPriority(7); dd->Release(); }
        LOGI("GPU priority: process scheduling class %s (status %08lX), GPU thread priority +7 %s",
             cls == 5 ? "REALTIME" : cls == 4 ? "HIGH" : "unchanged", (unsigned long)st, SUCCEEDED(hp) ? "ok" : "failed");
    }
    D3D11_QUERY_DESC qd{D3D11_QUERY_EVENT, 0};
    g_dev->CreateQuery(&qd, &g_copyDone);
    return true;
}

// Slot-state mode: the game may overwrite a slot as soon as we mark it FREE and there is no keyed mutex to order
// the two devices, so a slot stays READING until our copies out of it have executed on the GPU.
// Waits up to `ms`; returns true when the fence passed. On timeout the slot stays READING (see TryReleasePending).
static bool CopiesDone(unsigned ms) {
    if (!g_copyDone) { g_ctx->Flush(); return true; }
    DWORD t0 = GetTickCount();
    for (;;) {
        HRESULT r = g_ctx->GetData(g_copyDone, nullptr, 0, 0);
        if (r != S_FALSE) return true;   // S_OK, or device removed (nothing will ever complete then)
        if (GetTickCount() - t0 >= ms) return false;
        YieldProcessor();
    }
}

static void ReleaseSlot(int slot) {
    MemoryBarrier();
    InterlockedCompareExchange((volatile LONG*)&g_shm->slotState[slot], SLOT_FREE, SLOT_READING);
}

// Finish a release that timed out on an earlier frame. Returns false while it is still pending.
static bool TryReleasePending() {
    if (g_releasePending < 0) return true;
    if (!CopiesDone(0)) return false;
    ReleaseSlot(g_releasePending);
    g_releasePending = -1;
    return true;
}

// ------------------------------------------------------------------ shader blit
static const char kBlitHlsl[] =
    "cbuffer C : register(b0) { int2 offset; int linearize; int pad; };\n"
    "Texture2D<float4> src : register(t0);\n"
    "float4 vs(uint id : SV_VertexID) : SV_Position {\n"
    "  float2 uv = float2((id << 1) & 2, id & 2);\n"
    "  return float4(uv * float2(2, -2) + float2(-1, 1), 0, 1);\n"
    "}\n"
    "float3 toLinear(float3 c) { return c <= 0.04045 ? c / 12.92 : pow((c + 0.055) / 1.055, 2.4); }\n"
    "float4 ps(float4 pos : SV_Position) : SV_Target {\n"
    "  float4 c = src.Load(int3(int2(pos.xy) + offset, 0));\n"
    "  if (linearize) c.rgb = toLinear(c.rgb);\n"
    "  return c;\n"
    "}\n";

static bool InitBlit() {
    if (g_vs) return true;
    HMODULE dc = LoadLibraryW(L"d3dcompiler_47.dll");
    auto compile = dc ? (pD3DCompile)GetProcAddress(dc, "D3DCompile") : nullptr;
    if (!compile) { LOGE("d3dcompiler_47.dll not available - cannot convert texture formats"); return false; }
    ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
    if (FAILED(compile(kBlitHlsl, sizeof(kBlitHlsl) - 1, "blit", nullptr, nullptr, "vs", "vs_5_0", 0, 0, &vsb, &err)) ||
        FAILED(compile(kBlitHlsl, sizeof(kBlitHlsl) - 1, "blit", nullptr, nullptr, "ps", "ps_5_0", 0, 0, &psb, &err))) {
        LOGE("blit shader compile failed: %s", err ? (const char*)err->GetBufferPointer() : "?");
        if (err) err->Release();
        if (vsb) vsb->Release();
        if (psb) psb->Release();
        return false;
    }
    if (err) err->Release();
    g_dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_vs);
    g_dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ps);
    vsb->Release(); psb->Release();
    D3D11_BUFFER_DESC bd{16, D3D11_USAGE_DEFAULT, D3D11_BIND_CONSTANT_BUFFER, 0, 0, 0};
    g_dev->CreateBuffer(&bd, nullptr, &g_cb);
    D3D11_RASTERIZER_DESC rd{};
    rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
    g_dev->CreateRasterizerState(&rd, &g_rs);
    LOGI("shader blit ready");
    return g_vs && g_ps && g_cb;
}

// ------------------------------------------------------------------ OpenXR setup
static bool InitXr() {
    {   // implicit API layers (OpenXR Toolkit, Pimax / vendor layers, motion reprojection layers ...) load by themselves
        uint32_t n = 0;
        if (XR_SUCCEEDED(xrEnumerateApiLayerProperties(0, &n, nullptr)) && n) {
            std::vector<XrApiLayerProperties> lp(n, {XR_TYPE_API_LAYER_PROPERTIES});
            if (XR_SUCCEEDED(xrEnumerateApiLayerProperties(n, &n, lp.data())))
                for (uint32_t i = 0; i < n; ++i) LOGI("OpenXR API layer available: %s (%s)", lp[i].layerName, lp[i].description);
        } else LOGI("OpenXR API layers: none installed");
    }
    std::vector<const char*> exts = {XR_KHR_D3D11_ENABLE_EXTENSION_NAME};
    XrInstanceCreateInfo ci{XR_TYPE_INSTANCE_CREATE_INFO};
    char app[64] = {};
    memcpy(app, g_shm->appName, sizeof(app) - 1);
    strcpy_s(ci.applicationInfo.applicationName, app[0] ? app : g_name.c_str());
    ci.applicationInfo.applicationVersion = 1;
    strcpy_s(ci.applicationInfo.engineName, "XrBridge");
    ci.applicationInfo.engineVersion = kIpcVersion;
    ci.applicationInfo.apiVersion = XR_MAKE_VERSION(1, 0, 0);
    ci.enabledExtensionCount = (uint32_t)exts.size();
    ci.enabledExtensionNames = exts.data();
    XRC(xrCreateInstance(&ci, &g_inst));
    XrInstanceProperties ip{XR_TYPE_INSTANCE_PROPERTIES};
    xrGetInstanceProperties(g_inst, &ip);
    snprintf(g_runtimeName, sizeof g_runtimeName, "%s", ip.runtimeName);
    LOGI("OpenXR runtime: %s %u.%u.%u", ip.runtimeName, XR_VERSION_MAJOR(ip.runtimeVersion), XR_VERSION_MINOR(ip.runtimeVersion), XR_VERSION_PATCH(ip.runtimeVersion));
    strncpy_s(g_shm->runtimeName, ip.runtimeName, _TRUNCATE);

    XrSystemGetInfo sg{XR_TYPE_SYSTEM_GET_INFO};
    sg.formFactor = XR_FORM_FACTOR_HEAD_MOUNTED_DISPLAY;
    for (int tries = 0;; ++tries) {
        XrResult r = xrGetSystem(g_inst, &sg, &g_sys);
        if (XR_SUCCEEDED(r)) break;
        if (r == XR_ERROR_FORM_FACTOR_UNAVAILABLE && tries < 60) { if (tries == 0) LOGW("Headset not available yet, waiting..."); Sleep(1000); continue; }
        LOGE("xrGetSystem failed: %d", (int)r);
        return false;
    }
    XrSystemProperties sp{XR_TYPE_SYSTEM_PROPERTIES};
    xrGetSystemProperties(g_inst, g_sys, &sp);
    LOGI("System: %s (max swapchain %ux%u)", sp.systemName, sp.graphicsProperties.maxSwapchainImageWidth, sp.graphicsProperties.maxSwapchainImageHeight);
    strncpy_s(g_shm->systemName, sp.systemName, _TRUNCATE);

    uint32_t n = 0;
    XRC(xrEnumerateViewConfigurationViews(g_inst, g_sys, XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO, 2, &n, g_vcv));
    LOGI("Recommended per-eye %ux%u (max %ux%u)", g_vcv[0].recommendedImageRectWidth, g_vcv[0].recommendedImageRectHeight,
         g_vcv[0].maxImageRectWidth, g_vcv[0].maxImageRectHeight);

    PFN_xrGetD3D11GraphicsRequirementsKHR getReq = nullptr;
    XRC(xrGetInstanceProcAddr(g_inst, "xrGetD3D11GraphicsRequirementsKHR", (PFN_xrVoidFunction*)&getReq));
    XrGraphicsRequirementsD3D11KHR req{XR_TYPE_GRAPHICS_REQUIREMENTS_D3D11_KHR};
    XRC(getReq(g_inst, g_sys, &req));
    g_shm->adapterLuid = ((uint64_t)(uint32_t)req.adapterLuid.HighPart << 32) | req.adapterLuid.LowPart;
    if (!CreateDevice(req.adapterLuid)) return false;

    XrGraphicsBindingD3D11KHR gb{XR_TYPE_GRAPHICS_BINDING_D3D11_KHR};
    gb.device = g_dev;
    XrSessionCreateInfo sci{XR_TYPE_SESSION_CREATE_INFO};
    sci.next = &gb;
    sci.systemId = g_sys;
    XRC(xrCreateSession(g_inst, &sci, &g_sess));

    XrReferenceSpaceCreateInfo rs{XR_TYPE_REFERENCE_SPACE_CREATE_INFO};
    rs.poseInReferenceSpace = Identity();
    rs.referenceSpaceType = XR_REFERENCE_SPACE_TYPE_LOCAL;
    XRC(xrCreateReferenceSpace(g_sess, &rs, &g_local));
    rs.referenceSpaceType = XR_REFERENCE_SPACE_TYPE_VIEW;
    XRC(xrCreateReferenceSpace(g_sess, &rs, &g_view));

    uint32_t fc = 0;
    xrEnumerateSwapchainFormats(g_sess, 0, &fc, nullptr);
    g_runtimeFormats.resize(fc);
    xrEnumerateSwapchainFormats(g_sess, fc, &fc, g_runtimeFormats.data());
    std::string list;
    for (auto f : g_runtimeFormats) list += std::to_string(f) + " ";
    LOGI("Runtime swapchain formats: %s", list.c_str());

    {   // the largest per-eye image the runtime takes (swapchain and view limits)
        uint32_t mw = g_vcv[0].maxImageRectWidth, mh = g_vcv[0].maxImageRectHeight;
        if (g_vcv[1].maxImageRectWidth && g_vcv[1].maxImageRectWidth < mw) mw = g_vcv[1].maxImageRectWidth;
        if (g_vcv[1].maxImageRectHeight && g_vcv[1].maxImageRectHeight < mh) mh = g_vcv[1].maxImageRectHeight;
        if (sp.graphicsProperties.maxSwapchainImageWidth && sp.graphicsProperties.maxSwapchainImageWidth < mw) mw = sp.graphicsProperties.maxSwapchainImageWidth;
        if (sp.graphicsProperties.maxSwapchainImageHeight && sp.graphicsProperties.maxSwapchainImageHeight < mh) mh = sp.graphicsProperties.maxSwapchainImageHeight;
        g_shm->maxEyeWidth = mw; g_shm->maxEyeHeight = mh;
    }
    // the larger of the two eyes' recommendations (runtimes may report them differently)
    g_shm->recWidth = g_vcv[0].recommendedImageRectWidth > g_vcv[1].recommendedImageRectWidth ? g_vcv[0].recommendedImageRectWidth : g_vcv[1].recommendedImageRectWidth;
    g_shm->recHeight = g_vcv[0].recommendedImageRectHeight > g_vcv[1].recommendedImageRectHeight ? g_vcv[0].recommendedImageRectHeight : g_vcv[1].recommendedImageRectHeight;
    if (g_vcv[0].recommendedImageRectWidth != g_vcv[1].recommendedImageRectWidth || g_vcv[0].recommendedImageRectHeight != g_vcv[1].recommendedImageRectHeight)
        LOGI("Eyes recommend %ux%u / %ux%u - the larger is used", g_vcv[0].recommendedImageRectWidth, g_vcv[0].recommendedImageRectHeight,
             g_vcv[1].recommendedImageRectWidth, g_vcv[1].recommendedImageRectHeight);
    MemoryBarrier();
    g_shm->hostState = HOST_READY;
    return true;
}

static bool RuntimeHasFormat(int64_t f) {
    for (auto x : g_runtimeFormats) if (x == f) return true;
    return false;
}

// Pick the swapchain format for the game's texture format. Same family -> plain GPU copy; otherwise shader blit.
static bool ChooseSwapFormat(uint32_t texFormat) {
    Family fam = FormatFamily(texFormat);
    if (fam == FAM_NONE) { LOGE("Unsupported shared texture format %u (need an 8-bit RGBA or BGRA format)", texFormat); return false; }
    Family other = fam == FAM_RGBA ? FAM_BGRA : FAM_RGBA;
    const int64_t prefs[4] = {Srgb(fam), Unorm(fam), Srgb(other), Unorm(other)};
    g_swapFormat = 0;
    for (int64_t p : prefs) if (RuntimeHasFormat(p)) { g_swapFormat = p; break; }
    if (!g_swapFormat) { LOGE("Runtime offers no 8-bit RGBA/BGRA swapchain format"); return false; }
    // Game pixels are gamma-encoded. An sRGB swapchain takes them as-is; a UNORM one is treated as linear by the
    // runtime, so we must decode in the blit shader (CopySubresourceRegion can't convert).
    g_blit = FormatFamily(g_swapFormat) != fam || !IsSrgb(g_swapFormat);
    if (g_blit && !InitBlit()) return false;
    g_shm->swapFormat = (uint32_t)g_swapFormat;
    g_shm->hostCopyMode = g_blit ? 1 : 0;
    LOGI("Game texture format %u -> swapchain format %lld (%s)", texFormat, (long long)g_swapFormat, g_blit ? "shader blit" : "direct copy");
    return true;
}

static bool CreateSwap(Swap& s, uint32_t w, uint32_t h) {
    XrSwapchainCreateInfo ci{XR_TYPE_SWAPCHAIN_CREATE_INFO};
    ci.usageFlags = XR_SWAPCHAIN_USAGE_TRANSFER_DST_BIT | XR_SWAPCHAIN_USAGE_COLOR_ATTACHMENT_BIT | XR_SWAPCHAIN_USAGE_SAMPLED_BIT;
    ci.format = g_swapFormat;
    ci.sampleCount = 1; ci.width = w; ci.height = h; ci.faceCount = 1; ci.arraySize = 1; ci.mipCount = 1;
    XRC(xrCreateSwapchain(g_sess, &ci, &s.sc));
    uint32_t n = 0;
    xrEnumerateSwapchainImages(s.sc, 0, &n, nullptr);
    s.images.assign(n, {XR_TYPE_SWAPCHAIN_IMAGE_D3D11_KHR});
    XRC(xrEnumerateSwapchainImages(s.sc, n, &n, (XrSwapchainImageBaseHeader*)s.images.data()));
    s.rtv.assign(n, nullptr);
    s.w = w; s.h = h;
    return true;
}

static void DestroySwap(Swap& s) {
    s.last = -1;
    for (auto* r : s.rtv) if (r) r->Release();
    if (s.sc) xrDestroySwapchain(s.sc);
    s = Swap();
}

static void ReleaseOverlayTex();
static void ReleaseShared() {
    ReleaseOverlayTex();
    for (auto& t : g_tex) {
        if (t.srv) t.srv->Release();
        if (t.mutex) t.mutex->Release();
        if (t.tex) t.tex->Release();
        t = SharedTex();
    }
}

static bool RectOk(const IpcRect& r, uint32_t aw, uint32_t ah) {
    return r.w > 0 && r.h > 0 && r.x >= 0 && r.y >= 0 && (uint32_t)(r.x + r.w) <= aw && (uint32_t)(r.y + r.h) <= ah;
}

// (Re)open the game's shared atlases when the game publishes a new generation.
static bool SyncSharedTextures() {
    uint32_t gen = g_shm->gameState;
    if (gen == g_texGen && !g_forceResync) return g_tex[0].tex != nullptr;
    if (g_releasePending >= 0) { CopiesDone(100); ReleaseSlot(g_releasePending); g_releasePending = -1; }
    g_forceResync = false;
    ReleaseShared();
    DestroySwap(g_eye[0]); DestroySwap(g_eye[1]); DestroySwap(g_hud);
    g_haveFrame = false;
    g_texGen = gen;
    if (!gen) return false;
    MemoryBarrier();
    uint32_t aw = g_shm->atlasWidth, ah = g_shm->atlasHeight;
    if (!aw || !ah) { LOGI("Game withdrew its textures (gen %u)", gen); return false; }
    g_syncMode = g_shm->syncMode;
    g_eyeRect[0] = g_shm->eyeRect[0]; g_eyeRect[1] = g_shm->eyeRect[1]; g_hudRect = g_shm->hudRect;
    if (!RectOk(g_eyeRect[0], aw, ah) || !RectOk(g_eyeRect[1], aw, ah) || !RectOk(g_hudRect, aw, ah) ||
        g_eyeRect[0].w != g_eyeRect[1].w || g_eyeRect[0].h != g_eyeRect[1].h) {
        LOGE("Invalid atlas layout from game (atlas %ux%u)", aw, ah);
        return false;
    }
    if (!ChooseSwapFormat(g_shm->texFormat)) return false;
    for (int i = 0; i < kSlots; ++i) {
        // 32-bit handle values are sign-extended when moved to a 64-bit process (Windows interop rule)
        HANDLE h = (HANDLE)(LONG_PTR)(LONG)(uint32_t)g_shm->sharedHandle[i];
        if (FAILED(g_dev->OpenSharedResource(h, __uuidof(ID3D11Texture2D), (void**)&g_tex[i].tex))) {
            LOGE("OpenSharedResource(slot %d, handle %p) failed - is the game on the same GPU as the headset?", i, h);
            ReleaseShared();
            return false;
        }
        if (g_syncMode == SYNC_KEYED_MUTEX && FAILED(g_tex[i].tex->QueryInterface(__uuidof(IDXGIKeyedMutex), (void**)&g_tex[i].mutex))) {
            LOGE("Slot %d has no keyed mutex but the game asked for SYNC_KEYED_MUTEX", i);
            ReleaseShared();
            return false;
        }
        if (g_blit) {
            D3D11_TEXTURE2D_DESC td; g_tex[i].tex->GetDesc(&td);
            D3D11_SHADER_RESOURCE_VIEW_DESC sv{};
            sv.Format = Unorm(FormatFamily(td.Format));
            sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D;
            sv.Texture2D.MipLevels = 1;
            if (FAILED(g_dev->CreateShaderResourceView(g_tex[i].tex, &sv, &g_tex[i].srv))) {
                LOGE("Cannot create SRV on shared slot %d (format %u, bind %u)", i, td.Format, td.BindFlags);
                ReleaseShared();
                return false;
            }
        }
    }
    bool ok = CreateSwap(g_eye[0], g_eyeRect[0].w, g_eyeRect[0].h) && CreateSwap(g_eye[1], g_eyeRect[1].w, g_eyeRect[1].h) &&
              CreateSwap(g_hud, g_hudRect.w, g_hudRect.h);
    LOGI("Opened game atlases %ux%u (gen %u, %s): eyes %dx%d, HUD %dx%d, swapchains %s", aw, ah, gen,
         g_syncMode == SYNC_KEYED_MUTEX ? "keyed mutex" : "slot state", g_eyeRect[0].w, g_eyeRect[0].h, g_hudRect.w, g_hudRect.h,
         ok ? "ok" : "FAILED");
    if (!ok) { ReleaseShared(); DestroySwap(g_eye[0]); DestroySwap(g_eye[1]); DestroySwap(g_hud); }
    return ok;
}

// ------------------------------------------------------------------ frame
static bool Recenter(XrTime t) {
    XrSpaceLocation loc{XR_TYPE_SPACE_LOCATION};
    if (XR_FAILED(xrLocateSpace(g_view, g_local, t, &loc)) || !(loc.locationFlags & XR_SPACE_LOCATION_ORIENTATION_VALID_BIT) ||
        !(loc.locationFlags & XR_SPACE_LOCATION_POSITION_VALID_BIT)) return false;
    // keep only yaw (rotation about +Y) and position
    Quat q{loc.pose.orientation.x, loc.pose.orientation.y, loc.pose.orientation.z, loc.pose.orientation.w};
    Vec3 fwd = QRot(q, {0, 0, -1});
    float yaw = atan2f(-fwd.x, -fwd.z);
    g_base.orientation = {0, sinf(yaw * 0.5f), 0, cosf(yaw * 0.5f)};
    g_base.position = loc.pose.position;
    LOGI("Recentered: yaw %.1f deg, pos (%.2f %.2f %.2f)", yaw * 57.2958f, g_base.position.x, g_base.position.y, g_base.position.z);
    g_recenteredNow = true;
    return true;
}

static void PublishPoses(const XrView views[2], XrTime t, XrDuration period) {
    XrPosef inv = PoseInv(g_base);
    g_shm->poseSeq = g_shm->poseSeq + 1;   // odd: writing
    MemoryBarrier();
    for (int e = 0; e < 2; ++e) {
        XrPosef p = PoseMul(inv, views[e].pose);
        g_shm->eyePose[e] = {p.position.x, p.position.y, p.position.z, p.orientation.x, p.orientation.y, p.orientation.z, p.orientation.w};
        g_shm->eyeFov[e] = {views[e].fov.angleLeft, views[e].fov.angleRight, views[e].fov.angleUp, views[e].fov.angleDown};
    }
    g_shm->predictedTime = t;
    g_shm->displayPeriodNs = period;
    MemoryBarrier();
    g_shm->poseSeq = g_shm->poseSeq + 1;
}

static ID3D11RenderTargetView* GetRtv(Swap& s, uint32_t idx) {
    if (s.rtv[idx]) return s.rtv[idx];
    // Prefer a UNORM view so the game's (already gamma-encoded) bytes pass through unchanged. This needs a typeless
    // swapchain texture; if the runtime's texture is typed sRGB we use an sRGB view and linearise in the shader.
    D3D11_RENDER_TARGET_VIEW_DESC rd{};
    rd.ViewDimension = D3D11_RTV_DIMENSION_TEXTURE2D;
    rd.Format = Unorm(FormatFamily(g_swapFormat));
    s.rtvSrgb = false;
    if (FAILED(g_dev->CreateRenderTargetView(s.images[idx].texture, &rd, &s.rtv[idx]))) {
        rd.Format = (DXGI_FORMAT)g_swapFormat;
        s.rtvSrgb = IsSrgb(g_swapFormat);
        if (FAILED(g_dev->CreateRenderTargetView(s.images[idx].texture, &rd, &s.rtv[idx]))) { LOGE("swapchain RTV failed"); return nullptr; }
    }
    return s.rtv[idx];
}

static void BlitRegion(Swap& s, uint32_t idx, ID3D11ShaderResourceView* srv, const IpcRect& r) {
    ID3D11RenderTargetView* rtv = GetRtv(s, idx);
    if (!rtv) return;
    // decode gamma if the hardware re-encodes (sRGB view) or the runtime treats the swapchain as linear (UNORM)
    int cb[4] = {r.x, r.y, (s.rtvSrgb || !IsSrgb(g_swapFormat)) ? 1 : 0, 0};
    g_ctx->UpdateSubresource(g_cb, 0, nullptr, cb, 0, 0);
    D3D11_VIEWPORT vp{0, 0, (float)r.w, (float)r.h, 0, 1};
    g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
    g_ctx->OMSetBlendState(nullptr, nullptr, 0xffffffff);
    g_ctx->RSSetViewports(1, &vp);
    g_ctx->RSSetState(g_rs);
    g_ctx->IASetInputLayout(nullptr);
    g_ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
    g_ctx->VSSetShader(g_vs, nullptr, 0);
    g_ctx->PSSetShader(g_ps, nullptr, 0);
    g_ctx->PSSetConstantBuffers(0, 1, &g_cb);
    g_ctx->PSSetShaderResources(0, 1, &srv);
    g_ctx->Draw(3, 0);
    ID3D11ShaderResourceView* nul = nullptr;
    g_ctx->PSSetShaderResources(0, 1, &nul);
    g_ctx->OMSetRenderTargets(0, nullptr, nullptr);
}

// ------------------------------------------------------------------ panels drawn into the eye images
static const char kOverlayHlsl[] =
    "cbuffer C : register(b0) { float4 pos[4]; float4 opt; };\n"   // clip-space corners (TL TR BL BR); opt.x linearize, opt.y opaque
    "Texture2D<float4> src : register(t0); SamplerState smp : register(s0);\n"
    "struct V { float4 p : SV_Position; float2 uv : TEXCOORD0; };\n"
    "V vs(uint id : SV_VertexID) { V o; o.p = id == 0u ? pos[0] : (id == 1u ? pos[1] : (id == 2u ? pos[2] : pos[3])); o.uv = float2((float)(id & 1u), (float)(id >> 1u)); return o; }\n"
    "float3 toLinear(float3 c) { float3 lo = c / 12.92; float3 hi = pow(max((c + 0.055) / 1.055, 0.0), 2.4); return lerp(hi, lo, step(c, 0.04045)); }\n"
    "float4 ps(V i) : SV_Target {\n"
    "  float4 c = src.Sample(smp, i.uv);\n"
    "  if (opt.y > 0.5) c.a = 1.0;\n"
    "  if (opt.x > 0.5) c.rgb = toLinear(c.rgb);\n"
    "  return c;\n"
    "}\n";

static bool InitOverlay() {
    if (g_ovVs) return true;
    if (g_ovFailed) return false;
    g_ovFailed = true;
    HMODULE dc = LoadLibraryW(L"d3dcompiler_47.dll");
    auto compile = dc ? (pD3DCompile)GetProcAddress(dc, "D3DCompile") : nullptr;
    if (!compile) { LOGE("panels: d3dcompiler_47.dll not available - quad layers only"); return false; }
    ID3DBlob *vsb = nullptr, *psb = nullptr, *err = nullptr;
    if (FAILED(compile(kOverlayHlsl, sizeof(kOverlayHlsl) - 1, "overlay", nullptr, nullptr, "vs", "vs_5_0", 0, 0, &vsb, &err)) ||
        FAILED(compile(kOverlayHlsl, sizeof(kOverlayHlsl) - 1, "overlay", nullptr, nullptr, "ps", "ps_5_0", 0, 0, &psb, &err))) {
        LOGE("panels: shader compile failed: %s", err ? (const char*)err->GetBufferPointer() : "?");
        if (err) err->Release();
        if (vsb) vsb->Release();
        if (psb) psb->Release();
        return false;
    }
    if (err) err->Release();
    g_dev->CreateVertexShader(vsb->GetBufferPointer(), vsb->GetBufferSize(), nullptr, &g_ovVs);
    g_dev->CreatePixelShader(psb->GetBufferPointer(), psb->GetBufferSize(), nullptr, &g_ovPs);
    vsb->Release(); psb->Release();
    D3D11_BUFFER_DESC bd{80, D3D11_USAGE_DEFAULT, D3D11_BIND_CONSTANT_BUFFER, 0, 0, 0};
    g_dev->CreateBuffer(&bd, nullptr, &g_ovCb);
    D3D11_SAMPLER_DESC sd{}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR; sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    sd.MaxLOD = D3D11_FLOAT32_MAX;
    g_dev->CreateSamplerState(&sd, &g_ovSmp);
    D3D11_BLEND_DESC b{}; b.RenderTarget[0].BlendEnable = TRUE;
    b.RenderTarget[0].SrcBlend = D3D11_BLEND_ONE; b.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA; b.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
    b.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE; b.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_INV_SRC_ALPHA; b.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
    b.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
    g_dev->CreateBlendState(&b, &g_ovBlendPre);
    b.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
    g_dev->CreateBlendState(&b, &g_ovBlendStraight);
    D3D11_RASTERIZER_DESC rd{}; rd.FillMode = D3D11_FILL_SOLID; rd.CullMode = D3D11_CULL_NONE; rd.DepthClipEnable = TRUE;
    g_dev->CreateRasterizerState(&rd, &g_ovRs);
    if (!(g_ovVs && g_ovPs && g_ovCb && g_ovSmp && g_ovBlendPre && g_ovBlendStraight && g_ovRs)) { LOGE("panels: D3D11 objects failed"); return false; }
    g_ovFailed = false;
    LOGI("panels: drawing into the eye images ready");
    return true;
}

static void ReleaseOverlayTex() {
    if (g_hudSrv) g_hudSrv->Release(), g_hudSrv = nullptr;
    if (g_hudTex) g_hudTex->Release(), g_hudTex = nullptr;
    for (auto*& c : g_clean) if (c) c->Release(), c = nullptr;
}

// 1 = quad layers, 2 = into the projection layer
static int PanelMode() {
    uint32_t m = g_shm ? g_shm->panelMode : 0;
    // auto = drawn into the eye images on every runtime (GOTGVR 0.6.25): quad layers were black / unreadable on
    // Virtual Desktop and SteamVR reports (menus, loading screens, the VR panel), as on Pimax before - one path that
    // works everywhere. quad (1) stays selectable.
    int r = m == 1 ? 1 : 2;
    if (r == 2 && !InitOverlay()) r = 1;
    if (r != g_panelModeLogged) {
        g_panelModeLogged = r;
        LOGI("panels (HUD, VR menu, flat screen): %s%s", r == 2 ? "drawn into the eye images" : "quad layers",
             m == 0 ? " (auto: works on every runtime)" : "");
    }
    return r;
}

static XrVector3f QRot(const XrQuaternionf& q, const XrVector3f& v) {
    XrVector3f u{q.x, q.y, q.z};
    auto cr = [](XrVector3f a, XrVector3f b) { return XrVector3f{a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x}; };
    XrVector3f t = cr(u, v); t = {t.x * 2, t.y * 2, t.z * 2};
    XrVector3f c = cr(u, t);
    return {v.x + q.w * t.x + c.x, v.y + q.w * t.y + c.y, v.z + q.w * t.z + c.z};
}

// draw the panel picture (g_hudSrv) as a quad of `size` metres at `quadPose` (LOCAL space) into image idx of eye
// swapchain s, as seen from `eyePose` with `fov`. opaque: the flat screen (alpha ignored); otherwise alpha-blended.
static void DrawPanel(Swap& s, uint32_t idx, const XrPosef& eyePose, const XrFovf& fov, const XrPosef& quadPose, XrExtent2Df size, bool opaque, bool premul) {
    if (!g_hudSrv || !InitOverlay()) return;
    ID3D11RenderTargetView* rtv = GetRtv(s, idx);
    if (!rtv) return;
    XrPosef inv = PoseInv(eyePose);
    float tl = tanf(fov.angleLeft), tr = tanf(fov.angleRight), tu = tanf(fov.angleUp), td = tanf(fov.angleDown);
    float cb[20];
    const float cx[4] = {-0.5f, 0.5f, -0.5f, 0.5f}, cy[4] = {0.5f, 0.5f, -0.5f, -0.5f};   // TL TR BL BR
    for (int i = 0; i < 4; i++) {
        XrVector3f local = QRot(quadPose.orientation, {cx[i] * size.width, cy[i] * size.height, 0});
        XrVector3f w{quadPose.position.x + local.x, quadPose.position.y + local.y, quadPose.position.z + local.z};
        XrVector3f e = QRot(inv.orientation, w); e = {e.x + inv.position.x, e.y + inv.position.y, e.z + inv.position.z};
        float d = -e.z;   // depth in front of the eye
        cb[i * 4 + 0] = (2.f * e.x - (tr + tl) * d) / (tr - tl);
        cb[i * 4 + 1] = (2.f * e.y - (tu + td) * d) / (tu - td);
        cb[i * 4 + 2] = 0.f;
        cb[i * 4 + 3] = d;
    }
    cb[16] = (s.rtvSrgb || !IsSrgb(g_swapFormat)) ? 1.f : 0.f;
    cb[17] = opaque ? 1.f : 0.f; cb[18] = cb[19] = 0.f;
    g_ctx->UpdateSubresource(g_ovCb, 0, nullptr, cb, 0, 0);
    D3D11_VIEWPORT vp{0, 0, (float)s.w, (float)s.h, 0, 1};
    g_ctx->OMSetRenderTargets(1, &rtv, nullptr);
    g_ctx->OMSetBlendState(opaque ? nullptr : premul ? g_ovBlendPre : g_ovBlendStraight, nullptr, 0xffffffff);
    g_ctx->RSSetViewports(1, &vp);
    g_ctx->RSSetState(g_ovRs);
    g_ctx->IASetInputLayout(nullptr);
    g_ctx->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
    g_ctx->VSSetShader(g_ovVs, nullptr, 0);
    g_ctx->VSSetConstantBuffers(0, 1, &g_ovCb);
    g_ctx->PSSetShader(g_ovPs, nullptr, 0);
    g_ctx->PSSetConstantBuffers(0, 1, &g_ovCb);
    g_ctx->PSSetShaderResources(0, 1, &g_hudSrv);
    g_ctx->PSSetSamplers(0, 1, &g_ovSmp);
    g_ctx->Draw(4, 0);
    ID3D11ShaderResourceView* nul = nullptr;
    g_ctx->PSSetShaderResources(0, 1, &nul);
    g_ctx->OMSetRenderTargets(0, nullptr, nullptr);
    g_ctx->OMSetBlendState(nullptr, nullptr, 0xffffffff);
}

static void DumpImage(ID3D11Texture2D* img, const wchar_t* what);
static void DumpImage(ID3D11Texture2D* img, const wchar_t* what) {
    D3D11_TEXTURE2D_DESC d; img->GetDesc(&d);
    D3D11_TEXTURE2D_DESC sd{};
    sd.Width = d.Width; sd.Height = d.Height; sd.MipLevels = 1; sd.ArraySize = 1; sd.Format = d.Format;
    sd.SampleDesc.Count = 1; sd.Usage = D3D11_USAGE_STAGING; sd.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    ID3D11Texture2D* st = nullptr;
    if (FAILED(g_dev->CreateTexture2D(&sd, nullptr, &st))) { LOGE("dump: staging texture failed"); return; }
    g_ctx->CopyResource(st, img);
    D3D11_MAPPED_SUBRESOURCE m;
    if (SUCCEEDED(g_ctx->Map(st, 0, D3D11_MAP_READ, 0, &m))) {
        wchar_t path[MAX_PATH];
        swprintf(path, MAX_PATH, L"%shost_%u_%s.bmp", g_dumpDir.c_str(), g_dumpNow, what);
        bool rgba = FormatFamily(d.Format == DXGI_FORMAT_R8G8B8A8_TYPELESS ? DXGI_FORMAT_R8G8B8A8_UNORM : d.Format) != FAM_BGRA;
        bool ok = WriteBmp32(path, (const uint8_t*)m.pData, d.Width, d.Height, m.RowPitch, rgba);
        LOGI("dump: %S %ux%u format %u %s", path, d.Width, d.Height, d.Format, ok ? "saved" : "FAILED");
        g_ctx->Unmap(st, 0);
    }
    st->Release();
}

// where the panel is (LOCAL space) and its size - the same placement as the quad layer
static void PanelPlace(bool menu, const XrPosef& head, XrPosef& pose, XrExtent2Df& size) {
    float dist = menu ? g_shm->menuDistance : g_shm->hudDistance;
    float width = menu ? g_shm->menuWidth : g_shm->hudWidth;
    float shp = g_shm->hudShape; if (!(shp > 0.3f && shp < 3.f)) shp = 1.f;
    size = {width, width * (float)g_hudRect.h / (float)g_hudRect.w / shp};
    XrPosef off = Identity();
    if (!menu && g_shm->hudFollowHead) { off.position = {0, g_shm->hudOffsetY, -dist}; pose = PoseMul(head, off); }
    else { off.position = {0, menu ? 0.0f : g_shm->hudOffsetY, -dist}; pose = PoseMul(menu && g_menuBaseSet ? g_menuBase : g_base, off); }
}
static XrPosef EyeLocal(const IpcPose& p) { XrPosef rel{{p.qx, p.qy, p.qz, p.qw}, {p.px, p.py, p.pz}}; return PoseMul(g_base, rel); }
static XrPosef HeadOf(const XrPosef& l, const XrPosef& r) {
    XrPosef h = l; h.position = {(l.position.x + r.position.x) * 0.5f, (l.position.y + r.position.y) * 0.5f, (l.position.z + r.position.z) * 0.5f}; return h;
}

// composite mode, a game frame's eye image just copied into image idx: keep it clean, then draw the HUD / VR menu on it
static IpcPose g_panelPose[2]; static IpcFov g_panelFov[2]; static uint32_t g_panelFlags = 0;
static void PanelOnEye(Swap& s, uint32_t idx, int eye, bool fromClean) {
    if (eye < 0 || PanelMode() != 2) return;
    if (!g_clean[eye]) {
        D3D11_TEXTURE2D_DESC d; s.images[idx].texture->GetDesc(&d);
        d.BindFlags = 0; d.MiscFlags = 0; d.CPUAccessFlags = 0; d.Usage = D3D11_USAGE_DEFAULT;
        if (FAILED(g_dev->CreateTexture2D(&d, nullptr, &g_clean[eye]))) { g_clean[eye] = nullptr; return; }
    }
    if (fromClean) g_ctx->CopyResource(s.images[idx].texture, g_clean[eye]);
    else g_ctx->CopyResource(g_clean[eye], s.images[idx].texture);
    if (!(g_panelFlags & SLOT_HUD_VISIBLE) || (g_panelFlags & SLOT_MENU_MODE)) return;
    XrPosef ep = EyeLocal(g_panelPose[eye]);
    XrPosef qp; XrExtent2Df sz;
    PanelPlace(false, HeadOf(EyeLocal(g_panelPose[0]), EyeLocal(g_panelPose[1])), qp, sz);
    XrFovf f{g_panelFov[eye].left, g_panelFov[eye].right, g_panelFov[eye].up, g_panelFov[eye].down};
    DrawPanel(s, idx, ep, f, qp, sz, false, g_shm->hudPremultiplied != 0);
}

static void CopyRegion(Swap& s, const SharedTex& src, const IpcRect& r, const wchar_t* what, int eye = -1) {
    uint32_t idx = 0;
    XrSwapchainImageAcquireInfo ai{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
    if (XR_FAILED(xrAcquireSwapchainImage(s.sc, &ai, &idx))) return;
    XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
    wi.timeout = 100000000;   // 100 ms; XR_TIMEOUT_EXPIRED is a *success* code, so keep waiting on it
    XrResult wr;
    int tries = 0;
    do { wr = xrWaitSwapchainImage(s.sc, &wi); } while (wr == XR_TIMEOUT_EXPIRED && ++tries < 20);
    if (wr != XR_SUCCESS) {
        // Not waited -> must not write or release it. The swapchain's acquire/wait order is now unknown: rebuild.
        LOGE("xrWaitSwapchainImage failed (%d) - recreating swapchains", (int)wr);
        g_forceResync = true;
        return;
    }
    if (g_blit) {
        BlitRegion(s, idx, src.srv, r);
    } else {
        D3D11_BOX box{(UINT)r.x, (UINT)r.y, 0, (UINT)(r.x + r.w), (UINT)(r.y + r.h), 1};
        g_ctx->CopySubresourceRegion(s.images[idx].texture, 0, 0, 0, 0, src.tex, 0, &box);
    }
    PanelOnEye(s, idx, eye, false);
    if (g_dumpNow) DumpImage(s.images[idx].texture, what);   // read back exactly what the runtime will show
    XrSwapchainImageReleaseInfo ri{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
    xrReleaseSwapchainImage(s.sc, &ri);
    s.last = (int)idx;
}

// No new game frame for this headset frame: hand the runtime a NEW swapchain image with the same picture. A frame
// without a newly released image is what the runtime counts as "the app missed a frame"; enough of those and its
// motion smoothing (Pimax Smart Smoothing, ASW, SteamVR) drops the display to half rate. With a fresh image every
// headset frame the app is at full rate as far as the runtime can tell; the picture is reprojected to the head as
// before (its own pose goes with it).
static unsigned g_recopied = 0;
static void RecopyLast(Swap& s) {
    if (s.last < 0 || s.images.empty() || s.last >= (int)s.images.size()) return;
    uint32_t idx = 0;
    XrSwapchainImageAcquireInfo ai{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
    if (XR_FAILED(xrAcquireSwapchainImage(s.sc, &ai, &idx))) return;
    XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO};
    wi.timeout = 100000000;
    XrResult wr; int tries = 0;
    do { wr = xrWaitSwapchainImage(s.sc, &wi); } while (wr == XR_TIMEOUT_EXPIRED && ++tries < 20);
    if (wr != XR_SUCCESS) { g_forceResync = true; return; }
    int eye = &s == &g_eye[0] ? 0 : &s == &g_eye[1] ? 1 : -1;
    if (eye >= 0 && g_clean[eye] && PanelMode() == 2) PanelOnEye(s, idx, eye, true);   // clean picture + the panel again
    else if ((int)idx != s.last) g_ctx->CopyResource(s.images[idx].texture, s.images[s.last].texture);
    XrSwapchainImageReleaseInfo ri{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
    xrReleaseSwapchainImage(s.sc, &ri);
    s.last = (int)idx;
}

// Pull the newest finished game frame into the swapchains (if there is one).
static void FetchGameFrame() {
    if (!SyncSharedTextures()) return;
    if (!TryReleasePending()) { g_stats.busy++; return; }   // previous copy still in flight on the GPU
    uint32_t seq = g_shm->submitSeq;
    if (seq == g_lastSubmitSeq && g_haveFrame) {
        if (g_shm->framePacing == 1 && !(g_shownFlags & SLOT_MENU_MODE)) { RecopyLast(g_eye[0]); RecopyLast(g_eye[1]); g_recopied++; }
        return;
    }
    MemoryBarrier();
    int slot = g_shm->lastSlot;
    if (slot < 0 || slot >= kSlots || !g_tex[slot].tex) return;

    if (g_syncMode == SYNC_KEYED_MUTEX) {
        if (g_tex[slot].mutex->AcquireSync(1, 4) != S_OK) { g_stats.busy++; return; }   // game still owns it (or it was recycled)
    } else {
        LONG prev = InterlockedCompareExchange((volatile LONG*)&g_shm->slotState[slot], SLOT_READING, SLOT_READY);
        if (prev != SLOT_READY) {
            // FREE: we already consumed it (a newer submit raced with our read of submitSeq) -> nothing new.
            // RENDERING: the game recycled it because a newer slot was submitted -> pick that up next frame.
            if (prev == SLOT_FREE) g_lastSubmitSeq = seq;
            else g_stats.busy++;
            return;
        }
        if (g_shm->gameState != g_texGen) {   // the game re-published between our generation check and the CAS
            InterlockedCompareExchange((volatile LONG*)&g_shm->slotState[slot], SLOT_READY, SLOT_READING);
            return;
        }
    }
    MemoryBarrier();
    g_stats.fetched++;
    IpcPose pose[2]; IpcFov fov[2];
    memcpy(pose, g_shm->slotPose[slot], sizeof(pose));
    memcpy(fov, g_shm->slotFov[slot], sizeof(fov));
    uint32_t flags = g_shm->slotFlags[slot];
    IpcMotion motion = g_shm->slotMotion[slot];
    uint32_t dumpReq = g_shm->dumpRequest;
    if (dumpReq != g_lastDump) { g_lastDump = dumpReq; g_dumpNow = dumpReq; }
    // the panel picture first (composite mode draws it onto the eyes as they are copied)
    if (PanelMode() == 2) {
        if (!g_hudTex) {
            D3D11_TEXTURE2D_DESC td; g_tex[slot].tex->GetDesc(&td);
            D3D11_TEXTURE2D_DESC d{}; d.Width = g_hudRect.w; d.Height = g_hudRect.h; d.MipLevels = 1; d.ArraySize = 1; d.Format = td.Format;
            d.SampleDesc.Count = 1; d.Usage = D3D11_USAGE_DEFAULT; d.BindFlags = D3D11_BIND_SHADER_RESOURCE;
            if (SUCCEEDED(g_dev->CreateTexture2D(&d, nullptr, &g_hudTex))) {
                D3D11_SHADER_RESOURCE_VIEW_DESC sv{}; sv.Format = Unorm(FormatFamily(td.Format)); sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
                if (FAILED(g_dev->CreateShaderResourceView(g_hudTex, &sv, &g_hudSrv))) { LOGE("panels: SRV failed"); g_hudSrv = nullptr; }
            } else { LOGE("panels: texture failed"); g_hudTex = nullptr; }
        }
        if (g_hudTex) {
            D3D11_BOX box{(UINT)g_hudRect.x, (UINT)g_hudRect.y, 0, (UINT)(g_hudRect.x + g_hudRect.w), (UINT)(g_hudRect.y + g_hudRect.h), 1};
            g_ctx->CopySubresourceRegion(g_hudTex, 0, 0, 0, 0, g_tex[slot].tex, 0, &box);
        }
    }
    memcpy(g_panelPose, pose, sizeof(pose)); memcpy(g_panelFov, fov, sizeof(fov)); g_panelFlags = flags;
    if (!(flags & SLOT_MENU_MODE)) { CopyRegion(g_eye[0], g_tex[slot], g_eyeRect[0], L"left", 0); CopyRegion(g_eye[1], g_tex[slot], g_eyeRect[1], L"right", 1); }
    if (PanelMode() != 2 || g_dumpNow) CopyRegion(g_hud, g_tex[slot], g_hudRect, flags & SLOT_MENU_MODE ? L"menu" : L"hud");
    if (g_dumpNow) {
        LOGI("dump %u: flags %u, left eye pose (%.3f %.3f %.3f) fov L%.3f R%.3f U%.3f D%.3f, right eye pose (%.3f %.3f %.3f)", g_dumpNow, flags,
             pose[0].px, pose[0].py, pose[0].pz, fov[0].left, fov[0].right, fov[0].up, fov[0].down, pose[1].px, pose[1].py, pose[1].pz);
        g_dumpNow = 0;
    }

    if (g_syncMode == SYNC_KEYED_MUTEX) {
        g_tex[slot].mutex->ReleaseSync(0);
    } else if (g_copyDone) {
        g_ctx->End(g_copyDone);
        g_ctx->Flush();
        // Never wait here: our copy queues behind the game's GPU work, and a spin of a few ms inside the frame made
        // the host miss 90 Hz deadlines. The slot is released on a later frame once the fence passed (the game
        // has the other slots meanwhile); never hand the game a slot mid-copy.
        if (CopiesDone(0)) ReleaseSlot(slot);
        else g_releasePending = slot;
    } else {
        ReleaseSlot(slot);
    }
    memcpy(g_shownPose, pose, sizeof(pose));
    memcpy(g_shownFov, fov, sizeof(fov));
    g_shownFlags = flags;
    g_shownMotion = motion;
    g_shownNew = true;
    g_lastSubmitSeq = seq;
    g_haveFrame = true;
}

static bool RunFrame() {
    XrFrameWaitInfo fwi{XR_TYPE_FRAME_WAIT_INFO};
    XrFrameState fs{XR_TYPE_FRAME_STATE};
    if (!g_qpf.QuadPart) QueryPerformanceFrequency(&g_qpf);
    LONGLONG tw0 = QpcNow();
    XRC(xrWaitFrame(g_sess, &fwi, &fs));
    LONGLONG tw1 = QpcNow();
    g_stats.waitMs += QpcMs(tw0, tw1);
    if (g_lastWaitDone.QuadPart) {
        double iv = QpcMs(g_lastWaitDone.QuadPart, tw1);
        if (iv > g_stats.intervalMaxMs) g_stats.intervalMaxMs = iv;
        if (fs.predictedDisplayPeriod > 0 && iv > 1.5 * fs.predictedDisplayPeriod / 1e6) g_stats.late++;
    }
    g_lastWaitDone.QuadPart = tw1;
    XrFrameBeginInfo fbi{XR_TYPE_FRAME_BEGIN_INFO};
    XRC(xrBeginFrame(g_sess, &fbi));

    if (g_spaceChangePending && fs.predictedDisplayTime >= g_spaceChangeTime) { g_spaceChangePending = false; g_needRecenter = true; }
    if (g_shm->recenterRequest != g_lastRecenter) { g_lastRecenter = g_shm->recenterRequest; g_needRecenter = true; }
    if (g_needRecenter && Recenter(fs.predictedDisplayTime)) g_needRecenter = false;   // retried until tracking is valid
    XrViewLocateInfo vli{XR_TYPE_VIEW_LOCATE_INFO};
    vli.viewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
    vli.displayTime = fs.predictedDisplayTime;
    vli.space = g_local;
    XrViewState vs{XR_TYPE_VIEW_STATE};
    XrView views[2] = {{XR_TYPE_VIEW}, {XR_TYPE_VIEW}};
    uint32_t vc = 0;
    if (XR_SUCCEEDED(xrLocateViews(g_sess, &vli, &vs, 2, &vc, views)) && (vs.viewStateFlags & XR_VIEW_STATE_ORIENTATION_VALID_BIT))
        PublishPoses(views, fs.predictedDisplayTime, fs.predictedDisplayPeriod);
    g_shm->hostHeartbeat = g_shm->hostHeartbeat + 1;
    if (g_evtHostFrame) SetEvent(g_evtHostFrame);   // pace the game to the headset

    // Game-paced frames: wait (inside the frame, after xrBeginFrame) until the game has handed over a new frame. The
    // headset frame is then late whenever the game is slower than the display - exactly what the runtime's motion
    // smoothing watches for - and every submitted frame is a new image with its own pose, never a repeat.
    uint32_t pacing = g_shm->framePacing;
    if (pacing != g_pacingLogged) {
        g_pacingLogged = pacing;
        LOGI("frame pacing mode %u: %s", pacing, pacing == 2 ? "game paced - the runtime's motion smoothing takes over at half rate when the game is slow"
                               : pacing ? "full rate - synced to game frames, never late (motion smoothing never halves the frame rate)"
                                        : "every headset frame (the newest game frame is repeated, host rotation reprojection)");
    }
    // A game that keeps up with the display must never make a headset frame late: Pimax Smart Smoothing (and ASW /
    // motion smoothing) take late frames as "the app is too slow", drop the display to half rate (36 Hz on a 72 Hz
    // headset) and synthesize every second frame - laggy, hitchy head motion although the game made 90 fps. So the
    // host only waits past the frame deadline while the game really is slower than the display.
    static double s_gameIv = 0; static LONGLONG s_lastNew = 0; static uint32_t s_lastSeq = 0;
    {
        uint32_t sq = g_shm->submitSeq; LONGLONG now = QpcNow();
        if (sq != s_lastSeq) {
            if (s_lastNew) { double iv = QpcMs(s_lastNew, now) / (double)(sq - s_lastSeq); s_gameIv = s_gameIv ? s_gameIv * 0.9 + iv * 0.1 : iv; }
            s_lastSeq = sq; s_lastNew = now;
        }
    }
    double periodMs = fs.predictedDisplayPeriod > 0 ? fs.predictedDisplayPeriod / 1e6 : 13.9;
    // hysteresis: "slow" from 15 % over the display period, back to "keeps up" under 5 % - no flapping between the
    // two (each switch would look like a hitch, and the runtime's smoothing would toggle with it)
    static bool s_slow = false;
    if (!s_slow && s_gameIv > periodMs * 1.08) s_slow = true;
    else if (s_slow && s_gameIv < periodMs * 1.03) s_slow = false;
    bool gameSlow = s_slow;
    // menus / loading screens / the flat screen (quad layers only): never paced. A 30 fps loading screen made every
    // headset frame late and the runtime switched its smoothing on (36 Hz) for the rest of the session.
    bool flatOnly = g_haveFrame && (g_shownFlags & SLOT_MENU_MODE);
    if (pacing && g_haveFrame && g_evtGameFrame && !flatOnly) {
        double budget = periodMs - 4.0 - QpcMs(tw1, QpcNow());
        // mode 1 (default): NEVER wait past the frame deadline, whatever the game does. A game frame that is not ready
        // in time is replaced by the newest one, reprojected to the current head pose - the headset frame is never
        // late, so the runtime's motion smoothing (Pimax Smart Smoothing, ASW, SteamVR) never sees "app too slow" and
        // never drops the display to half rate. Mode 2: the old behaviour (the runtime's smoothing takes over at half
        // rate while the game is slower than the display).
        // mode 1: wait only while the game is clearly at least as fast as the display, and only briefly. A game a
        // little slower than the display (68 fps on 72 Hz) made the host wait ~10 ms inside nearly every frame and
        // miss the runtime's deadline (late frames = head tracking hitches on Pimax); now such a frame is shown at once
        // with the newest image (reprojected to the head) and the headset never misses a refresh.
        bool keepsUp = s_gameIv > 0 && s_gameIv <= periodMs * 0.98;
        bool noWait = pacing != 2 && (gameSlow || !keepsUp);
        if (pacing != 2) gameSlow = false;
        double cap = periodMs * 0.30;            // at most ~4 ms on 72 Hz: the compositor keeps its time
        if (pacing != 2 && budget > cap) budget = cap;
        DWORD lim = noWait ? 0 : gameSlow ? (g_shm->pacedTimeoutMs ? g_shm->pacedTimeoutMs : 100) : (DWORD)(budget > 0 ? budget : 0);
        if (!gameSlow) g_stats.pacedFast++;
        LONGLONG ts = QpcNow();
        while (g_shm->submitSeq == g_lastSubmitSeq) {
            double el = QpcMs(ts, QpcNow());
            if (el >= lim) { if (gameSlow) g_stats.pacedTimeouts++; break; }
            WaitForSingleObject(g_evtGameFrame, (DWORD)(lim - el) + 1);
        }
        g_stats.pacedWaitMs += QpcMs(ts, QpcNow());
    }

    LONGLONG tf0 = QpcNow();
    FetchGameFrame();
    double fm = QpcMs(tf0, QpcNow());
    g_stats.fetchMs += fm;
    if (fm > g_stats.fetchMaxMs) g_stats.fetchMaxMs = fm;

    XrQuaternionf rp[2];
    bool reproject = g_haveFrame && ReprojectRotation(fs.predictedDisplayTime, rp);
    g_shownNew = false;

    std::vector<XrCompositionLayerBaseHeader*> layers;
    XrCompositionLayerProjection proj{XR_TYPE_COMPOSITION_LAYER_PROJECTION};
    XrCompositionLayerProjectionView pv[2] = {{XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW}, {XR_TYPE_COMPOSITION_LAYER_PROJECTION_VIEW}};
    XrCompositionLayerQuad quad{XR_TYPE_COMPOSITION_LAYER_QUAD};
    bool viewsOk = (vs.viewStateFlags & XR_VIEW_STATE_ORIENTATION_VALID_BIT) && vc == 2;
    int panelMode = PanelMode();
    if (fs.shouldRender && g_haveFrame) {
        bool menu = (g_shownFlags & SLOT_MENU_MODE) != 0;
        // GOTGVR 0.6.25: the flat screen / VR panel is placed in front of the head as it is NOW when it appears (yaw
        // only, at head height). It used to sit at the recentre point - taken at the session's first frame, before the
        // headset is worn; Virtual Desktop logs show it 1.4-1.6 m below the head (pos y -1.64): black menus, loading
        // screens and an invisible VR panel. Recentring (Space) moves it again.
        // It also follows lazily: if the head stays more than 0.75 m away from it or turned more than 70 degrees from
        // it for 1.5 s (the headset was lying on the desk at start, you stood up, turned round), it comes back in front.
        if (menu && viewsOk) {
            XrPosef h = HeadOf(views[0].pose, views[1].pose);
            XrVector3f fwd = QRot(h.orientation, {0, 0, -1});
            float yaw = atan2f(-fwd.x, -fwd.z);
            static ULONGLONG s_away = 0;
            bool place = !g_menuWas || g_recenteredNow || !g_menuBaseSet;
            if (!place) {
                float dx = h.position.x - g_menuBase.position.x, dy = h.position.y - g_menuBase.position.y, dz = h.position.z - g_menuBase.position.z;
                float by = 2.f * atan2f(g_menuBase.orientation.y, g_menuBase.orientation.w), d = yaw - by;
                while (d > 3.14159265f) d -= 6.2831853f; while (d < -3.14159265f) d += 6.2831853f;
                bool away = dx * dx + dy * dy + dz * dz > 0.75f * 0.75f || fabsf(d) > 1.2217f;
                ULONGLONG now = GetTickCount64();
                if (!away) s_away = 0; else if (!s_away) s_away = now; else if (now - s_away > 1500) { place = true; s_away = 0; }
            }
            if (place) {
                g_menuBase.orientation = {0, sinf(yaw * 0.5f), 0, cosf(yaw * 0.5f)};
                g_menuBase.position = h.position;
                g_menuBaseSet = true;
            }
            g_menuWas = true;
        } else if (!menu) g_menuWas = false;
        g_recenteredNow = false;
        if (menu && viewsOk) {
            // flat screen / menus: a projection layer as well (black, the screen drawn in when compositing) - some
            // runtimes show nothing for a frame made of quad layers only
            bool ok = true;
            for (int e = 0; e < 2 && ok; ++e) {
                Swap& sw = g_eye[e];
                uint32_t idx = 0;
                XrSwapchainImageAcquireInfo ai{XR_TYPE_SWAPCHAIN_IMAGE_ACQUIRE_INFO};
                if (XR_FAILED(xrAcquireSwapchainImage(sw.sc, &ai, &idx))) { ok = false; break; }
                XrSwapchainImageWaitInfo wi{XR_TYPE_SWAPCHAIN_IMAGE_WAIT_INFO}; wi.timeout = 100000000;
                XrResult wr; int tries = 0;
                do { wr = xrWaitSwapchainImage(sw.sc, &wi); } while (wr == XR_TIMEOUT_EXPIRED && ++tries < 20);
                if (wr != XR_SUCCESS) { g_forceResync = true; ok = false; break; }
                if (ID3D11RenderTargetView* rtv = GetRtv(sw, idx)) { const float black[4] = {0, 0, 0, 1}; g_ctx->ClearRenderTargetView(rtv, black); }
                if (panelMode == 2) {
                    XrPosef qp; XrExtent2Df sz; PanelPlace(true, HeadOf(views[0].pose, views[1].pose), qp, sz);
                    DrawPanel(sw, idx, views[e].pose, views[e].fov, qp, sz, true, false);
                }
                XrSwapchainImageReleaseInfo ri{XR_TYPE_SWAPCHAIN_IMAGE_RELEASE_INFO};
                xrReleaseSwapchainImage(sw.sc, &ri);
                sw.last = (int)idx;
                pv[e].pose = views[e].pose; pv[e].fov = views[e].fov;
                pv[e].subImage.swapchain = sw.sc;
                pv[e].subImage.imageRect = {{0, 0}, {(int32_t)sw.w, (int32_t)sw.h}};
            }
            if (ok) {
                proj.space = g_local; proj.viewCount = 2; proj.views = pv;
                layers.push_back((XrCompositionLayerBaseHeader*)&proj);
                if (g_clean[0]) g_clean[0]->Release(), g_clean[0] = nullptr;   // the eye images no longer hold the game's picture
                if (g_clean[1]) g_clean[1]->Release(), g_clean[1] = nullptr;
            }
        }
        if (!menu) {
            for (int e = 0; e < 2; ++e) {
                const IpcPose& p = g_shownPose[e];
                XrPosef rel{{p.qx, p.qy, p.qz, p.qw}, {p.px, p.py, p.pz}};
                if (reproject) { XrPosef r{rp[e], {0, 0, 0}}; rel = PoseMul(r, rel); }   // scene rotated with the game camera
                pv[e].pose = PoseMul(g_base, rel);   // back to LOCAL space
                pv[e].fov = {g_shownFov[e].left, g_shownFov[e].right, g_shownFov[e].up, g_shownFov[e].down};
                pv[e].subImage.swapchain = g_eye[e].sc;
                pv[e].subImage.imageRect = {{0, 0}, {(int32_t)g_eye[e].w, (int32_t)g_eye[e].h}};
            }
            proj.space = g_local;
            proj.viewCount = 2;
            proj.views = pv;
            layers.push_back((XrCompositionLayerBaseHeader*)&proj);
        }
        if ((g_shownFlags & SLOT_HUD_VISIBLE) && panelMode != 2) {
            float dist = menu ? g_shm->menuDistance : g_shm->hudDistance;
            float width = menu ? g_shm->menuWidth : g_shm->hudWidth;
            quad.layerFlags = 0;
            if (!menu) {
                quad.layerFlags = XR_COMPOSITION_LAYER_BLEND_TEXTURE_SOURCE_ALPHA_BIT;
                if (!g_shm->hudPremultiplied) quad.layerFlags |= XR_COMPOSITION_LAYER_UNPREMULTIPLIED_ALPHA_BIT;
            }
            quad.subImage.swapchain = g_hud.sc;
            quad.subImage.imageRect = {{0, 0}, {(int32_t)g_hud.w, (int32_t)g_hud.h}};
            quad.eyeVisibility = XR_EYE_VISIBILITY_BOTH;
            float shp = g_shm->hudShape;   // menus and the weapon wheel (flat screen) too if (!(shp > 0.3f && shp < 3.f)) shp = 1.f;
            quad.size = {width, width * (float)g_hud.h / (float)g_hud.w / shp};
            if (!menu && g_shm->hudFollowHead) {
                quad.space = g_view;
                quad.pose = Identity();
                quad.pose.position = {0, g_shm->hudOffsetY, -dist};
            } else {
                quad.space = g_local;
                XrPosef off = Identity();
                off.position = {0, menu ? 0.0f : g_shm->hudOffsetY, -dist};
                quad.pose = PoseMul(menu && g_menuBaseSet ? g_menuBase : g_base, off);
            }
            layers.push_back((XrCompositionLayerBaseHeader*)&quad);
        }
    }
    g_stats.frames++;
    if (fs.shouldRender) g_stats.shouldRender++;
    for (auto* l : layers) { if (l->type == XR_TYPE_COMPOSITION_LAYER_PROJECTION) g_stats.layersProj++; else g_stats.layersQuad++; }
    DWORD now = GetTickCount();
    if (!g_stats.t0) g_stats.t0 = now;
    if (now - g_stats.t0 >= 10000) {
        float sec = (now - g_stats.t0) / 1000.0f;
        double n = g_stats.frames ? g_stats.frames : 1;
        LOGI("stats: %.1f host fps, shouldRender %u, game frames %.1f/s, slot busy %u, proj layers %u, quad layers %u, state %d",
             g_stats.frames / sec, g_stats.shouldRender, g_stats.fetched / sec, g_stats.busy, g_stats.layersProj, g_stats.layersQuad, (int)g_state);
        LOGI("timing: per frame xrWaitFrame %.2f ms, fetch+copy %.2f ms (max %.2f), xrEndFrame %.2f ms; longest frame interval %.2f ms, "
             "late frames %u (display period %.2f ms)",
             g_stats.waitMs / n, g_stats.fetchMs / n, g_stats.fetchMaxMs, g_stats.endMs / n, g_stats.intervalMaxMs, g_stats.late,
             fs.predictedDisplayPeriod / 1e6);
        if (g_shm->framePacing) LOGI("pacing: headset frames given a fresh image of the same game frame: %u", g_recopied), g_recopied = 0;
        if (g_shm->framePacing)
            LOGI("pacing: game paced, waited for the game %.2f ms per headset frame, %u timeouts (frame repeated); game frame %.1f ms, "
                 "%u of %u headset frames with the game faster than the display (never late)",
                 g_stats.pacedWaitMs / n, g_stats.pacedTimeouts, s_gameIv, g_stats.pacedFast, g_stats.frames);
        if (g_rpStats.frames)
            LOGI("reproject: %u headset frames, extrapolated avg %.2f ms (max %.2f), avg camera turn speed %.1f deg/s", g_rpStats.frames,
                 g_rpStats.dtMs / g_rpStats.frames, g_rpStats.dtMaxMs, g_rpStats.speedDeg / g_rpStats.frames);
        g_rpStats = {};
        g_stats = {}; g_stats.t0 = now;
    }
    XrFrameEndInfo fei{XR_TYPE_FRAME_END_INFO};
    fei.displayTime = fs.predictedDisplayTime;
    fei.environmentBlendMode = XR_ENVIRONMENT_BLEND_MODE_OPAQUE;
    fei.layerCount = (uint32_t)layers.size();
    fei.layers = layers.data();
    LONGLONG te0 = QpcNow();
    XRC(xrEndFrame(g_sess, &fei));
    g_stats.endMs += QpcMs(te0, QpcNow());
    TryReleasePending();   // hand the slot back as soon as our copy finished, not only at the next headset frame
    return true;
}

static bool OwnShm();
static bool PollEvents(bool* quit) {
    XrEventDataBuffer ev{XR_TYPE_EVENT_DATA_BUFFER};
    while (xrPollEvent(g_inst, &ev) == XR_SUCCESS) {
        switch (ev.type) {
        case XR_TYPE_EVENT_DATA_SESSION_STATE_CHANGED: {
            auto* e = (XrEventDataSessionStateChanged*)&ev;
            g_state = e->state;
            LOGI("Session state -> %d", (int)g_state);
            if (!OwnShm()) { *quit = true; break; }
            if (g_state == XR_SESSION_STATE_READY) {
                XrSessionBeginInfo bi{XR_TYPE_SESSION_BEGIN_INFO};
                bi.primaryViewConfigurationType = XR_VIEW_CONFIGURATION_TYPE_PRIMARY_STEREO;
                XRC(xrBeginSession(g_sess, &bi));
                g_running = true;
                g_shm->hostState = HOST_READY;
            } else if (g_state == XR_SESSION_STATE_STOPPING) {
                xrEndSession(g_sess);
                g_running = false;
                g_shm->hostState = HOST_READY;
            } else if (g_state == XR_SESSION_STATE_FOCUSED) {
                g_shm->hostState = HOST_FOCUSED;
            } else if (g_state == XR_SESSION_STATE_VISIBLE) {
                g_shm->hostState = HOST_RUNNING;
            } else if (g_state == XR_SESSION_STATE_SYNCHRONIZED) {
                g_shm->hostState = HOST_READY;   // not shown yet (runtime may throttle): game must not pace to us
            } else if (g_state == XR_SESSION_STATE_EXITING || g_state == XR_SESSION_STATE_LOSS_PENDING) {
                *quit = true;
            }
            break;
        }
        case XR_TYPE_EVENT_DATA_INSTANCE_LOSS_PENDING: *quit = true; break;
        case XR_TYPE_EVENT_DATA_REFERENCE_SPACE_CHANGE_PENDING: {
            auto* e = (XrEventDataReferenceSpaceChangePending*)&ev;
            if (e->referenceSpaceType == XR_REFERENCE_SPACE_TYPE_LOCAL) { g_spaceChangePending = true; g_spaceChangeTime = e->changeTime; }
            break;
        }
        default: break;
        }
        ev = {XR_TYPE_EVENT_DATA_BUFFER};
    }
    return true;
}

// A restarted game re-initialises the shared memory and launches a new host; an old host must then stop writing.
static bool OwnShm() { return g_shm && g_shm->hostPid == GetCurrentProcessId() && g_shm->magic == kIpcMagic; }

static void Fail(const char* msg) {
    LOGE("%s", msg);
    if (g_shm) {
        strncpy_s(g_shm->hostError, msg, _TRUNCATE);
        MemoryBarrier();
        g_shm->hostState = HOST_ERROR;
    }
    LogFlush();
}

// ------------------------------------------------------------------ main
// In-process mode (XRB_IN_PROCESS, GOTGVR 0.6.6): the same host runs as a thread inside the game - no XrBridgeHost.exe.
// Everything stays as in the exe (its own D3D11 device and OpenXR session, the shared-memory protocol to the mod),
// except what would act on the whole game process: no process priority class, no process GPU scheduling class.
static int HostMain(DWORD pid, std::wstring logPath) {
    if (logPath.empty()) {
        wchar_t exe[MAX_PATH];
        GetModuleFileNameW(nullptr, exe, MAX_PATH);
        logPath = exe;
        logPath = logPath.substr(0, logPath.find_last_of(L"\\/") + 1) + L"XrBridgeHost_";
        for (char c : g_name) logPath += (wchar_t)c;
        logPath += L".log";
    }
    LogInit(logPath.c_str(), LOG_INFO);
    g_dumpDir = logPath.substr(0, logPath.find_last_of(L"\\/") + 1);
    LOGI("XrBridge host v%u " __DATE__ " " __TIME__ " (instance '%s', game pid %lu)", kIpcVersion, g_name.c_str(), pid);
    if (!ValidInstanceName(g_name.c_str())) { LOGE("Missing or invalid --name - this exe is started by the mod, not by hand"); return 1; }
    // The host must hit every display frame even while the game keeps all cores busy (FF XIII spins dozens of
    // threads on Sleep(0)), so it runs at high priority. Its work per frame is tiny.
    BOOL pc = g_inProcess ? TRUE : SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
    BOOL tp = SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_HIGHEST);
    if (g_inProcess) LOGI("In-process host (no XrBridgeHost.exe): frame thread HIGHEST %s, the game's process priority left alone", tp ? "ok" : "failed");
    else LOGI("Priority: process HIGH %s, frame thread HIGHEST %s", pc ? "ok" : "failed", tp ? "ok" : "failed");

    HANDLE map = nullptr;
    std::wstring shmName = ShmName(g_name.c_str());
    for (int i = 0; i < 100 && !map; ++i) { map = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, shmName.c_str()); if (!map) Sleep(50); }
    if (!map) { LOGE("Shared memory %S not found - start the game, not this exe", shmName.c_str()); return 1; }
    g_shm = (IpcShared*)MapViewOfFile(map, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(IpcShared));
    if (!g_shm || g_shm->magic != kIpcMagic || g_shm->version != kIpcVersion) {
        LOGE("Shared memory version mismatch (got magic %08X version %u, want %08X v%u) - mod and host are from different builds",
             g_shm ? g_shm->magic : 0, g_shm ? g_shm->version : 0, kIpcMagic, kIpcVersion);
        return 1;
    }
    LogSetLevel((int)g_shm->hostLogLevel);
    g_shm->hostPid = GetCurrentProcessId();
    g_shm->hostState = HOST_STARTING;
    g_evtHostFrame = CreateEventW(nullptr, FALSE, FALSE, HostEventName(g_name.c_str()).c_str());
    g_evtGameFrame = CreateEventW(nullptr, FALSE, FALSE, FrameEventName(g_name.c_str()).c_str());   // opens the game's
    g_game = OpenProcess(SYNCHRONIZE, FALSE, pid ? pid : g_shm->gamePid);

    if (!InitXr()) {
        Fail("OpenXR initialisation failed - is SteamVR (or another OpenXR runtime) installed and set as active? See the host log.");
        return 2;
    }

    bool quit = false;
    while (!quit) {
        if (g_game && WaitForSingleObject(g_game, 0) == WAIT_OBJECT_0) { LOGI("Game exited"); break; }
        if (g_shm->quitRequest) { LOGI("Quit requested by game"); break; }
        if (!OwnShm()) { LOGW("Shared memory taken over by a newer game/host - exiting"); break; }
        PollEvents(&quit);
        if (g_running) {
            if (!RunFrame()) { Sleep(10); }
        } else {
            Sleep(20);
        }
    }
    LOGI("Shutting down");
    if (g_running) {   // clean exit: request, then wait for STOPPING (PollEvents ends the session there)
        xrRequestExitSession(g_sess);
        bool q = false;
        for (int i = 0; i < 100 && g_running; ++i) { PollEvents(&q); if (g_running) Sleep(10); }
        if (g_running) xrEndSession(g_sess);
    }
    if (g_releasePending >= 0 && OwnShm()) { CopiesDone(100); ReleaseSlot(g_releasePending); }
    DestroySwap(g_eye[0]); DestroySwap(g_eye[1]); DestroySwap(g_hud);
    ReleaseShared();
    if (g_sess) xrDestroySession(g_sess);
    if (g_inst) xrDestroyInstance(g_inst);
    if (OwnShm()) g_shm->hostState = HOST_NONE;
    LogFlush();
    return 0;
}

#ifdef XRB_IN_PROCESS
extern "C" int XrbHostRunInProcess(const wchar_t* name, unsigned long pid, const wchar_t* logPath) {
    g_inProcess = true;
    g_name.clear(); for (const wchar_t* p = name; p && *p; ++p) g_name += (char)*p;
    return HostMain(pid, logPath ? logPath : L"");
}
#else
int WINAPI wWinMain(HINSTANCE, HINSTANCE, LPWSTR, int) {
    int argc = 0;
    wchar_t** argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    DWORD pid = 0;
    std::wstring logPath;
    for (int i = 1; i < argc; ++i) {
        if (!wcscmp(argv[i], L"--pid") && i + 1 < argc) pid = wcstoul(argv[++i], nullptr, 10);
        else if (!wcscmp(argv[i], L"--log") && i + 1 < argc) logPath = argv[++i];
        else if (!wcscmp(argv[i], L"--name") && i + 1 < argc) { for (const wchar_t* p = argv[++i]; *p; ++p) g_name += (char)*p; }
    }
    return HostMain(pid, logPath);
}
#endif
