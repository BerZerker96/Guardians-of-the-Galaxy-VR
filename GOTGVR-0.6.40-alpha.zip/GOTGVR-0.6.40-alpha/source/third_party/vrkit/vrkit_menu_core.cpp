#include "vrkit_menu_core.h"
#include "vrkit_options.h"
#include <windows.h>
#include <vector>
#include <algorithm>
#include <cfloat>
#include <cctype>
#include <string>
#include <cmath>
#include <cstring>
#include "imgui.h"

// real time in 100 ns (speed hacks rewrite QueryPerformanceCounter; the interrupt-time clock keeps real time)
static void RealQpc(LARGE_INTEGER* c) { ULONGLONG t = 0; QueryUnbiasedInterruptTime(&t); c->QuadPart = (LONGLONG)t; }

namespace vrkit { namespace menu { namespace core {

namespace {
Settings g_s;
ImGuiContext* g_im = nullptr;
bool g_open = false;
int g_page = 0, g_sel = 0;
bool g_hkX = false;   // hotkey row: the X (unbind) button in front of the keycaps has the pad / keyboard focus
LARGE_INTEGER g_qpf, g_last;
ImFont* g_fBody = nullptr; ImFont* g_fTitle = nullptr; ImFont* g_fSmall = nullptr;
float g_anim = 0.f;          // seconds the menu has been drawn (pulse, scan line)
float g_selY = -1.f;         // animated selection bar position
int g_capOpt = -1;           // hotkey row capturing a new binding (index into Options::All), -1 = none
float g_capFlash = 0.f;      // "bound" flash after a capture
int g_capDoneOpt = -1;
// mouse hit areas, collected while drawing (used on the next frame's input)
struct Hit { float x0, y0, x1, y1; int kind; int idx; float v0, v1; };   // kind: 0 tab, 1 row, 2 value bar, 3 close, 4 hotkey X (unbind)
std::vector<Hit> g_hits, g_hitsPrev;

void StartCapture(int optIndex) { g_capOpt = optIndex; input::CaptureBegin(); }

std::vector<int> PageItems(int page) {
    auto& opts = Options::Get().All();
    auto pages = Options::Get().Pages();
    std::vector<int> r;
    if (pages.empty()) return r;
    page = (std::min)(page, (int)pages.size() - 1);
    for (int k = 0; k < (int)opts.size(); ++k)
        if (opts[k].page == pages[page] && (!opts[k].visible || opts[k].visible())) r.push_back(k);
    return r;
}

void Close() {
    g_open = false; g_capOpt = -1;
    input::SetBlocking(false);
    if (Options::Get().Dirty() && !g_s.configPath.empty()) {
        if (Options::Get().Save(g_s.configPath)) Log("vrkit: settings saved");
    }
}

void Navigate(uint32_t b) {
    auto pages = Options::Get().Pages();
    if (pages.empty()) return;
    int selWas = g_sel, pageWas = g_page;
    if (b & input::PagePrev) { g_page = (g_page + (int)pages.size() - 1) % (int)pages.size(); g_sel = 0; }
    if (b & input::PageNext) { g_page = (g_page + 1) % (int)pages.size(); g_sel = 0; }
    auto items = PageItems(g_page);
    if (items.empty()) return;
    int n = (int)items.size();
    if (b & input::Up) g_sel = (g_sel + n - 1) % n;
    if (b & input::Down) g_sel = (g_sel + 1) % n;
    g_sel = (std::min)(g_sel, n - 1);
    Option& o = Options::Get().All()[items[g_sel]];
    if (g_sel != selWas || g_page != pageWas || o.type != OptType::Hotkey) g_hkX = false;
    if (o.type == OptType::Hotkey) {   // hotkey row: Left = the X (unbind), Right = back to the keycaps
        if (b & input::Left) g_hkX = !o.noUnbind;
        if (b & input::Right) g_hkX = false;
        if (b & input::Accept) {
            if (g_hkX) { Options::Get().Reset(o); g_capDoneOpt = items[g_sel]; g_capFlash = 1.f; Log("vrkit: hotkey %s unbound", o.key.c_str()); }
            else StartCapture(items[g_sel]);
            return;
        }
        if (b & input::Reset) Options::Get().Reset(o);
        return;
    }
    if (b & input::Left) Options::Get().Step(o, -1);
    if (b & input::Right) Options::Get().Step(o, +1);
    if (b & input::Accept) Options::Get().Activate(o);
    if (b & input::Reset) Options::Get().Reset(o);
}
} // namespace

bool InitImGui(const Settings& s) {
    if (g_im) return true;
    g_s = s;
    input::Configure(s.input);
    input::InstallHooks();
    IMGUI_CHECKVERSION();
    g_im = ImGui::CreateContext();
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr; io.LogFilename = nullptr;
    io.DisplaySize = ImVec2((float)s.texW, (float)s.texH);
    // fonts: a font file the user drops into the mod folder (DXMDVR\vrkit_font.ttf / vrkit_title_font.ttf) wins;
    // otherwise Windows' Bahnschrift (DIN-style, close to the game's techno-industrial interface type), Agency FB
    // for the title when Office installed it, then Segoe UI / Arial. ImGui's built-in font as last resort.
    float os = s.fontOversample > 0 ? s.fontOversample : 1.f;
    std::wstring dir = s.configPath; { size_t k = dir.find_last_of(L"\\/"); dir = k == std::wstring::npos ? L"" : dir.substr(0, k + 1); }
    wchar_t win[MAX_PATH] = L"C:\\Windows"; GetWindowsDirectoryW(win, MAX_PATH);
    std::wstring fdir = std::wstring(win) + L"\\Fonts\\";
    auto load = [&](std::initializer_list<std::wstring> files, float px) -> ImFont* {
        for (const std::wstring& p : files) {
            if (p.empty() || GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) continue;
            char path[MAX_PATH * 3];
            WideCharToMultiByte(CP_UTF8, 0, p.c_str(), -1, path, sizeof(path), nullptr, nullptr);
            ImFontConfig fc; fc.OversampleH = 3; fc.OversampleV = 2;
            if (ImFont* f = io.Fonts->AddFontFromFileTTF(path, px * os, &fc)) { return f; }
        }
        return nullptr;
    };
    std::wstring user = dir.empty() ? L"" : dir + L"GOTGVR\\vrkit_font.ttf", userT = dir.empty() ? L"" : dir + L"GOTGVR\\vrkit_title_font.ttf";
    g_fBody = load({ user, fdir + L"bahnschrift.ttf", fdir + L"segoeui.ttf", fdir + L"arial.ttf" }, s.fontPx);
    if (!g_fBody) { ImFontConfig fc; fc.SizePixels = s.fontPx * os; g_fBody = io.Fonts->AddFontDefault(&fc); }
    g_fTitle = load({ userT, fdir + L"BAUHS93.TTF", fdir + L"seguibl.ttf", fdir + L"segoeuib.ttf", fdir + L"bahnschrift.ttf", user }, s.fontPx * 2.3f);
    g_fSmall = load({ user, fdir + L"bahnschrift.ttf", fdir + L"segoeui.ttf" }, s.fontPx * 0.78f);
    if (!g_fTitle) g_fTitle = g_fBody;
    if (!g_fSmall) g_fSmall = g_fBody;
    io.FontDefault = g_fBody;
    io.FontGlobalScale = 1.f / os;
    ImGuiStyle& st = ImGui::GetStyle();
    st.WindowRounding = 0.f; st.ChildRounding = 0.f; st.FrameRounding = 0.f; st.PopupRounding = 0.f; st.TabRounding = 0.f;
    st.GrabRounding = 0.f; st.ScrollbarRounding = 0.f;
    st.WindowBorderSize = 0.f; st.WindowPadding = ImVec2(0, 0);
    st.Colors[ImGuiCol_WindowBg] = ImVec4(0, 0, 0, 0);   // the plate is drawn by BuildFrame (chamfered frame)
    g_qpf.QuadPart = 10000000; RealQpc(&g_last);
    return true;
}

void ShutdownImGui() {
    if (g_im) { ImGui::DestroyContext(g_im); g_im = nullptr; }
    g_open = false;
}

const Settings& Get() { return g_s; }

bool UpdateInput() {
    if (!g_im) return false;
    static int rehook = 0;
    if ((++rehook % 300) == 1) input::InstallHooks();   // the game may load XInput late
    uint32_t b = input::Poll();
    if (g_open && g_capOpt >= 0) {   // capturing a hotkey: every key / button goes to the binding, not to the menu
        auto& all = Options::Get().All();
        if (g_capOpt >= (int)all.size() || all[g_capOpt].type != OptType::Hotkey) { g_capOpt = -1; }
        else {
            Option& o = all[g_capOpt];
            input::Binding bd = input::ParseBinding(*o.s);
            int r = input::CaptureStep(bd);
            if (r != 0) {
                if (r > 0 && o.noUnbind && !bd.vk && !bd.pad) r = 0;   // a key that can never be unbound keeps its binding
                if (r > 0) { Options::Get().SetValueText(o, input::BindingText(bd)); g_capDoneOpt = g_capOpt; g_capFlash = 1.f; Log("vrkit: hotkey %s = %s", o.key.c_str(), o.s->c_str()); }
                g_capOpt = -1;
            }
        }
        ImGui::SetCurrentContext(g_im);
        return true;
    }
    if (b & input::Toggle) { if (g_open) Close(); else { g_open = true; input::SetBlocking(true); input::MouseReset(g_s.texW * 0.5f, g_s.texH * 0.5f); } b &= ~input::Toggle; }
    else if (g_open && (b & input::Back)) { Close(); return false; }
    if (!g_open) return false;
    Navigate(b);
    ImGui::SetCurrentContext(g_im);
    return true;
}

namespace {
// colours: deep-space indigo / violet panel, neon magenta + cyan accents, a warm orange highlight - a retro-cosmic
// mixtape look for Guardians of the Galaxy (no game artwork is used; everything is drawn from shapes)
const ImU32 cText = IM_COL32(238, 234, 255, 255), cDim = IM_COL32(158, 148, 210, 255), cAcc = IM_COL32(255, 255, 255, 255),
            cMag = IM_COL32(255, 62, 196, 255), cCyan = IM_COL32(70, 228, 255, 255), cViolet = IM_COL32(146, 84, 255, 255),
            cOrange = IM_COL32(255, 150, 58, 255), cWarn = IM_COL32(255, 122, 84, 255), cBlack = IM_COL32(14, 8, 34, 255),
            cTrack = IM_COL32(36, 26, 78, 220), cLine = IM_COL32(146, 84, 255, 110), cFaint = IM_COL32(146, 84, 255, 26);
inline ImU32 Alpha(ImU32 c, float a) { unsigned al = (unsigned)((c >> IM_COL32_A_SHIFT) & 0xFF); al = (unsigned)(al * (a < 0 ? 0 : a > 1 ? 1 : a)); return (c & ~IM_COL32_A_MASK) | (al << IM_COL32_A_SHIFT); }
inline ImU32 Mix(ImU32 a, ImU32 b, float t) {
    auto ch = [&](int sh) { float x = (float)((a >> sh) & 0xFF), y = (float)((b >> sh) & 0xFF); return (unsigned)(x + (y - x) * t + 0.5f) << sh; };
    return ch(IM_COL32_R_SHIFT) | ch(IM_COL32_G_SHIFT) | ch(IM_COL32_B_SHIFT) | ch(IM_COL32_A_SHIFT);
}

float TextW(ImFont* f, float size, const char* t, float spacing = 0.f) {
    float w = f->CalcTextSizeA(size, FLT_MAX, 0.f, t).x;
    if (spacing > 0.f) { size_t n = strlen(t); if (n > 1) w += spacing * (float)(n - 1); }
    return w;
}
float SpacedText(ImDrawList* dl, ImFont* f, float size, ImVec2 p, ImU32 col, const char* t, float spacing) {
    char ch[2] = { 0, 0 };
    float x = p.x;
    for (const char* c = t; *c; ++c) {
        ch[0] = *c;
        dl->AddText(f, size, ImVec2(x, p.y), col, ch);
        x += f->CalcTextSizeA(size, FLT_MAX, 0.f, ch).x + spacing;
    }
    return x - spacing - p.x;
}
// letters coloured along a magenta -> violet -> cyan sweep, with a soft glow behind
float NeonText(ImDrawList* dl, ImFont* f, float size, ImVec2 p, const char* t, float spacing, float glow, float phase) {
    float total = TextW(f, size, t, spacing), x = p.x; char ch[2] = { 0, 0 };
    for (const char* c = t; *c; ++c) {
        ch[0] = *c;
        float u = total > 0 ? (x - p.x) / total : 0.f;
        float w = 0.5f + 0.5f * sinf(u * 3.1f + phase);
        ImU32 col = u < 0.5f ? Mix(cMag, cViolet, u * 2.f) : Mix(cViolet, cCyan, (u - 0.5f) * 2.f);
        col = Mix(col, cAcc, 0.25f * w);
        if (glow > 0.f) for (int g = 1; g <= 2; g++) {
            float o = g * size * 0.035f;
            dl->AddText(f, size, ImVec2(x - o, p.y), Alpha(col, glow * 0.22f / g), ch);
            dl->AddText(f, size, ImVec2(x + o, p.y), Alpha(col, glow * 0.22f / g), ch);
            dl->AddText(f, size, ImVec2(x, p.y + o), Alpha(col, glow * 0.22f / g), ch);
        }
        dl->AddText(f, size, ImVec2(x, p.y), col, ch);
        x += f->CalcTextSizeA(size, FLT_MAX, 0.f, ch).x + spacing;
    }
    return total;
}
void Pill(ImDrawList* dl, ImVec2 a, ImVec2 b, ImU32 fillL, ImU32 fillR, ImU32 line, float th = 2.f) {
    float r = (b.y - a.y) * 0.5f;
    if (fillL) {
        dl->AddRectFilled(a, b, fillL, r);
        if (fillR != fillL) {   // horizontal gradient inside the rounded shape: overlay a fading copy
            const int n = 12; float w = (b.x - a.x) / n;
            for (int i = 0; i < n; i++) {
                float x0 = a.x + i * w, x1 = x0 + w;
                ImDrawFlags fl = i == 0 ? ImDrawFlags_RoundCornersLeft : i == n - 1 ? ImDrawFlags_RoundCornersRight : ImDrawFlags_RoundCornersNone;
                dl->AddRectFilled(ImVec2(x0, a.y), ImVec2(x1 + (i < n - 1 ? 0.5f : 0.f), b.y), Mix(fillL, fillR, (i + 0.5f) / n), r, fl);
            }
        }
    }
    if (line) dl->AddRect(a, b, line, r, 0, th);
}
void Chevron(ImDrawList* dl, ImVec2 c, float r, int dir, ImU32 col, float th = 3.f) {
    dl->AddLine(ImVec2(c.x - dir * r * 0.5f, c.y - r), ImVec2(c.x + dir * r * 0.5f, c.y), col, th);
    dl->AddLine(ImVec2(c.x + dir * r * 0.5f, c.y), ImVec2(c.x - dir * r * 0.5f, c.y + r), col, th);
}
inline float Hash(int i) { unsigned h = (unsigned)i * 2654435761u; h ^= h >> 15; h *= 2246822519u; h ^= h >> 13; return (h & 0xFFFFFF) / 16777216.f; }
// a small spinning tape cassette (the mixtape flair) - reels turn while the menu is open
void Cassette(ImDrawList* dl, ImVec2 a, float w, float t) {
    float h = w * 0.62f; ImVec2 b(a.x + w, a.y + h);
    dl->AddRectFilled(a, b, IM_COL32(30, 18, 66, 235), w * 0.06f);
    dl->AddRect(a, b, Alpha(cViolet, 0.9f), w * 0.06f, 0, 2.f);
    ImVec2 la(a.x + w * 0.1f, a.y + h * 0.12f), lb(b.x - w * 0.1f, a.y + h * 0.42f);   // label strip
    dl->AddRectFilledMultiColor(la, lb, cOrange, cMag, cMag, cOrange);
    ImVec2 wa(a.x + w * 0.22f, a.y + h * 0.5f), wb(b.x - w * 0.22f, a.y + h * 0.82f);    // tape window
    dl->AddRectFilled(wa, wb, IM_COL32(8, 6, 22, 255), h * 0.12f);
    float rr = h * 0.13f;
    for (int k = 0; k < 2; k++) {
        ImVec2 c(k ? wb.x - rr * 1.6f : wa.x + rr * 1.6f, (wa.y + wb.y) * 0.5f);
        dl->AddCircleFilled(c, rr, IM_COL32(220, 214, 255, 255), 20);
        dl->AddCircleFilled(c, rr * 0.38f, IM_COL32(8, 6, 22, 255), 12);
        for (int s = 0; s < 3; s++) {
            float an = t * 4.f + s * 2.0944f;
            dl->AddLine(ImVec2(c.x + cosf(an) * rr * 0.4f, c.y + sinf(an) * rr * 0.4f), ImVec2(c.x + cosf(an) * rr * 0.95f, c.y + sinf(an) * rr * 0.95f),
                        IM_COL32(8, 6, 22, 255), 2.f);
        }
    }
}
} // namespace

void BuildFrame() {
    ImGui::SetCurrentContext(g_im);
    ImGuiIO& io = ImGui::GetIO();
    LARGE_INTEGER now; RealQpc(&now);
    io.DeltaTime = (std::max)(0.001f, (float)(now.QuadPart - g_last.QuadPart) / (float)g_qpf.QuadPart); g_last = now;
    g_anim += (std::min)(io.DeltaTime, 0.1f);
    g_capFlash = (std::max)(0.f, g_capFlash - io.DeltaTime * 1.2f);
    io.DisplaySize = ImVec2((float)g_s.texW, (float)g_s.texH);
    // ---------------------------------------------------------------- mouse (hit areas from the last frame)
    const input::Mouse& ms = input::PollMouse((float)g_s.texW, (float)g_s.texH, io.DeltaTime);
    {
        static float lastX = -1.f, lastY = -1.f;
        bool moved = fabsf(ms.x - lastX) > 0.5f || fabsf(ms.y - lastY) > 0.5f; lastX = ms.x; lastY = ms.y;
        auto itemsNow = PageItems(g_page);
        if (ms.visible && g_capOpt < 0) {
            const Hit* row = nullptr; const Hit* bar = nullptr; const Hit* tab = nullptr; const Hit* cls = nullptr; const Hit* unb = nullptr;
            for (const Hit& h : g_hits) {
                if (ms.x < h.x0 || ms.x > h.x1 || ms.y < h.y0 || ms.y > h.y1) continue;
                if (h.kind == 0) tab = &h; else if (h.kind == 1) row = &h; else if (h.kind == 2) bar = &h; else if (h.kind == 3) cls = &h; else if (h.kind == 4) unb = &h;
            }
            int n = (int)itemsNow.size();
            if (row && moved && row->idx < n) { if (g_sel != row->idx) g_hkX = false; g_sel = row->idx; }
            if (moved) { if (unb && unb->idx < n) g_hkX = true; else if (row) g_hkX = false; }   // the pointer on the X focuses it
            if (ms.wheel && n) { g_sel -= ms.wheel; g_sel = g_sel < 0 ? 0 : g_sel >= n ? n - 1 : g_sel; }
            auto& all = Options::Get().All();
            static int dragRow = -1;   // a slider drag stays on the slider it started on
            if (!ms.left) dragRow = -1;
            else if (ms.leftPressed) dragRow = bar ? bar->idx : -2;
            if (bar && ms.left && bar->idx < n && dragRow == bar->idx) {   // click / drag on a slider sets the value where the pointer is
                g_sel = bar->idx;
                Option& o = all[itemsNow[bar->idx]];
                float t = (ms.x - bar->v0) / (std::max)(1.f, bar->v1 - bar->v0); t = t < 0 ? 0 : t > 1 ? 1 : t;
                Options::Get().SetNumber(o, o.minV + t * (o.maxV - o.minV));
            } else if (ms.leftPressed || ms.rightPressed) {
                int dir = ms.leftPressed ? +1 : -1;
                if (cls) { Close(); }
                else if (unb && unb->idx < n && dir > 0) {   // the X in front of a hotkey's keycaps: unbind keyboard + pad
                    g_sel = unb->idx; g_hkX = true;
                    Option& o = all[itemsNow[unb->idx]];
                    if (o.type == OptType::Hotkey) { Options::Get().Reset(o); g_capDoneOpt = itemsNow[unb->idx]; g_capFlash = 1.f; Log("vrkit: hotkey %s unbound", o.key.c_str()); }
                }
                else if (tab) { g_page = tab->idx; g_sel = 0; }
                else if (row && row->idx < n) {
                    g_sel = row->idx;
                    Option& o = all[itemsNow[row->idx]];
                    if (o.type == OptType::Hotkey) { if (dir > 0) StartCapture(itemsNow[row->idx]); else Options::Get().Reset(o); }
                    else if (o.type == OptType::Action || o.type == OptType::Bool) { if (dir > 0 || o.type == OptType::Bool) Options::Get().Activate(o); }
                    else Options::Get().Step(o, dir);
                }
            }
        } else if (g_capOpt >= 0 && ms.rightPressed) g_capOpt = -1;   // right click cancels a hotkey capture
        g_hits.clear();
    }
    if (!g_open) { ImGui::NewFrame(); ImGui::Render(); return; }
    ImGui::NewFrame();
    const float W = (float)g_s.texW, H = (float)g_s.texH, fp = g_s.fontPx, pad = fp * 0.9f;
    ImGui::SetNextWindowPos(ImVec2(0, 0)); ImGui::SetNextWindowSize(ImVec2(W, H));
    ImGui::Begin("##vrkit", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                 ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoBackground);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    const float fs = fp, sm = fp * 0.78f, ttl = fp * 1.7f;
    const float pulse = 0.78f + 0.22f * sinf(g_anim * 3.2f);
    const float R = fp * 1.1f, m = 6.f;
    const float bgA = g_s.backgroundAlpha;

    // ---------------------------------------------------------------- panel: space gradient, nebulae, stars, neon rim
    ImVec2 p0(m, m), p1(W - m, H - m);
    dl->AddRectFilled(p0, p1, IM_COL32(12, 10, 38, (int)(bgA * 0.78f * 255)), R);
    {   // vertical gradient (indigo top -> violet middle -> deep blue bottom), drawn inside the rounded plate
        const int n = 24;
        for (int i = 0; i < n; i++) {
            float y0 = p0.y + R + (p1.y - p0.y - 2 * R) * i / n, y1 = p0.y + R + (p1.y - p0.y - 2 * R) * (i + 1) / n;
            float u = (i + 0.5f) / n;
            ImU32 c = u < 0.5f ? Mix(IM_COL32(28, 14, 70, 255), IM_COL32(52, 16, 92, 255), u * 2.f) : Mix(IM_COL32(52, 16, 92, 255), IM_COL32(8, 18, 54, 255), (u - 0.5f) * 2.f);
            dl->AddRectFilled(ImVec2(p0.x + 2, y0), ImVec2(p1.x - 2, y1 + 0.5f), Alpha(c, bgA * 0.32f));
        }
    }
    // nebula clouds (soft, slowly breathing)
    struct Neb { float x, y, r; ImU32 c; } nebs[] = { { 0.18f, 0.30f, 0.42f, cMag }, { 0.82f, 0.22f, 0.36f, cCyan }, { 0.65f, 0.80f, 0.48f, cViolet }, { 0.10f, 0.88f, 0.30f, cOrange } };
    for (auto& nb : nebs) {
        float br = 0.85f + 0.15f * sinf(g_anim * 0.6f + nb.x * 9.f);
        for (int k = 5; k >= 1; k--) dl->AddCircleFilled(ImVec2(W * nb.x, H * nb.y), W * nb.r * 0.2f * k * br, Alpha(nb.c, 0.018f * bgA), 48);
    }
    // stars: fixed positions, twinkling
    for (int i = 0; i < 140; i++) {
        float x = p0.x + R + Hash(i) * (p1.x - p0.x - 2 * R), y = p0.y + R + Hash(i + 977) * (p1.y - p0.y - 2 * R);
        float tw = 0.35f + 0.65f * (0.5f + 0.5f * sinf(g_anim * (1.2f + Hash(i + 31) * 2.5f) + Hash(i + 7) * 6.28f));
        float sz = 0.8f + Hash(i + 501) * 1.6f;
        ImU32 c = Hash(i + 3) < 0.15f ? cCyan : Hash(i + 3) < 0.25f ? cMag : IM_COL32(230, 226, 255, 255);
        dl->AddCircleFilled(ImVec2(x, y), sz, Alpha(c, tw * 0.75f), 8);
        if (sz > 2.f) { dl->AddLine(ImVec2(x - sz * 2.5f, y), ImVec2(x + sz * 2.5f, y), Alpha(c, tw * 0.3f), 1.f); dl->AddLine(ImVec2(x, y - sz * 2.5f), ImVec2(x, y + sz * 2.5f), Alpha(c, tw * 0.3f), 1.f); }
    }
    // synthwave horizon grid along the bottom edge
    {
        float hy = H - fs * 2.15f, gy1 = H - m - 4;
        for (int i = 0; i < 6; i++) { float u = i / 5.f; float y = hy + (gy1 - hy) * u * u; dl->AddLine(ImVec2(p0.x + R, y), ImVec2(p1.x - R, y), Alpha(cMag, 0.10f + 0.10f * u), 1.f); }
        float sc = fmodf(g_anim * 0.35f, 1.f);
        for (int i = -8; i <= 8; i++) { float x = W * 0.5f + (i + sc - 0.5f) * W * 0.07f; dl->AddLine(ImVec2(W * 0.5f + (x - W * 0.5f) * 0.25f, hy), ImVec2(x, gy1), Alpha(cViolet, 0.13f), 1.f); }
    }
    // neon rim: outer glow + gradient-ish outline (magenta left, cyan right)
    for (int g = 4; g >= 1; g--) dl->AddRect(ImVec2(p0.x - g * 1.5f, p0.y - g * 1.5f), ImVec2(p1.x + g * 1.5f, p1.y + g * 1.5f), Alpha(cViolet, 0.06f * (5 - g)), R + g * 1.5f, 0, 2.f);
    dl->AddRect(p0, p1, Alpha(cViolet, 0.85f), R, 0, 2.5f);
    dl->AddLine(ImVec2(p0.x + R, p0.y), ImVec2(W * 0.42f, p0.y), cMag, 4.f);
    dl->AddLine(ImVec2(W * 0.58f, p1.y), ImVec2(p1.x - R, p1.y), cCyan, 4.f);
    { float sx = p0.x + R + fmodf(g_anim * 160.f, p1.x - p0.x - 2 * R); dl->AddLine(ImVec2(sx, p0.y), ImVec2((std::min)(sx + 90.f, p1.x - R), p0.y), Alpha(cAcc, 0.7f), 3.f); }

    // ---------------------------------------------------------------- title block
    float y = pad * 0.7f;
    {
        float x = pad + R * 0.4f;
        float tw = NeonText(dl, g_fTitle, ttl, ImVec2(x, y), "GUARDIANS", ttl * 0.06f, 0.9f * pulse, g_anim * 1.5f);
        float sx = x + tw + fs * 0.7f, sy = y + ttl * 0.12f;
        float sw = SpacedText(dl, g_fBody, fs, ImVec2(sx, sy), cText, "OF THE GALAXY", fs * 0.24f);
        float bx = sx + sw + fs * 0.6f, bh = fs * 1.15f, bw = TextW(g_fBody, fs, "VR") + fs * 1.3f;
        Pill(dl, ImVec2(bx, sy - fs * 0.05f), ImVec2(bx + bw, sy - fs * 0.05f + bh), cOrange, cMag, 0);
        dl->AddText(g_fBody, fs, ImVec2(bx + (bw - TextW(g_fBody, fs, "VR")) * 0.5f, sy + fs * 0.02f), cBlack, "VR");
        y += ttl * 1.0f;
        float ruleEnd = W - pad;
        if (g_s.statusLine) {
            std::string st = g_s.statusLine(); for (auto& c : st) c = (char)toupper((unsigned char)c);
            float stw = TextW(g_fSmall, sm, st.c_str(), sm * 0.08f), bx1 = W - pad, bx0 = bx1 - stw - sm * 2.0f;
            float by0 = y - sm * 0.85f, by1 = y + sm * 0.85f;
            Pill(dl, ImVec2(bx0, by0), ImVec2(bx1, by1), IM_COL32(20, 12, 52, 235), IM_COL32(20, 12, 52, 235), Alpha(cCyan, 0.9f), 2.f);
            dl->AddCircleFilled(ImVec2(bx0 + sm * 0.75f, y), sm * 0.22f, Alpha(cMag, pulse), 12);
            SpacedText(dl, g_fSmall, sm, ImVec2(bx0 + sm * 1.3f, by0 + (by1 - by0 - sm) * 0.5f), cCyan, st.c_str(), sm * 0.08f);
            ruleEnd = bx0 - 12;
        }
        dl->AddRectFilledMultiColor(ImVec2(pad, y), ImVec2(ruleEnd, y + 3), cMag, Alpha(cCyan, 0.3f), Alpha(cCyan, 0.3f), cMag);
        y += fs * 0.7f;
    }

    // ---------------------------------------------------------------- tabs: neon pills
    auto pages = Options::Get().Pages();
    {
        ImFont* tf = g_fBody; float ts = fs * 0.8f, sp = ts * 0.14f, gap = 10.f;
        float total = 0; std::vector<std::string> ups;
        for (auto& pg : pages) { std::string up = pg; for (auto& c : up) c = (char)toupper((unsigned char)c); ups.push_back(up); total += TextW(tf, ts, up.c_str(), sp) + ts * 1.8f + gap; }
        float avail = W - 2 * pad;
        if (total > avail) { float sc = avail / total; ts *= sc; sp *= sc; }
        float x = pad, th = ts * 1.75f;
        for (int p = 0; p < (int)ups.size(); ++p) {
            float w = TextW(tf, ts, ups[p].c_str(), sp) + ts * 1.8f;
            ImVec2 a0(x, y), a1(x + w, y + th);
            g_hits.push_back({ a0.x, a0.y, a1.x, a1.y, 0, p, 0, 0 });
            if (p == g_page) {
                for (int g = 3; g >= 1; g--) dl->AddRect(ImVec2(a0.x - g * 2, a0.y - g * 2), ImVec2(a1.x + g * 2, a1.y + g * 2), Alpha(cMag, 0.10f * (4 - g) * pulse), th * 0.5f + g * 2, 0, 2.f);
                Pill(dl, a0, a1, cMag, cViolet, 0);
                SpacedText(dl, tf, ts, ImVec2(x + ts * 0.9f, y + (th - ts) * 0.5f), cAcc, ups[p].c_str(), sp);
            } else {
                Pill(dl, a0, a1, IM_COL32(40, 24, 90, 150), IM_COL32(24, 30, 90, 150), Alpha(cCyan, 0.35f), 1.5f);
                SpacedText(dl, tf, ts, ImVec2(x + ts * 0.9f, y + (th - ts) * 0.5f), cDim, ups[p].c_str(), sp);
            }
            x += w + gap;
        }
        y += th + fs * 0.45f;
    }

    // ---------------------------------------------------------------- option rows
    auto items = PageItems(g_page);
    auto& opts = Options::Get().All();
    const float rowH = fs * 1.32f, listTop = y + fs * 0.05f, listBottom = H - fs * 5.9f;
    // section dividers: a labelled line above the first row of every group (rows keep their own height)
    const float hdrH = fs * 1.05f;
    std::vector<float> rowY(items.size()); std::vector<char> hasHdr(items.size(), 0);
    float total = 0.f;
    for (size_t r = 0; r < items.size(); ++r) {
        const std::string& g = opts[items[r]].group;
        if (!g.empty() && (r == 0 || opts[items[r - 1]].group != g)) { hasHdr[r] = 1; total += hdrH; }
        rowY[r] = total; total += rowH;
    }
    const float listH = listBottom - listTop;
    float scroll = 0.f;
    if (total > listH && g_sel >= 0 && g_sel < (int)items.size()) {
        scroll = rowY[g_sel] + rowH * 0.5f - listH * 0.5f;
        scroll = (std::max)(0.f, (std::min)(scroll, total - listH));
    }
    const int visibleRows = (std::max)(1, (int)(listH / rowH));
    const float valR = W - pad - fs * 0.6f, valW = W * 0.34f;
    dl->PushClipRect(ImVec2(0, listTop - 2), ImVec2(W, listBottom + 2), true);
    for (int r = 0; r < (int)items.size(); ++r) {
        if (rowY[r] + rowH < scroll || rowY[r] - (hasHdr[r] ? hdrH : 0) > scroll + listH) continue;
        Option& o = opts[items[r]];
        float ry = listTop + rowY[r] - scroll, cy = ry + rowH * 0.5f - fs * 0.06f;
        if (hasHdr[r]) {
            float hy = ry - hdrH * 0.5f;
            std::string g = o.group; for (auto& c : g) c = (char)toupper((unsigned char)c);
            float gw = TextW(g_fSmall, sm, g.c_str(), sm * 0.18f), gx = pad * 0.6f + fs * 0.4f;
            SpacedText(dl, g_fSmall, sm, ImVec2(gx, hy - sm * 0.55f), cCyan, g.c_str(), sm * 0.18f);
            float lx0 = gx + gw + fs * 0.5f, lx1 = W - pad * 0.6f;
            if (lx1 > lx0) dl->AddRectFilledMultiColor(ImVec2(lx0, hy - 1), ImVec2(lx1, hy + 1), Alpha(cMag, 0.85f), Alpha(cCyan, 0.05f), Alpha(cCyan, 0.05f), Alpha(cMag, 0.85f));
        }
        { float hy0 = (std::max)(ry + 2.f, listTop), hy1 = (std::min)(ry + rowH - 2.f, listBottom);
          if (hy1 > hy0) g_hits.push_back({ pad * 0.6f, hy0, W - pad * 0.6f, hy1, 1, r, 0, 0 }); }
        bool sel = r == g_sel;
        if (sel) {
            if (g_selY < 0.f || fabsf(g_selY - ry) > rowH * 6) g_selY = ry;
            g_selY += (ry - g_selY) * (std::min)(1.f, io.DeltaTime * 18.f);
            float y0 = g_selY + 3, y1 = g_selY + rowH - 3;
            dl->AddRectFilledMultiColor(ImVec2(pad * 0.6f, y0), ImVec2(W - pad * 0.6f, y1), Alpha(cMag, 0.34f * pulse), Alpha(cCyan, 0.05f),
                                        Alpha(cCyan, 0.05f), Alpha(cMag, 0.34f * pulse));
            dl->AddRect(ImVec2(pad * 0.6f, y0), ImVec2(W - pad * 0.6f, y1), Alpha(cMag, 0.55f), 6.f, 0, 1.5f);
            dl->AddRectFilled(ImVec2(pad * 0.6f, y0), ImVec2(pad * 0.6f + 6, y1), cMag, 3.f);
            Chevron(dl, ImVec2(pad * 0.6f + 20, (y0 + y1) * 0.5f), fs * 0.22f, 1, cCyan);
        } else if (r & 1) dl->AddRectFilled(ImVec2(pad * 0.6f, ry + 3), ImVec2(W - pad * 0.6f, ry + rowH - 3), cFaint, 6.f);
        dl->AddText(g_fBody, fs, ImVec2(pad + fs * 0.7f, cy - fs * 0.5f), sel ? cAcc : cText, o.label.c_str());

        float x1 = valR;
        switch (o.type) {
        case OptType::Bool: {   // rounded switch, knob slides, track lights cyan -> magenta
            bool on = o.b && *o.b;
            float tw = fs * 2.4f, th = fs * 0.9f, x0 = x1 - tw, y0 = cy - th * 0.5f;
            Pill(dl, ImVec2(x0, y0), ImVec2(x1, y0 + th), on ? cCyan : cTrack, on ? cMag : cTrack, on ? Alpha(cAcc, 0.6f) : Alpha(cViolet, 0.6f), 1.5f);
            float kr = th * 0.38f, kx = on ? x1 - th * 0.5f : x0 + th * 0.5f;
            if (on) dl->AddCircleFilled(ImVec2(kx, cy), kr * 1.6f, Alpha(cAcc, 0.18f * pulse), 20);
            dl->AddCircleFilled(ImVec2(kx, cy), kr, on ? cAcc : IM_COL32(120, 108, 170, 255), 20);
            const char* t = on ? "ON" : "OFF";
            float lw = TextW(g_fSmall, sm, t, sm * 0.12f);
            SpacedText(dl, g_fSmall, sm, ImVec2(x0 - lw - fs * 0.5f, cy - sm * 0.55f), on ? cCyan : cDim, t, sm * 0.12f);
            break;
        }
        case OptType::Int: case OptType::Float: {   // segment bar coloured along the sweep
            float v = o.type == OptType::Int ? (float)*o.i : *o.f;
            float frac = o.maxV > o.minV ? (v - o.minV) / (o.maxV - o.minV) : 0.f; frac = frac < 0 ? 0 : frac > 1 ? 1 : frac;
            const int N = 20; float bw = valW * 0.62f, cw = bw / N, x0 = x1 - bw, h = fs * 0.58f, y0 = cy - h * 0.5f;
            int lit = (int)(frac * N + 0.5f);
            if (cy > listTop && cy < listBottom) g_hits.push_back({ x0 - 4.f, y0 - fs * 0.3f, x1 + 4.f, y0 + h + fs * 0.3f, 2, r, x0, x1 });
            for (int c = 0; c < N; c++) {
                ImVec2 a(x0 + c * cw + 1, y0), b(x0 + (c + 1) * cw - 2, y0 + h);
                ImU32 col = Mix(cCyan, cMag, (c + 0.5f) / N);
                if (c < lit) dl->AddRectFilled(a, b, c == lit - 1 && sel ? Alpha(cAcc, pulse) : col, 2.f);
                else dl->AddRectFilled(a, b, cTrack, 2.f);
            }
            std::string t = Options::Get().DisplayText(o);
            float tw = TextW(g_fBody, fs, t.c_str());
            float tx = x0 - tw - fs * (sel ? 1.3f : 0.6f);
            if (sel) { Chevron(dl, ImVec2(tx - fs * 0.45f, cy), fs * 0.2f, -1, cCyan, 2.5f); Chevron(dl, ImVec2(x0 - fs * 0.45f, cy), fs * 0.2f, 1, cCyan, 2.5f); }
            dl->AddText(g_fBody, fs, ImVec2(tx, cy - fs * 0.5f), sel ? cAcc : cText, t.c_str());
            break;
        }
        case OptType::Choice: {   // value between chevrons + a dot per choice
            std::string t = Options::Get().DisplayText(o); for (auto& c : t) c = (char)toupper((unsigned char)c);
            float tw = TextW(g_fBody, fs * 0.9f, t.c_str(), fs * 0.05f);
            float tx = x1 - tw - (sel ? fs * 0.9f : 0.f);
            if (sel) { Chevron(dl, ImVec2(x1 - fs * 0.25f, cy), fs * 0.22f, 1, cCyan, 2.5f); Chevron(dl, ImVec2(tx - fs * 0.6f, cy), fs * 0.22f, -1, cCyan, 2.5f); }
            SpacedText(dl, g_fBody, fs * 0.9f, ImVec2(tx, cy - fs * 0.5f), sel ? cAcc : cText, t.c_str(), fs * 0.05f);
            int n = (int)o.choices.size(), cur = 0;
            for (int k = 0; k < n; k++) if (o.choices[k] == *o.s) cur = k;
            if (n > 1 && n <= 12) {
                float pr = 3.5f, pg = 13.f, px = tx + tw - (n - 1) * pg - pr, py = cy + fs * 0.6f;
                for (int k = 0; k < n; k++) dl->AddCircleFilled(ImVec2(px + k * pg, py), k == cur ? pr * 1.3f : pr, k == cur ? cMag : Alpha(cViolet, 0.6f), 10);
            }
            break;
        }
        case OptType::Hotkey: {   // two keycaps: keyboard | gamepad; while capturing a pulsing prompt
            if (g_capOpt == items[r]) {
                const char* t = "PRESS A KEY OR PAD BUTTONS...";
                float tw = TextW(g_fSmall, sm, t, sm * 0.1f), bw = tw + sm * 2.f, bh = sm * 1.8f, x0 = x1 - bw, y0 = cy - bh * 0.5f;
                float a = 0.55f + 0.45f * sinf(g_anim * 7.f);
                Pill(dl, ImVec2(x0, y0), ImVec2(x1, y0 + bh), Alpha(cOrange, a), Alpha(cMag, a), cAcc, 1.5f);
                SpacedText(dl, g_fSmall, sm, ImVec2(x0 + sm, cy - sm * 0.55f), cBlack, t, sm * 0.1f);
                break;
            }
            input::Binding bd = input::ParseBinding(*o.s);
            std::string kt = input::KeyText(bd.vk, bd.mods), pt = input::PadText(bd.pad);
            bool flash = g_capDoneOpt == items[r] && g_capFlash > 0.f;
            float bh = sm * 1.7f, y0 = cy - bh * 0.5f, xr = x1;
            const std::string* parts[2] = { &pt, &kt };   // right to left: pad, keyboard
            const char* tags[2] = { "PAD", "KEY" };
            for (int k = 0; k < 2; k++) {
                bool none = *parts[k] == "none";
                std::string t = none ? "-" : *parts[k];
                float tw = TextW(g_fSmall, sm, t.c_str(), sm * 0.06f), gw = TextW(g_fSmall, sm * 0.7f, tags[k], 1.f);
                float bw = (std::max)(tw + gw + sm * 2.2f, sm * 5.2f), x0 = xr - bw;
                ImU32 rim = none ? Alpha(cViolet, 0.45f) : (k == 0 ? Alpha(cCyan, 0.9f) : Alpha(cMag, 0.9f));
                if (flash) rim = Mix(rim, cOrange, g_capFlash);
                Pill(dl, ImVec2(x0, y0), ImVec2(xr, y0 + bh), IM_COL32(24, 14, 60, 235), IM_COL32(30, 18, 76, 235), rim, sel ? 2.f : 1.5f);
                dl->AddText(g_fSmall, sm * 0.7f, ImVec2(x0 + sm * 0.7f, cy - sm * 0.36f), none ? cDim : (k == 0 ? cCyan : cMag), tags[k]);
                SpacedText(dl, g_fSmall, sm, ImVec2(x0 + sm * 0.7f + gw + sm * 0.5f, cy - sm * 0.55f), none ? cDim : (sel ? cAcc : cText), t.c_str(), sm * 0.06f);
                xr = x0 - sm * 0.5f;
            }
            if (!o.noUnbind) {   // the X (unbind keyboard + pad): a round neon button in front of the keycaps - Left + A, or click it
                bool unbound = pt == "none" && kt == "none";
                float d = bh, x0 = xr - d, cx = x0 + d * 0.5f, r0 = d * 0.5f;
                bool hot = ms.visible && ms.x >= x0 - 3.f && ms.x <= xr + 3.f && ms.y >= y0 - 3.f && ms.y <= y0 + bh + 3.f;
                bool foc = (sel && g_hkX) || hot;
                if (foc) {
                    for (int g = 3; g >= 1; g--) dl->AddCircleFilled(ImVec2(cx, cy), r0 + g * sm * 0.12f, Alpha(cMag, 0.10f * pulse), 28);
                    dl->AddCircleFilled(ImVec2(cx, cy), r0, Mix(cOrange, cMag, 0.5f + 0.5f * sinf(g_anim * 4.f)), 28);
                    dl->AddCircle(ImVec2(cx, cy), r0, cAcc, 28, 2.f);
                } else {
                    dl->AddCircleFilled(ImVec2(cx, cy), r0, IM_COL32(24, 14, 60, 235), 28);
                    dl->AddCircle(ImVec2(cx, cy), r0, unbound ? Alpha(cViolet, 0.45f) : Alpha(cMag, sel ? 0.95f : 0.7f), 28, sel ? 2.f : 1.5f);
                }
                float k = r0 * 0.38f, th = foc ? 3.f : 2.2f;
                ImU32 xc = foc ? cBlack : unbound ? cDim : (sel ? cAcc : cMag);
                dl->AddLine(ImVec2(cx - k, cy - k), ImVec2(cx + k, cy + k), xc, th);
                dl->AddLine(ImVec2(cx - k, cy + k), ImVec2(cx + k, cy - k), xc, th);
                if (cy > listTop && cy < listBottom) g_hits.push_back({ x0 - 3.f, y0 - 3.f, xr + 3.f, y0 + bh + 3.f, 4, r, 0, 0 });
            }
            break;
        }
        case OptType::Action: {
            const char* t = "ENGAGE";
            float tw = TextW(g_fSmall, sm, t, sm * 0.2f), bw = tw + sm * 2.4f, bh = sm * 1.8f, x0 = x1 - bw, y0 = cy - bh * 0.5f;
            if (sel) Pill(dl, ImVec2(x0, y0), ImVec2(x1, y0 + bh), cOrange, cMag, 0);
            else Pill(dl, ImVec2(x0, y0), ImVec2(x1, y0 + bh), IM_COL32(40, 24, 90, 160), IM_COL32(40, 24, 90, 160), Alpha(cOrange, 0.7f), 1.5f);
            SpacedText(dl, g_fSmall, sm, ImVec2(x0 + (bw - tw) * 0.5f, cy - sm * 0.55f), sel ? cBlack : cOrange, t, sm * 0.2f);
            x1 = x0;
            break;
        }
        }
        if (o.needsRestart) {
            const char* rs = "RESTART";
            float lw = TextW(g_fBody, fs, o.label.c_str()), rw = TextW(g_fSmall, sm * 0.85f, rs, 2.f);
            float rx = pad + fs * 0.7f + lw + fs * 0.6f, rh = sm * 1.2f;
            Pill(dl, ImVec2(rx, cy - rh * 0.5f), ImVec2(rx + rw + 16, cy + rh * 0.5f), 0, 0, Alpha(cWarn, 0.85f), 1.5f);
            SpacedText(dl, g_fSmall, sm * 0.85f, ImVec2(rx + 8, cy - sm * 0.45f), cWarn, rs, 2.f);
        }
    }
    dl->PopClipRect();
    (void)visibleRows;
    if (items.empty()) dl->AddText(g_fBody, fs, ImVec2(pad, listTop), cDim, "(nothing on this page)");
    if (total > listH) {
        float sx = W - pad * 0.45f, h = listH, th = h * listH / total, ty = listTop + h * scroll / total;
        dl->AddRectFilled(ImVec2(sx - 1, listTop), ImVec2(sx + 1, listBottom), cLine);
        dl->AddRectFilled(ImVec2(sx - 3, ty), ImVec2(sx + 3, ty + th), cMag, 3.f);
    }

    // ---------------------------------------------------------------- info box + key hints
    float hy = H - fs * 5.1f;
    {
        float bx0 = pad, bx1 = W - pad, by0 = hy, by1 = H - fs * 2.25f;
        dl->AddRectFilled(ImVec2(bx0, by0), ImVec2(bx1, by1), IM_COL32(18, 12, 48, 200), 10.f);
        dl->AddRect(ImVec2(bx0, by0), ImVec2(bx1, by1), Alpha(cViolet, 0.6f), 10.f, 0, 1.5f);
        float lw = TextW(g_fSmall, sm, "INFO", sm * 0.25f);
        Pill(dl, ImVec2(bx0 + sm, by0 - sm * 0.7f), ImVec2(bx0 + sm * 3.2f + lw, by0 + sm * 0.7f), cCyan, cViolet, 0);
        SpacedText(dl, g_fSmall, sm, ImVec2(bx0 + sm * 2.1f, by0 - sm * 0.5f), cBlack, "INFO", sm * 0.25f);
        if (!items.empty()) {
            const Option& o = opts[items[(std::min)(g_sel, (int)items.size() - 1)]];
            std::string h = o.help;
            if (!o.key.empty()) h += (h.empty() ? "" : "   ") + std::string("[") + o.key + "]";
            ImGui::PushFont(g_fSmall);
            ImGui::SetCursorScreenPos(ImVec2(bx0 + sm * 0.9f, by0 + sm * 1.0f));
            ImGui::PushTextWrapPos(bx1 - sm * 0.9f);
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(200, 192, 245, 255));
            ImGui::TextWrapped("%s", h.c_str());
            ImGui::PopStyleColor(); ImGui::PopTextWrapPos(); ImGui::PopFont();
        }
    }
    {
        struct K { const char* key; const char* what; };
        bool hk = !items.empty() && opts[items[(std::min)(g_sel, (int)items.size() - 1)]].type == OptType::Hotkey;
        const K keysN[] = { { "A/ENTER", "CHANGE" }, { "Y/DEL", "UNDO" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" }, { "MOUSE", "CLICK / WHEEL" } };
        const K keysHX[] = { { "A/ENTER/CLICK", "UNBIND KEY + PAD" }, { "RIGHT", "BACK TO KEYS" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" } };
        const K keysH0[] = { { "A/ENTER/CLICK", "BIND" }, { "LEFT / CLICK X", "UNBIND" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" } };
        const K keysHL[] = { { "A/ENTER/CLICK", "BIND" }, { "ALWAYS BOUND", "PANEL KEY" }, { "LB/RB", "PAGE" }, { "B/BKSP", "CLOSE" } };
        bool lockedRow = hk && opts[items[(std::min)(g_sel, (int)items.size() - 1)]].noUnbind;
        const K* keysH = lockedRow ? keysHL : g_hkX ? keysHX : keysH0;
        const K keysC[] = { { "KEY", "KEYBOARD" }, { "PAD", "HOLD + RELEASE" }, { "BKSP", "CLEAR KEY" }, { "ESC", "CANCEL" } };
        const K* keys = g_capOpt >= 0 ? keysC : hk ? keysH : keysN;
        int nk = g_capOpt >= 0 ? 4 : hk ? 4 : 5;
        float ks = sm, total = 0.f;
        for (int i = 0; i < nk; i++) { const K& k = keys[i]; total += TextW(g_fSmall, ks, k.key) + ks * 1.2f + ks * 0.45f + TextW(g_fSmall, ks, k.what, ks * 0.12f) + ks * 1.3f; }
        float avail = W - 2.f * (pad + R * 0.4f);
        if (total > avail) ks *= avail / total;
        const float sm = ks;
        float x = pad + R * 0.4f, ky = H - fs * 1.75f, kh = sm * 1.45f;
        for (int i = 0; i < nk; i++) {
            const K& k = keys[i];
            float kw = TextW(g_fSmall, sm, k.key) + sm * 1.2f, x0 = x;
            bool isClose = strcmp(k.what, "CLOSE") == 0;
            bool hot = isClose && ms.visible && ms.x >= x0 && ms.x <= x0 + kw + sm * 4.5f && ms.y >= ky && ms.y <= ky + kh;
            Pill(dl, ImVec2(x, ky), ImVec2(x + kw, ky + kh), hot ? Alpha(cMag, 0.6f) : IM_COL32(30, 20, 70, 230), hot ? Alpha(cMag, 0.6f) : IM_COL32(30, 20, 70, 230), Alpha(cCyan, 0.8f), 1.5f);
            dl->AddText(g_fSmall, sm, ImVec2(x + sm * 0.6f, ky + (kh - sm) * 0.5f), hot ? cAcc : cCyan, k.key);
            x += kw + sm * 0.45f;
            x += SpacedText(dl, g_fSmall, sm, ImVec2(x, ky + (kh - sm) * 0.5f), hot ? cAcc : cDim, k.what, sm * 0.12f) + sm * 1.3f;
            if (isClose) g_hits.push_back({ x0, ky, x - sm * 1.3f, ky + kh, 3, 0, 0, 0 });
        }
    }
    // ---------------------------------------------------------------- mouse pointer: a neon arrow in the menu's colours
    // (dark core, magenta -> cyan rim with a glow, an orange spark at the tip and a slowly turning star ring), drawn
    // larger than a desktop pointer so it reads at panel distance in the headset
    if (ms.alpha > 0.02f) {
        const float a = ms.alpha, s = fs * 1.6f;           // pointer height (large: it is read at panel distance)
        const ImVec2 t(ms.x, ms.y);
        const ImVec2 P[7] = { t, ImVec2(t.x, t.y + s), ImVec2(t.x + s * 0.27f, t.y + s * 0.76f), ImVec2(t.x + s * 0.47f, t.y + s * 1.12f),
                              ImVec2(t.x + s * 0.62f, t.y + s * 1.04f), ImVec2(t.x + s * 0.43f, t.y + s * 0.69f), ImVec2(t.x + s * 0.76f, t.y + s * 0.69f) };
        ImVec2 sh[7]; for (int k = 0; k < 7; k++) sh[k] = ImVec2(P[k].x + 3.f, P[k].y + 4.f);
        dl->AddConcavePolyFilled(sh, 7, IM_COL32(0, 0, 0, (int)(120 * a)));          // drop shadow
        for (int g = 3; g >= 1; g--) dl->AddPolyline(P, 7, Alpha(cMag, 0.10f * a * (4 - g)), ImDrawFlags_Closed, 2.f + g * 3.f);   // glow
        dl->AddConcavePolyFilled(P, 7, Alpha(IM_COL32(16, 8, 40, 255), 0.94f * a));    // core
        ImVec2 in[4] = { ImVec2(t.x + s * 0.08f, t.y + s * 0.22f), ImVec2(t.x + s * 0.08f, t.y + s * 0.78f), ImVec2(t.x + s * 0.24f, t.y + s * 0.62f), ImVec2(t.x + s * 0.5f, t.y + s * 0.62f) };
        dl->AddConvexPolyFilled(in, 4, Alpha(cViolet, 0.35f * a));                     // inner sheen
        for (int k = 0; k < 7; k++) {                                                    // rim: magenta at the tip -> cyan at the tail
            const ImVec2& p0 = P[k]; const ImVec2& p1 = P[(k + 1) % 7];
            float u = ((p0.y + p1.y) * 0.5f - t.y) / (s * 1.12f);
            dl->AddLine(p0, p1, Alpha(Mix(cMag, cCyan, u < 0 ? 0 : u > 1 ? 1 : u), a), 2.5f);
        }
        float pr = s * 0.13f * (0.85f + 0.15f * sinf(g_anim * 6.f));                     // spark at the tip
        dl->AddCircleFilled(t, pr * 1.9f, Alpha(cOrange, 0.25f * a), 16);
        dl->AddCircleFilled(t, pr * 0.8f, Alpha(cOrange, a), 12);
        dl->AddCircleFilled(t, pr * 0.35f, Alpha(cAcc, a), 8);
        float rr = s * 0.42f, an = g_anim * 1.6f;                                         // star ring around the tip
        for (int k = 0; k < 4; k++) {
            float q = an + k * 1.5708f;
            ImVec2 c(t.x + cosf(q) * rr, t.y + sinf(q) * rr);
            ImU32 col = Alpha(k & 1 ? cCyan : cMag, 0.85f * a);
            dl->AddLine(ImVec2(c.x - 4.f, c.y), ImVec2(c.x + 4.f, c.y), col, 1.5f); dl->AddLine(ImVec2(c.x, c.y - 4.f), ImVec2(c.x, c.y + 4.f), col, 1.5f);
        }
        if (ms.left || ms.right) dl->AddCircle(t, rr * 0.75f, Alpha(ms.left ? cOrange : cCyan, a), 24, 2.f);   // press ring
    }
    ImGui::End();
    ImGui::Render();
}

bool IsOpen() { return g_open; }
void SetOpen(bool open) { if (open == g_open) return; if (open) { g_open = true; input::SetBlocking(true); input::MouseReset(g_s.texW * 0.5f, g_s.texH * 0.5f); } else Close(); }
bool IsCapturing() { return g_open && g_capOpt >= 0; }

} } } // namespace vrkit::menu::core
