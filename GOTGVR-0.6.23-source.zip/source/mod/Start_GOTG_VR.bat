@echo off
rem Guardians of the Galaxy VR (GOTGVR): starts the game straight into VR, without the launcher.
rem Put this file next to GOTG.exe (the game's bin folder). Start your VR software (SteamVR, Pimax Play, ...) first.
cd /d "%~dp0"
if exist "%~dp0GOTG.exe" (
    start "" "%~dp0GOTG.exe" -nolauncher
) else (
    rem not in the bin folder: let Steam start it with the switch (Steam asks once to allow the launch option)
    start "" "steam://run/1088850//-nolauncher/"
)
