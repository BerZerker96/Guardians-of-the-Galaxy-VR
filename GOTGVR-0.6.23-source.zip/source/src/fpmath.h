#pragma once
// First person: the pure maths (no game access), shared by firstperson.cpp and tools/firstperson_unittest.cpp.
#include <cmath>
#include "vrmath.h"

namespace fpm {

// Head bob filter. The head bone swings with the walk / run animation (a few cm up / down and sideways each step):
// in a headset that is the worst kind of motion. The filter works on the head RELATIVE to the character root, so the
// character's own travel (the root moves smoothly with its capsule) is never delayed - only the bob is smoothed.
// k = 0 off .. 1 strong (time constant up to 0.2 s). A jump of more than 0.6 m (teleport, ragdoll, a new character)
// is taken at once. The character's travel needs no such rule: the root is never filtered.
struct BobFilter {
    V3 rel = { 0, 0, 0 }, rel1 = { 0, 0, 0 }; bool have = false;   // two first-order stages: -12 dB/octave above ~1 Hz
    V3 Step(V3 root, V3 head, float dt, float k) {
        V3 r = head - root;
        if (!have || !(k > 0.01f) || !(dt > 0.f && dt < 0.25f) || Len(r - rel) > 0.6f) { rel = rel1 = r; have = true; return head; }
        float tau = 0.2f * k, a = 1.f - expf(-dt / tau);
        rel1 = rel1 + (r - rel1) * a;
        rel = rel + (rel1 - rel) * a;
        return root + rel;
    }
};

// The eye base in first person: the camera frame `cam` (decoupled / stabilized as the user set it) moved to the head.
// Offsets (metres) are along the camera's HEADING (level right / up / forward, never pitched), so looking up or
// down in the game does not move the eye point around the head.
inline Frame AtHead(Frame cam, V3 head, const float off[3], float unitsPerMetre) {
    V3 fwd = cam.axis[2] * -1.f;
    V3 h = { fwd.x, fwd.y, 0.f };
    if (Len(h) < 1e-3f) h = { cam.axis[1].x, cam.axis[1].y, 0.f };   // looking straight down / up
    h = Len(h) > 1e-6f ? Norm(h) : V3{ 1, 0, 0 };
    V3 up = { 0, 0, 1 }, right = Cross(h, up);
    float u = unitsPerMetre;
    cam.pos = head + right * (off[0] * u) + up * (off[1] * u) + h * (off[2] * u);
    return cam;
}

// Is the game camera the gameplay camera that follows the player (behind and looking at them)? Cutscene / scripted
// cameras are usually somewhere else: there first person is suspended and the game's camera is shown.
inline bool FollowsPlayer(const Frame& cam, V3 head, float maxDistUnits) {
    V3 d = head - cam.pos;
    float l = Len(d);
    if (!(l < maxDistUnits)) return false;
    if (l < 0.05f) return true;
    V3 fwd = cam.axis[2] * -1.f;
    return Dot(fwd, d * (1.f / l)) > 0.5f;   // the player within 60 degrees of the view centre
}

} // namespace fpm
