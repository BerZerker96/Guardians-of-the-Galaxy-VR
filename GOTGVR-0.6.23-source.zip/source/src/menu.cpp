#include <algorithm>
// Settings (gotgvr_config.txt) and the in-headset VR menu (vrkit: Dear ImGui into an off-screen texture, the same
// panel as DXMDVR). Insert or hold L3 + R3 opens it. Options edit g_set; the config file is rewritten on close.
#include <windows.h>
#include <d3d11.h>
#include <cmath>
#include <cstdio>
#include <string>
#include "log.h"
#include "config.h"
#include "settings.h"
#include "camera.h"
#include "game.h"
#include "version.h"
#include "vrkit_options.h"
#include "vrkit_menu.h"
#include "xrbridge/client.h"

extern std::wstring g_gameDir;
extern ID3D11Device* g_dev11;
extern ID3D11DeviceContext* g_ctx11;
void XrSetMode(int mode);
void XrRequestRecenter();
void SmoothingSet(const std::string& m);
void FpsLimitSet(const std::string& v);
void UiSplitSet();

VrSettings g_set;
static bool g_menuInit = false;
static float g_fps = 0;

int ModeFromString(const std::string& m) { return m == "head" ? VRMODE_HEAD : m == "screen" ? VRMODE_SCREEN : (m == "aer" || m == "stereo") ? VRMODE_STEREO : (m == "recon" || m == "afw") ? VRMODE_RECON : VRMODE_SYNCED; }
static const char* ModeKey(int m) { return m == VRMODE_HEAD ? "head" : m == VRMODE_SCREEN ? "screen" : m == VRMODE_STEREO ? "aer" : m == VRMODE_RECON ? "recon" : "synced"; }

void SettingsLoad() {
    VrSettings d;
    g_set.vrMode = ConfigStr("vr_mode", d.vrMode.c_str());
    if (g_set.vrMode == "stereo") g_set.vrMode = "aer";
    g_set.syncSubmit = ConfigStr("sync_submit", d.syncSubmit.c_str());
    g_set.syncLag = ConfigInt("sync_lag", d.syncLag);
    g_set.ui2d = ConfigBool("ui_2d", d.ui2d);
    g_set.symmetricView = ConfigBool("symmetric_view", d.symmetricView);
    g_set.wideCull = ConfigBool("wide_cull", d.wideCull);
    g_set.submitView = ConfigStr("submit_view", d.submitView.c_str()); if (g_set.submitView != "rendered") g_set.submitView = "headset";
    g_set.gameAa = ConfigStr("game_aa", d.gameAa.c_str());
    if (g_set.gameAa != "off" && g_set.gameAa != "on") g_set.gameAa = "game";
    g_set.gameUpscaling = ConfigStr("game_upscaling", d.gameUpscaling.c_str());
    if (g_set.gameUpscaling != "off") g_set.gameUpscaling = "game";
    g_set.flatPauseMenus = ConfigBool("flat_pause_menus", d.flatPauseMenus);
    g_set.flatVideos = ConfigBool("flat_videos", d.flatVideos);
    g_set.flatVideoMinWidth = ConfigInt("flat_video_min_width", d.flatVideoMinWidth);
    // 0.6.11: stereo reconstruction always draws the head-centre view and rebuilds both eyes (the left / alternate
    // drawn views were removed: misaligned on canted headsets, flashing history fill)
    g_set.reconEye = "centre"; g_set.reconHistory = false; g_set.reconShared = false;
    g_set.reconGapReach = ConfigInt("recon_gap_reach", d.reconGapReach);
    g_set.reconDepth = ConfigStr("recon_depth", d.reconDepth.c_str());
    if (g_set.reconDepth != "game" && g_set.reconDepth != "flip") g_set.reconDepth = "auto";
    g_set.reconDebug = ConfigInt("recon_debug", d.reconDebug);
    g_set.renderResolution = ConfigStr("render_resolution", d.renderResolution.c_str());
    g_set.renderScale = ConfigFloat("render_scale", d.renderScale);
    g_set.uiTarget = ConfigStr("ui_target", d.uiTarget.c_str());
    g_set.renderDensity = ConfigStr("render_density", d.renderDensity.c_str());
    g_set.eyeAspect = ConfigStr("eye_aspect", d.eyeAspect.c_str());
    g_set.renderMaxSide = ConfigInt("render_max_side", d.renderMaxSide);
    g_set.worldScale = ConfigFloat("world_scale", d.worldScale);
    g_set.unitsPerMetre = ConfigFloat("units_per_metre", d.unitsPerMetre);
    g_set.swapEyes = ConfigBool("swap_eyes", d.swapEyes);
    g_set.frameDelay = ConfigInt("aer_frame_delay", d.frameDelay);
    g_set.ipdScale = ConfigFloat("ipd_scale", d.ipdScale);
    g_set.cameraReprojection = ConfigBool("camera_reprojection", d.cameraReprojection);
    g_set.cullMargin = ConfigFloat("cull_margin", d.cullMargin);
    g_set.reconShiftH = ConfigFloat("recon_align_h", d.reconShiftH); g_set.reconShiftV = ConfigFloat("recon_align_v", d.reconShiftV);
    g_set.aerShiftH = ConfigFloat("aer_align_h", d.aerShiftH); g_set.aerShiftV = ConfigFloat("aer_align_v", d.aerShiftV);
    g_set.reconParallax = ConfigFloat("recon_parallax", d.reconParallax);
    g_set.edgeFill = ConfigBool("edge_fill", d.edgeFill);
    g_set.exactRenderSize = ConfigBool("exact_render_size", d.exactRenderSize);
    g_set.viewWidth = ConfigFloat("view_width", d.viewWidth); g_set.viewHeight = ConfigFloat("view_height", d.viewHeight);
    g_set.decoupledPitch = ConfigBool("decoupled_pitch", d.decoupledPitch);
    g_set.offsetStepCm = ConfigFloat("offset_step_cm", d.offsetStepCm);
    if (!(g_set.offsetStepCm >= 1.f && g_set.offsetStepCm <= 30.f)) g_set.offsetStepCm = 3.f;
    g_set.camOffsetX = ConfigFloat("camera_offset_x", 0.f);
    g_set.camOffsetY = ConfigFloat("camera_offset_y", 0.f);
    g_set.camOffsetZ = ConfigFloat("camera_offset_z", 0.f);
    g_set.cameraAxes = ConfigStr("camera_axes", d.cameraAxes.c_str());
    g_set.skipLauncher = ConfigBool("skip_launcher", d.skipLauncher);
    g_set.panelLayers = ConfigStr("panel_layers", d.panelLayers.c_str());
    g_set.forceWindowed = ConfigBool("force_windowed", d.forceWindowed);
    g_set.firstPerson = ConfigBool("first_person", d.firstPerson);
    g_set.fpOffsetX = ConfigFloat("fp_offset_x", d.fpOffsetX);
    g_set.fpOffsetY = ConfigFloat("fp_offset_y", d.fpOffsetY);
    g_set.fpOffsetZ = ConfigFloat("fp_offset_z", d.fpOffsetZ);
    g_set.fpSmooth = ConfigFloat("fp_smooth", d.fpSmooth);
    g_set.fpHideBody = ConfigBool("fp_hide_body", d.fpHideBody);
    g_set.fpMaxDistance = ConfigFloat("fp_max_distance", d.fpMaxDistance);
    g_cam.firstPerson = g_set.firstPerson;
    g_set.stabilize = ConfigFloat("camera_stabilize", d.stabilize);
    g_set.settle = ConfigFloat("camera_settle", d.settle);
    g_set.nearClip = ConfigFloat("near_clip", d.nearClip);
    g_set.maxFrameLatency = ConfigInt("max_frame_latency", d.maxFrameLatency);
    g_set.fovMode = ConfigStr("fov_mode", d.fovMode.c_str());
    g_set.fovInner = ConfigFloat("fov_inner", d.fovInner);
    g_set.fovOuter = ConfigFloat("fov_outer", d.fovOuter);
    g_set.fovWide = ConfigFloat("fov_wide", d.fovWide);
    g_set.fovDebug = ConfigBool("fov_debug", d.fovDebug);
    g_set.uiMode = ConfigStr("ui_mode", d.uiMode.c_str());
    g_set.uiScale = ConfigFloat("ui_scale", d.uiScale);
    g_set.uiPick = ConfigInt("ui_pick", 0); if (g_set.uiPick < 0 || g_set.uiPick > 16) g_set.uiPick = 0;
    g_set.uiPickSig = ConfigStr("ui_pick_sig", "");
    g_set.uiLayers = ConfigStr("ui_layers", d.uiLayers.c_str()); if (g_set.uiLayers != "one") g_set.uiLayers = "all";
    g_set.uiDepth = ConfigFloat("ui_depth", d.uiDepth);
    g_set.uiOffsetY = ConfigFloat("ui_offset_y", d.uiOffsetY);
    g_set.hudSplit = ConfigStr("hud_split", d.hudSplit.c_str());
    g_set.hudSceneDraws = ConfigInt("hud_scene_draws", d.hudSceneDraws);
    g_set.hideHud = ConfigBool("hide_hud", d.hideHud);
    g_set.dofOff = ConfigBool("dof_off", d.dofOff);
    g_set.motionBlurOff = ConfigBool("motion_blur_off", d.motionBlurOff);
    g_set.radialBlurOff = ConfigBool("radial_blur_off", d.radialBlurOff);
    g_set.filmGrainOff = ConfigBool("film_grain_off", d.filmGrainOff);
    g_set.noBlackBars = ConfigBool("no_black_bars", d.noBlackBars);
    g_set.runInBackground = ConfigBool("run_in_background", d.runInBackground);
    g_set.fpsLimit = ConfigStr("fps_limit", d.fpsLimit.c_str());
    if (g_set.fpsLimit != "headset") g_set.fpsLimit = "0";
    g_set.fpsUnlocked = ConfigBool("fps_unlocked", d.fpsUnlocked);
    g_set.headsetHz = ConfigFloat("headset_refresh_hz", d.headsetHz);
    g_set.smoothing = ConfigStr("headset_smoothing", d.smoothing.c_str());
    g_set.pacedTimeoutMs = ConfigInt("paced_timeout_ms", d.pacedTimeoutMs);
    g_set.vsyncOff = ConfigBool("vsync_off", d.vsyncOff);
    g_set.sharpen = ConfigFloat("sharpen", d.sharpen);
    g_set.hdrInput = ConfigStr("hdr_input", d.hdrInput.c_str());
    g_set.hdrNits = ConfigFloat("hdr_paper_white", d.hdrNits);
    g_set.mirror = ConfigStr("mirror", d.mirror.c_str());
    g_set.screenDistance = ConfigFloat("screen_distance", d.screenDistance);
    g_set.screenWidth = ConfigFloat("screen_width", d.screenWidth);
    g_set.menuWidth = ConfigFloat("menu_width", d.menuWidth);
    g_set.menuDistance = ConfigFloat("menu_distance", d.menuDistance);
    g_set.menuPanelWidth = ConfigFloat("menu_panel_width", d.menuPanelWidth);
    g_set.recenterKey = ConfigStr("recenter_key", d.recenterKey.c_str());
    g_set.screenshotKey = ConfigStr("screenshot_key", d.screenshotKey.c_str());
    g_set.fpKey = ConfigStr("fp_key", d.fpKey.c_str());
    g_set.screenshotView = ConfigStr("screenshot_view", d.screenshotView.c_str());
}

// "+0+1+2": for right, up, back: sign and row of the node matrix
static void ParseAxes(const std::string& s) {
    int row[3]; float sg[3]; size_t i = 0; int k = 0;
    while (k < 3 && i + 1 < s.size()) {
        char c = s[i], r = s[i + 1];
        if ((c != '+' && c != '-') || r < '0' || r > '2') break;
        sg[k] = c == '-' ? -1.f : 1.f; row[k] = r - '0'; k++; i += 2;
    }
    if (k == 3 && row[0] != row[1] && row[1] != row[2] && row[0] != row[2]) {
        for (int j = 0; j < 3; j++) { g_cam.axisRow[j] = row[j]; g_cam.axisSign[j] = sg[j]; }
    } else LOGW("camera_axes '%s' invalid - using +0+1+2", s.c_str());
}

void SettingsApplyCamera() {
    g_cam.worldScale = g_set.worldScale < 0.05f ? 0.05f : g_set.worldScale;
    g_cam.unitsPerMetre = g_set.unitsPerMetre > 0.f ? g_set.unitsPerMetre : 1.f;
    g_cam.ipdScale = g_set.ipdScale < 0.f ? 0.f : g_set.ipdScale > 3.f ? 3.f : g_set.ipdScale;
    g_cam.decoupledPitch = g_set.decoupledPitch;
    g_cam.stabilize = g_set.stabilize < 0.f ? 0.f : g_set.stabilize > 1.f ? 1.f : g_set.stabilize;
    g_cam.settle = g_set.settle < 0.f ? 0.f : g_set.settle > 1.f ? 1.f : g_set.settle;
    g_cam.nearClip = g_set.nearClip < 0.f ? 0.f : g_set.nearClip > 1.f ? 1.f : g_set.nearClip;
    g_cam.camOffset[0] = g_set.camOffsetX; g_cam.camOffset[1] = g_set.camOffsetY; g_cam.camOffset[2] = g_set.camOffsetZ;
    {
        auto cl = [](float v, float a, float b) { return v < a ? a : v > b ? b : v; };
        g_cam.fpOffset[0] = cl(g_set.fpOffsetX, -1.f, 1.f); g_cam.fpOffset[1] = cl(g_set.fpOffsetY, -1.f, 1.f); g_cam.fpOffset[2] = cl(g_set.fpOffsetZ, -1.f, 1.f);
        g_cam.fpSmooth = cl(g_set.fpSmooth, 0.f, 1.f);
        g_cam.fpHideBody = g_set.fpHideBody;
        g_cam.fpMaxDist = cl(g_set.fpMaxDistance, 1.f, 50.f);
    }
    ParseAxes(g_set.cameraAxes);
    g_cam.cullMargin = g_set.cullMargin < 1.f ? 1.f : g_set.cullMargin > 2.f ? 2.f : g_set.cullMargin;
    g_cam.swapEyes = g_set.swapEyes;
    g_cam.frameDelay = g_set.frameDelay < 0 ? 0 : g_set.frameDelay > 2 ? 2 : g_set.frameDelay;
    g_cam.cameraReprojection = g_set.cameraReprojection;
    g_cam.syncPairSubmit = g_set.syncSubmit != "each";
    g_cam.syncLag = g_set.syncLag < -1 ? -1 : g_set.syncLag > 2 ? 2 : g_set.syncLag;
    g_cam.reconCentre = g_set.reconEye == "centre";
    g_cam.reconAlternate = g_set.reconEye == "alternate";
    g_cam.reconShared = g_set.reconShared;
    g_cam.symmetricView = g_set.symmetricView;
    g_cam.wideCull = g_set.wideCull;
    g_cam.flatMenus = g_set.flatPauseMenus;
    g_cam.flatVideos = g_set.flatVideos;
    g_cam.flatVideoMinW = (unsigned)(g_set.flatVideoMinWidth < 320 ? 320 : g_set.flatVideoMinWidth > 8192 ? 8192 : g_set.flatVideoMinWidth);
    CameraUpdateFrustum();
    UiSplitSet();
}

void SettingsApplyGame() {
    { extern void PostFxApply(); PostFxApply(); }
    game::ApplyNoBlackBars(g_set.noBlackBars);
    game::ApplyExactRenderSize(g_set.exactRenderSize);
    game::ApplyRunInBackground(g_set.runInBackground);
    if (game::HudFlagFound()) { static int last = -1; if (last != (int)g_set.hideHud) { if (last >= 0 || g_set.hideHud) game::SetHudHidden(g_set.hideHud); last = g_set.hideHud; } }
}

void SettingsApply() {
    SettingsApplyCamera();
    XrSetMode(ModeFromString(g_set.vrMode));
    xrb::ClientSetHud(g_set.menuDistance, g_set.menuPanelWidth, -0.05f, true);
    xrb::ClientSetMenu(g_set.screenDistance, g_set.screenWidth);
    xrb::ClientSetPanelMode(g_set.panelLayers == "quad" ? 1 : g_set.panelLayers == "composite" ? 2 : 0);
    SmoothingSet(g_set.smoothing);   // only acts on a change
}

void MenuNoteFps(float fps) { g_fps = fps; }

// every offset slider moves by offset_step_cm per press
static void OffsetStepApply(vrkit::Options& o) {
    float st = g_set.offsetStepCm * 0.01f;
    for (auto& op : o.All())
        if (op.key == "camera_offset_x" || op.key == "camera_offset_y" || op.key == "camera_offset_z" ||
            op.key == "fp_offset_x" || op.key == "fp_offset_y" || op.key == "fp_offset_z") op.step = st;
}
// 0.6.9: five tabs, each in a fixed order - the most used first; settings that belong to one stereo method are only
// shown while that method is selected (the View tab held 30 rows of every method's settings mixed together)
static void OrganisePages(vrkit::Options& o) {
    struct M { const char* key; const char* tab; const char* only; const char* group; };   // only: shown with this vr_mode only ("" = always)
    static const M map[] = {
        // View
        { "vr_mode", "View", "", "Stereo" }, { "world_scale", "View", "", "Stereo" }, { "ipd_scale", "View", "", "Stereo" }, { "swap_eyes", "View", "", "Stereo" },
        { "recon_parallax", "View", "recon", "Reconstruction" }, { "recon_gap_reach", "View", "recon", "Reconstruction" },
        { "sync_submit", "View", "synced", "Synchronized" }, { "camera_reprojection", "View", "aer|synced", "Alternate eye / synchronized" },
        { "aer_frame_delay", "View", "aer", "Alternate eye / synchronized" },
        { "Recenter view", "View", "", "Quick actions" }, { "First person on / off (End)", "View", "", "Quick actions" }, { "Flat screen now (F6)", "View", "", "Quick actions" },
        // Camera
        { "decoupled_pitch", "Camera", "", "Camera" }, { "camera_stabilize", "Camera", "", "Camera" }, { "camera_settle", "Camera", "", "Camera" },
        { "camera_offset_x", "Camera", "", "Camera offset" }, { "camera_offset_y", "Camera", "", "Camera offset" }, { "camera_offset_z", "Camera", "", "Camera offset" },
        { "Reset camera", "Camera", "", "Camera offset" },
        { "first_person", "Camera", "", "First person" }, { "fp_offset_x", "Camera", "", "First person" }, { "fp_offset_y", "Camera", "", "First person" },
        { "fp_offset_z", "Camera", "", "First person" }, { "fp_smooth", "Camera", "", "First person" }, { "fp_hide_body", "Camera", "", "First person" },
        { "fp_max_distance", "Camera", "", "First person" }, { "Reset first person", "Camera", "", "First person" },
        // HUD
        { "ui_mode", "HUD", "", "HUD" }, { "ui_scale", "HUD", "", "HUD" }, { "ui_depth", "HUD", "", "HUD" }, { "ui_offset_y", "HUD", "", "HUD" }, { "hide_hud", "HUD", "", "HUD" },
        { "ui_pick", "HUD", "", "Which UI is scaled" }, { "ui_pick_sig", "HUD", "", "Which UI is scaled" },
        // Graphics
        { "game_aa", "Graphics", "", "Game effects" }, { "game_upscaling", "Graphics", "", "Game effects" }, { "dof_off", "Graphics", "", "Game effects" },
        { "motion_blur_off", "Graphics", "", "Game effects" }, { "radial_blur_off", "Graphics", "", "Game effects" }, { "film_grain_off", "Graphics", "", "Game effects" },
        { "sharpen", "Graphics", "", "Game effects" },
        { "render_scale", "Graphics", "", "Resolution and speed" }, { "no_black_bars", "Graphics", "", "Resolution and speed" },
        // Screen
        { "edge_fill", "Screen", "", "Flat screen" }, { "flat_pause_menus", "Screen", "", "Flat screen" }, { "flat_videos", "Screen", "", "Flat screen" },
        { "screen_distance", "Screen", "", "Flat screen" }, { "screen_width", "Screen", "", "Flat screen" },
        { "menu_distance", "Screen", "", "Panels" }, { "menu_panel_width", "Screen", "", "Panels" }, { "menu_width", "Screen", "", "Panels" },
        { "mirror", "Screen", "", "Desktop window" }, { "vsync_off", "Screen", "", "Desktop window" }, { "hdr_input", "Screen", "", "Desktop window" },
        { "screenshot_view", "Screen", "", "Desktop window" },
        { "skip_launcher", "Screen", "", "Start-up" }, { "force_windowed", "Screen", "", "Start-up" }, { "run_in_background", "Screen", "", "Start-up" },
        // 0.6.16 Advanced: set once / rarely touched - foveated rendering first
        { "fps_unlocked", "Advanced", "", "Frame rate" }, { "fps_limit", "Advanced", "", "Frame rate" }, { "headset_refresh_hz", "Advanced", "", "Frame rate" },
        { "fov_mode", "Advanced", "", "Foveated rendering" }, { "fov_inner", "Advanced", "", "Foveated rendering" }, { "fov_outer", "Advanced", "", "Foveated rendering" },
        { "fov_wide", "Advanced", "", "Foveated rendering" }, { "fov_debug", "Advanced", "", "Foveated rendering" },
        { "view_width", "Advanced", "", "Picture and frustum" }, { "view_height", "Advanced", "", "Picture and frustum" }, { "wide_cull", "Advanced", "", "Picture and frustum" }, { "symmetric_view", "Advanced", "", "Picture and frustum" },
        { "cull_margin", "Advanced", "", "Picture and frustum" }, { "near_clip", "Advanced", "", "Picture and frustum" }, { "units_per_metre", "Advanced", "", "Picture and frustum" },
        { "recon_depth", "Advanced", "recon", "Eye alignment" }, { "recon_align_h", "Advanced", "recon", "Eye alignment" }, { "recon_align_v", "Advanced", "recon", "Eye alignment" },
        { "recon_debug", "Advanced", "recon", "Eye alignment" }, { "aer_align_h", "Advanced", "aer|synced", "Eye alignment" }, { "aer_align_v", "Advanced", "aer|synced", "Eye alignment" },
        { "sync_lag", "Advanced", "synced", "Eye alignment" },
        { "render_resolution", "Advanced", "", "Render size and timing" }, { "render_density", "Advanced", "", "Render size and timing" },
        { "exact_render_size", "Advanced", "", "Render size and timing" }, 
        { "headset_smoothing", "Advanced", "", "Render size and timing" }, { "max_frame_latency", "Advanced", "", "Render size and timing" },
        { "ui_layers", "Advanced", "", "Fine tuning" }, { "hud_split", "Advanced", "", "Fine tuning" }, { "hud_scene_draws", "Advanced", "", "Fine tuning" },
        { "offset_step_cm", "Advanced", "", "Fine tuning" }, { "flat_video_min_width", "Advanced", "", "Fine tuning" }, { "panel_layers", "Advanced", "", "Fine tuning" },
        { "hdr_paper_white", "Advanced", "", "Fine tuning" },
    };
    static const char* order[] = { "View", "Camera", "HUD", "Graphics", "Screen", "Advanced" };
    auto& v = o.All();
    std::vector<int> idx(v.size(), 1000);
    for (size_t k = 0; k < v.size(); k++) {
        auto& op = v[k];
        if (op.page == "First person") op.page = "Camera";
        else if (op.page == "Stereo" || op.page == "Recon") op.page = "View";
        else if (op.page == "Speed") op.page = "Graphics";
        else if (op.page == "Start") op.page = "Screen";
        for (int i = 0; i < (int)(sizeof map / sizeof *map); i++) {
            const M& m = map[i];
            if (!(op.key == m.key || (op.key.empty() && op.label == m.key))) continue;
            op.page = m.tab; op.group = m.group; idx[k] = i;
            std::string only = m.only;
            if (!only.empty()) op.visible = [only] {
                size_t p = 0;
                while (p <= only.size()) { size_t q = only.find('|', p); if (q == std::string::npos) q = only.size();
                    if (only.compare(p, q - p, g_set.vrMode) == 0 && q - p == g_set.vrMode.size()) return true; p = q + 1; }
                return false;
            };
            break;
        }
    }
    auto rank = [&](const std::string& pg) { for (int i = 0; i < (int)(sizeof order / sizeof *order); i++) if (pg == order[i]) return i; return 99; };
    std::vector<int> perm(v.size()); for (size_t k = 0; k < v.size(); k++) perm[k] = (int)k;
    std::stable_sort(perm.begin(), perm.end(), [&](int a, int b) {
        int ra = rank(v[a].page), rb = rank(v[b].page);
        return ra != rb ? ra < rb : idx[a] < idx[b];
    });
    std::vector<vrkit::Option> sorted; sorted.reserve(v.size());
    for (int k : perm) sorted.push_back(std::move(v[k]));
    v = std::move(sorted);
}
static void MenuInit() {
    g_menuInit = true;
    vrkit::SetLog([](const char* m) { LOGI("vrkit: %s", m); });
    auto& o = vrkit::Options::Get();
    auto apply = [] { SettingsApply(); };
    auto cam = [] { SettingsApplyCamera(); };
    auto gameP = [] { extern void SettingsApplyGame(); SettingsApplyGame(); };

    // ---- View
    auto& m = o.AddChoice("View", "vr_mode", "Stereo method", &g_set.vrMode, { "synced", "recon", "aer", "head", "screen" },
                          "Synchronized: both eyes from the SAME game tick (UEVR's synchronized sequential) - the game clock "
                          "waits for the second eye, both eyes always match; world motion updates every second frame. "
                          "Stereo reconstruction: one eye drawn per frame, the other reconstructed from its picture and depth - "
                          "both eyes new every frame, same moment, full frame rate (small fringes around close objects). "
                          "Alternate eye: every frame is a new tick for one eye - the eyes are one tick apart. "
                          "Head: one head-tracked image. Screen: flat virtual screen. (F8 cycles them.)", apply);
    m.choiceLabels = { "Synchronized (same tick)", "Stereo reconstruction (full rate)", "Alternate eye (AER)", "Head-tracked mono", "Flat screen" };
    o.AddFloat("View", "world_scale", "World scale", &g_set.worldScale, 0.25f, 4.f, 0.05f, 2,
               "1.0 = real size. Larger values make the world look smaller (head movement moves you more).", cam);
    o.AddFloat("View", "units_per_metre", "Engine units per metre", &g_set.unitsPerMetre, 0.1f, 200.f, 0.1f, 1,
               "Calibration: how many game units are one metre. Leaning 10 cm should move the view 10 cm.", cam);
    o.AddBool("View", "flat_pause_menus", "Flat screen in pause menus", &g_set.flatPauseMenus,
              "When the game is paused (pause menu, settings, map, gear, codex ...) the game is shown on the flat virtual "
              "screen instead of in 3D. Photo mode stays 3D once you move its camera. Screens without any 3D view "
              "(title, loading) are always flat.", cam);
    o.AddBool("View", "flat_videos", "Flat screen for video cutscenes", &g_set.flatVideos,
              "Pre-rendered cutscenes (full-size Bink videos) on the flat virtual screen. Cutscenes the game renders in "
              "real time stay in 3D. Small videos (in-world screens) never switch.", cam);
    o.AddInt("View", "flat_video_min_width", "Video cutscene: minimum width", &g_set.flatVideoMinWidth, 640, 3840, 64,
             "Videos at least this wide count as cutscenes (pixels). Raise it if an in-world screen switches to flat.", cam);
    o.AddAction("View", "Flat screen now (F6)", [] { g_cam.flatHold = !g_cam.flatHold; }, "Shows the flat virtual screen until pressed again (also F6).");
    o.AddBool("View", "skip_launcher", "Skip the launcher (next start)", &g_set.skipLauncher,
              "Starts the game directly, without its Play / Options launcher window. Takes effect the next time the game starts.", [] {});
    o.AddBool("View", "force_windowed", "Always windowed (next start)", &g_set.forceWindowed,
              "The game runs windowed whatever its display setting says, so its window - and the picture - can be the "
              "headset's full per-eye resolution and shape, larger than your monitor. Nothing is changed in the game's "
              "own settings. Takes effect the next time the game starts.", [] {});
    o.AddAction("View", "Recenter view", [] { XrRequestRecenter(); }, "Puts the view and the panels in front of you (also Space / F9).");
    auto& sv = o.AddChoice("View", "screenshot_view", "Screenshot (Delete)", &g_set.screenshotView, { "headset", "full" },
                           "Delete saves the left eye as a PNG next to GoTG.exe. Headset: exactly the part of the image your "
                           "headset shows, pixel for pixel. Full: the whole rendered eye image (with its margin).", [] {});
    sv.choiceLabels = { "As the headset shows it (1:1)", "Whole eye image" };
    o.AddAction("View", "First person on / off (End)", [] { extern void FpToggleFromMenu(); FpToggleFromMenu(); },
                "Star-Lord's head instead of behind his shoulder. Settings: the First person page.");

    // ---- Stereo
    auto& ss = o.AddChoice("Stereo", "sync_submit", "Synchronized: send eyes", &g_set.syncSubmit, { "pair", "each" },
                           "Pair: the headset gets both eyes of a tick together (never mismatched). Each: every eye as soon "
                           "as it is drawn (one frame less latency for the first eye).", cam);
    ss.choiceLabels = { "As a pair", "As drawn" };
    o.AddInt("Stereo", "sync_lag", "Synchronized: clock lag", &g_set.syncLag, -1, 2, 1,
             "-1 = automatic (found from when the game camera stands still). Which game tick a picture belongs to. "
             "If the two eyes of moving characters do not match, try 0, 1 or 2.", cam);
    auto& ga = o.AddChoice("Stereo", "game_aa", "Game anti-aliasing", &g_set.gameAa, { "game", "off", "on" },
                           "Game: the mod never touches it (your in-game setting). Off / On: set through the game's own option "
                           "while this is chosen. On also turns TAA back on in the FuckTAA-patched exe: the game's shadows, "
                           "hair, reflections and ambient occlusion are made to be smoothed by TAA - without it they look "
                           "broken or missing and the picture is over-sharp. Best with stereo reconstruction (the same view "
                           "every frame); in alternate eye / synchronized TAA mixes the eyes (double image).", [] {});
    ga.choiceLabels = { "Game's setting", "Off", "On" };
    auto& gu = o.AddChoice("Stereo", "game_upscaling", "Game upscaling", &g_set.gameUpscaling, { "game", "off" },
                           "Game: the mod never touches it. Off: upscaling / dynamic resolution (DLSS, FSR) off and resolution "
                           "scale 100 % while this is chosen (native eye resolution). Nothing is saved over your settings.", [] {});
    gu.choiceLabels = { "Game's setting", "Off (native)" };
    auto& rd = o.AddChoice("Stereo", "recon_depth", "Reconstruction: depth direction", &g_set.reconDepth, { "auto", "game", "flip" },
                           "Which way the game's depth buffer runs. Auto: measured on the depth itself (the log says what it "
                           "found). If both eyes look crossed or everything looks very close, try the other fixed value.", [] {});
    rd.choiceLabels = { "Auto (measured)", "As the game says", "Turned round" };
    o.AddInt("Stereo", "recon_gap_reach", "Reconstruction: gap reach", &g_set.reconGapReach, 8, 192, 4,
             "How far (pixels at 1920 wide) a hidden area looks sideways for the surface behind it.", [] {});
    o.AddInt("Stereo", "recon_debug", "Reconstruction: show hidden areas", &g_set.reconDebug, 0, 2, 1,
             "1 = hidden areas tinted (orange stretched, blue from the last image, red nothing), 2 = picture grey and "
             "the UI in colour (checks the UI split). 0 = off.", [] {});
    o.AddBool("Stereo", "swap_eyes", "Swap eyes", &g_set.swapEyes, "Use if depth looks inside out.", cam);
    o.AddInt("Stereo", "aer_frame_delay", "Frame delay", &g_set.frameDelay, 0, 2, 1,
             "0 = automatic (a frame is shown right after the camera was set for it). If both eyes look the same "
             "or depth flickers, try 1.", cam);
    o.AddFloat("Stereo", "ipd_scale", "Eye distance x", &g_set.ipdScale, 0.f, 2.f, 0.02f, 2,
               "1.0 = your headset's IPD. Lower = less depth (world looks bigger), higher = more depth.", cam);
    o.AddBool("Stereo", "camera_reprojection", "Turn the older eye with the camera", &g_set.cameraReprojection,
              "Alternate-eye: one eye's image is a frame older. On: the host turns it by the game camera's own "
              "turning speed, so both eyes agree while you turn with the stick / mouse. Test option.", cam);
    o.AddFloat("Stereo", "recon_parallax", "Reconstruction: depth strength", &g_set.reconParallax, 0.f, 2.f, 0.05f, 2,
               "How far apart the two rebuilt eyes are (x the real eye distance). Lower it if close things look doubled, "
               "raise it for more depth. 1 = your own eye distance.", cam);
    o.AddFloat("Stereo", "recon_align_h", "Reconstruction: eye align sideways", &g_set.reconShiftH, -10.f, 10.f, 0.1f, 1,
               "Degrees each eye's picture is moved sideways (+ apart, - together). Use it if the two eyes do not line up "
               "on far away things.", cam);
    o.AddFloat("Stereo", "recon_align_v", "Reconstruction: eye align up / down", &g_set.reconShiftV, -5.f, 5.f, 0.1f, 1,
               "Degrees the left eye's picture is moved up and the right eye's down (- the other way).", cam);
    o.AddFloat("Stereo", "aer_align_h", "Eye align sideways", &g_set.aerShiftH, -10.f, 10.f, 0.1f, 1,
               "Alternate eye / synchronized: degrees each eye's picture is moved sideways (+ apart, - together).", cam);
    o.AddFloat("Stereo", "aer_align_v", "Eye align up / down", &g_set.aerShiftV, -5.f, 5.f, 0.1f, 1,
               "Alternate eye / synchronized: degrees the left eye's picture is moved up and the right eye's down.", cam);
    o.AddFloat("Stereo", "view_width", "Picture width", &g_set.viewWidth, 0.7f, 1.3f, 0.01f, 2,
               "How wide the world looks in the headset. Above 1 = narrower (more of the picture squeezed in), below 1 = "
               "wider. 1 = exactly the headset's field of view. All 3D methods.", cam);
    o.AddFloat("Stereo", "view_height", "Picture height", &g_set.viewHeight, 0.7f, 1.3f, 0.01f, 2,
               "How tall the world looks in the headset. Above 1 = flatter, below 1 = taller. 1 = the headset's own.", cam);
    o.AddBool("Screen", "edge_fill", "Edge fill", &g_set.edgeFill,
              "Where the headset sees past the game's picture (picture size / eye align / reconstruction edges), the picture's "
              "rim is stretched outward with a blur instead of black.", [] {});
    o.AddBool("Stereo", "wide_cull", "Wide culling (no pop-in at the sides)", &g_set.wideCull,
              "On (default): the game decides what to draw (and which shadows to cast) from one symmetric view that "
              "covers the eye, while the picture is drawn with the eye's own view at the headset's size - nothing pops "
              "in at the outer sides and nothing extra is rendered. Off: culling uses the eye's view (side pop-in).", [] { SettingsApplyCamera(); });
    o.AddBool("Stereo", "symmetric_view", "One symmetric view for both eyes", &g_set.symmetricView,
              "Off (default): each eye is drawn with its own off-centre view at the headset's exact size (fastest; "
              "Wide culling stops the side pop-in). On: one symmetric view covering both eyes - the render grows "
              "about 1.4x wider to keep the headset's pixel density (Pixel density = fixed: headset size, softer).", [] { SettingsApplyCamera(); extern void ResolutionFollowView(); ResolutionFollowView(); });
    o.AddFloat("Stereo", "cull_margin", "FOV / culling margin", &g_set.cullMargin, 1.f, 1.6f, 0.01f, 2,
               "Renders (and culls) this much more than the headset shows. Raise it if objects pop at the edges.", cam);

    // ---- Camera
    o.AddBool("Camera", "decoupled_pitch", "Decoupled pitch", &g_set.decoupledPitch,
              "Removes the game camera's up / down tilt (and roll): the horizon stays level and only your head pitches "
              "the view. Stick / mouse turning (yaw) still applies.", cam);
    o.AddFloat("Camera", "camera_settle", "Idle sway lock", &g_set.settle, 0.f, 1.f, 0.05f, 2,
               "Removes the game camera's small automatic movement while you stand still (third person idle drift, first "
               "person breathing / head bob): the camera only moves once the game's moves more than a little "
               "(1.0 = 2.5 degrees / 6 cm), then follows exactly. 0 = off.", [] { SettingsApplyCamera(); });
    o.AddFloat("Camera", "camera_stabilize", "Camera shake filter", &g_set.stabilize, 0.f, 1.f, 0.05f, 2,
               "Smooths the game camera's shake and bob (jumps, landings, hits) - only the fast part; walking and turning "
               "stay. 0 = off. Your own head movement is never filtered.", cam);
    o.AddFloat("Camera", "near_clip", "Near clip (m)", &g_set.nearClip, 0.f, 0.5f, 0.01f, 2,
               "How close to your eyes the game still draws. Lower it if walls, Star-Lord or objects get cut open when "
               "you lean in. 0 = the game's own (it applies only while VR frames are made).", cam);
    // the step of every offset slider (third and first person), cm per press; the vector holds the options by value,
    // so they are looked up by key when the step changes (and once after the menu is built: OffsetStepApply)
    o.AddFloat("Camera", "offset_step_cm", "Offset step (cm per press)", &g_set.offsetStepCm, 1.f, 30.f, 1.f, 0,
               "How far one press moves the camera / first-person eye offsets below. Default 3 cm.", [] { OffsetStepApply(vrkit::Options::Get()); });
    o.AddFloat("Camera", "camera_offset_x", "Camera X (right)", &g_set.camOffsetX, -9.f, 9.f, 0.03f, 2, "Metres.", cam);
    o.AddFloat("Camera", "camera_offset_y", "Camera Y (up)", &g_set.camOffsetY, -9.f, 9.f, 0.03f, 2, "Metres.", cam);
    o.AddFloat("Camera", "camera_offset_z", "Camera Z (forward)", &g_set.camOffsetZ, -15.f, 15.f, 0.03f, 2,
               "Metres. The game camera is behind Star-Lord's shoulder: forward brings you closer to him.", cam);
    o.AddAction("Camera", "Reset camera", [] {
        g_set.decoupledPitch = true; g_set.camOffsetX = g_set.camOffsetY = g_set.camOffsetZ = 0.f; SettingsApplyCamera();
    }, "Decoupled pitch on, offsets 0.");

    // ---- First person (End): the camera in Star-Lord's head. Offsets of its own - the Camera page's are third person.
    auto fpc = [] { g_cam.firstPerson = g_set.firstPerson; SettingsApplyCamera(); };
    o.AddBool("First person", "first_person", "First person (End)", &g_set.firstPerson,
              "Your view is in Star-Lord's head instead of behind his shoulder, turned with the game camera. His body is "
              "hidden (as in the game's own first-person moments). Cutscenes and scripted cameras keep the game's camera "
              "and show him again. End toggles it.", fpc);
    o.AddFloat("First person", "fp_offset_x", "Eye X (right)", &g_set.fpOffsetX, -1.5f, 1.5f, 0.03f, 2,
               "Metres from the head bone, along where the camera faces. First person only.", cam);
    o.AddFloat("First person", "fp_offset_y", "Eye Y (up)", &g_set.fpOffsetY, -1.5f, 1.5f, 0.03f, 2,
               "Metres above the head bone (its pivot sits low in the head: ~0.07 = eye height). First person only.", cam);
    o.AddFloat("First person", "fp_offset_z", "Eye Z (forward)", &g_set.fpOffsetZ, -1.5f, 1.5f, 0.03f, 2,
               "Metres in front of the head bone (~0.1 = the eyes). Raise it if you see the inside of the head. First person only.", cam);
    o.AddFloat("First person", "fp_smooth", "Head bob filter", &g_set.fpSmooth, 0.f, 1.f, 0.05f, 2,
               "Smooths the walk / run animation's head bob. Only the bob: walking and running speed are never delayed. 0 = off.", cam);
    o.AddBool("First person", "fp_hide_body", "Hide body", &g_set.fpHideBody,
              "Hides Star-Lord's body while you are in his head (the head and hair would fill the view).", cam);
    o.AddFloat("First person", "fp_max_distance", "Cutscene distance (m)", &g_set.fpMaxDistance, 2.f, 20.f, 0.5f, 1,
               "If the game camera is farther than this from the head (or not looking at him), it is a cutscene or "
               "scripted camera: first person waits and the game's camera is used.", cam);
    o.AddAction("First person", "Reset first person", [] {
        VrSettings d; g_set.fpOffsetX = d.fpOffsetX; g_set.fpOffsetY = d.fpOffsetY; g_set.fpOffsetZ = d.fpOffsetZ;
        g_set.fpSmooth = d.fpSmooth; g_set.fpHideBody = d.fpHideBody; g_set.fpMaxDistance = d.fpMaxDistance; SettingsApplyCamera();
    }, "Eye offsets, bob filter, body and cutscene distance to their defaults.");

    // ---- HUD / UI
    auto& um = o.AddChoice("HUD", "ui_mode", "UI placement", &g_set.uiMode, { "eyes", "flat" },
                           "eyes: the game's UI is moved onto each eye's centre of view, scaled and set at a fixed depth "
                           "(one sharp image). flat: kept in the middle of each eye's picture, scaled by UI scale.", cam);
    um.choiceLabels = { "In the eyes (scaled, fixed depth)", "Picture centre (scaled)" };
    um.visible = [] { return false; };   // 0.6.20: one placement (both values place the UI the same way)
    o.AddFloat("HUD", "ui_scale", "UI scale", &g_set.uiScale, 0.2f, 1.f, 0.01f, 2,
               "Size of the HUD and menus in your view: 1 = edge to edge, 0.6 = comfortable.", cam);
    { auto& ps = o.AddChoice("HUD", "ui_pick_sig", "UI element kind", &g_set.uiPickSig, {}, "", [] {}); ps.visible = [] { return false; }; }
    { auto& ul = o.AddChoice("HUD", "ui_layers", "UI layers (automatic)", &g_set.uiLayers, { "all", "one" },
                             "With the picker at 0: All = every full-screen UI layer the game draws (menus AND the gameplay HUD) is scaled; "
                             "One = only the busiest one.", [] {});
      ul.choiceLabels = { "All UI layers", "Busiest only" }; }
    o.AddInt("HUD", "ui_pick", "UI element (picker)", &g_set.uiPick, 0, 16, 1,
             "0 = automatic. 1, 2, 3 ... = each target the game draws 2D / UI into this session (the panel's status line "
             "shows how many were found). Step through them with the HUD in view until it shrinks to the UI scale - that one "
             "is the HUD. It is kept for this session and saved.", [] {});
    o.AddFloat("HUD", "ui_depth", "UI depth (m)", &g_set.uiDepth, 0.5f, 10.f, 0.1f, 1, "How far away the UI appears.", cam);
    o.AddFloat("HUD", "ui_offset_y", "UI height", &g_set.uiOffsetY, -0.3f, 0.3f, 0.01f, 2, "Moves the UI up (+) or down (-).", cam);
    auto& hs = o.AddChoice("HUD", "hud_split", "Where the UI starts", &g_set.hudSplit, { "auto", "count", "all" },
                           "auto: after the full-screen pass that puts the 3D image on screen. count: after the given number "
                           "of draws. all: every draw into the final image is UI.", cam);
    hs.choiceLabels = { "Auto", "Draw count", "Everything" };
    o.AddInt("HUD", "hud_scene_draws", "3D draws before the UI", &g_set.hudSceneDraws, 0, 8, 1, "Only for 'Draw count'.", cam);
    o.AddBool("HUD", "hide_hud", "Hide the game HUD", &g_set.hideHud, "The game's own HUD toggle (also F7).", gameP);

    // ---- Display
    auto& rr = o.AddChoice("Display", "render_resolution", "Render resolution", &g_set.renderResolution, { "auto", "game" },
                           "auto: the headset's real per-eye size x render scale (read from the VR runtime). game: the game's window size.");
    rr.choiceLabels = { "Headset (auto)", "Game setting" }; rr.needsRestart = true;
    { auto& rdn = o.AddChoice("Display", "render_density", "Pixel density", &g_set.renderDensity, { "headset", "fixed" },
                              "Headset: when the rendered view is wider than the headset's own (stereo reconstruction draws one "
                              "eye wide enough for both, a cull margin, head mode), the eye image grows with it so the part you "
                              "see keeps the headset's full resolution. Fixed: the headset's size whatever is rendered (faster, "
                              "softer).", [] {});
      rdn.choiceLabels = { "Headset's full density", "Fixed size" }; }
    o.AddFloat("Display", "render_scale", "Render scale", &g_set.renderScale, 0.3f, 1.5f, 0.05f, 2,
               "Fraction of the headset's recommended size (per eye).").needsRestart = true;
    o.AddBool("Display", "fps_unlocked", "Uncapped frame rate", &g_set.fpsUnlocked,
              "Off (default): the game runs at the headset's own refresh rate. On: no cap at all - the game runs as fast "
              "as it can, beyond the headset's refresh rate; the headset shows the newest frame each refresh.",
              [] { FpsLimitSet(g_set.fpsLimit); });
    auto& fl = o.AddChoice("Display", "fps_limit", "FPS limiter", &g_set.fpsLimit, { "headset", "0" },
                           "Headset: never more frames than the headset's own refresh rate - never the half rate a headset's "
                           "motion smoothing / ASW runs at (a reported 45 Hz on a 90 Hz headset is taken as 90). Off: no cap "
                           "in flat mode (in VR it stays at the headset's rate - use Uncapped frame rate to go beyond it).",
                           [] { FpsLimitSet(g_set.fpsLimit); });
    fl.choiceLabels = { "Headset refresh rate", "Off" };
    o.AddFloat("Display", "headset_refresh_hz", "Headset refresh rate (Hz)", &g_set.headsetHz, 0.f, 240.f, 1.f, 0,
               "0 = automatic: the headset's own refresh rate, never the half rate its motion smoothing / ASW runs at "
               "(remembered per headset). Set it only if the log shows a wrong rate.", [] {});
    auto& sm = o.AddChoice("Display", "headset_smoothing", "Headset smoothing", &g_set.smoothing, { "full", "runtime", "repeat" },
                           "None of these ever slows the game: it keeps running at the headset's full refresh rate. Full rate "
                           "(default): every headset frame gets a fresh image on time, so Smart Smoothing / Motion Smoothing / "
                           "ASW / SSW never switch on. Headset smoothing: when the game is slower than the headset, the "
                           "headset's own smoothing fills in the missing frames. Repeat: the newest frame every headset frame.", apply);
    sm.choiceLabels = { "Full rate (default)", "Headset smoothing fills in", "Repeat newest" };
    auto gameS = [] { extern void SettingsApplyGame(); SettingsApplyGame(); };
    o.AddBool("Display", "dof_off", "Depth of field off", &g_set.dofOff,
              "Depth of field (the background or foreground blurred) off everywhere - gameplay and cutscenes. In VR your "
              "eyes focus themselves; a blurred background looks like bad eyesight.", gameS);
    o.AddBool("Display", "motion_blur_off", "Motion blur off", &g_set.motionBlurOff,
              "The game's camera / object motion blur off (it smears the view when you turn your head).", gameS);
    o.AddBool("Display", "radial_blur_off", "Radial blur off", &g_set.radialBlurOff,
              "The zoom blur of sprints, dashes and hits off (uncomfortable in a headset).", gameS);
    o.AddBool("Display", "film_grain_off", "Film grain off", &g_set.filmGrainOff, "The film grain overlay off.", gameS);
    o.AddFloat("Display", "sharpen", "Sharpening", &g_set.sharpen, 0.f, 2.f, 0.05f, 2, "Sharpens the 3D image. 0 = off.");
    auto& hd = o.AddChoice("Display", "hdr_input", "HDR input", &g_set.hdrInput, { "auto", "off", "pq", "scrgb" },
                           "The game's HDR output is converted for the headset (8-bit SDR). Better: HDR off in the game.");
    hd.choiceLabels = { "Auto", "SDR", "HDR10 (PQ)", "scRGB" };
    o.AddFloat("Display", "hdr_paper_white", "HDR paper white (nits)", &g_set.hdrNits, 80.f, 500.f, 10.f, 0, "HDR input only.");
    auto& mi = o.AddChoice("Display", "mirror", "Monitor shows", &g_set.mirror, { "left", "game" },
                           "left: the left eye (no flicker). game: what the game draws (alternates between the eyes).");
    mi.choiceLabels = { "Left eye", "Both (alternating)" };
    o.AddInt("Display", "max_frame_latency", "Frames queued ahead", &g_set.maxFrameLatency, 0, 4, 1,
             "Frames the CPU may prepare before the GPU shows them: 1-2 = the freshest head pose in each frame. 0 = the "
             "game's own. Only if the game's swap chain allows it (the log says).").needsRestart = true;
    o.AddBool("Display", "vsync_off", "No vsync on the monitor", &g_set.vsyncOff, "The monitor's refresh rate does not cap VR frames.");
    o.AddBool("Display", "exact_render_size", "Exact render size", &g_set.exactRenderSize,
              "The game rounds its internal render size down to a multiple of 64 px and scales it up (3420x2668 -> 3392x2624). "
              "On: rendered at exactly the headset's size (the FuckTAA resolution fix, done in memory - the exe is not changed).",
              [] { SettingsApplyGame(); });
    o.AddBool("Display", "no_black_bars", "No cutscene black bars", &g_set.noBlackBars,
              "Cutscenes are letter- / pillarboxed for 16:9 - not in a headset.", gameP);
    o.AddBool("Display", "run_in_background", "Keep running without focus", &g_set.runInBackground,
              "The game pauses when its window loses focus (the headset software has it in VR). On: it keeps running.", gameP);

    // ---- Foveated (D3D12 variable rate shading)
    {
        auto toCustom = [] { if (g_set.fovMode != "off") g_set.fovMode = "custom"; };
        auto& fm = o.AddChoice("Foveated", "fov_mode", "Foveated rendering", &g_set.fovMode, { "off", "quality", "balanced", "performance", "custom" },
                               "Fixed foveated rendering: full detail around each eye's lens centre, fewer pixel-shader runs "
                               "towards the edges the lenses blur anyway. Any GPU with variable rate shading tier 2 (RTX 20+, "
                               "RX 6000+, Arc). The HUD / UI is never affected.");
        fm.choiceLabels = { "Off", "Quality", "Balanced", "Performance", "Custom" };
        o.AddFloat("Foveated", "fov_inner", "Full-detail zone", &g_set.fovInner, 0.1f, 1.5f, 0.05f, 2, "Radius in half image heights from the lens centre.", toCustom);
        o.AddFloat("Foveated", "fov_outer", "Reduced zone ends at", &g_set.fovOuter, 0.2f, 2.f, 0.05f, 2, "Beyond this: the lowest rate.", toCustom);
        o.AddFloat("Foveated", "fov_wide", "Zone width", &g_set.fovWide, 0.8f, 2.f, 0.05f, 2, "Above 1 = wider than tall (wide lenses).", toCustom);
        o.AddBool("Foveated", "fov_debug", "Show the zones", &g_set.fovDebug, "The outer ring at the coarsest rate, to see where it starts.");
    }

    // ---- Screen / menu
    o.AddFloat("Screen", "screen_distance", "Screen distance", &g_set.screenDistance, 1.f, 10.f, 0.1f, 1,
               "Flat screen mode, loading screens and videos.", apply);
    o.AddFloat("Screen", "screen_width", "Screen width", &g_set.screenWidth, 1.f, 10.f, 0.1f, 1, "Metres.", apply);
    { auto& pl = o.AddChoice("Screen", "panel_layers", "Panels shown as", &g_set.panelLayers, { "auto", "composite", "quad" },
                             "How this menu, the HUD and the flat screen reach the headset. Drawn into the picture works on every "
                             "headset; separate layers are a little sharper but some runtimes (Pimax) show them black or not at "
                             "all. Auto: drawn in on Pimax, layers elsewhere.", [] { SettingsApply(); });
      pl.choiceLabels = { "Auto", "Drawn into the picture", "Separate layers" }; }
    o.AddFloat("Screen", "menu_distance", "This menu's distance", &g_set.menuDistance, 0.5f, 4.f, 0.05f, 2, "Metres (in 3D).", apply);
    o.AddFloat("Screen", "menu_panel_width", "This menu's panel width", &g_set.menuPanelWidth, 0.4f, 3.f, 0.05f, 2, "Metres (in 3D).", apply);
    o.AddFloat("Screen", "menu_width", "Menu size on the panel", &g_set.menuWidth, 0.3f, 1.f, 0.05f, 2, "Fraction of the panel.");

    vrkit::menu::Settings s;
    s.title = "Guardians of the Galaxy VR";
    s.fontPx = 26.f; s.texH = 860;   // 0.6.7: smaller text, a shorter panel, more rows per page
    s.configPath = g_gameDir + L"\\gotgvr_config.txt";
    s.statusLine = [] {
        extern UINT g_bbW, g_bbH;
        char b[160];
        extern int UiPickCount();
        int pn = UiPickCount();
        char pk[40] = ""; if (g_set.uiPick > 0) snprintf(pk, sizeof pk, "  |  UI %d/%d", g_set.uiPick, pn); else if (pn) snprintf(pk, sizeof pk, "  |  UI auto (%d found)", pn);
        snprintf(b, sizeof b, "%.0f FPS  |  %s  |  %ux%u per eye%s", g_fps,
                 g_cam.flatNow ? (g_cam.flatReason == 2 ? "FLAT (paused)" : g_cam.flatReason == 3 ? "FLAT (video)" : "FLAT (F6)") : g_cam.mode == VRMODE_SYNCED ? "SYNCED 3D" : g_cam.mode == VRMODE_RECON ? "RECON 3D" : g_cam.mode == VRMODE_STEREO ? "AER 3D" : g_cam.mode == VRMODE_HEAD ? "HEAD" : "SCREEN", g_bbW, g_bbH, pk);
        return std::string(b);
    };
    s.input.keyboardToggleVk = VK_INSERT;
    { float a = ConfigFloat("menu_opacity", 0.8f); s.backgroundAlpha = a < 0.3f ? 0.3f : a > 1.f ? 1.f : a; }
    OffsetStepApply(o);
    OrganisePages(o);
    bool ok = vrkit::menu::Init(g_dev11, g_ctx11, s);
    LOGI("menu: %s (%ux%u)", ok ? "ready - Insert or L3+R3" : "init FAILED", vrkit::menu::Width(), vrkit::menu::Height());
}

// Present thread, before the frame goes to the headset. Returns the menu texture while open.
ID3D11Texture2D* MenuUpdate() {
    if (!g_dev11 || !g_ctx11) return nullptr;
    if (!g_menuInit) MenuInit();
    if (!vrkit::menu::IsOpen()) g_set.vrMode = ModeKey(g_cam.mode);
    bool wasOpen = vrkit::menu::IsOpen();
    bool open = vrkit::menu::Update();
    if (open != wasOpen) LOGI("menu: %s", open ? "opened" : "closed");
    return open ? vrkit::menu::Texture() : nullptr;
}

void MenuSetOpen(bool open) { if (g_menuInit) vrkit::menu::SetOpen(open); }
