// Start-up: straight into the game (no launcher) and always windowed.
//
// Launcher: GOTG.exe shows its own launcher window first (ZPcLauncher, "Guardians of the Galaxy Launcher": Play /
// Options / Support). Its argument parser (exe+101E50) turns UseLauncher off for "-nolauncher" / "-NoLauncher". The
// mod adds "-nolauncher" to the process command line before the game reads it. GOTGVR's DllMain runs before the exe's
// CRT start-up, which copies the command line into argv:
//   * kernelbase GetCommandLineA / W are hooked (whoever asks later gets the new line),
//   * ucrtbase's _acmdln / _wcmdln (__p__acmdln / __p__wcmdln) are pointed at it, in case ucrtbase already took the line.
//
// Windowed: in fullscreen (exclusive, or the borderless "Fullscreen" mode) the game sizes its window and its
// rendering to the monitor. Windowed, it renders at the window's size, which the mod makes the headset's eye size -
// beyond the monitor if needed (window.cpp lifts the size limit). The game keeps its display settings in
// HKCU\Software\Eidos Montreal\Guardians of the Galaxy (DWORD values, as in Deus Ex: MD on the same engine).
// RegQueryValueExA / W and RegGetValueA / W are hooked. A read of "Fullscreen" or "ExclusiveFullscreen" under an
// "Eidos Montreal" key comes back 0, and a missing value on the first start is answered as 0 too. Nothing is written
// to the registry: without the mod the game starts the way you set it. The swap chain side (created windowed,
// exclusive fullscreen refused, Alt+Enter off) is in d3d12hooks.cpp.
#include <windows.h>
#include <winternl.h>
#include <string>
#include <cwchar>
#include <cstring>
#include "MinHook.h"
#include "log.h"
#include "settings.h"

static std::string g_cmdA; static std::wstring g_cmdW;
typedef LPSTR(WINAPI* PFN_GCLA)(); typedef LPWSTR(WINAPI* PFN_GCLW)();
static PFN_GCLA o_GetCommandLineA; static PFN_GCLW o_GetCommandLineW;
static LPSTR WINAPI H_GetCommandLineA() { return (LPSTR)g_cmdA.c_str(); }
static LPWSTR WINAPI H_GetCommandLineW() { return (LPWSTR)g_cmdW.c_str(); }

static bool HasArgW(const wchar_t* cmd, const wchar_t* arg) {
    size_t n = wcslen(arg);
    for (const wchar_t* p = cmd; *p; p++)
        if (_wcsnicmp(p, arg, n) == 0 && (p == cmd || p[-1] == L' ' || p[-1] == L'\t' || p[-1] == L'"') &&
            (p[n] == 0 || p[n] == L' ' || p[n] == L'\t' || p[n] == L'"')) return true;
    return false;
}

static void SkipLauncher() {
    const wchar_t* orig = GetCommandLineW();
    if (HasArgW(orig, L"-nolauncher")) { LOGI("startup: -nolauncher already on the command line"); return; }
    g_cmdW = std::wstring(orig) + L" -nolauncher";
    int n = WideCharToMultiByte(CP_ACP, 0, g_cmdW.c_str(), -1, nullptr, 0, nullptr, nullptr);
    g_cmdA.assign(n > 0 ? n - 1 : 0, '\0');
    if (n > 1) WideCharToMultiByte(CP_ACP, 0, g_cmdW.c_str(), -1, &g_cmdA[0], n, nullptr, nullptr);
    int hooked = 0;
    if (HMODULE kb = GetModuleHandleW(L"kernelbase.dll")) {
        void* a = (void*)GetProcAddress(kb, "GetCommandLineA"); void* w = (void*)GetProcAddress(kb, "GetCommandLineW");
        if (a && MH_CreateHook(a, (void*)H_GetCommandLineA, (void**)&o_GetCommandLineA) == MH_OK && MH_EnableHook(a) == MH_OK) hooked++;
        if (w && MH_CreateHook(w, (void*)H_GetCommandLineW, (void**)&o_GetCommandLineW) == MH_OK && MH_EnableHook(w) == MH_OK) hooked++;
    }
    int crt = 0;
    for (const wchar_t* dll : { L"ucrtbase.dll", L"msvcrt.dll" }) {   // GOTG: ucrtbase (api-ms-win-crt-runtime)
        HMODULE u = GetModuleHandleW(dll);
        if (!u) continue;
        typedef char** (__cdecl * PA)(); typedef wchar_t** (__cdecl * PW)();
        PA pa = (PA)GetProcAddress(u, "__p__acmdln"); PW pw = (PW)GetProcAddress(u, "__p__wcmdln");
        if (pa) if (char** p = pa()) { *p = (char*)g_cmdA.c_str(); crt++; }
        if (pw) if (wchar_t** p = pw()) { *p = (wchar_t*)g_cmdW.c_str(); crt++; }
        // argv already built (some CRTs build it when they load): one more argument
        typedef int* (__cdecl * PC)(); typedef char*** (__cdecl * PV)(); typedef wchar_t*** (__cdecl * PVW)();
        PC pc = (PC)GetProcAddress(u, "__p___argc"); PV pv = (PV)GetProcAddress(u, "__p___argv"); PVW pvw = (PVW)GetProcAddress(u, "__p___wargv");
        int* argc = pc ? pc() : nullptr;
        if (argc && *argc > 0 && *argc < 1000) {
            int n0 = *argc; bool grown = false;
            if (pv && pv() && *pv()) {
                char** a = (char**)HeapAlloc(GetProcessHeap(), 0, sizeof(char*) * (n0 + 2));
                memcpy(a, *pv(), sizeof(char*) * n0); a[n0] = (char*)"-nolauncher"; a[n0 + 1] = nullptr; *pv() = a; grown = true;
            }
            if (pvw && pvw() && *pvw()) {
                wchar_t** a = (wchar_t**)HeapAlloc(GetProcessHeap(), 0, sizeof(wchar_t*) * (n0 + 2));
                memcpy(a, *pvw(), sizeof(wchar_t*) * n0); a[n0] = (wchar_t*)L"-nolauncher"; a[n0 + 1] = nullptr; *pvw() = a; grown = true;
            }
            if (grown) { *argc = n0 + 1; crt++; }
        }
    }
    // the process parameters too (read directly by some runtimes, e.g. Wine / Proton build argv from them)
    bool peb = false;
    {
        PPEB pb = NtCurrentTeb()->ProcessEnvironmentBlock;
        if (pb && pb->ProcessParameters) {
            UNICODE_STRING& c = pb->ProcessParameters->CommandLine;
            c.Buffer = (PWSTR)g_cmdW.c_str(); c.Length = (USHORT)(g_cmdW.size() * 2); c.MaximumLength = (USHORT)(g_cmdW.size() * 2 + 2);
            peb = true;
        }
    }
    LOGI("startup: launcher skipped (-nolauncher added; command line hooks %d/2, CRT copies %d, process parameters %s)", hooked, crt, peb ? "yes" : "no");
}

// ---------------------------------------------------------------- registry: Fullscreen / ExclusiveFullscreen = 0
typedef LSTATUS(WINAPI* PFN_RQVW)(HKEY, LPCWSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);
typedef LSTATUS(WINAPI* PFN_RQVA)(HKEY, LPCSTR, LPDWORD, LPDWORD, LPBYTE, LPDWORD);
typedef LSTATUS(WINAPI* PFN_RGVW)(HKEY, LPCWSTR, LPCWSTR, DWORD, LPDWORD, PVOID, LPDWORD);
typedef LSTATUS(WINAPI* PFN_RGVA)(HKEY, LPCSTR, LPCSTR, DWORD, LPDWORD, PVOID, LPDWORD);
static PFN_RQVW o_RQVW; static PFN_RQVA o_RQVA; static PFN_RGVW o_RGVW; static PFN_RGVA o_RGVA;
static volatile LONG g_regOverrides = 0;

static bool IsFsName(const wchar_t* n) { return n && (!_wcsicmp(n, L"Fullscreen") || !_wcsicmp(n, L"ExclusiveFullscreen")); }
static bool IsFsNameA(const char* n) { return n && (!_stricmp(n, "Fullscreen") || !_stricmp(n, "ExclusiveFullscreen")); }

// the key's full name contains "Eidos Montreal" (NtQueryKey, KeyNameInformation)
static bool IsGameKey(HKEY k, const wchar_t* sub = nullptr) {
    if (sub && wcsstr(sub, L"Eidos Montreal")) return true;
    typedef LONG(NTAPI * PFN_NtQueryKey)(HANDLE, int, PVOID, ULONG, PULONG);
    static PFN_NtQueryKey q = (PFN_NtQueryKey)GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtQueryKey");
    if (!q || !k || ((ULONG_PTR)k >= 0x80000000ull && (ULONG_PTR)k <= 0x800000FFull)) return false;   // predefined handles
    alignas(8) unsigned char buf[1024]; ULONG got = 0;
    if (q(k, 3 /* KeyNameInformation */, buf, sizeof buf - 2, &got) < 0) return false;
    ULONG len = *(ULONG*)buf; if (len > sizeof buf - 6) len = sizeof buf - 6;
    wchar_t* name = (wchar_t*)(buf + 4); name[len / 2] = 0;
    return wcsstr(name, L"Eidos Montreal") != nullptr;
}

static void Note(const char* what, bool synth) {
    if (InterlockedIncrement(&g_regOverrides) <= 8)
        LOGI("startup: game setting %s read -> 0 (windowed)%s", what, synth ? " [not set yet]" : "");
}

// a successful DWORD read is set to 0; a missing value is answered as DWORD 0 (first start)
static LSTATUS FixDword(LSTATUS r, LPDWORD type, void* data, LPDWORD cb, const char* name) {
    if (r == ERROR_SUCCESS && type && *type == REG_DWORD && data && cb && *cb >= 4) { if (*(DWORD*)data) Note(name, false); *(DWORD*)data = 0; }
    else if (r == ERROR_SUCCESS && !type && data && cb && *cb == 4) { *(DWORD*)data = 0; Note(name, false); }
    else if (r == ERROR_FILE_NOT_FOUND && data && cb && *cb >= 4) { *(DWORD*)data = 0; *cb = 4; if (type) *type = REG_DWORD; Note(name, true); r = ERROR_SUCCESS; }
    return r;
}

static LSTATUS WINAPI H_RQVW(HKEY k, LPCWSTR n, LPDWORD res, LPDWORD type, LPBYTE data, LPDWORD cb) {
    LSTATUS r = o_RQVW(k, n, res, type, data, cb);
    if (IsFsName(n) && IsGameKey(k)) { char a[32]; WideCharToMultiByte(CP_ACP, 0, n, -1, a, 32, nullptr, nullptr); r = FixDword(r, type, data, cb, a); }
    return r;
}
static LSTATUS WINAPI H_RQVA(HKEY k, LPCSTR n, LPDWORD res, LPDWORD type, LPBYTE data, LPDWORD cb) {
    LSTATUS r = o_RQVA(k, n, res, type, data, cb);
    if (IsFsNameA(n) && IsGameKey(k)) r = FixDword(r, type, data, cb, n);
    return r;
}
static LSTATUS WINAPI H_RGVW(HKEY k, LPCWSTR sub, LPCWSTR n, DWORD fl, LPDWORD type, PVOID data, LPDWORD cb) {
    LSTATUS r = o_RGVW(k, sub, n, fl, type, data, cb);
    if (IsFsName(n) && (fl & RRF_RT_REG_DWORD) && IsGameKey(k, sub)) { char a[32]; WideCharToMultiByte(CP_ACP, 0, n, -1, a, 32, nullptr, nullptr); r = FixDword(r, type, data, cb, a); }
    return r;
}
static LSTATUS WINAPI H_RGVA(HKEY k, LPCSTR sub, LPCSTR n, DWORD fl, LPDWORD type, PVOID data, LPDWORD cb) {
    LSTATUS r = o_RGVA(k, sub, n, fl, type, data, cb);
    wchar_t ws[260] = L""; if (sub) MultiByteToWideChar(CP_ACP, 0, sub, -1, ws, 260);
    if (IsFsNameA(n) && (fl & RRF_RT_REG_DWORD) && IsGameKey(k, sub ? ws : nullptr)) r = FixDword(r, type, data, cb, n);
    return r;
}

static void ForceWindowedSettings() {
    int n = 0;
    for (const wchar_t* dll : { L"kernelbase.dll", L"advapi32.dll" }) {
        HMODULE m = LoadLibraryW(dll); if (!m) continue;
        struct { const char* name; void* h; void** o; } t[] = { { "RegQueryValueExW", (void*)H_RQVW, (void**)&o_RQVW }, { "RegQueryValueExA", (void*)H_RQVA, (void**)&o_RQVA },
                                                                 { "RegGetValueW", (void*)H_RGVW, (void**)&o_RGVW }, { "RegGetValueA", (void*)H_RGVA, (void**)&o_RGVA } };
        for (auto& e : t) {
            if (*e.o) continue;   // already hooked in kernelbase (advapi32's are forwarders to it)
            void* f = (void*)GetProcAddress(m, e.name);
            if (f && MH_CreateHook(f, e.h, e.o) == MH_OK && MH_EnableHook(f) == MH_OK) n++;
        }
    }
    LOGI("startup: windowed - the game's Fullscreen / ExclusiveFullscreen settings read as off (%d registry hooks)", n);
}

bool StartupForceWindowed() { return g_set.forceWindowed && g_set.vrMode != "screen"; }

void StartupInstall() {
    if (g_set.skipLauncher) SkipLauncher(); else LOGI("startup: launcher kept (skip_launcher = false)");
    if (StartupForceWindowed()) ForceWindowedSettings();
    else LOGI("startup: the game's own display mode is used (%s)", g_set.forceWindowed ? "screen mode" : "force_windowed = false");
}
