#pragma once
// Time for the mod's own pacing (FPS limiter, frame timing, timeouts) that a speed hack does not touch. Cheat Engine's
// speed hack (and similar tools) rewrites QueryPerformanceCounter, GetTickCount / GetTickCount64 and timeGetTime
// inside the game process, so everything the mod timed with them ran fast or slow with the game: the FPS limiter
// capped at the wrong rate, timeouts and the pause detection shrank or stretched. The interrupt-time clock
// (QueryUnbiasedInterruptTimePrecise, 100 ns units) is not one of the rewritten functions and keeps real time.
#include <windows.h>
namespace modtime {
typedef VOID(WINAPI* PFN_QITP)(PULONGLONG);
inline PFN_QITP Fn() {
    static PFN_QITP f = [] {
        PFN_QITP p = nullptr;
        if (HMODULE k = GetModuleHandleW(L"kernelbase.dll")) p = (PFN_QITP)GetProcAddress(k, "QueryUnbiasedInterruptTimePrecise");
        return p;
    }();
    return f;
}
inline ULONGLONG Now100ns() {
    if (PFN_QITP f = Fn()) { ULONGLONG t = 0; f(&t); return t; }
    ULONGLONG t = 0; QueryUnbiasedInterruptTime(&t); return t;   // coarser, still real time
}
}
inline BOOL ModQpc(LARGE_INTEGER* c) { c->QuadPart = (LONGLONG)modtime::Now100ns(); return TRUE; }
inline BOOL ModQpf(LARGE_INTEGER* f) { f->QuadPart = 10000000; return TRUE; }
inline ULONGLONG ModTick64() { return modtime::Now100ns() / 10000; }
