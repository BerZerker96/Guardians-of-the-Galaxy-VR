#include "modtime.h"
// Stereo reconstruction (vr_mode = recon).
//
// The game draws ONE eye per frame, as in alternate-eye rendering, but the headset gets BOTH eyes every frame, of the
// same moment: the other eye is reconstructed from this frame's picture and its depth. Each eye is therefore new at
// the game's full frame rate, the two eyes never show different game ticks (unlike AER) and the game clock is never
// held (unlike synchronized). Depth-based view synthesis is a well known technique (PureDark's AFW builds for UEVR /
// REFramework and the Dark Souls III native VR mod use the same family of ideas); this file is written for GOTGVR
// from scratch and shares no code with them.
//
// Inputs, all from the game's own D3D12 command lists (no shader or engine patch):
//   * scene depth: the depth target that is bound with colour targets and gets the most draws (the G-buffer depth,
//     D32F_S8 in this game). When the game moves it out of DEPTH_WRITE (its depth is complete), the mod appends to
//     that command list: depth -> buffer -> R32 texture shared with the mod's D3D11 device. Copying plane 0 through
//     a buffer footprint is legal for every depth format (D32, D32S8, D24S8, D16).
//   * the picture without UI: before the first UI draw into the final image (d3d12hooks' UI split) that target is
//     copied; the UI is later separated as "final != scene" and placed where the other eye's UI belongs.
//   * matrices: the camera hook records the drawn eye's camera, the projection the renderer really got (depth rows,
//     jitter) and the other eye's camera / frustum from the SAME head pose.
//   * shared frustum (recon_shared_frustum): the drawn eye is rendered wide enough to hold what the other eye sees,
//     so the reconstructed eye never runs out of picture at its outer edge.
// Reconstruction (D3D11 compute on the mod's own device):
//   1 forward: every depth pixel of the drawn eye -> world -> the other eye's image, the nearest kept (atomic min)
//   2 resolve: each pixel of the other eye reads its distance; where nothing landed (behind a close object) it
//     marches along the row - the direction the eyes are apart - to the nearest real surface on each side and takes
//     the deeper one (the background). With history on, those pixels come from that eye's own last real image,
//     reprojected at that depth (alternating eyes: one frame old). UI pixels are copied to the other eye's UI place.
#include "recon.h"
#include <d3dcompiler.h>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <vector>
#include "log.h"
#include "settings.h"
#include "camera.h"

extern volatile LONG g_presents;
bool UiCentreForEye(int eye, const float* tan, UINT W, UINT H, float& cx, float& cy);   // d3d12hooks.cpp
bool HeadsetEyeSize(unsigned& w, unsigned& h);   // window.cpp
bool CameraRenderSize(unsigned& w, unsigned& h);                       // camera.cpp

namespace recon {
template <class T> static void Rel(T*& p) { if (p) { p->Release(); p = nullptr; } }

typedef void(STDMETHODCALLTYPE* PFN_Barrier)(ID3D12GraphicsCommandList*, UINT, const D3D12_RESOURCE_BARRIER*);
typedef void(STDMETHODCALLTYPE* PFN_CopyRegion)(ID3D12GraphicsCommandList*, const D3D12_TEXTURE_COPY_LOCATION*, UINT, UINT, UINT, const D3D12_TEXTURE_COPY_LOCATION*, const D3D12_BOX*);
typedef void(STDMETHODCALLTYPE* PFN_CopyRes)(ID3D12GraphicsCommandList*, ID3D12Resource*, ID3D12Resource*);
static PFN_Barrier r_Barrier = nullptr; static PFN_CopyRegion r_CopyRegion = nullptr; static PFN_CopyRes r_CopyRes = nullptr;
void SetRaw(void* b, void* cr, void* c) { r_Barrier = (PFN_Barrier)b; r_CopyRegion = (PFN_CopyRegion)cr; r_CopyRes = (PFN_CopyRes)c; }

// ---------------------------------------------------------------- D3D12 copies (shared with D3D11)
static const int kSlots = 3;
struct Slot {
    ID3D12Resource* depth12 = nullptr; ID3D11Texture2D* depth11 = nullptr; ID3D11ShaderResourceView* depthSrv = nullptr;
    ID3D12Resource* scene12 = nullptr; ID3D11Texture2D* scene11 = nullptr; ID3D11ShaderResourceView* sceneSrv = nullptr;
    volatile LONG tagDepth = -1, tagScene = -1;   // g_presents when recorded (= the Present that shows that frame)
    volatile LONG depthCopies = 0;
    UINT64 needB = 0;                             // fence B value after D3D11 read this slot
};
struct Set {
    Slot s[kSlots];
    ID3D12Resource* buf = nullptr;
    D3D12_PLACED_SUBRESOURCE_FOOTPRINT fp = {};   // plane 0 of the depth as the game's format
    DXGI_FORMAT copyFmt = DXGI_FORMAT_R32_UINT; int decode = 0;   // 0 float32, 1 unorm24, 2 unorm16
    // The shared copy is an 8-bit-per-channel texture holding the depth's bytes: D3D11 cannot open D3D12 R32_UINT /
    // R16_UINT textures as shared resources on every driver (NVIDIA: E_INVALIDARG), RGBA8 / RG8 always work. The
    // shader puts the bytes back together.
    // (0.6.6: UNORM, not TYPELESS / UINT - the 0.6.5 log showed fmt 27 (RGBA8 typeless) refused with 80070057 on NVIDIA
    // too, while the RGBA8 UNORM eye ring shares fine; the shader turns each channel back into its byte exactly)
    DXGI_FORMAT shareFmt = DXGI_FORMAT_R8G8B8A8_UNORM, shareView = DXGI_FORMAT_R8G8B8A8_UNORM;
    UINT dW = 0, dH = 0; DXGI_FORMAT dFmt = DXGI_FORMAT_UNKNOWN;
    ID3D12Resource* volatile forDepth = nullptr;  // the depth these copies are for (pointer compare only)
    UINT sW = 0, sH = 0; DXGI_FORMAT sFmt = DXGI_FORMAT_UNKNOWN;   // scene copy (0 = none)
    ULONGLONG retiredAt = 0;
};
static Set* volatile g_pub = nullptr;            // read by game threads
static std::vector<Set*> g_retired;
static ID3D12Resource* volatile g_depth = nullptr;   // chosen scene depth (pointer compare only on game threads)
static volatile LONG g_depthState = -1;             // its last known state (from the game's barriers)
static volatile LONG g_depthAlive = -1;             // g_presents when the game last used it (it exists this frame)
static volatile bool g_armed = false;
static D3D12_RESOURCE_DESC g_depthDesc = {}; static bool g_depthDescOk = false;
static D3D12_RESOURCE_DESC g_sceneDesc = {}; static volatile LONG g_sceneDescNew = 0; static int g_sceneSame = 0;
static SRWLOCK g_noteLock = SRWLOCK_INIT;
static unsigned g_stSizeSkips = 0;
static unsigned g_stBarrierCopies = 0, g_stUiCopies = 0, g_stSceneCopies = 0, g_stSceneMismatch = 0, g_stNotDirect = 0;

bool Armed() { return g_armed; }
ID3D12Resource* Depth() { return g_depth; }

// depth candidates: tallied per frame
struct Cand { ID3D12Resource* r; D3D12_RESOURCE_DESC d; unsigned draws; };
static Cand g_cand[8]; static SRWLOCK g_candLock = SRWLOCK_INIT;
void TallyDepth(ID3D12Resource* r, const D3D12_RESOURCE_DESC& d, unsigned draws) {
    if (!r || !draws) return;
    AcquireSRWLockExclusive(&g_candLock);
    Cand* free = nullptr; bool done = false;
    for (auto& c : g_cand) { if (c.r == r) { c.draws += draws; c.d = d; done = true; break; } if (!c.r && !free) free = &c; }
    if (!done && free) *free = { r, d, draws };
    ReleaseSRWLockExclusive(&g_candLock);
}

static D3D12_RESOURCE_BARRIER Tr(ID3D12Resource* r, UINT sub, D3D12_RESOURCE_STATES a, D3D12_RESOURCE_STATES b) {
    D3D12_RESOURCE_BARRIER br = {}; br.Type = D3D12_RESOURCE_BARRIER_TYPE_TRANSITION;
    br.Transition.pResource = r; br.Transition.Subresource = sub; br.Transition.StateBefore = a; br.Transition.StateAfter = b;
    return br;
}
static bool Direct(ID3D12GraphicsCommandList* l) {
    if (l->GetType() == D3D12_COMMAND_LIST_TYPE_DIRECT) return true;
    g_stNotDirect++; return false;
}

// depth (state st) -> buffer -> shared R32 texture of this frame's slot
static void RecordDepth(ID3D12GraphicsCommandList* l, ID3D12Resource* r, UINT sub, D3D12_RESOURCE_STATES st) {
    Set* s = g_pub;
    if (!s || !s->buf || !r_Barrier || !r_CopyRegion || !Direct(l)) return;
    LONG p = g_presents; Slot& sl = s->s[(unsigned)p % kSlots];
    if (!sl.depth12 || r != s->forDepth) return;
    // the copy is sized for this set: never record it for a depth of another size / format (an out-of-bounds GPU copy)
    D3D12_RESOURCE_DESC rd = r->GetDesc();
    if (rd.Width != s->dW || rd.Height != s->dH || rd.Format != s->dFmt) { g_stSizeSkips++; return; }
    bool move = !(st & D3D12_RESOURCE_STATE_COPY_SOURCE) || (st & ~(D3D12_RESOURCE_STATE_COPY_SOURCE | D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE |
                 D3D12_RESOURCE_STATE_NON_PIXEL_SHADER_RESOURCE | D3D12_RESOURCE_STATE_DEPTH_READ));
    D3D12_RESOURCE_BARRIER b[3]; int n = 0;
    if (move) b[n++] = Tr(r, sub, st, D3D12_RESOURCE_STATE_COPY_SOURCE);
    b[n++] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    r_Barrier(l, n, b);
    D3D12_TEXTURE_COPY_LOCATION src = {}, dst = {};
    src.pResource = r; src.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; src.SubresourceIndex = 0;
    dst.pResource = s->buf; dst.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; dst.PlacedFootprint = s->fp;
    r_CopyRegion(l, &dst, 0, 0, 0, &src, nullptr);
    n = 0;
    if (move) b[n++] = Tr(r, sub, D3D12_RESOURCE_STATE_COPY_SOURCE, st);
    b[n++] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COPY_SOURCE);
    b[n++] = Tr(sl.depth12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
    r_Barrier(l, n, b);
    D3D12_TEXTURE_COPY_LOCATION bs = {}, td = {};
    bs.pResource = s->buf; bs.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT; bs.PlacedFootprint = s->fp; bs.PlacedFootprint.Footprint.Format = s->shareView;   // same bytes, read as RGBA8 / RG8
    td.pResource = sl.depth12; td.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX; td.SubresourceIndex = 0;
    r_CopyRegion(l, &td, 0, 0, 0, &bs, nullptr);
    b[0] = Tr(sl.depth12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
    b[1] = Tr(s->buf, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_COMMON);
    r_Barrier(l, 2, b);
    InterlockedExchange(&sl.tagDepth, p);
    InterlockedIncrement(&sl.depthCopies);
}

void NoteDepthUsed(ID3D12Resource* r) { if (r && r == g_depth) g_depthAlive = g_presents; }
void OnDepthBarrier(ID3D12GraphicsCommandList* l, ID3D12Resource* r, UINT sub, D3D12_RESOURCE_STATES before, D3D12_RESOURCE_STATES after) {
    if (r != g_depth) return;
    g_depthAlive = g_presents;
    if (sub == D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES || sub == 0) InterlockedExchange(&g_depthState, (LONG)after);
    if (!g_armed || (sub != D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES && sub != 0)) return;
    if ((before & D3D12_RESOURCE_STATE_DEPTH_WRITE) && !(after & D3D12_RESOURCE_STATE_DEPTH_WRITE) &&
        after != D3D12_RESOURCE_STATE_COMMON) {   // COMMON: end of frame / aliasing - not a read of the finished depth
        RecordDepth(l, r, sub, after); g_stBarrierCopies++;
    }
}

void OnFirstUiDraw(ID3D12GraphicsCommandList* l, ID3D12Resource* rt) {
    if (!g_armed || !rt) return;
    Set* s = g_pub;
    LONG p = g_presents;
    D3D12_RESOURCE_DESC d = rt->GetDesc();
    if (!s || !s->sW || d.Width != s->sW || d.Height != s->sH || d.Format != s->sFmt) {   // (re)created at the next Present
        // the same new target several frames running before the copies are rebuilt (a target that changes from frame
        // to frame must not rebuild them every frame)
        AcquireSRWLockExclusive(&g_noteLock);
        if (g_sceneDesc.Width == d.Width && g_sceneDesc.Height == d.Height && g_sceneDesc.Format == d.Format) g_sceneSame++;
        else { g_sceneDesc = d; g_sceneSame = 1; }
        if (g_sceneSame >= 8 || !s || !s->sW) g_sceneDescNew = 1;
        ReleaseSRWLockExclusive(&g_noteLock);
        if (s && s->sW) g_stSceneMismatch++;
    } else if (r_Barrier && r_CopyRes && Direct(l)) {
        Slot& sl = s->s[(unsigned)p % kSlots];
        D3D12_RESOURCE_BARRIER b[2] = { Tr(rt, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_RENDER_TARGET, D3D12_RESOURCE_STATE_COPY_SOURCE),
                                        Tr(sl.scene12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST) };
        r_Barrier(l, 2, b);
        r_CopyRes(l, sl.scene12, rt);
        b[0] = Tr(rt, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_SOURCE, D3D12_RESOURCE_STATE_RENDER_TARGET);
        b[1] = Tr(sl.scene12, D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES, D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_COMMON);
        r_Barrier(l, 2, b);
        InterlockedExchange(&sl.tagScene, p);
        g_stSceneCopies++;
    }
    // the depth never left DEPTH_WRITE this frame (no barrier copy): take it now, in its last known state - only if
    // the game used it this frame (a depth target freed on a resolution change must never be touched)
    // and only in a state the game's own barriers told us (a guessed state would be an invalid barrier)
    ID3D12Resource* dep = g_depth;
    LONG st = g_depthState;
    if (s && dep && st >= 0 && s->s[(unsigned)p % kSlots].tagDepth != p && g_depthAlive == p) {
        RecordDepth(l, dep, 0, (D3D12_RESOURCE_STATES)st);
        g_stUiCopies++;
    }
}

// ---------------------------------------------------------------- Present thread: depth choice, copy targets
static void FreeSet(Set* s) {
    if (!s) return;
    for (auto& sl : s->s) { Rel(sl.depthSrv); Rel(sl.depth11); Rel(sl.depth12); Rel(sl.sceneSrv); Rel(sl.scene11); Rel(sl.scene12); }
    Rel(s->buf);
    delete s;
}
static void Retire(Set* s) { if (s) { s->retiredAt = ModTick64(); g_retired.push_back(s); } }

static int DepthFamily(DXGI_FORMAT f, DXGI_FORMAT& copy) {
    switch (f) {
    case DXGI_FORMAT_D16_UNORM: case DXGI_FORMAT_R16_TYPELESS: case DXGI_FORMAT_R16_UNORM: copy = DXGI_FORMAT_R16_UINT; return 2;
    case DXGI_FORMAT_D24_UNORM_S8_UINT: case DXGI_FORMAT_R24G8_TYPELESS: case DXGI_FORMAT_R24_UNORM_X8_TYPELESS: copy = DXGI_FORMAT_R32_UINT; return 1;
    case DXGI_FORMAT_D32_FLOAT: case DXGI_FORMAT_R32_TYPELESS: case DXGI_FORMAT_R32_FLOAT: case DXGI_FORMAT_D32_FLOAT_S8X24_UINT:
    case DXGI_FORMAT_R32G8X24_TYPELESS: case DXGI_FORMAT_R32_FLOAT_X8X24_TYPELESS: copy = DXGI_FORMAT_R32_UINT; return 0;
    default: copy = DXGI_FORMAT_UNKNOWN; return -1;
    }
}
static DXGI_FORMAT SrvFmt(DXGI_FORMAT f) {
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_TYPELESS: return DXGI_FORMAT_R8G8B8A8_UNORM;
    case DXGI_FORMAT_B8G8R8A8_TYPELESS: return DXGI_FORMAT_B8G8R8A8_UNORM;
    case DXGI_FORMAT_R10G10B10A2_TYPELESS: return DXGI_FORMAT_R10G10B10A2_UNORM;
    case DXGI_FORMAT_R16G16B16A16_TYPELESS: return DXGI_FORMAT_R16G16B16A16_FLOAT;
    case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: return DXGI_FORMAT_R8G8B8A8_UNORM;   // the bytes as they are (no decode)
    case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: return DXGI_FORMAT_B8G8R8A8_UNORM;
    default: return f;
    }
}
static DXGI_FORMAT Typeless(DXGI_FORMAT f) {
    switch (f) {
    case DXGI_FORMAT_R8G8B8A8_UNORM: case DXGI_FORMAT_R8G8B8A8_UNORM_SRGB: return DXGI_FORMAT_R8G8B8A8_TYPELESS;
    case DXGI_FORMAT_B8G8R8A8_UNORM: case DXGI_FORMAT_B8G8R8A8_UNORM_SRGB: return DXGI_FORMAT_B8G8R8A8_TYPELESS;
    case DXGI_FORMAT_R10G10B10A2_UNORM: return DXGI_FORMAT_R10G10B10A2_TYPELESS;
    case DXGI_FORMAT_R16G16B16A16_FLOAT: return DXGI_FORMAT_R16G16B16A16_TYPELESS;
    default: return f;
    }
}

static bool SharedTex(ID3D12Device* d12, ID3D11Device5* d11, UINT w, UINT h, DXGI_FORMAT f, DXGI_FORMAT srvF, D3D12_RESOURCE_FLAGS fl,
                      ID3D12Resource*& r12, ID3D11Texture2D*& t11, ID3D11ShaderResourceView*& srv) {
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC rd = {}; rd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; rd.Width = w; rd.Height = h; rd.DepthOrArraySize = 1;
    rd.MipLevels = 1; rd.Format = f; rd.SampleDesc.Count = 1; rd.Flags = fl;
    HANDLE hd = nullptr;
    HRESULT hr = d12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_SHARED, &rd, D3D12_RESOURCE_STATE_COMMON, nullptr, __uuidof(ID3D12Resource), (void**)&r12);
#ifdef GOTGVR_TEST_RECON
    if (!d11) { if (FAILED(hr)) LOGE("recon: test: shared texture failed %08lx", (unsigned long)hr); return SUCCEEDED(hr); }   // D3D12 side only
#endif
    if (SUCCEEDED(hr)) hr = d12->CreateSharedHandle(r12, nullptr, GENERIC_ALL, nullptr, &hd);
    if (SUCCEEDED(hr)) hr = d11->OpenSharedResource1(hd, __uuidof(ID3D11Texture2D), (void**)&t11);
    if (hd) CloseHandle(hd);
    if (SUCCEEDED(hr)) {
        D3D11_SHADER_RESOURCE_VIEW_DESC sv = {}; sv.Format = srvF; sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
        hr = d11->CreateShaderResourceView(t11, &sv, &srv);
    }
    if (FAILED(hr)) { LOGE("recon: shared texture %ux%u fmt %d failed %08lx", w, h, (int)f, (unsigned long)hr); return false; }
    return true;
}

static Set* MakeSet(ID3D12Device* d12, ID3D11Device5* d11, ID3D12Resource* depth, const D3D12_RESOURCE_DESC& dd, const D3D12_RESOURCE_DESC* sd) {
    Set* s = new Set();
    s->forDepth = depth;
    s->decode = DepthFamily(dd.Format, s->copyFmt);
    if (s->decode == 2) { s->shareFmt = DXGI_FORMAT_R8G8_UNORM; s->shareView = DXGI_FORMAT_R8G8_UNORM; }
    if (s->decode < 0) { LOGW("recon: depth format %d not handled", (int)dd.Format); delete s; return nullptr; }
    UINT rows = 0; UINT64 rowSize = 0, total = 0;
    D3D12_RESOURCE_DESC one = dd; one.MipLevels = 1;
    d12->GetCopyableFootprints(&one, 0, 1, 0, &s->fp, &rows, &rowSize, &total);
    if (!total) { LOGE("recon: no copy footprint for the depth"); delete s; return nullptr; }
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC bd = {}; bd.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; bd.Width = total; bd.Height = 1; bd.DepthOrArraySize = 1;
    bd.MipLevels = 1; bd.SampleDesc.Count = 1; bd.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    if (FAILED(d12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &bd, D3D12_RESOURCE_STATE_COMMON, nullptr, __uuidof(ID3D12Resource), (void**)&s->buf))) {
        LOGE("recon: depth copy buffer failed"); delete s; return nullptr;
    }
    s->dW = (UINT)dd.Width; s->dH = dd.Height; s->dFmt = dd.Format;
    for (auto& sl : s->s)
        if (!SharedTex(d12, d11, s->dW, s->dH, s->shareFmt, s->shareView, D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET, sl.depth12, sl.depth11, sl.depthSrv)) { FreeSet(s); return nullptr; }
    if (sd) {
        bool ok = true;
        for (auto& sl : s->s)
            if (!SharedTex(d12, d11, (UINT)sd->Width, sd->Height, SrvFmt(sd->Format), SrvFmt(sd->Format),
                           D3D12_RESOURCE_FLAG_ALLOW_RENDER_TARGET, sl.scene12, sl.scene11, sl.sceneSrv)) { ok = false; break; }
        if (ok) { s->sW = (UINT)sd->Width; s->sH = sd->Height; s->sFmt = sd->Format; }
        else for (auto& sl : s->s) { Rel(sl.sceneSrv); Rel(sl.scene11); Rel(sl.scene12); }
    }
    LOGI("recon: depth copies %ux%u fmt %d (%s), footprint row %u; picture-without-UI copies %s", s->dW, s->dH, (int)s->dFmt,
         s->decode == 0 ? "float" : s->decode == 1 ? "24-bit" : "16-bit", s->fp.Footprint.RowPitch,
         s->sW ? "ready" : "not yet (the UI is warped with the picture)");
    return s;
}

static ID3D12Resource* g_chosen = nullptr; static unsigned g_chosenDraws = 0; static int g_chosenMiss = 0;
static UINT g_bbW = 0, g_bbH = 0;
void OnPresent(ID3D12Device* d12, ID3D11Device5* d11, UINT bbW, UINT bbH, DXGI_FORMAT) {
    g_bbW = bbW; g_bbH = bbH;
    for (size_t i = 0; i < g_retired.size();) {   // sets the game threads may still have looked at a moment ago
        if (ModTick64() - g_retired[i]->retiredAt > 3000) { FreeSet(g_retired[i]); g_retired.erase(g_retired.begin() + i); } else i++;
    }
    bool want = g_cam.mode == VRMODE_RECON && CameraFrameIsVR();
#ifdef GOTGVR_TEST_RECON
    want = g_cam.mode == VRMODE_RECON;   // test build: no headset needed
#endif
    // the scene depth: the depth target bound with colour targets that got the most draws, near the back buffer's shape
    Cand best = {}; bool chosenSeen = false;
    AcquireSRWLockExclusive(&g_candLock);
    float a = bbH ? (float)bbW / bbH : 1.f;
    for (auto& c : g_cand) {
        if (!c.r) continue;
        float ca = c.d.Height ? (float)c.d.Width / c.d.Height : 0.f;
        bool shape = fabsf(ca - a) < 0.03f * a && c.d.Width >= bbW * 3 / 10 && c.d.Width <= bbW + 64;
        if (shape && c.draws > best.draws) best = c;
        if (c.r == g_chosen) chosenSeen = true;
    }
    memset(g_cand, 0, sizeof g_cand);
    ReleaseSRWLockExclusive(&g_candLock);
    // switch: no depth yet, the current one was not drawn into this frame (released / replaced), or a clearly busier one
    if (best.r && best.r != g_chosen && (!g_chosen || !chosenSeen || best.draws > g_chosenDraws * 3 / 2)) {
        g_chosen = best.r; g_chosenMiss = 0;
        g_depth = best.r; g_depthState = -1;
        g_depthDesc = best.d; g_depthDescOk = true;
        LOGI("recon: scene depth %p %llux%u fmt %d (%u draws a frame)", (void*)best.r, (unsigned long long)best.d.Width, best.d.Height, (int)best.d.Format, best.draws);
    }
    if (best.r == g_chosen) { g_chosenDraws = best.draws; g_chosenMiss = 0; if (best.r) g_depthDesc = best.d; }
    else if (g_chosen && ++g_chosenMiss > 120) { g_chosen = nullptr; g_depth = nullptr; g_depthDescOk = false; LOGI("recon: scene depth gone"); }
    if (!want) { g_armed = false; return; }
    Set* s = g_pub;
    D3D12_RESOURCE_DESC sd = {}; bool sNew = false;
    AcquireSRWLockExclusive(&g_noteLock); if (g_sceneDescNew) { sd = g_sceneDesc; sNew = true; g_sceneDescNew = 0; } ReleaseSRWLockExclusive(&g_noteLock);
    if (g_depthDescOk) {
        bool depthChanged = !s || s->dW != g_depthDesc.Width || s->dH != g_depthDesc.Height || s->dFmt != g_depthDesc.Format;
        bool sceneChanged = sNew && (!s || s->sW != sd.Width || s->sH != sd.Height || s->sFmt != sd.Format);
        if (depthChanged || sceneChanged) {
            D3D12_RESOURCE_DESC keepScene = {}; bool haveScene = false;
            if (sNew) { keepScene = sd; haveScene = true; }
            else if (s && s->sW) { keepScene.Width = s->sW; keepScene.Height = s->sH; keepScene.Format = s->sFmt; haveScene = true; }
            Set* n = MakeSet(d12, d11, g_depth, g_depthDesc, haveScene ? &keepScene : nullptr);
            if (n) { g_pub = n; Retire(s); s = n; }
            else { static int fails = 0; if (++fails > 3) { g_depthDescOk = false; LOGE("recon: copies could not be made - the other eye keeps its last image"); } }
        } else if (s && s->forDepth != g_depth) s->forDepth = g_depth;   // a new depth of the same size: same copies
    }
    s = g_pub;
    g_armed = s && g_depth && s->forDepth == g_depth && s->dW == g_depthDesc.Width && s->dH == g_depthDesc.Height && s->dFmt == g_depthDesc.Format;
}

UINT64 NeedBForNextFrame() {
    Set* s = g_pub;
    return s ? s->s[(unsigned)(g_presents + 1) % kSlots].needB : 0;
}

// ---------------------------------------------------------------- D3D11 reconstruction
static ID3D11Device* g_dev = nullptr;
static ID3D11ComputeShader* g_csForward = nullptr, * g_csResolve = nullptr;
static ID3D11Buffer* g_cbFwd = nullptr, * g_cbRes = nullptr;
static ID3D11SamplerState* g_bilinear = nullptr;
struct Tex { ID3D11Texture2D* t = nullptr; ID3D11ShaderResourceView* srv = nullptr; ID3D11UnorderedAccessView* uav = nullptr; UINT w = 0, h = 0; DXGI_FORMAT f = DXGI_FORMAT_UNKNOWN; };
static void Drop(Tex& x) { Rel(x.uav); Rel(x.srv); Rel(x.t); x.w = x.h = 0; x.f = DXGI_FORMAT_UNKNOWN; }
static Tex g_nearest, g_result, g_history[2];
struct EyeHist { bool ok = false; float T[12]; double P[16]; LONG at = 0; };
static EyeHist g_hist[2];
static ID3D11Buffer* g_counters = nullptr; static ID3D11UnorderedAccessView* g_countersU = nullptr;
static ID3D11Buffer* g_readback[3] = {}; static bool g_rbPending[3] = {}; static int g_rbNext = 0;
struct GpuTimer { ID3D11Query* dj = nullptr, * t0 = nullptr, * t1 = nullptr; bool pending = false; };
static GpuTimer g_timers[4]; static int g_timerNext = 0; static double g_gpuMs = 0; static unsigned g_gpuN = 0;
static int g_ready = 0;   // 0 not tried, 1 ready, -1 failed
static unsigned g_made = 0, g_noDepth = 0, g_noScene = 0, g_noMatrix = 0;
static float g_pctGap = 0, g_pctHist = 0, g_pctUi = 0;
// 0.6.12: depth direction. The 0.6.11 log + screenshots: the centre view's two rebuilt eyes were turned ~20 deg apart
// (crossed), near and far alike, "gaps stretched" ~10 % in every scene - every pixel was rebuilt as if it were at the
// near plane: the depth buffer runs the other way (reversed Z / standard Z) than the projection the game hands out.
// Measured on the depth itself: at a few metres a standard-Z depth is > 0.5, a reversed-Z depth < 0.5.
static int g_flip = -1;              // -1 not known yet, 0 as the projection says, 1 turned round
static int g_flipVotes = 0; static float g_farHalf = -1.f; static bool g_projFarHigh = true; static bool g_projKnown = false;
static bool g_uiSplitOff = false; static int g_uiAll = 0; static ULONGLONG g_uiRetryAt = 0;

static const char* kHlsl = R"(
#pragma pack_matrix(row_major)
// ---- pass 1 (render size): forward-project the drawn eye's depth into the other eye, nearest distance kept
Texture2D<float4> DepthIn : register(t0);   // the depth's bytes as UNORM channels
RWTexture2D<uint> Nearest : register(u0);
RWByteAddressBuffer Counters : register(u1);
cbuffer Fwd : register(b0) { float4x4 ClipToWorld; float4x4 WorldToOther; float4 Size; float4 Fmt; };
float Depth01(float4 v) {
    uint4 b = (uint4)round(saturate(v) * 255.0);
    uint raw = (b.x & 0xFFu) | ((b.y & 0xFFu) << 8);
    if (Fmt.x < 1.5) raw |= ((b.z & 0xFFu) << 16) | ((b.w & 0xFFu) << 24);   // RGBA8 bytes of a 32-bit depth
    if (Fmt.x < 0.5) return asfloat(raw);
    if (Fmt.x < 1.5) return float(raw & 0xFFFFFF) * (1.0 / 16777215.0);
    return float(raw & 0xFFFF) * (1.0 / 65535.0);
}
// 0.6.12: Fmt.y = 1: the depth buffer uses the other depth direction than the projection the game hands out
// (reversed Z <-> standard Z) - turned round so the depth matches the matrices; Fmt.z = 1: count (1 pixel in 256)
float DepthFixed(float4 v) { float d = Depth01(v); return Fmt.y > 0.5 ? 1.0 - d : d; }
[numthreads(16, 8, 1)] void forward(uint3 t : SV_DispatchThreadID) {
    if (t.x >= (uint)Size.x || t.y >= (uint)Size.y) return;
    float2 ndc = float2((t.x + 0.5) * Size.z, (t.y + 0.5) * Size.w) * float2(2, -2) + float2(-1, 1);
    float4 raw4 = DepthIn.Load(int3(t.xy, 0));
    if (Fmt.z > 0.5 && (t.x & 15u) == 0 && (t.y & 15u) == 0) {   // which way the depth runs: far half / near half
        float d0 = Depth01(raw4); uint o;
        if (d0 > 0.0 && d0 < 1.0) { Counters.InterlockedAdd(16, 1u, o); if (d0 > 0.5) Counters.InterlockedAdd(20, 1u, o); }
    }
    float4 wp = mul(float4(ndc, DepthFixed(raw4), 1.0), ClipToWorld);
    wp *= sign(wp.w + 1e-30);                            // w >= 0; w = 0 is a direction (sky at infinity)
    float4 oc = mul(wp, WorldToOther);
    if (oc.w <= 1e-9) return;                            // behind the other eye
    float dist = wp.w > 1e-20 ? oc.w / wp.w : 1e30;
    float2 px = (oc.xy / oc.w * float2(0.5, -0.5) + 0.5) * Size.xy;
    uint key = asuint(min(dist, 1e30)); uint was;
    // a 2 x 2 footprint: the four pixels whose centres surround the point, so a source grid that is coarser than the
    // other eye's (shared frustum, canted displays) leaves no empty rows or columns
    int2 q0 = int2(floor(px - 0.5));
    [unroll] for (int j = 0; j < 4; j++) {
        int2 q = q0 + int2(j & 1, j >> 1);
        if (q.x >= 0 && q.y >= 0 && q.x < (int)Size.x && q.y < (int)Size.y) InterlockedMin(Nearest[q], key, was);
    }
}

// ---- pass 2 (eye size): every pixel of the other eye
Texture2D<uint> NearestIn : register(t0);
Texture2D<float4> Scene : register(t1);     // drawn eye, without UI
Texture2D<float4> History : register(t2);   // this eye's own last real image (without UI)
Texture2D<float4> Final : register(t3);     // drawn eye, with UI
RWTexture2D<float4> Result : register(u0);
SamplerState Bilinear : register(s0);
cbuffer Res : register(b0) { float4x4 OtherToDrawn; float4x4 OtherToHistory; float4 OutSize; float4 KeySize; float4 Z; float4 Opt; float4 UiC; };
// Z: ndc depth = Z.x + Z.y / distance, march reach (key pixels), history usable
// Opt: debug, UI split on, UI change threshold, UI scale drawn / other;  UiC: UI centre drawn (px), other (px)
static const uint NONE = 0xFFFFFFFF;
uint NearAt(int2 q) { return (q.x < 0 || q.y < 0 || q.x >= (int)KeySize.x || q.y >= (int)KeySize.y) ? NONE : NearestIn.Load(int3(q, 0)); }
float2 ClipUv(float4 c) { return c.xy / c.w * float2(0.5, -0.5) + 0.5; }
bool Inside(float2 u) { return u.x >= 0.0 && u.y >= 0.0 && u.x <= 1.0 && u.y <= 1.0; }
groupshared uint gsCount[4];
[numthreads(16, 8, 1)] void resolve(uint3 t : SV_DispatchThreadID, uint gi : SV_GroupIndex) {
    if (gi < 4) gsCount[gi] = 0;
    GroupMemoryBarrierWithGroupSync();
    bool live = t.x < (uint)OutSize.x && t.y < (uint)OutSize.y;
    int kind = 0;   // 0 seen by the drawn eye, 1 gap: background stretched, 2 gap: from history, 3 nothing
    bool isUi = false;
    if (live) {
        float2 uv = (t.xy + 0.5) * OutSize.zw;
        int2 kp = min(int2(uv * KeySize.xy), int2(KeySize.xy) - 1);
        uint key = NearAt(kp);
        bool gap = false;
        int bgDir = 0, bgDist = 0;   // 0.6.16: which side the background is on and how far its edge is (key px)
        if (key == NONE) {
            uint kl = NONE, kr = NONE; int reach = (int)Z.z, stride = max(1, (int)((uint)reach / 24u)), i = 1, firstL = 0, firstR = 0;
            [loop] for (; i <= reach && (kl == NONE || kr == NONE); i += (i < 4 ? 1 : stride)) {
                if (kl == NONE) { kl = NearAt(kp - int2(i, 0)); firstL = i; }
                if (kr == NONE) { kr = NearAt(kp + int2(i, 0)); firstR = i; }
            }
            if (kl != NONE && kr != NONE) {
                float dl = asfloat(kl), dr = asfloat(kr);
                // close on both sides at nearly the same distance: a crack in one surface, not something hidden
                bool crack = firstL + firstR <= 6 && abs(dl - dr) <= 0.03 * min(dl, dr);
                key = crack ? min(kl, kr) : max(kl, kr);   // hidden: the deeper side is the background
                gap = !crack;
                if (gap) { bgDir = kl >= kr ? -1 : 1; bgDist = kl >= kr ? firstL : firstR; }
            }
            else if (kl != NONE || kr != NONE) { key = kl != NONE ? kl : kr; gap = true; bgDir = kl != NONE ? -1 : 1; bgDist = kl != NONE ? firstL : firstR; }
            else { key = asuint(1e30); gap = true; kind = 3; }
        }
        float dist = asfloat(key);
        float4 p = float4(uv * float2(2, -2) + float2(-1, 1), dist >= 1e29 ? Z.x : Z.x + Z.y / max(dist, 1e-6), 1.0);
        float4 dc = mul(p, OtherToDrawn);
        float2 su = dc.w > 1e-9 ? ClipUv(dc) : float2(-1, -1);
        bool seen = Inside(su);
        float4 col = Scene.SampleLevel(Bilinear, saturate(su), 0);
        // 0.6.17 hole fill (after SuperDepth3D's background infill, softer): a hidden area is filled from the background
        // beyond the occluder's edge - several taps reaching further into the background (the reach grows with the
        // hole's width), each kept only when it is the same background (its depth within 15 %, or deeper), each read
        // from the drawn picture at its own depth and spread up / down; the edge tap weighs most, so the fill starts
        // as the background's own edge and fades into its blurred continuation - like the out-of-focus background the
        // other eye would see, no stretched streaks, no mirrored copies
        if (gap && bgDir != 0 && kind != 3) {
            uint sw, sh; Scene.GetDimensions(sw, sh);
            float dBg = asfloat(key);
            float step = max(1.5, (float)bgDist * 0.35);
            float spread = (1.0 + min((float)bgDist, 32.0) * 0.3) / sh;
            float4 acc = 0; float wsum = 0;
            [unroll] for (int j = 0; j < 6; j++) {
                float2 uvT = uv + float2(bgDir * ((float)bgDist + j * step) / KeySize.x, 0);
                uint kT = NearAt(int2(uvT * KeySize.xy));
                if (kT == NONE) continue;
                float dT = asfloat(kT);
                if (j > 0 && dT < dBg * 0.85) continue;   // something closer again: not this background
                float4 pT = float4(uvT * float2(2, -2) + float2(-1, 1), dT >= 1e29 ? Z.x : Z.x + Z.y / max(dT, 1e-6), 1.0);
                float4 cT = mul(pT, OtherToDrawn);
                if (cT.w <= 1e-9) continue;
                float2 s2 = ClipUv(cT);
                if (!Inside(s2)) continue;
                float w = exp(-0.45 * j);
                float oy = spread * (0.5 + 0.5 * j) * ((j & 1) ? 1.0 : -1.0);
                acc += w * 0.5 * (Scene.SampleLevel(Bilinear, saturate(s2 + float2(0, oy)), 0) +
                                  Scene.SampleLevel(Bilinear, saturate(s2 - float2(0, oy * 0.5)), 0));
                wsum += w;
            }
            if (wsum > 0) col = acc / wsum;
        }
        if (gap || !seen) {
            if (kind != 3) kind = 1;
            if (Z.w > 0.5) {
                float4 hc = mul(p, OtherToHistory);
                if (hc.w > 1e-9) { float2 hu = ClipUv(hc); if (Inside(hu)) { col = History.SampleLevel(Bilinear, hu, 0); kind = 2; } }
            }
        }
        if (Opt.y > 0.5) {   // the UI: what the UI changed in the drawn eye, at this eye's UI place (copied, never moved by depth)
            float2 dp = UiC.xy + (t.xy + 0.5 - UiC.zw) * Opt.w;
            uint fw, fh; Final.GetDimensions(fw, fh);   // dp is in the drawn picture's pixels (not this eye's)
            if (dp.x >= 0 && dp.y >= 0 && dp.x < (float)fw && dp.y < (float)fh) {
                int3 q = int3(dp, 0);
                float4 f = Final.Load(q), d4 = abs(f - Scene.Load(q));
                if (max(max(d4.r, d4.g), max(d4.b, d4.a)) > Opt.z) { col = f; isUi = true; }
            }
        }
        if (Opt.x > 0.5 && Opt.x < 1.5 && !isUi) {   // debug 1: gaps tinted - orange stretched, blue history, red nothing
            float3 tint = kind == 1 ? float3(1, 0.45, 0) : kind == 2 ? float3(0.1, 0.4, 1) : kind == 3 ? float3(1, 0, 0) : col.rgb;
            col.rgb = lerp(col.rgb, tint, 0.6);
        } else if (Opt.x > 1.5 && !isUi) {           // debug 2: picture grey, the UI in colour (checks the UI split)
            float g = dot(col.rgb, float3(0.299, 0.587, 0.114)); col.rgb = float3(g, g, g);
        }
        Result[t.xy] = col;
        uint o;
        InterlockedAdd(gsCount[0], 1u, o);
        if (kind == 1 || kind == 3) InterlockedAdd(gsCount[1], 1u, o);
        if (kind == 2) InterlockedAdd(gsCount[2], 1u, o);
        if (isUi) InterlockedAdd(gsCount[3], 1u, o);
    }
    GroupMemoryBarrierWithGroupSync();
    if (gi < 4 && gsCount[gi]) { uint o; Counters.InterlockedAdd(gi * 4, gsCount[gi], o); }
}
)";

static bool Ready(ID3D11Device* dev) {
    if (g_ready) return g_ready > 0;
    g_ready = -1; g_dev = dev;
    auto compile = [&](const char* entry, ID3D11ComputeShader** cs) {
        ID3DBlob* code = nullptr, * msg = nullptr;
        HRESULT hr = D3DCompile(kHlsl, strlen(kHlsl), "gotgvr_recon", nullptr, nullptr, entry, "cs_5_0", D3DCOMPILE_OPTIMIZATION_LEVEL3, 0, &code, &msg);
        if (FAILED(hr) || !code) { LOGE("recon: shader %s: %s", entry, msg ? (const char*)msg->GetBufferPointer() : "compile failed"); Rel(msg); return false; }
        Rel(msg);
        hr = dev->CreateComputeShader(code->GetBufferPointer(), code->GetBufferSize(), nullptr, cs);
        code->Release();
        return SUCCEEDED(hr);
    };
    if (!compile("forward", &g_csForward) || !compile("resolve", &g_csResolve)) return false;
    D3D11_BUFFER_DESC cb = {}; cb.Usage = D3D11_USAGE_DEFAULT; cb.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
    cb.ByteWidth = 160; if (FAILED(dev->CreateBuffer(&cb, nullptr, &g_cbFwd))) return false;
    cb.ByteWidth = 208; if (FAILED(dev->CreateBuffer(&cb, nullptr, &g_cbRes))) return false;
    D3D11_SAMPLER_DESC sd = {}; sd.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR; sd.MaxLOD = D3D11_FLOAT32_MAX;
    sd.AddressU = sd.AddressV = sd.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;
    if (FAILED(dev->CreateSamplerState(&sd, &g_bilinear))) return false;
    D3D11_BUFFER_DESC bd = {}; bd.ByteWidth = 32; bd.Usage = D3D11_USAGE_DEFAULT; bd.BindFlags = D3D11_BIND_UNORDERED_ACCESS;
    bd.MiscFlags = D3D11_RESOURCE_MISC_BUFFER_ALLOW_RAW_VIEWS;
    if (FAILED(dev->CreateBuffer(&bd, nullptr, &g_counters))) return false;
    D3D11_UNORDERED_ACCESS_VIEW_DESC ud = {}; ud.Format = DXGI_FORMAT_R32_TYPELESS; ud.ViewDimension = D3D11_UAV_DIMENSION_BUFFER;
    ud.Buffer.NumElements = 8; ud.Buffer.Flags = D3D11_BUFFER_UAV_FLAG_RAW;
    if (FAILED(dev->CreateUnorderedAccessView(g_counters, &ud, &g_countersU))) return false;
    bd.Usage = D3D11_USAGE_STAGING; bd.BindFlags = 0; bd.MiscFlags = 0; bd.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
    for (auto& r : g_readback) dev->CreateBuffer(&bd, nullptr, &r);
    g_ready = 1;
    LOGI("recon: shaders ready");
    return true;
}

static bool MakeTex(Tex& x, UINT w, UINT h, DXGI_FORMAT f, bool uav, const char* what) {
    if (x.t && x.w == w && x.h == h && x.f == f) return true;
    Drop(x);
    D3D11_TEXTURE2D_DESC d = {}; d.Width = w; d.Height = h; d.MipLevels = 1; d.ArraySize = 1; d.Format = Typeless(f); d.SampleDesc.Count = 1;
    d.BindFlags = D3D11_BIND_SHADER_RESOURCE | (uav ? D3D11_BIND_UNORDERED_ACCESS : 0);
    D3D11_SHADER_RESOURCE_VIEW_DESC sv = {}; sv.Format = SrvFmt(f); sv.ViewDimension = D3D11_SRV_DIMENSION_TEXTURE2D; sv.Texture2D.MipLevels = 1;
    D3D11_UNORDERED_ACCESS_VIEW_DESC uv = {}; uv.Format = SrvFmt(f); uv.ViewDimension = D3D11_UAV_DIMENSION_TEXTURE2D;
    if (FAILED(g_dev->CreateTexture2D(&d, nullptr, &x.t)) || FAILED(g_dev->CreateShaderResourceView(x.t, &sv, &x.srv)) ||
        (uav && FAILED(g_dev->CreateUnorderedAccessView(x.t, &uv, &x.uav)))) {
        LOGE("recon: %s %ux%u fmt %d failed", what, w, h, (int)f); Drop(x); return false;
    }
    x.w = w; x.h = h; x.f = f;
    LOGI("recon: %s %ux%u", what, w, h);
    return true;
}

// ---- matrices (row vectors: clip = [x y z 1] * View * Proj; node matrix rows = right, up, back, position)
static void Mul(const double* a, const double* b, double* o) {
    double t[16];
    for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { double v = 0; for (int k = 0; k < 4; k++) v += a[i * 4 + k] * b[k * 4 + j]; t[i * 4 + j] = v; }
    memcpy(o, t, sizeof t);
}
static bool Inv(const double* m, double* o) {   // Gauss-Jordan, partial pivoting
    double a[4][8];
    for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) a[i][j] = j < 4 ? m[i * 4 + j] : (j - 4 == i ? 1.0 : 0.0);
    for (int c = 0; c < 4; c++) {
        int p = c; for (int r = c + 1; r < 4; r++) if (fabs(a[r][c]) > fabs(a[p][c])) p = r;
        if (fabs(a[p][c]) < 1e-300) return false;
        if (p != c) for (int j = 0; j < 8; j++) { double t = a[c][j]; a[c][j] = a[p][j]; a[p][j] = t; }
        double d = a[c][c]; for (int j = 0; j < 8; j++) a[c][j] /= d;
        for (int r = 0; r < 4; r++) if (r != c) { double f = a[r][c]; if (f != 0) for (int j = 0; j < 8; j++) a[r][j] -= f * a[c][j]; }
    }
    for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) o[i * 4 + j] = a[i][j + 4];
    return true;
}
// world -> view of a node matrix, with the world origin moved to `o` (float precision on the GPU stays good)
static bool View(const float* T, const double* o, double* V) {
    double W[16] = { T[0], T[1], T[2], 0, T[3], T[4], T[5], 0, T[6], T[7], T[8], 0, T[9] - o[0], T[10] - o[1], T[11] - o[2], 1 };
    return Inv(W, V);
}
// the projection the renderer got (cap, drawn with frustum capTan), with frustum `tan`'s x / y terms; jit = keep the
// game's sub-pixel jitter (only what the depth was drawn with has it)
static void ProjFor(const float* cap, const float* capTan, const float* tan, bool jit, double* P) {
    for (int i = 0; i < 16; i++) P[i] = cap[i];
    double wc = capTan[1] - capTan[0], hc = capTan[2] - capTan[3];
    double jx = cap[8] - (capTan[1] + capTan[0]) / wc, jy = cap[9] - (capTan[2] + capTan[3]) / hc;
    double w = tan[1] - tan[0], h = tan[2] - tan[3];
    P[0] = 2.0 / w; P[5] = 2.0 / h; P[1] = P[4] = 0;
    P[8] = (jit ? jx : 0.0) + (tan[1] + tan[0]) / w;
    P[9] = (jit ? jy : 0.0) + (tan[2] + tan[3]) / h;
}
static void ToF(const double* d, float* f) { for (int i = 0; i < 16; i++) f[i] = (float)d[i]; }

static void Collect(ID3D11DeviceContext* c) {   // counters / timing of a few frames ago, never waiting
    for (int i = 0; i < 3; i++) {
        if (!g_rbPending[i]) continue;
        D3D11_MAPPED_SUBRESOURCE m = {};
        if (c->Map(g_readback[i], 0, D3D11_MAP_READ, D3D11_MAP_FLAG_DO_NOT_WAIT, &m) != S_OK) continue;
        const UINT* n = (const UINT*)m.pData;
        if (n[4] > 50) {
            g_farHalf = (float)n[5] / (float)n[4];
            bool depthFarHigh = g_farHalf > 0.5f;   // the scene's pixels mostly in the upper half: standard Z
            int want = g_projKnown ? (depthFarHigh != g_projFarHigh ? 1 : 0) : -1;
            if (want >= 0 && want != g_flip) {
                if (++g_flipVotes >= (g_flip < 0 ? 2 : 6)) {
                    g_flip = want; g_flipVotes = 0;
                    LOGI("recon: depth runs %s (%.0f %% of the scene in the upper half), the game's projection says %s - %s",
                         depthFarHigh ? "standard (far = 1)" : "reversed (far = 0)", g_farHalf * 100.f, g_projFarHigh ? "standard" : "reversed",
                         want ? "depth turned round to match" : "used as it is");
                }
            } else g_flipVotes = 0;
        }
        if (n[0]) {
            g_pctGap = 100.f * n[1] / n[0]; g_pctHist = 100.f * n[2] / n[0]; g_pctUi = 100.f * n[3] / n[0];
            // a pass over the whole picture after the UI split (a final colour pass) would make every pixel "UI"
            // a pass over the whole picture after the UI split (a final colour pass) makes every pixel "UI" for good; a
            // full-screen menu does it for a while. ~10 s of it: the split goes off and is tried again 20 s later.
            if (g_pctUi > 60.f) {
                if (++g_uiAll > 30 && !g_uiSplitOff) {
                    g_uiSplitOff = true; g_uiRetryAt = ModTick64() + 20000;
                    LOGW("recon: nearly the whole picture counts as UI for 10 s - UI reconstructed with the picture, split retried in 20 s");
                }
            } else g_uiAll = 0;
        }
        c->Unmap(g_readback[i], 0); g_rbPending[i] = false;
    }
    for (auto& q : g_timers) {
        if (!q.pending) continue;
        D3D11_QUERY_DATA_TIMESTAMP_DISJOINT dj = {}; UINT64 a = 0, b = 0;
        if (c->GetData(q.dj, &dj, sizeof dj, D3D11_ASYNC_GETDATA_DONOTFLUSH) != S_OK ||
            c->GetData(q.t0, &a, sizeof a, D3D11_ASYNC_GETDATA_DONOTFLUSH) != S_OK || c->GetData(q.t1, &b, sizeof b, D3D11_ASYNC_GETDATA_DONOTFLUSH) != S_OK) continue;
        q.pending = false;
        if (!dj.Disjoint && dj.Frequency && b > a) { g_gpuMs += (double)(b - a) * 1000.0 / (double)dj.Frequency; g_gpuN++; }
    }
}

static Slot* g_usedSlot = nullptr;
bool Reconstruct(ID3D11DeviceContext* c, const RenderedEye& re, ID3D11Texture2D* finalTex, ID3D11ShaderResourceView* finalSrv, ID3D11ShaderResourceView** out) {
    g_usedSlot = nullptr; *out = nullptr;
    if (!re.recon || re.mono || !re.projOk) { g_noMatrix++; return false; }
    Set* s = g_pub;
    LONG now = g_presents;
    Slot* sl = s ? &s->s[(unsigned)now % kSlots] : nullptr;
    if (!sl || sl->tagDepth != now) { g_noDepth++; return false; }
    ID3D11Device* dev = nullptr; c->GetDevice(&dev); if (!dev) return false;
    bool ok = Ready(dev); dev->Release();
    if (!ok) return false;
    D3D11_TEXTURE2D_DESC fd; finalTex->GetDesc(&fd);
    // the depth's drawn area: the camera's render size (a depth target can be padded); a depth smaller than that is
    // an upscaler's internal resolution and is used whole
    unsigned rw = 0, rh = 0;
    if (!CameraRenderSize(rw, rh)) { rw = s->dW; rh = s->dH; }
    if (s->dW < rw * 95 / 100 || s->dH < rh * 95 / 100) { rw = s->dW; rh = s->dH; }
    rw = rw > s->dW ? s->dW : rw; rh = rh > s->dH ? s->dH : rh;
    // 0.6.8: the rebuilt eye is made at its own view only (the drawn picture is wider: the shared / centre view), at
    // the drawn picture's pixel density - every pixel computed is one the headset shows
    UINT ow = fd.Width, oh = fd.Height;
    unsigned hw = 0, hh = 0;
    if (::HeadsetEyeSize(hw, hh)) { ow = hw; oh = hh; }   // 0.6.14: the rebuilt eye at the headset's own size (the drawn picture is squeezed)
    else {
        float wD = re.tanD[1] - re.tanD[0], hD = re.tanD[2] - re.tanD[3], wO = re.tanO[1] - re.tanO[0], hO = re.tanO[2] - re.tanO[3];
        if (wD > 0.05f && hD > 0.05f && wO > 0.05f && hO > 0.05f) {
            ow = (UINT)(fd.Width * (wO / wD) + 0.5f); oh = (UINT)(fd.Height * (hO / hD) + 0.5f);
            if (ow > fd.Width) ow = fd.Width; if (oh > fd.Height) oh = fd.Height;
            if (ow < 256) ow = 256; if (oh < 256) oh = 256;
            ow = (ow + 1) & ~1u; oh = (oh + 1) & ~1u;
        }
    }
    if (!MakeTex(g_nearest, rw, rh, DXGI_FORMAT_R32_UINT, true, "nearest-distance map") ||
        !MakeTex(g_result, ow, oh, DXGI_FORMAT_R16G16B16A16_FLOAT, true, "reconstructed eye")) return false;
    for (int e = 0; e < 2 && !re.centre; e++) {   // the centre view never uses an eye history (no VRAM for it)
        bool had = g_history[e].t != nullptr && g_history[e].f == fd.Format && g_history[e].w == fd.Width && g_history[e].h == fd.Height;
        if (!MakeTex(g_history[e], fd.Width, fd.Height, fd.Format, false, "eye history")) return false;
        if (!had) g_hist[e].ok = false;
    }
    bool sceneOk = sl->sceneSrv && sl->tagScene == now && s->sW == fd.Width && s->sH == fd.Height && Typeless(s->sFmt) == Typeless(fd.Format);
    if (!sceneOk) g_noScene++;
    ID3D11ShaderResourceView* sceneSrv = sceneOk ? sl->sceneSrv : finalSrv;
    ID3D11Texture2D* sceneTex = sceneOk ? sl->scene11 : finalTex;

    const int d = re.eye & 1, o = d ^ 1;
    double org[3] = { re.nodeD[9], re.nodeD[10], re.nodeD[11] };
    double Vd[16], Vo[16], Pdj[16], Pd[16], Po[16];
    if (!View(re.nodeD, org, Vd) || !View(re.nodeO, org, Vo)) { g_noMatrix++; return false; }
    ProjFor(re.proj, re.tanD, re.tanD, true, Pdj);
    ProjFor(re.proj, re.tanD, re.tanD, false, Pd);
    ProjFor(re.proj, re.tanD, re.tanO, false, Po);
    if (fabs(Po[11] + 1.0) > 1e-3 || fabs(Po[15]) > 1e-3 || fabs(Po[3]) > 1e-6 || fabs(Po[7]) > 1e-6) { g_noMatrix++; return false; }
    double VPdj[16], VPd[16], VPo[16], clipToWorld[16], otherInv[16], toDrawn[16], toHist[16];
    Mul(Vd, Pdj, VPdj); Mul(Vd, Pd, VPd); Mul(Vo, Po, VPo);
    if (!Inv(VPdj, clipToWorld) || !Inv(VPo, otherInv)) { g_noMatrix++; return false; }
    Mul(otherInv, VPd, toDrawn);
    EyeHist& h = g_hist[o];
    bool histOk = !re.centre && g_set.reconHistory && h.ok && now - h.at <= 3;   // centre view: no eye is ever drawn for real
    if (histOk) { double Vh[16], VPh[16]; if (View(h.T, org, Vh)) { Mul(Vh, h.P, VPh); Mul(otherInv, VPh, toHist); } else histOk = false; }
    if (!histOk) memcpy(toHist, toDrawn, sizeof toHist);

    // the UI: this eye's UI centre / size against the drawn eye's (the drawn eye may use the wider shared frustum)
    if (g_uiSplitOff && ModTick64() >= g_uiRetryAt) { g_uiSplitOff = false; g_uiAll = 0; LOGI("recon: UI split on again"); }
    // 0.6.12: the centre view splits the UI too - the UI the game drew into the centre picture (placed at its middle,
    // scaled) is copied flat into each rebuilt eye at that eye's UI place (ui_depth), never moved by the scene's depth
    bool uiOn = sceneOk && !g_uiSplitOff;
    float cdx = fd.Width * 0.5f, cdy = fd.Height * 0.5f, cox = cdx, coy = cdy, uiK = 1.f;
    if (uiOn && re.centre) {
        cdy = fd.Height * 0.5f - g_set.uiOffsetY * (float)fd.Height;
        UiCentreForEye(re.physEye ^ 1, re.tanO, ow, oh, cox, coy);
        uiK = 1.f;   // the rebuilt eye has the centre picture's pixel density
    } else if (uiOn) {
        UiCentreForEye(re.physEye, re.tanD, fd.Width, fd.Height, cdx, cdy);
        UiCentreForEye(re.physEye ^ 1, re.tanO, fd.Width, fd.Height, cox, coy);
        // UI pixels per UI unit: drawn image = scale x (its eye's headset width / drawn width), this image = scale
        // (its frustum is the headset's): a step of 1 pixel here is we / wd pixels in the drawn image
        float wd = re.tanD[1] - re.tanD[0], we = g_cam.eyeTan[re.physEye][1] - g_cam.eyeTan[re.physEye][0];
        if (wd > 0.05f && we > 0.05f) uiK = we / wd;
    }

    struct { float clipToWorld[16], worldToOther[16], size[4], fmt[4]; } cf;
    ToF(clipToWorld, cf.clipToWorld); ToF(VPo, cf.worldToOther);
    cf.size[0] = (float)rw; cf.size[1] = (float)rh; cf.size[2] = 1.f / rw; cf.size[3] = 1.f / rh;
    {   // which way the game's projection runs (at 5 m): standard Z gives a depth near 1 there, reversed Z near 0
        double dist = 5.0 * (g_cam.unitsPerMetre > 0.f ? g_cam.unitsPerMetre : 1.f);
        double ndc = -Pd[10] + Pd[14] / dist;
        bool farHigh = ndc > 0.5;
        if (!g_projKnown || farHigh != g_projFarHigh) {
            g_projFarHigh = farHigh; g_projKnown = true; g_flipVotes = 0;
            LOGI("recon: the game's projection: depth terms [10] %.6g [11] %.3g [14] %.6g [15] %.3g - %s Z (depth %.4f at 5 m)",
                 Pd[10], Pd[11], Pd[14], Pd[15], farHigh ? "standard" : "reversed", ndc);
        }
    }
    const std::string& dm = g_set.reconDepth;
    int flip = dm == "flip" ? 1 : dm == "game" ? 0 : (g_flip > 0 ? 1 : 0);
    cf.fmt[0] = (float)s->decode; cf.fmt[1] = (float)flip; cf.fmt[2] = 0; cf.fmt[3] = 0;
    struct { float toDrawn[16], toHist[16], outSize[4], keySize[4], z[4], opt[4], uiC[4]; } cr;
    ToF(toDrawn, cr.toDrawn); ToF(toHist, cr.toHist);
    cr.outSize[0] = (float)ow; cr.outSize[1] = (float)oh; cr.outSize[2] = 1.f / ow; cr.outSize[3] = 1.f / oh;
    cr.keySize[0] = (float)rw; cr.keySize[1] = (float)rh; cr.keySize[2] = 1.f / rw; cr.keySize[3] = 1.f / rh;
    int reach = g_set.reconGapReach < 4 ? 4 : g_set.reconGapReach > 256 ? 256 : g_set.reconGapReach;
    cr.z[0] = (float)-Po[10]; cr.z[1] = (float)Po[14]; cr.z[2] = (float)reach * rw / 1920.f + 2.f; cr.z[3] = histOk ? 1.f : 0.f;
    cr.opt[0] = (float)g_set.reconDebug; cr.opt[1] = uiOn ? 1.f : 0.f; cr.opt[2] = 1.5f / 255.f; cr.opt[3] = uiK;
    cr.uiC[0] = cdx; cr.uiC[1] = cdy; cr.uiC[2] = cox; cr.uiC[3] = coy;

    Collect(c);
    GpuTimer& q = g_timers[g_timerNext++ & 3];
    bool timed = !q.pending;
    if (timed && !q.dj) {
        D3D11_QUERY_DESC qd = { D3D11_QUERY_TIMESTAMP_DISJOINT, 0 }; g_dev->CreateQuery(&qd, &q.dj);
        qd.Query = D3D11_QUERY_TIMESTAMP; g_dev->CreateQuery(&qd, &q.t0); g_dev->CreateQuery(&qd, &q.t1);
    }
    timed = timed && q.dj && q.t0 && q.t1;
    if (timed) { c->Begin(q.dj); c->End(q.t0); }
    bool count = (g_made % 30) == 0 && !g_rbPending[g_rbNext];
    cf.fmt[2] = count ? 1.f : 0.f;
    c->UpdateSubresource(g_cbFwd, 0, nullptr, &cf, 0, 0);
    c->UpdateSubresource(g_cbRes, 0, nullptr, &cr, 0, 0);
    const UINT far4[4] = { 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu, 0xFFFFFFFFu };
    c->ClearUnorderedAccessViewUint(g_nearest.uav, far4);
    if (count) { const UINT zero[4] = {}; c->ClearUnorderedAccessViewUint(g_countersU, zero); }
    ID3D11ShaderResourceView* noSrv[4] = {}; ID3D11UnorderedAccessView* noUav[2] = {};
    c->CSSetShader(g_csForward, nullptr, 0);
    c->CSSetConstantBuffers(0, 1, &g_cbFwd);
    c->CSSetShaderResources(0, 1, &sl->depthSrv);
    { ID3D11UnorderedAccessView* fw[2] = { g_nearest.uav, g_countersU }; c->CSSetUnorderedAccessViews(0, 2, fw, nullptr); }
    c->Dispatch((rw + 15) / 16, (rh + 7) / 8, 1);
    c->CSSetUnorderedAccessViews(0, 2, noUav, nullptr);
    c->CSSetShaderResources(0, 4, noSrv);
    ID3D11ShaderResourceView* in[4] = { g_nearest.srv, sceneSrv, g_history[o].srv, finalSrv };
    ID3D11UnorderedAccessView* outs[2] = { g_result.uav, g_countersU };
    c->CSSetShader(g_csResolve, nullptr, 0);
    c->CSSetConstantBuffers(0, 1, &g_cbRes);
    c->CSSetShaderResources(0, 4, in);
    c->CSSetUnorderedAccessViews(0, 2, outs, nullptr);
    c->CSSetSamplers(0, 1, &g_bilinear);
    c->Dispatch((ow + 15) / 16, (oh + 7) / 8, 1);
    c->CSSetUnorderedAccessViews(0, 2, noUav, nullptr);
    c->CSSetShaderResources(0, 4, noSrv);
    c->CSSetShader(nullptr, nullptr, 0);
    if (timed) { c->End(q.t1); c->End(q.dj); q.pending = true; }
    if (count && g_readback[g_rbNext]) { c->CopyResource(g_readback[g_rbNext], g_counters); g_rbPending[g_rbNext] = true; g_rbNext = (g_rbNext + 1) % 3; }
    // the drawn eye's real image (without UI) becomes its history for the frame that reconstructs it
    if (!re.centre) {
        c->CopyResource(g_history[d].t, sceneTex);
        EyeHist& hd = g_hist[d];
        memcpy(hd.T, re.nodeD, sizeof hd.T); memcpy(hd.P, Pd, sizeof hd.P); hd.at = now; hd.ok = true;
    }
    g_usedSlot = sl;
    g_made++;
    *out = g_result.srv;
    return true;
}

void AfterSignal(UINT64 vB) { if (g_usedSlot) g_usedSlot->needB = vB; g_usedSlot = nullptr; }

void Report() {
    if (g_cam.mode != VRMODE_RECON) return;
    Set* s = g_pub;
    double ms = g_gpuN ? g_gpuMs / g_gpuN : 0; g_gpuMs = 0; g_gpuN = 0;
    unsigned dc = 0; if (s) for (auto& sl : s->s) dc += (unsigned)InterlockedExchange(&sl.depthCopies, 0);
    LOGI("recon: %s | reconstructed %u (%.2f ms GPU), no depth %u, no picture-without-UI %u, no matrices %u | depth copies %u (at its barrier %u, "
         "at the UI %u), picture copies %u (other size %u), copies on non-direct lists skipped %u | shared frustum %s",
         g_armed ? "running" : g_depth ? "depth known, copies not ready" : "no scene depth found yet", g_made, ms, g_noDepth, g_noScene, g_noMatrix,
         dc, g_stBarrierCopies, g_stUiCopies, g_stSceneCopies, g_stSceneMismatch, g_stNotDirect, g_cam.reconShared ? "on" : "off");
    if (g_stSizeSkips) LOGW("recon: %u depth copies skipped (depth of another size than the copies)", g_stSizeSkips);
    g_stSizeSkips = 0;
    LOGI("recon: reconstructed eye pixels: gaps stretched %.1f %%, gaps from history %.1f %%, UI %.1f %%%s",
         g_pctGap, g_pctHist, g_pctUi, g_uiSplitOff ? " (UI split off)" : "");
    g_made = g_noDepth = g_noScene = g_noMatrix = 0;
    g_stBarrierCopies = g_stUiCopies = g_stSceneCopies = g_stSceneMismatch = g_stNotDirect = 0;
}

void Release() {   // before ResizeBuffers (the compositor has waited for its last GPU work)
    g_armed = false;
    Set* s = g_pub; g_pub = nullptr; Retire(s);
    Drop(g_result); for (int e = 0; e < 2; e++) { Drop(g_history[e]); g_hist[e].ok = false; }
    g_uiSplitOff = false; g_uiAll = 0;
}
}   // namespace recon
