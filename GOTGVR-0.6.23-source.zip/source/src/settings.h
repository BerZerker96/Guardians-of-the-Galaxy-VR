#pragma once
#include <string>

// User settings edited by the in-headset menu (keys = gotgvr_config.txt keys). Carried over from DXMDVR where the
// feature exists in GOTG; the side-by-side / Scaleform / NVAPI-D3D11 specific ones are gone (see NOTES.md).
struct VrSettings {
    std::string panelLayers = "auto";        // panel_layers: auto | quad | composite (HUD, VR menu, flat screen drawn into the eye images)
    bool skipLauncher = true;                 // skip_launcher: start the game directly (adds -nolauncher)
    bool forceWindowed = true;                // force_windowed: the game always windowed (its Fullscreen settings read as off), sized to the eye
    std::string vrMode = "recon";             // vr_mode: recon (stereo reconstruction, default) | synced (same-tick 3D) | aer (alternate-eye 3D) | head | screen
    std::string syncSubmit = "pair";          // sync_submit: pair | each
    int syncLag = -1;                         // sync_lag: -1 auto | 0..2
    std::string gameAa = "game";              // game_aa: game (never touched) | off | on - the game's anti-aliasing option
    std::string gameUpscaling = "game";       // game_upscaling: game (never touched) | off (upscaling / dynamic res off, scale 100 %)
    // stereo reconstruction (vr_mode = recon): one eye drawn per frame, the other reconstructed from its picture + depth
    std::string reconEye = "centre";     // recon_eye: centre (head-centre view drawn, both eyes rebuilt) | left | alternate
    bool reconHistory = true;                 // recon_history: gaps behind close objects from that eye's last real image
    bool reconShared = true;                  // recon_shared_frustum: the drawn eye also covers the other eye's view
    std::string reconDepth = "auto";          // recon_depth: auto | game | flip (which way the depth buffer runs)
    int reconGapReach = 64;                   // recon_gap_reach: how far a gap looks sideways for a surface (px at 1920)
    int reconDebug = 0;                       // recon_debug: 1 gaps tinted, 2 picture grey / UI in colour
    // flat screen for game states without a usable 3D view (title / loading screens with no camera are always flat)
    bool flatPauseMenus = true;               // flat_pause_menus: pause menu and its screens (settings, map, gear ...)
    bool flatVideos = true;                   // flat_videos: pre-rendered (Bink) cutscenes
    int flatVideoMinWidth = 1280;             // flat_video_min_width: smaller videos (in-world screens) stay in 3D
    // render size
    std::string renderResolution = "auto";    // render_resolution: auto (headset) | WxH (per eye) | game
    std::string uiTarget = "auto";            // ui_target: auto (find the game's separate UI layer) | off
    std::string renderDensity = "headset";   // render_density: headset (the eye image grows with a wider rendered view: cull margin, reconstruction) | fixed
    float renderScale = 1.0f;                 // render_scale (x the headset's recommended per-eye size)
    std::string eyeAspect = "headset";        // eye_aspect: headset | 1:1 | 5:4 | 4:3 (per-eye width : height)
    int renderMaxSide = 8192;                 // render_max_side
    // world
    float worldScale = 1.f;                   // world_scale (1 = real size; larger = world looks smaller)
    float unitsPerMetre = 1.f;                // units_per_metre: engine world units per metre
    // stereo (alternate-eye rendering)
    bool swapEyes = false;                    // swap_eyes: depth inside out
    int frameDelay = 0;                       // aer_frame_delay: 0 = a frame is presented right after its view update; 1-2 = later
    float ipdScale = 1.f;                     // ipd_scale: 1 = the headset's IPD
    bool cameraReprojection = false;          // camera_reprojection: host rotates the older eye with the game camera
    // 0.6.13: picture fixes (View tab). Eye align: degrees each eye's picture is moved (horizontal: + = apart,
    // vertical: + = left eye up / right eye down) - for reconstruction and for alternate / synchronized separately.
    float reconShiftH = 0.f, reconShiftV = 0.f, aerShiftH = 0.f, aerShiftV = 0.f;
    float reconParallax = 1.f;                // recon_parallax: the rebuilt eyes' distance from the centre view x this
    float viewWidth = 1.f, viewHeight = 1.f;
    bool edgeFill = true;
    bool exactRenderSize = true;              // exact_render_size: the internal render size not rounded down to 64 px (in memory)                     // edge_fill: rim of the picture stretched + blurred where the eye reaches past it  // view_width / view_height: how much of the picture the headset shows
    float cullMargin = 1.0f;                  // cull_margin: rendered frustum = headset FOV x this
    // camera
    bool decoupledPitch = true;               // decoupled_pitch: horizon stays level (third-person camera tilt removed)
    float camOffsetX = 0.f, camOffsetY = 0.f, camOffsetZ = 0.f;   // camera_offset_x / _y / _z (metres: right, up, forward)
    std::string cameraAxes = "+0+1+2";
    // first person (fp_key, End): the camera in Star-Lord's head; offsets of its own (camera_offset_* = third person)
    bool firstPerson = false;                 // first_person: start in first person
    float fpOffsetX = 0.f, fpOffsetY = 0.07f, fpOffsetZ = 0.1f;   // fp_offset_x / _y / _z (metres from the head bone: right, up, forward)
    float fpSmooth = 0.6f;                    // fp_smooth: head bob filter (0 off .. 1 strong)
    bool fpHideBody = true;                   // fp_hide_body: hide the body (as the game's own first-person camera does)
    float fpMaxDistance = 6.f;                // fp_max_distance: game camera farther from the head = cutscene (first person waits)
    float nearClip = 0.f;                     // near_clip: metres, 0 = the game's own near plane (VR: lean close without clipping)
    float settle = 0.5f;                      // camera_settle: idle-sway lock (0 off .. 1 strong)
    float stabilize = 0.35f;                  // camera_stabilize: game camera shake filter (0 off .. 1 strong)        // camera_axes: rows of the node matrix that are right, up, back
    // UI
    std::string uiMode = "eyes";              // ui_mode: eyes (UI in each eye, scaled, at a fixed depth) | flat (untouched)
    float uiScale = 0.60f;                    // ui_scale: size of the game's UI in each eye (1 = edge to edge)
    float uiDepth = 2.2f;                     // ui_depth: metres the UI appears at (eyes mode)
    float uiOffsetY = 0.f;                    // ui_offset_y: + = UI higher (fraction of the eye height)
    std::string submitView = "headset";       // submit_view: headset (eye images cut to the headset view) | rendered
    float offsetStepCm = 3.f;                 // offset_step_cm: camera / first-person offset sliders, cm per press
    bool symmetricView = false;   // 0.6.17: off again - headset size and shape; the side pop-in is fixed by wide_cull instead (0.6.16 rendered 1.4x wider)
    bool wideCull = true;         // wide_cull: culling gets a symmetric frustum covering the eye, the picture keeps the eye's own
                                  // 0.6.14: the node projection is patched now - each eye gets its own asymmetric frustum
                   // symmetric_view: the engine draws a symmetric view, each eye is cut out of it
    std::string uiLayers = "one";            // ui_layers: all = every full-screen UI layer is scaled | one = the busiest only
    std::string uiPickSig;                    // ui_pick_sig: what the picked UI element is (size / format / order), kept over restarts
    int uiPick = 0;                           // ui_pick: 0 = automatic UI layer, 1..16 = that UI picker candidate is the UI
    bool ui2d = true;                         // ui_2d: draws with 2D pipelines (UI / HUD) are scaled / placed as UI
    std::string hudSplit = "auto";            // hud_split: auto | count | all
    int hudSceneDraws = 1;                    // hud_scene_draws (hud_split = count)
    bool hideHud = false;
    // post effects (postfx.cpp): depth of field is always off (gameplay and cutscenes) unless dof_off = false
    bool dofOff = true;                       // dof_off
    bool motionBlurOff = false;               // motion_blur_off
    bool radialBlurOff = false;                // radial_blur_off (sprint / dash / impact zoom blur)
    bool filmGrainOff = false;                // film_grain_off                     // hide_hud: the game's own HUD toggle (IGCS flag)
    bool noBlackBars = true;                  // no_black_bars: cutscene letterbox / pillarbox off
    bool runInBackground = true;              // run_in_background: no pause when the window loses focus
    // display / timing
    float headsetHz = 0.f;                    // headset_refresh_hz: 0 = automatic (the headset's own refresh, never a smoothing rate)
    bool fpsUnlocked = false;                 // fps_unlocked: no frame cap at all, also in VR (beyond the headset's refresh)
    std::string fpsLimit = "headset";         // fps_limit: headset | <fps> | 0
    std::string smoothing = "full";           // headset_smoothing: full (never halves) | runtime (may halve) | repeat
    int pacedTimeoutMs = 100;                 // paced_timeout_ms
    bool vsyncOff = true;                     // vsync_off: no vsync while VR frames are produced
    float sharpen = 0.f;                      // sharpen (LumaSharpen-style, 0 = off)
    std::string hdrInput = "auto";            // hdr_input: auto | off | pq | scrgb
    float hdrNits = 200.f;                    // hdr_paper_white (HDR input only)
    std::string mirror = "left";
    int maxFrameLatency = 2;                  // max_frame_latency (frames the CPU may queue; 0 = the game's)
    // fixed foveated rendering (D3D12 variable rate shading, tier 2: RTX 20+, RX 6000+, Arc)
    std::string fovMode = "off";              // fov_mode: off | quality | balanced | performance | custom
    float fovInner = 0.6f, fovOuter = 1.0f;   // fov_inner / fov_outer (half image heights from the lens centre)
    float fovWide = 1.25f;                    // fov_wide
    bool fovDebug = false;                    // fov_debug: outer zone shown at the lowest rate (to see it)              // mirror: left (monitor shows the left eye) | game (alternating)
    // screen / menu
    float screenDistance = 2.7f, screenWidth = 3.2f;
    float menuWidth = 0.8f;                   // menu_width (fraction of the panel)
    float menuDistance = 1.2f, menuPanelWidth = 1.1f;   // menu_distance / menu_panel_width (in VR frames)
    std::string recenterKey = "SPACE";
    std::string screenshotKey = "DELETE";
    std::string fpKey = "END";               // fp_key: first person on / off
    std::string screenshotView = "headset";  // screenshot_view: headset (exactly the headset's field of view, 1:1 pixels) | full (the whole rendered eye)
};
extern VrSettings g_set;
void SettingsLoad();
void SettingsApply();
void SettingsApplyCamera();
