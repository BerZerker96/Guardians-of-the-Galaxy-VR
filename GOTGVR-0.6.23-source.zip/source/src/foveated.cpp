// Fixed foveated rendering on D3D12 (variable rate shading tier 2: shading-rate images; any GPU that has it - NVIDIA
// RTX 20 and newer, AMD RX 6000 and newer, Intel Arc). DXMDVR's version was NVIDIA-only (NVAPI on D3D11).
// Every pass that renders into an eye-size target (the scene, G-buffer, lighting, post effects) gets a shading-rate
// image: full rate around the current eye's lens centre (its optical axis in the asymmetric frustum), lower rates in
// two outer rings. The final image (back buffer and what the game copies into it), so the UI, is never affected.
// One image per eye + one for head mode; rebuilt when the eye size, the frustum or the settings change.
#include "modtime.h"
#include "d3d.h"
#include <cmath>
#include <vector>
#include "log.h"
#include "camera.h"
#include "settings.h"

// D3D12 VRS declarations (not in the mingw-w64 headers). Values / layout from Microsoft's d3d12.h.
static const D3D12_FEATURE kFeatureOptions6 = (D3D12_FEATURE)30;
struct Options6 { BOOL AdditionalShadingRatesSupported; BOOL PerPrimitiveShadingRateSupportedWithViewportIndexing;
                  int VariableShadingRateTier; UINT ShadingRateImageTileSize; BOOL BackgroundProcessingSupported; };
enum : int { RATE_1X1 = 0, RATE_1X2 = 0x1, RATE_2X1 = 0x4, RATE_2X2 = 0x5, RATE_2X4 = 0x6, RATE_4X2 = 0x9, RATE_4X4 = 0xA };
enum : int { COMBINER_PASSTHROUGH = 0, COMBINER_OVERRIDE = 1 };
static const D3D12_RESOURCE_STATES kStateShadingRateSource = (D3D12_RESOURCE_STATES)0x1000000;
static const GUID kIID_List5 = { 0x55050859, 0x4024, 0x474c, { 0x87, 0xf5, 0x64, 0x72, 0xea, 0xee, 0x44, 0xea } };
// ID3D12GraphicsCommandList5 vtable: 77 RSSetShadingRate(base, const combiners[2]), 78 RSSetShadingRateImage(resource)
typedef void(STDMETHODCALLTYPE* PFN_RSSetShadingRate)(void*, int, const int*);
typedef void(STDMETHODCALLTYPE* PFN_RSSetShadingRateImage)(void*, ID3D12Resource*);

namespace fov {

static int g_tier = -1;                 // -1 not checked, 0 none, 1, 2
static UINT g_tile = 16;
static bool g_moreRates = false;        // 2x4 / 4x2 / 4x4
static ID3D12Resource* g_img[3] = {};   // left, right, mono
static float g_key[16] = {};
static volatile bool g_ready = false;
static unsigned g_applied = 0, g_cleared = 0;

bool Supported() {
    if (g_tier >= 0) return g_tier >= 2;
    g_tier = 0;
    if (!g_dev12) return false;
    Options6 o6 = {};
    if (SUCCEEDED(g_dev12->CheckFeatureSupport(kFeatureOptions6, &o6, sizeof o6))) {
        g_tier = (int)o6.VariableShadingRateTier;
        g_tile = o6.ShadingRateImageTileSize ? o6.ShadingRateImageTileSize : 16;
        g_moreRates = o6.AdditionalShadingRatesSupported != 0;
    }
    LOGI("foveated: variable rate shading tier %d, tile %u px%s", g_tier, g_tile, g_moreRates ? ", 4x4 rates" : "");
    return g_tier >= 2;
}

// resources the GPU may still read (frames in flight) are released a few seconds later
struct Dead { ID3D12Resource* r; ULONGLONG t; };
static std::vector<Dead> g_dead;
static void Retire(ID3D12Resource*& r) { if (r) { g_dead.push_back({ r, ModTick64() }); r = nullptr; } }
static void FlushDead() {
    for (size_t i = 0; i < g_dead.size();) if (ModTick64() - g_dead[i].t > 3000) { g_dead[i].r->Release(); g_dead.erase(g_dead.begin() + i); } else i++;
}
static void Release() {
    g_ready = false;
    for (auto*& r : g_img) Retire(r);
}

struct Params { float inner, outer, wide; int mid, outerR; };
static Params Get() {
    const std::string& m = g_set.fovMode;
    Params p = { g_set.fovInner, g_set.fovOuter, g_set.fovWide, RATE_2X1, RATE_2X2 };
    if (m == "quality") p = { 0.65f, 1.05f, 1.25f, RATE_2X1, RATE_2X2 };
    else if (m == "balanced") p = { 0.5f, 0.85f, 1.25f, RATE_2X2, g_moreRates ? RATE_4X2 : RATE_2X2 };
    else if (m == "performance") p = { 0.38f, 0.65f, 1.25f, RATE_2X2, g_moreRates ? RATE_4X4 : RATE_2X2 };
    if (g_set.fovDebug) p.outerR = g_moreRates ? RATE_4X4 : RATE_2X2;
    if (p.outer < p.inner) p.outer = p.inner;
    return p;
}

// one image: rates by the distance from the lens centre (cx, cy in tiles), in half image heights, wider horizontally
static void Fill(std::vector<unsigned char>& d, UINT tw, UINT th, float cx, float cy, const Params& p) {
    float hh = th * 0.5f;
    for (UINT y = 0; y < th; y++) for (UINT x = 0; x < tw; x++) {
        float dx = (x + 0.5f - cx) / (hh * p.wide), dy = (y + 0.5f - cy) / hh, r = sqrtf(dx * dx + dy * dy);
        d[y * tw + x] = (unsigned char)(r < p.inner ? RATE_1X1 : r < p.outer ? p.mid : p.outerR);
    }
}

// (re)build the images for this eye size and frustum, recorded on the compositor's list. Always a NEW set: lists the
// game recorded earlier (maybe still waiting to run on another thread) keep the old images in their state. The new
// set is used from Commit() on (after the compositor's list was submitted), the old one retired.
static ID3D12Resource* g_next[3] = {};
static bool g_haveNext = false;
static float g_nextKey[16] = {};
void Prepare(ID3D12GraphicsCommandList* list, UINT w, UINT h) {
    FlushDead();
    if (g_set.fovMode == "off" || !Supported() || !w || !h) { if (g_ready) Release(); return; }
    if (g_haveNext) return;
    Params p = Get();
    float key[16] = { (float)w, (float)h, p.inner, p.outer, p.wide, (float)p.mid, (float)p.outerR };
    for (int e = 0; e < 2; e++) for (int k = 0; k < 4; k++) key[7 + e * 4 + k] = CameraDrawTan(e)[k];
    key[15] = g_cam.monoTan[0];
    if (g_ready && !memcmp(key, g_key, sizeof key)) return;
    static ULONGLONG last = 0;
    if (g_ready && ModTick64() - last < 1000) return;   // at most one rebuild a second (a setting being dragged)
    last = ModTick64();
    UINT tw = (w + g_tile - 1) / g_tile, th = (h + g_tile - 1) / g_tile, pitch = (tw + 255) & ~255u;
    D3D12_HEAP_PROPERTIES hp = {}; hp.Type = D3D12_HEAP_TYPE_DEFAULT;
    D3D12_RESOURCE_DESC rd = {}; rd.Dimension = D3D12_RESOURCE_DIMENSION_TEXTURE2D; rd.Width = tw; rd.Height = th; rd.DepthOrArraySize = 1;
    rd.MipLevels = 1; rd.Format = DXGI_FORMAT_R8_UINT; rd.SampleDesc.Count = 1;
    D3D12_HEAP_PROPERTIES uh = {}; uh.Type = D3D12_HEAP_TYPE_UPLOAD;
    D3D12_RESOURCE_DESC bd = {}; bd.Dimension = D3D12_RESOURCE_DIMENSION_BUFFER; bd.Width = pitch * th; bd.Height = 1; bd.DepthOrArraySize = 1;
    bd.MipLevels = 1; bd.SampleDesc.Count = 1; bd.Layout = D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
    std::vector<unsigned char> d(tw * th);
    for (int i = 0; i < 3; i++) {
        ID3D12Resource* up = nullptr;
        if (FAILED(g_dev12->CreateCommittedResource(&hp, D3D12_HEAP_FLAG_NONE, &rd, D3D12_RESOURCE_STATE_COPY_DEST, nullptr, __uuidof(ID3D12Resource), (void**)&g_next[i])) ||
            FAILED(g_dev12->CreateCommittedResource(&uh, D3D12_HEAP_FLAG_NONE, &bd, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, __uuidof(ID3D12Resource), (void**)&up))) {
            LOGE("foveated: rate image failed"); for (auto*& r : g_next) Retire(r); if (up) up->Release(); return;
        }
        const float* t = i < 2 ? CameraDrawTan(i) : g_cam.monoTan;
        float cx = (t[1] - t[0]) > 0.05f ? -t[0] / (t[1] - t[0]) * tw : tw * 0.5f;   // lens centre = tangent 0
        float cy = (t[2] - t[3]) > 0.05f ? t[2] / (t[2] - t[3]) * th : th * 0.5f;
        Fill(d, tw, th, cx, cy, p);
        unsigned char* m = nullptr; D3D12_RANGE rr = { 0, 0 };
        if (SUCCEEDED(up->Map(0, &rr, (void**)&m))) { for (UINT y = 0; y < th; y++) memcpy(m + y * pitch, &d[y * tw], tw); up->Unmap(0, nullptr); }
        D3D12_TEXTURE_COPY_LOCATION dst = {}, src = {};
        dst.pResource = g_next[i]; dst.Type = D3D12_TEXTURE_COPY_TYPE_SUBRESOURCE_INDEX;
        src.pResource = up; src.Type = D3D12_TEXTURE_COPY_TYPE_PLACED_FOOTPRINT;
        src.PlacedFootprint.Footprint.Format = DXGI_FORMAT_R8_UINT; src.PlacedFootprint.Footprint.Width = tw;
        src.PlacedFootprint.Footprint.Height = th; src.PlacedFootprint.Footprint.Depth = 1; src.PlacedFootprint.Footprint.RowPitch = pitch;
        list->CopyTextureRegion(&dst, 0, 0, 0, &src, nullptr);
        D3D12_RESOURCE_BARRIER b = {}; b.Transition.pResource = g_next[i]; b.Transition.Subresource = D3D12_RESOURCE_BARRIER_ALL_SUBRESOURCES;
        b.Transition.StateBefore = D3D12_RESOURCE_STATE_COPY_DEST; b.Transition.StateAfter = kStateShadingRateSource;
        list->ResourceBarrier(1, &b);
        Retire(up);   // released after the copy has long run
    }
    memcpy(g_nextKey, key, sizeof key);
    g_haveNext = true;
    LOGI("foveated: %s, rings %.2f / %.2f, %ux%u tiles of %u px", g_set.fovMode.c_str(), p.inner, p.outer, tw, th, g_tile);
}
// the compositor's list (with the copies into the new images) was submitted
void Commit() {
    if (!g_haveNext) return;
    for (int i = 0; i < 3; i++) { Retire(g_img[i]); g_img[i] = g_next[i]; g_next[i] = nullptr; }
    memcpy(g_key, g_nextKey, sizeof g_key);
    g_haveNext = false; g_ready = true;
}

// command list hook: an eye-size render target that is not the final image was just bound (or something else was)
void OnBind(ID3D12GraphicsCommandList* l, void*& list5, bool& on, bool eyeTarget) {
    bool want = eyeTarget && g_ready && CameraFrameIsVR();
    if (!want && !on) return;
    if (!list5) {
        IUnknown* l5 = nullptr;
        if (FAILED(l->QueryInterface(kIID_List5, (void**)&l5)) || !l5) { list5 = (void*)1; return; }
        l5->Release(); list5 = l5;   // the same object as the list; the pointer stays valid while it lives
    }
    if (list5 == (void*)1) return;
    void** vt = *(void***)list5;
    auto setRate = (PFN_RSSetShadingRate)vt[77];
    auto setImage = (PFN_RSSetShadingRateImage)vt[78];
    if (want) {
        int i = g_cam.curMono || g_cam.mode == VRMODE_HEAD ? 2 : (g_cam.curEye & 1);
        int c[2] = { COMBINER_PASSTHROUGH, COMBINER_OVERRIDE };
        setRate(list5, RATE_1X1, c);
        setImage(list5, g_img[i]);
        on = true; g_applied++;
    } else {
        setImage(list5, nullptr);
        setRate(list5, RATE_1X1, nullptr);
        on = false; g_cleared++;
    }
}

void Report() {
    if (g_set.fovMode != "off") LOGI("foveated: %s - passes with reduced shading %u, switched back %u", g_ready ? "running" : "not running", g_applied, g_cleared);
    g_applied = g_cleared = 0;
}
void OnResize() { Release(); for (auto*& r : g_next) Retire(r); g_haveNext = false; }

} // namespace fov

void FovPrepare(ID3D12GraphicsCommandList* l, UINT w, UINT h) { fov::Prepare(l, w, h); }
void FovReport() { fov::Report(); }
void FovCommit() { fov::Commit(); }
