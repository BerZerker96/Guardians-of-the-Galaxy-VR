#include "modtime.h"
// Render size and the game window.
// GOTG renders at the size of its swap chain, which follows its window in windowed mode (IGCS's hotsampling resizes
// the window to take screenshots above the monitor's resolution). The mod:
//   * asks the VR runtime for the headset's recommended per-eye size as early as possible (the host starts while
//     the game is still loading; the size is cached in GOTGVR\headset.txt for the next start),
//   * picks the eye size: render_resolution auto = recommended x render_scale, reshaped by eye_aspect
//     (headset | 1:1 | 5:4 | 4:3: same height, width from the shape; the FOV is widened to match in camera.cpp),
//   * creates the swap chain at that size, keeps the window borderless at that client size (it may be larger than
//     the monitor: the window's size limit is lifted) and forces ResizeBuffers to it.
#include "d3d.h"
#include <string>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include "log.h"
#include "config.h"
#include "settings.h"
#include "camera.h"
#include "xrbridge/client.h"

extern std::wstring g_modDir;
static volatile LONG g_targetW = 0, g_targetH = 0;
static volatile bool g_targetSet = false;

void ResolutionSaveHeadset(unsigned w, unsigned h) {
    unsigned ow = 0, oh = 0;
    if (FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"r")) { if (fscanf(f, "%u %u", &ow, &oh) != 2) ow = oh = 0; fclose(f); }
    if (ow == w && oh == h) return;
    if (FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"w")) { fprintf(f, "%u %u\n", w, h); fclose(f); }
    LOGI("resolution: headset size %ux%u saved", w, h);
}
static bool CachedHeadset(unsigned& w, unsigned& h) {
    w = h = 0;
    if (FILE* f = _wfopen((g_modDir + L"\\headset.txt").c_str(), L"r")) { if (fscanf(f, "%u %u", &w, &h) != 2) w = h = 0; fclose(f); }
    return w && h;
}

static unsigned g_baseRw = 0, g_baseRh = 0; static float g_growX = 1.f, g_growY = 1.f;
static unsigned g_eyeOutW = 0, g_eyeOutH = 0;
// 0.6.9: the size of the images that go to the headset - its recommended size x render_scale, its own shape. The game
// renders a wider view (symmetric, per-axis growth); each eye is cut out of it 1:1 at this size, so the runtime gets
// square pixels at exactly the headset's resolution and aspect. It does not change with the stereo method.
bool HeadsetEyeSize(unsigned& w, unsigned& h) { w = g_eyeOutW; h = g_eyeOutH; return w >= 256 && h >= 256; }
static void ComputeTarget(unsigned rw, unsigned rh) {
    g_baseRw = rw; g_baseRh = rh;
    {
        float s = g_set.renderScale; if (!(s > 0.1f && s < 3.f)) s = 1.f;
        g_eyeOutW = ((unsigned)(rw * s + 0.5f) + 1) & ~1u; g_eyeOutH = ((unsigned)(rh * s + 0.5f) + 1) & ~1u;
        if (g_eyeOutW > 8192) { g_eyeOutH = g_eyeOutH * 8192 / g_eyeOutW; g_eyeOutW = 8192; }
        // 0.6.22: never above the runtime's largest per-eye image (render_scale > 1 on a high-resolution headset
        // could ask for more - its swap chains would fail and the headset would stay black); same shape
        unsigned mw = 0, mh = 0;
        if (xrb::ClientMaxEyeSize(&mw, &mh) && mw >= 256 && mh >= 256 && (g_eyeOutW > mw || g_eyeOutH > mh)) {
            double k = std::min((double)mw / g_eyeOutW, (double)mh / g_eyeOutH);
            g_eyeOutW = ((unsigned)(g_eyeOutW * k)) & ~1u; g_eyeOutH = ((unsigned)(g_eyeOutH * k)) & ~1u;
            LOGW("resolution: limited to %ux%u per eye (the runtime's largest)", g_eyeOutW, g_eyeOutH);
        }
    }
    std::string rr = g_set.renderResolution;
    unsigned w = 0, h = 0;
    if (rr == "game") { LOGI("resolution: the game's own window size is kept"); g_targetSet = false; return; }
    if (rr == "auto") {
        float s = g_set.renderScale; if (!(s > 0.1f && s < 3.f)) s = 1.f;
        w = (unsigned)(rw * s + 0.5f); h = (unsigned)(rh * s + 0.5f);
        LOGI("resolution: headset recommends %ux%u per eye, x %.2f", rw, rh, s);
    } else if (sscanf(rr.c_str(), "%ux%u", &w, &h) != 2) { LOGW("resolution: bad render_resolution '%s'", rr.c_str()); w = rw; h = rh; }
    const char* a = "headset";
    if (rr == "auto" && (g_growX > 1.005f || g_growY > 1.005f)) {   // a wider / taller rendered view keeps the headset's pixel density
        w = (unsigned)(w * g_growX + 0.5f); h = (unsigned)(h * g_growY + 0.5f);
        // 0.6.12: the render size gets exactly the drawn view's shape (square pixels; the engine may take its
        // sideways field of view from the window's shape) - the height follows the width
        float da = CameraDrawAspect();
        if (da > 0.2f && da < 5.f) h = (unsigned)(w / da + 0.5f);
        LOGI("resolution: rendered view %.2f x %.2f the headset's (width x height) - render size grown to match, shape %.3f", g_growX, g_growY, da);
    }
    if (rr == "auto" && g_growX <= 1.005f && g_growY <= 1.005f) { w = g_eyeOutW; h = g_eyeOutH; }   // 0.6.22: exactly the eye images' size
    unsigned maxSide = (unsigned)(g_set.renderMaxSide > 512 ? g_set.renderMaxSide : 8192);
    if (maxSide > 16384) maxSide = 16384;
    if (w > maxSide) { h = h * maxSide / w; w = maxSide; }
    if (h > maxSide) { w = w * maxSide / h; h = maxSide; }
    w = (w + 1) & ~1u; h = (h + 1) & ~1u;
    if (w < 256 || h < 256) { w = 2048; h = 2048; }
    g_targetW = w; g_targetH = h; g_targetSet = true;
    LOGI("resolution: game render size %ux%u (%s, %.2f MP)", w, h, a, w * (double)h / 1e6);
}

// called every Present: when the rendered view gets wider or narrower than the headset's (mode change: stereo
// reconstruction's shared view, head mode, cull margin), the eye image size follows so the headset keeps its density
void ResolutionFollowView() {
    // 0.6.14: the game renders at the headset's own size and shape, always. Each eye now gets its own (asymmetric)
    // frustum in the node projection the whole renderer uses, so nothing wider is needed for alternate eye /
    // synchronized; head mode and reconstruction's centre view squeeze the both-eye view into the same size.
    // 0.6.16: with one symmetric view for both eyes (the culling fix) the render grows sideways so the pixel
    // density stays the headset's; Pixel density = fixed keeps the headset's exact size instead (cheaper, softer)
    if (!g_set.symmetricView) { g_growX = g_growY = 1.f; return; }
    if (!g_baseRw || g_set.renderResolution != "auto" || g_set.renderDensity != "headset") { g_growX = g_growY = 1.f; return; }
    float gx, gy; CameraStableGrowthXY(gx, gy);   // 0.6.9: one size for every stereo method
    // 0.6.11: exact (the 2 % steps made the render size's shape differ from the picture's by up to 1 %); it only
    // changes with the headset's field of view / the eyes' angle / cull margin, not with the stereo method
    if (fabsf(gx - g_growX) < 0.002f && fabsf(gy - g_growY) < 0.002f) return;
    static ULONGLONG last = 0; ULONGLONG now = ModTick64();
    if (now - last < 1500) return;        // not more often than every 1.5 s (mode cycling)
    last = now;
    LOGI("resolution: rendered view %.2f x %.2f the headset's - eye image follows (headset pixel density kept)", gx, gy);
    g_growX = gx; g_growY = gy;
    ComputeTarget(g_baseRw, g_baseRh);
    WindowApplyTarget();
}

bool ResolutionTarget(unsigned& w, unsigned& h) {
    if (!g_targetSet || g_set.vrMode == "screen") return false;
    w = (unsigned)g_targetW; h = (unsigned)g_targetH;
    return w && h;
}

static DWORD WINAPI HostThread(LPVOID) {
    unsigned w = 0, h = 0, cw = 0, ch = 0;
    bool cached = CachedHeadset(cw, ch);
    if (cached) ComputeTarget(cw, ch);   // right away: the swap chain may come before the runtime answers
    bool ok = XrStartHost() && xrb::ClientWaitRecommendedSize(&w, &h, cached ? 8000 : 20000) && w && h;
    if (ok) {
        ResolutionSaveHeadset(w, h);
        LONG ow = g_targetW, oh = g_targetH;
        ComputeTarget(w, h);   // again also with the same size: the runtime's limits are known now
        if (!cached || g_targetW != ow || g_targetH != oh) WindowApplyTarget();
    } else if (!cached) {
        LOGW("resolution: the VR runtime did not report the headset size - 2048x2048 for now (start the VR software first)");
        ComputeTarget(2048, 2048); WindowApplyTarget();
    }
    return 0;
}

void ResolutionStart() {
    if (g_set.vrMode == "screen") { LOGI("resolution: screen mode - the window is left alone"); XrStartHost(); return; }
    CreateThread(nullptr, 0, HostThread, nullptr, 0, nullptr);
}

// ---------------------------------------------------------------- window
// The game renders at the size it asks ResizeBuffers for, which it takes from its window's client area. If that is
// not the eye size, the game draws its frame at its own size and copies it into back buffers of another size - the
// picture lands in the top part of the eye image (stretched FOV, black band at the bottom) and the mismatched copy can
// end in garbage and a GPU crash. Windows (and the game itself) keep a window inside the monitor, so a 3420x2668 eye
// on a 2160-line monitor came out 3420x2153. Now, while a VR eye size is set:
//   * WM_WINDOWPOSCHANGING is set to the eye size AFTER the game's own handler too, WM_GETMINMAXINFO allows it,
//   * WM_SIZE tells the game the eye size,
//   * GetClientRect on the game window answers the eye size (what IGCS-style hotsampling relies on),
// so the game asks for - and renders at - exactly the eye size, whatever fits on the monitor.
#include "MinHook.h"
static WNDPROC g_origProc = nullptr;
static bool g_applying = false;
static volatile LONG g_clampSeen = 0;
typedef BOOL(WINAPI* PFN_GetClientRect)(HWND, LPRECT);
static PFN_GetClientRect o_GetClientRect = nullptr;
static BOOL WINAPI H_GetClientRect(HWND h, LPRECT r) {
    BOOL ok = o_GetClientRect(h, r);
    unsigned tw, th;
    if (ok && r && h && h == g_hwnd && !IsIconic(h) && ResolutionTarget(tw, th)) {
        if ((unsigned)(r->right - r->left) != tw || (unsigned)(r->bottom - r->top) != th) {
            if (InterlockedIncrement(&g_clampSeen) <= 3)
                LOGI("window: client area %ld x %ld (kept inside the monitor) - the game is told %u x %u", r->right - r->left, r->bottom - r->top, tw, th);
            r->left = 0; r->top = 0; r->right = (LONG)tw; r->bottom = (LONG)th;
        }
    }
    return ok;
}

static void ForceSizeInPos(HWND h, WINDOWPOS* p, unsigned tw, unsigned th) {
    if (p->flags & SWP_NOSIZE) return;
    RECT r = { 0, 0, (LONG)tw, (LONG)th };
    AdjustWindowRectEx(&r, (DWORD)GetWindowLongW(h, GWL_STYLE), FALSE, (DWORD)GetWindowLongW(h, GWL_EXSTYLE));
    p->cx = r.right - r.left; p->cy = r.bottom - r.top;
}
static LRESULT CALLBACK SizeProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    unsigned tw, th;
    bool vr = ResolutionTarget(tw, th);
    if (msg == WM_WINDOWPOSCHANGING && vr) ForceSizeInPos(h, (WINDOWPOS*)lp, tw, th);   // keep the client area at the eye size
    if (msg == WM_SIZE && vr && wp != SIZE_MINIMIZED) lp = MAKELPARAM(tw, th);         // what the game sizes its frame by
    LRESULT res = CallWindowProcW(g_origProc, h, msg, wp, lp);
    if (msg == WM_WINDOWPOSCHANGING && vr) ForceSizeInPos(h, (WINDOWPOS*)lp, tw, th);   // ... after the game's own handler too
    if (msg == WM_GETMINMAXINFO) {
        auto* mm = (MINMAXINFO*)lp;
        mm->ptMaxTrackSize.x = mm->ptMaxSize.x = 16384;
        mm->ptMaxTrackSize.y = mm->ptMaxSize.y = 16384;
    }
    return res;
}

void WindowHook(HWND h) {
    if (!h || g_hwnd == h) return;
    g_hwnd = h;
    g_origProc = (WNDPROC)SetWindowLongPtrW(h, GWLP_WNDPROC, (LONG_PTR)SizeProc);
    if (!o_GetClientRect) {
        void* f = (void*)GetProcAddress(GetModuleHandleW(L"user32.dll"), "GetClientRect");
        if (f && MH_CreateHook(f, (void*)H_GetClientRect, (void**)&o_GetClientRect) == MH_OK && MH_EnableHook(f) == MH_OK) LOGI("window: GetClientRect hooked");
        else o_GetClientRect = (PFN_GetClientRect)f;
    }
    RECT rc; o_GetClientRect(h, &rc);
    LOGI("window %p: client %ld x %ld", (void*)h, rc.right, rc.bottom);
}

// borderless, client area = eye size. Asynchronous: the window's own thread may be the one waiting on us.
void WindowApplyTarget() {
    unsigned tw, th;
    if (!g_hwnd || !ResolutionTarget(tw, th)) return;
    RECT rc; (o_GetClientRect ? o_GetClientRect : GetClientRect)(g_hwnd, &rc);
    LONG st = GetWindowLongW(g_hwnd, GWL_STYLE);
    bool styled = (st & WS_POPUP) && !(st & (WS_CAPTION | WS_THICKFRAME));
    if (styled && rc.right == (LONG)tw && rc.bottom == (LONG)th) return;
    g_applying = true;
    st &= ~(WS_CAPTION | WS_THICKFRAME | WS_MINIMIZEBOX | WS_MAXIMIZEBOX | WS_SYSMENU);
    st |= WS_POPUP;
    SetWindowLongW(g_hwnd, GWL_STYLE, st);
    SetWindowPos(g_hwnd, nullptr, 0, 0, (int)tw, (int)th, SWP_NOZORDER | SWP_NOACTIVATE | SWP_FRAMECHANGED | SWP_ASYNCWINDOWPOS);
    g_applying = false;
    LOGI("window: borderless %u x %u (was %ld x %ld)", tw, th, rc.right, rc.bottom);
}
