// GOTG specifics: signatures, patches. See game.h and NOTES.md.
#include "game.h"
#include <cstdio>
#include <cstring>
#include <climits>
#include <string>
#include <vector>
#include "log.h"

namespace game {

uintptr_t g_base = 0;
size_t g_size = 0;
void* g_nodeUpdate = nullptr;
void* g_getProj = nullptr;
void* g_timerUpdate = nullptr;
uintptr_t g_gameTimer = 0;
volatile unsigned char* g_taaFlag = nullptr;
volatile float* g_nearOverride = nullptr;   // exe+3D97774: used by the projection getter / view-projection when > 0
uintptr_t kNodeTransform = 0x24, kNodeProj = 0xC0, kNodeW = 0x1A8, kNodeH = 0x1AC;

struct Section { uintptr_t start = 0; size_t size = 0; bool exec = false; char name[9] = {}; };
static std::vector<Section> g_secs;
static bool g_quiet = false;
void FindRenderSizeRounding();

bool InCode(uintptr_t a) { for (auto& s : g_secs) if (s.exec && a >= s.start && a < s.start + s.size) return true; return false; }

// 0.6.14: VirtualQuery gets slow as the game's address space fills up (the camera / menu part of the mod's time at
// Present grew from 0.6 to 5.5 ms over a session in the 0.6.13 log). Regions checked readable in the last 50 ms are
// remembered per thread (16 of them) - the same few objects are checked many times a frame.
struct RdCache { uintptr_t lo, hi; ULONGLONG at; };
static thread_local RdCache t_rd[16]; static thread_local unsigned t_rdNext = 0;
static volatile LONG64 g_vqCalls = 0, g_vqHits = 0;
void ReadableStats(long long& calls, long long& hits) { calls = g_vqCalls; hits = g_vqHits; g_vqCalls = g_vqHits = 0; }
bool Readable(const void* p, size_t n) {
    MEMORY_BASIC_INFORMATION mi;
    const char* a = (const char*)p; const char* e = a + n;
    {
        ULONGLONG now = GetTickCount64();
        uintptr_t lo = (uintptr_t)a, hi = (uintptr_t)e;
        for (auto& c : t_rd) if (lo >= c.lo && hi <= c.hi && now - c.at <= 50) { g_vqHits++; return true; }
    }
    uintptr_t okLo = 0, okHi = 0;
    while (a < e) {
        g_vqCalls++;
        if (!VirtualQuery(a, &mi, sizeof mi)) return false;
        if (mi.State != MEM_COMMIT || (mi.Protect & (PAGE_NOACCESS | PAGE_GUARD))) return false;
        if (!(mi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY))) return false;
        if (!okLo) okLo = (uintptr_t)mi.BaseAddress;
        a = (const char*)mi.BaseAddress + mi.RegionSize; okHi = (uintptr_t)a;
    }
    if (okLo) { RdCache& c = t_rd[t_rdNext++ & 15]; c.lo = okLo; c.hi = okHi; c.at = GetTickCount64(); }
    return true;
}

static void FindSections() {
    g_secs.clear();
    auto* dos = (IMAGE_DOS_HEADER*)g_base;
    auto* nt = (IMAGE_NT_HEADERS64*)(g_base + dos->e_lfanew);
    g_size = nt->OptionalHeader.SizeOfImage;
    auto* s = IMAGE_FIRST_SECTION(nt);
    for (int i = 0; i < nt->FileHeader.NumberOfSections; i++, s++) {
        Section sec; sec.start = g_base + s->VirtualAddress; sec.size = s->Misc.VirtualSize;
        sec.exec = (s->Characteristics & IMAGE_SCN_MEM_EXECUTE) != 0;
        memcpy(sec.name, s->Name, 8);
        g_secs.push_back(sec);
    }
}

// "48 8B ?? 05" pattern, ?? = any byte
static std::vector<int> Parse(const char* pattern) {
    std::vector<int> pat;
    for (const char* p = pattern; *p;) {
        while (*p == ' ') p++;
        if (!*p) break;
        if (p[0] == '?') { pat.push_back(-1); p += (p[1] == '?') ? 2 : 1; }
        else { pat.push_back((int)strtoul(p, nullptr, 16)); p += 2; }
    }
    return pat;
}
static void ScanSec(const Section& sec, const std::vector<int>& pat, std::vector<uintptr_t>& out, size_t max) {
    if (pat.empty() || sec.size < pat.size() || !Readable((void*)sec.start, 1)) return;
    const unsigned char* b = (const unsigned char*)sec.start;
    size_t n = sec.size - pat.size();
    int first = pat[0];
    for (size_t i = 0; i < n; i++) {
        if (first >= 0 && b[i] != first) continue;
        size_t k = 1;
        for (; k < pat.size(); k++) if (pat[k] >= 0 && b[i + k] != pat[k]) break;
        if (k == pat.size()) { out.push_back(sec.start + i); if (out.size() >= max) return; }
    }
}
// only the main code section (.shared in this exe): the protector's sections hold copies / noise
static uintptr_t ScanOne(const char* name, const char* pattern) {
    std::vector<int> pat = Parse(pattern);
    std::vector<uintptr_t> r;
    for (auto& s : g_secs) if (s.exec && s.size > 0x100000 && s.size < 0x10000000) { ScanSec(s, pat, r, 2); if (r.size() > 1) break; }
    if (g_quiet && r.size() != 1) return 0;
    if (r.size() == 1) { LOGI("sig %-24s exe+%llx", name, (unsigned long long)(r[0] - g_base)); return r[0]; }
    LOGE("sig %-24s %s - feature off", name, r.empty() ? "NOT FOUND" : "AMBIGUOUS");
    return 0;
}
static uintptr_t Rip(uintptr_t insn, int dispOffset, int insnLen) { return insn + insnLen + *(int32_t*)(insn + dispOffset); }
uintptr_t Scan(const char* name, const char* pattern) { if (g_secs.empty()) FindSections(); return ScanOne(name, pattern); }
static std::vector<uintptr_t> ScanAll(const char* pattern, size_t max) {
    std::vector<int> pat = Parse(pattern);
    std::vector<uintptr_t> r;
    for (auto& s : g_secs) if (s.exec && s.size > 0x100000 && s.size < 0x10000000) ScanSec(s, pat, r, max);
    return r;
}

static bool WriteCode(uintptr_t at, const void* bytes, size_t n) {
    DWORD old;
    if (!VirtualProtect((void*)at, n, PAGE_EXECUTE_READWRITE, &old)) return false;
    memcpy((void*)at, bytes, n);
    VirtualProtect((void*)at, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), (void*)at, n);
    return true;
}

// the view update's vtable (log: confirms the class through RTTI)
static void CheckNodeVtable(uintptr_t fn) {
    for (auto& s : g_secs) {
        if (s.exec || !Readable((void*)s.start, 8)) continue;
        const uint64_t* q = (const uint64_t*)s.start;
        for (size_t j = 1; j < s.size / 8; j++) {
            if (q[j] != fn) continue;
            uintptr_t vt = (uintptr_t)&q[j] - 9 * 8;
            if (!Readable((void*)(vt - 8), 8)) continue;
            uintptr_t col = *(uintptr_t*)(vt - 8);
            if (col < g_base || col >= g_base + g_size || !Readable((void*)col, 24)) continue;
            uint32_t td = ((const uint32_t*)col)[3];
            const char* nm = (const char*)(g_base + td + 0x10);
            if (Readable(nm, 40))
                LOGI("rtti: view update is slot 9 of %s (vtable exe+%llx)", nm, (unsigned long long)(vt - g_base));
            return;
        }
    }
    LOGW("rtti: vtable of the view update not found (only logged)");
}

static uintptr_t g_barsA = 0, g_barsB = 0, g_pause = 0, g_hudFlag = 0;

// ---- the game's render options (see game.h). The settings-apply function (exe+CDBF1) pushes every PC setting into
// the option table with the table's own setters; the same three-instruction sequence gives the setting's address,
// the table and the setter. The setters are thunks into protected code - they are only called, never patched.
typedef void(__fastcall* PFN_OptBool)(void*, int, unsigned char);
typedef void(__fastcall* PFN_OptInt)(void*, int, int);
typedef void(__fastcall* PFN_OptFloat)(void*, int, float);
static void* g_optTable = nullptr; static PFN_OptBool g_setBool = nullptr; static PFN_OptInt g_setInt = nullptr; static PFN_OptFloat g_setFloat = nullptr;
static volatile unsigned char* g_psAA = nullptr; static volatile int* g_psDynRes = nullptr; static volatile int* g_psDlss = nullptr;
static volatile int* g_psFsr = nullptr; static volatile float* g_psResScale = nullptr;
static const int kOptAA = 0x4BE, kOptDynRes = 0x51B, kOptResScale = 0x51A;
static void FindRenderOptions() {
    uintptr_t h = ScanOne("OptAntiAliasing", "44 0F B6 05 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? BA BE 04 00 00 E8");
    if (!h) return;
    uintptr_t aa = Rip(h, 4, 8), table = Rip(h + 8, 3, 7);
    uintptr_t sb = Rip(h + 20, 1, 5);
    // PC settings block (exe+3E603A0): AntiAliasing +0x60, DynResType +0x24, DlssQuality +0x28, ResScale +0x38, FSRQuality +0x64
    uintptr_t blk = aa - 0x60;
    uintptr_t si = 0, sf = 0;
    for (uintptr_t c : ScanAll("44 8B 05 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? BA 1B 05 00 00 E8", 4))
        if (Rip(c, 3, 7) == blk + 0x24 && Rip(c + 7, 3, 7) == table) si = Rip(c + 19, 1, 5);
    for (uintptr_t c : ScanAll("F3 0F 10 15 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? BA 1A 05 00 00 E8", 4))
        if (Rip(c, 4, 8) == blk + 0x38 && Rip(c + 8, 3, 7) == table) sf = Rip(c + 20, 1, 5);
    if (!InCode(sb) || !Readable((void*)blk, 0x68) || !Readable((void*)table, 8)) { LOGW("render options: layout not as expected - off"); return; }
    g_optTable = (void*)table; g_setBool = (PFN_OptBool)sb;
    g_psAA = (volatile unsigned char*)aa; g_psDynRes = (volatile int*)(blk + 0x24); g_psDlss = (volatile int*)(blk + 0x28);
    g_psResScale = (volatile float*)(blk + 0x38); g_psFsr = (volatile int*)(blk + 0x64);
    if (si && InCode(si)) g_setInt = (PFN_OptInt)si;
    if (sf && InCode(sf)) g_setFloat = (PFN_OptFloat)sf;
    LOGI("render options: table exe+%llx, settings exe+%llx (anti-aliasing setter %s, upscaling %s, resolution scale %s)",
         (unsigned long long)(table - g_base), (unsigned long long)(blk - g_base), "found", g_setInt ? "found" : "NOT FOUND", g_setFloat ? "found" : "NOT FOUND");
}
// the table's own lookup (as its getter exe+D4010): FNV-1a of the id's 4 bytes -> bucket -> chain of 24-byte entries
// {next index, id, option object}. The setters assume the option exists - checked here before every call.
static bool OptionExists(int id) {
    if (!g_optTable || !Readable((const char*)g_optTable + 0x78, 0x18)) return false;
    const char* t = (const char*)g_optTable;
    const int64_t* buckets = *(int64_t* const*)(t + 0x80); uint64_t count = *(const uint64_t*)(t + 0x78);
    const char* entries = *(const char* const*)(t + 0x88);
    if (!buckets || !entries || !count || count > (1u << 24)) return false;
    uint32_t u = (uint32_t)id, h = 0x811C9DC5u;
    for (int k = 0; k < 4; k++) h = (h ^ ((u >> (8 * k)) & 0xFF)) * 0x01000193u;
    uint64_t b = (uint64_t)h % count;
    if (!Readable(&buckets[b], 8)) return false;
    int64_t i = buckets[b];
    for (int guard = 0; i != -1 && guard < 4096; guard++) {
        const char* e = entries + i * 24;
        if (!Readable(e, 24)) return false;
        if (*(const int32_t*)(e + 8) == id) return *(void* const*)(e + 16) != nullptr;
        i = *(const int64_t*)e;
    }
    return false;
}
bool RenderOptionsFound() { return g_setBool != nullptr; }
void RenderOptionsLog() {
    if (!g_psAA) return;
    LOGI("render options: the game's settings - anti-aliasing %d, upscaling / dynamic resolution type %d, DLSS quality %d, FSR quality %d, resolution scale %.0f %%",
         (int)*g_psAA, *g_psDynRes, *g_psDlss, *g_psFsr, *g_psResScale);
}
// game thread only (the game's menu applies its options from there too)
void RenderOptionsApply(bool native, int aaWant) {
    if (!g_setBool) return;
    static bool ready = false;
    if (!ready) {   // the game registers its options at start-up: wait for them
        if (!OptionExists(kOptAA)) return;
        if (g_setInt && !OptionExists(kOptDynRes)) g_setInt = nullptr;
        if (g_setFloat && !OptionExists(kOptResScale)) g_setFloat = nullptr;
        ready = true;
        LOGI("render options: in the game's option table (anti-aliasing%s%s)", g_setInt ? ", upscaling" : "", g_setFloat ? ", resolution scale" : "");
    }
    static int curNative = 0, curAa = -1;   // start: nothing changed by the mod
    static int seenDyn = INT_MIN, seenAA = -1; static float seenScale = -1.f;
    int dyn = *g_psDynRes, aa = *g_psAA; float sc = *g_psResScale;
    bool changed = seenAA >= 0 && (dyn != seenDyn || aa != seenAA || sc != seenScale);   // the player changed a setting
    if (changed) RenderOptionsLog();
    seenDyn = dyn; seenAA = aa; seenScale = sc;
    if (g_setInt && g_setFloat) {
        if (native && (curNative != 1 || changed)) {
            g_setInt(g_optTable, kOptDynRes, 0); g_setFloat(g_optTable, kOptResScale, 100.f);
            if (curNative != 1) LOGI("render options: game_upscaling = off - upscaling / dynamic resolution off, resolution scale 100 %% (your settings: %d / %.0f %%)", dyn, sc);
            curNative = 1;
        } else if (!native && curNative == 1) {
            g_setInt(g_optTable, kOptDynRes, dyn); g_setFloat(g_optTable, kOptResScale, sc);
            LOGI("render options: game_upscaling = game - your upscaling / resolution scale back (%d / %.0f %%)", dyn, sc);
            curNative = 0;
        }
    }
    if (aaWant >= 0 && (curAa != aaWant || changed)) {
        g_setBool(g_optTable, kOptAA, (unsigned char)aaWant);
        if (curAa != aaWant) LOGI("render options: game_aa = %s - the game's anti-aliasing %s (your setting: %d)", aaWant ? "on" : "off", aaWant ? "on" : "off", aa);
        curAa = aaWant;
    } else if (aaWant < 0 && curAa >= 0) {
        g_setBool(g_optTable, kOptAA, (unsigned char)aa);
        LOGI("render options: game_aa = game - your anti-aliasing setting back (%d)", aa);
        curAa = -1;
    }
}

bool Init(bool quiet) {
    g_base = (uintptr_t)GetModuleHandleW(nullptr);
    FindSections();
    g_quiet = quiet;
    // the per-frame view update of ZRenderGraphNodeCamera (prologue down to "sub rsp,428h"; unique)
    uintptr_t upd = ScanOne("NodeViewUpdate", "48 8B C4 44 89 48 20 48 89 50 10 48 89 48 08 55 56 57 41 54 41 55 41 56 48 8D A8 ?? ?? FF FF 48 81 EC ?? ?? 00 00");
    if (!upd) { if (!quiet) LOGW("game: view update not found (code not readable yet?)"); g_quiet = false; return false; }
    g_quiet = false;
    LOGI("game: GOTG.exe base %p, image %zu bytes, %zu sections", (void*)g_base, g_size, g_secs.size());
    g_nodeUpdate = (void*)upd;
    CheckNodeVtable(upd);
    const unsigned char* f = (const unsigned char*)upd;
    // the node's transform copy: the first "movups xmm4, [rsi + X]" (0F 10 66 X) of the update (1.x: +24h)
    int at = -1;
    for (int i = 0; i < 0x180; i++) if (f[i] == 0x0F && f[i + 1] == 0x10 && f[i + 2] == 0x66) { at = i; break; }
    if (at >= 0) kNodeTransform = f[at + 3]; else LOGW("game: node transform read not found - using +%llx", (unsigned long long)kNodeTransform);
    // the projection getter: the first call of the update; checked by its body (copies node+0C0h, movzx esi, r8b)
    static const unsigned char body[] = { 0x48, 0x89, 0x5C, 0x24, 0x08, 0x48, 0x89, 0x74, 0x24, 0x10, 0x57, 0x48, 0x83, 0xEC, 0x30, 0x0F, 0x10, 0x81 };
    uintptr_t gp = 0;   // (an E8 byte can also be part of another instruction: take the first call whose target matches)
    for (int i = 0; i < 0x100 && !gp; i++) if (f[i] == 0xE8) {
        uintptr_t t = Rip(upd + i, 1, 5);
        if (InCode(t) && Readable((void*)t, 32) && !memcmp((void*)t, body, sizeof body)) gp = t;
    }
    if (gp && InCode(gp) && !memcmp((void*)gp, body, sizeof body) && ((const unsigned char*)gp)[22] == 0x48) {
        g_getProj = (void*)gp;
        kNodeProj = *(const uint32_t*)(gp + 18);
        LOGI("sig %-24s exe+%llx (node projection +%llx)", "ProjectionGetter", (unsigned long long)(gp - g_base), (unsigned long long)kNodeProj);
    } else LOGE("sig %-24s DOES NOT MATCH - per-eye projection off (mono FOV only)", "ProjectionGetter");
    // render size fields (mov eax,[rsi+X] ... mov edx,[rsi+Y] inside the update)
    for (int i = 0; i < 0x300; i++) {
        if (f[i] == 0x8B && f[i + 1] == 0x86 && f[i + 4] == 0 && f[i + 5] == 0) {
            for (int k = 6; k < 18; k++) if (f[i + k] == 0x8B && f[i + k + 1] == 0x96 && f[i + k + 4] == 0 && f[i + k + 5] == 0) {
                kNodeW = *(const uint32_t*)(f + i + 2); kNodeH = *(const uint32_t*)(f + i + k + 2); i = 0x300; break;
            }
        }
    }
    LOGI("game: node transform +%llx, projection +%llx, render size +%llx/+%llx", (unsigned long long)kNodeTransform,
         (unsigned long long)kNodeProj, (unsigned long long)kNodeW, (unsigned long long)kNodeH);

    g_barsA = ScanOne("NoBlackBars1", "76 42 44 0F 28 C7 F3 44 0F 59 C0");
    g_barsB = ScanOne("NoBlackBars2", "76 31 F3 0F 59 F1 0F 2F F7 73 28");
    g_pause = ScanOne("PauseOnFocusLoss", "0F 84 72 02 00 00 48 8B 0D ?? ?? ?? ?? 4C 8D 0D ?? ?? ?? ?? 41 B0 01");
    if (uintptr_t h = ScanOne("HudFlag", "0F B6 05 ?? ?? ?? ?? 38 83 ?? ?? 00 00 74 14")) {
        g_hudFlag = Rip(h, 3, 7);
        if (!Readable((void*)g_hudFlag, 1)) g_hudFlag = 0;
        else LOGI("game: HUD flag at exe+%llx", (unsigned long long)(g_hudFlag - g_base));
    }
    if (uintptr_t t = ScanOne("TimerUpdate", "80 79 78 00 44 0F B6 CA 4C 8B C1 0F 85 ?? ?? ?? ?? F3 0F 10 0D")) {
        g_timerUpdate = (void*)t;
        // the main loop's call: lea rcx, [game timer]; call TimerUpdate; mov rcx, [..]; mov r8d, 1; mov edx, 4
        if (uintptr_t c = ScanOne("GameTimerCall", "48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 8B 0D ?? ?? ?? ?? 41 B8 01 00 00 00 BA 04 00 00 00"))
            if (Rip(c + 7, 1, 5) == t) { g_gameTimer = Rip(c, 3, 7); LOGI("game: game clock at exe+%llx", (unsigned long long)(g_gameTimer - g_base)); }
        if (!g_gameTimer) LOGW("game: game clock not identified - synchronized stereo off");
    }
    // the projection getter: movss xmm5, [near override]; if > 0 it replaces the camera's near plane (node+0x1D0);
    // exe+9724C0 (view x projection for LOD) reads the same global
    if (uintptr_t n = ScanOne("NearOverride", "F3 0F 10 2D ?? ?? ?? ?? 0F 57 C0 0F 2F E8 77 08 F3 0F 10 AF D0 01 00 00")) {
        uintptr_t f = Rip(n, 4, 8);
        if (Readable((void*)f, 4)) { g_nearOverride = (volatile float*)f; LOGI("game: near-plane override at exe+%llx (%g)", (unsigned long long)(f - g_base), *g_nearOverride); }
    }
    FindRenderOptions();
    RenderOptionsLog();
    if (uintptr_t j = ScanOne("TaaJitter", "80 3D ?? ?? ?? ?? 00 4C 8B D2 4C 8B C9 0F 84")) {
        uintptr_t f = Rip(j, 2, 7);
        if (Readable((void*)f, 1)) {
            g_taaFlag = (volatile unsigned char*)f;
            // the FuckTAA TAA fix (TL431) is this same byte set to 0 in the exe ("01 01 02 00 00 00 00 00 80 3F" ->
            // "00 01 ..."); "Game anti-aliasing: Off" does the same in memory
            LOGI("game: TAA flag at exe+%llx = %d%s", (unsigned long long)(f - g_base), (int)*g_taaFlag,
                 *g_taaFlag == 0 ? " (TAA off in the exe - the FuckTAA TAA fix)" : " (the game's TAA - \"Game anti-aliasing: Off\" turns it off like the FuckTAA fix)");
        }
    }
    FindRenderSizeRounding();
    return true;
}

// 0.6.15: the internal render size is rounded DOWN to a multiple of 64 (3420x2668 -> 3392x2624) and scaled up to
// the output (the FuckTAA "resolution fix" by TL431 removes the two "and reg, -64"). For VR the picture has to be
// rendered at exactly the headset's size: the same two instructions are NOPed in memory (the exe file is not
// touched; an exe that already has the hex fix is recognised).
static uintptr_t g_round64[2] = {}; static int g_round64State = -1;   // -1 not found, 0 game's, 1 exe already patched
void FindRenderSizeRounding() {
    bool q = g_quiet; g_quiet = true;
    uintptr_t a = ScanOne("RenderSizeRound64W", "F3 48 0F 2A C8 83 E2 C0");
    uintptr_t b = ScanOne("RenderSizeRound64H", "F3 48 0F 2C C9 83 E1 C0");
    uintptr_t pa = (a && b) ? 0 : ScanOne("RenderSizeRound64W", "F3 48 0F 2A C8 90 90 90");
    uintptr_t pb = (a && b) ? 0 : ScanOne("RenderSizeRound64H", "F3 48 0F 2C C9 90 90 90");
    g_quiet = q;
    if (a && b) { g_round64[0] = a + 5; g_round64[1] = b + 5; g_round64State = 0; LOGI("game: render size rounding to 64 px at exe+%llx / exe+%llx", (unsigned long long)(a - g_base), (unsigned long long)(b - g_base)); }
    else if (pa && pb) { g_round64State = 1; LOGI("game: the exe already has the FuckTAA resolution fix (render size not rounded to 64 px)"); }
    else LOGW("game: render size rounding not found - the internal size may be rounded down to 64 px");
}
bool ApplyExactRenderSize(bool on) {
    if (g_round64State != 0) return g_round64State == 1;
    static int applied = -1;
    if (applied == (int)on) return true;
    const unsigned char nop[3] = { 0x90, 0x90, 0x90 }, w[3] = { 0x83, 0xE2, 0xC0 }, h[3] = { 0x83, 0xE1, 0xC0 };
    bool ok = WriteCode(g_round64[0], on ? nop : w, 3) && WriteCode(g_round64[1], on ? nop : h, 3);
    applied = on;
    LOGI("patch: internal render size %s", on ? "exact (no rounding down to 64 px - the FuckTAA resolution fix, in memory)" : "rounded to 64 px (the game's own)");
    return ok;
}

bool ApplyNoBlackBars(bool on) {
    if (!g_barsA || !g_barsB) return false;
    unsigned char a = on ? 0xEB : 0x76;
    bool ok = WriteCode(g_barsA, &a, 1) && WriteCode(g_barsB, &a, 1);
    LOGI("patch: cutscene black bars %s", on ? "removed" : "restored");
    return ok;
}

bool ApplyRunInBackground(bool on) {
    if (!g_pause) return false;
    static const unsigned char jmp[] = { 0x90, 0xE9, 0x73, 0x02, 0x00, 0x00 }, je[] = { 0x0F, 0x84, 0x72, 0x02, 0x00, 0x00 };
    bool ok = WriteCode(g_pause, on ? jmp : je, 6);
    LOGI("patch: pause on focus loss %s", on ? "off (keeps running behind the headset software)" : "restored");
    return ok;
}

// near clip in engine units (0 = the game's own); the global is plain data (no protection change needed, checked)
void SetNearClip(float units) {
    if (!g_nearOverride) return;
    static float orig = -1.f;
    if (orig < 0.f) orig = *g_nearOverride < 0.f ? 0.f : *g_nearOverride;
    float v = units > 0.f ? units : orig;
    if (*g_nearOverride == v) return;
    MEMORY_BASIC_INFORMATION mi = {};
    if (!VirtualQuery((void*)g_nearOverride, &mi, sizeof mi) || !(mi.Protect & (PAGE_READWRITE | PAGE_EXECUTE_READWRITE | PAGE_WRITECOPY))) {
        DWORD old; if (!VirtualProtect((void*)g_nearOverride, 4, PAGE_READWRITE, &old)) return;
    }
    *g_nearOverride = v;
    LOGI("game: near clip %s", v > 0.f ? "set by the mod" : "the game's own");
}
// ---- RTTI: the vtable of a class by its MSVC type name (".?AVZRenderPostfilterPassDOF@@"). Type descriptor = the name
// - 16; complete object locator: signature 1, type descriptor RVA at +12, its own RVA at +20; vtable[-1] = locator.
// Independent of code bytes, so it survives game patches.
static bool SecReadable(const Section& s) {
    MEMORY_BASIC_INFORMATION mi = {};
    for (uintptr_t a = s.start; a < s.start + s.size; a = (uintptr_t)mi.BaseAddress + mi.RegionSize) {
        if (!VirtualQuery((void*)a, &mi, sizeof mi)) return false;
        if (mi.State != MEM_COMMIT || (mi.Protect & (PAGE_NOACCESS | PAGE_GUARD)) || !(mi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE)))
            return false;
    }
    return true;
}
uintptr_t VtableByRtti(const char* typeName) {
    if (g_secs.empty()) FindSections();
    size_t n = strlen(typeName) + 1;
    for (auto& s : g_secs) {
        if (s.exec || s.size < n || !SecReadable(s)) continue;
        const char* b = (const char*)s.start; const char* e = b + s.size - n;
        for (const char* p = b; p <= e; p++) {
            if (*p != typeName[0] || memcmp(p, typeName, n)) continue;
            uintptr_t td = (uintptr_t)p - 16;
            uint32_t tdRva = (uint32_t)(td - g_base);
            for (auto& s2 : g_secs) {
                if (s2.exec || !SecReadable(s2)) continue;
                for (uintptr_t q = s2.start; q + 24 <= s2.start + s2.size; q += 4) {
                    if (*(uint32_t*)q != tdRva) continue;
                    uintptr_t col = q - 12;
                    if (col < s2.start || *(uint32_t*)col != 1 || *(uint32_t*)(col + 20) != (uint32_t)(col - g_base) || *(uint32_t*)(col + 4) != 0) continue;
                    for (auto& s3 : g_secs) {
                        if (s3.exec || !SecReadable(s3)) continue;
                        for (uintptr_t v = s3.start; v + 16 <= s3.start + s3.size; v += 8)
                            if (*(uintptr_t*)v == col) {
                                uintptr_t vt = v + 8;
                                if (InCode(*(uintptr_t*)vt)) return vt;
                            }
                    }
                }
            }
        }
    }
    return 0;
}

bool HudFlagFound() { return g_hudFlag != 0; }
void SetHudHidden(bool hide) {
    static int orig = -1;
    if (!g_hudFlag) return;
    volatile unsigned char* p = (volatile unsigned char*)g_hudFlag;
    if (orig < 0) orig = *p;
    unsigned char v = hide ? (unsigned char)(orig ? 0 : 1) : (unsigned char)orig;
    *p = v;
    LOGI("hud: game HUD %s (flag %d -> %d)", hide ? "hidden" : "shown", orig, v);
}

} // namespace game
