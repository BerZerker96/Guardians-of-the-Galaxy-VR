// Post effects off for VR: depth of field (always, gameplay and cutscenes), motion blur, radial blur, film grain.
//
// Every post filter of the game is a class ZRenderPostfilterPass<X> with a 3-slot vtable: [0] IsActive (bool), [1]
// record the pass into the render graph, [2] destructor. The post filter chain asks IsActive before each pass; it
// returns false when the effect is switched off (its global enable flag, its parameters, an orthographic camera ...),
// and the chain then routes around it - the game's own "effect off" path, as when a setting turns it off.
// The mod puts a small stub in front of IsActive: while the effect's switch is on it returns false, otherwise it
// jumps to the game's function. The classes are found by their RTTI names (no code bytes), and the switches change
// live. Found in GOTG.exe (2023-01-26): DOF exe+8DA090, HexDOF (bokeh DOF) exe+90C210, MotionBlur exe+90C2A0,
// RadialBlur exe+90C2E0, FilmGrain exe+90C0F0.
// DOF and HexDOF together are all of the game's depth of field: the gameplay DOF (the graphics setting) and the
// cutscene DOF (ZPostfilterDepthOfFieldAspect / ActivateDepthOfField) both end in these two passes.
#include <windows.h>
#include <cstdint>
#include <cstring>
#include "log.h"
#include "MinHook.h"
#include "game.h"
#include "settings.h"

struct Pass { const char* rtti; const char* name; volatile unsigned char off; void* orig; void* target; unsigned char* stub; };
static Pass g_pass[] = {
    { ".?AVZRenderPostfilterPassDOF@@", "depth of field", 1, nullptr, nullptr, nullptr },
    { ".?AVZRenderPostfilterPassHexDOF@@", "bokeh depth of field", 1, nullptr, nullptr, nullptr },
    { ".?AVZRenderPostfilterPassMotionBlur@@", "motion blur", 0, nullptr, nullptr, nullptr },
    { ".?AVZRenderPostfilterPassRadialBlur@@", "radial blur", 0, nullptr, nullptr, nullptr },
    { ".?AVZRenderPostfilterPassFilmGrain@@", "film grain", 0, nullptr, nullptr, nullptr },
};
static unsigned char* g_code = nullptr;

// mov rax, &off ; cmp byte [rax], 0 ; je +3 ; xor eax, eax ; ret ; mov rax, &orig ; jmp [rax]
// (rax only: never an argument register - the game's call is passed on untouched)
static unsigned char* MakeStub(unsigned char* at, volatile unsigned char* flag, void** orig) {
    unsigned char* p = at;
    *p++ = 0x48; *p++ = 0xB8; uint64_t f = (uint64_t)(uintptr_t)flag; memcpy(p, &f, 8); p += 8;
    *p++ = 0x80; *p++ = 0x38; *p++ = 0x00;
    *p++ = 0x74; *p++ = 0x03;
    *p++ = 0x31; *p++ = 0xC0; *p++ = 0xC3;
    *p++ = 0x48; *p++ = 0xB8; uint64_t o = (uint64_t)(uintptr_t)orig; memcpy(p, &o, 8); p += 8;
    *p++ = 0xFF; *p++ = 0x20;
    return at;
}

void PostFxApply() {
    g_pass[0].off = g_pass[1].off = g_set.dofOff ? 1 : 0;
    g_pass[2].off = g_set.motionBlurOff ? 1 : 0;
    g_pass[3].off = g_set.radialBlurOff ? 1 : 0;
    g_pass[4].off = g_set.filmGrainOff ? 1 : 0;
}

void PostFxInstall() {
    if (!g_code) g_code = (unsigned char*)VirtualAlloc(nullptr, 4096, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    if (!g_code) { LOGE("postfx: no memory for the stubs"); return; }
    PostFxApply();
    int ok = 0, i = 0;
    for (auto& ps : g_pass) {
        uintptr_t vt = game::VtableByRtti(ps.rtti);
        void* isActive = vt ? *(void**)vt : nullptr;
        if (!isActive || !game::InCode((uintptr_t)isActive)) { LOGW("postfx: %s pass not found - left as the game has it", ps.name); i++; continue; }
        ps.target = isActive;
        ps.stub = MakeStub(g_code + 64 * i, &ps.off, &ps.orig);
        if (MH_CreateHook(isActive, ps.stub, &ps.orig) == MH_OK && MH_EnableHook(isActive) == MH_OK) {
            ok++;
            LOGI("postfx: %s pass at exe+%llx (IsActive) - %s", ps.name, (unsigned long long)((uintptr_t)isActive - game::g_base), ps.off ? "OFF" : "as the game has it");
        } else LOGE("postfx: %s hook failed", ps.name);
        i++;
    }
    FlushInstructionCache(GetCurrentProcess(), g_code, 4096);
    LOGI("postfx: %d of %zu post effect switches in place", ok, sizeof g_pass / sizeof g_pass[0]);
}

void PostFxReport() {
    static int last = -1;
    int now = g_pass[0].off | (g_pass[2].off << 1) | (g_pass[3].off << 2) | (g_pass[4].off << 3);
    if (now != last) {
        last = now;
        LOGI("postfx: depth of field %s, motion blur %s, radial blur %s, film grain %s", g_pass[0].off ? "off" : "game", g_pass[2].off ? "off" : "game",
             g_pass[3].off ? "off" : "game", g_pass[4].off ? "off" : "game");
    }
}
