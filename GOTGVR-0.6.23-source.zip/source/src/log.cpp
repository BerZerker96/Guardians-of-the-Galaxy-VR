#include "modtime.h"
#include "log.h"
#include <windows.h>
#include <io.h>

static FILE* g_log = nullptr;
static CRITICAL_SECTION g_cs;
static LARGE_INTEGER g_freq, g_t0;

void LogInit(const wchar_t* path) {
    InitializeCriticalSection(&g_cs);
    ModQpf(&g_freq);
    ModQpc(&g_t0);
    g_log = _wfopen(path, L"w");
}

void LogWrite(const char* level, const char* fmt, ...) {
    if (!g_log) return;
    LARGE_INTEGER t; ModQpc(&t);
    double s = double(t.QuadPart - g_t0.QuadPart) / double(g_freq.QuadPart);
    char buf[2048];
    va_list ap; va_start(ap, fmt);
    vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    EnterCriticalSection(&g_cs);
    fprintf(g_log, "%9.3f [%s] [%5lu] %s\n", s, level, GetCurrentThreadId(), buf);
    fflush(g_log);
    LeaveCriticalSection(&g_cs);
}

void LogFlushDisk() {
    if (!g_log) return;
    EnterCriticalSection(&g_cs);
    FlushFileBuffers((HANDLE)_get_osfhandle(_fileno(g_log)));
    LeaveCriticalSection(&g_cs);
}
