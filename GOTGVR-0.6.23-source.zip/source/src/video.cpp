#include "modtime.h"
// Pre-rendered videos (Bink 2, bink2w64.dll - a static import of GOTG.exe): which videos are being decoded right now
// and how big they are. The camera code shows the flat screen while a full-size video plays and the game camera is
// frozen (a pre-rendered cutscene); small videos (in-world screens, holograms, UI) are ignored.
//
// Bink 2's BINK struct starts with U32 Width, U32 Height. The frame calls (BinkDoFrame, BinkDoFrameAsync,
// BinkDoFramePlane) take the HBINK first; one forwarding detour serves all of them (<= 4 integer arguments in
// registers, the result in rax).
#include <windows.h>
#include <cstdint>
#include "log.h"
#include "MinHook.h"
#include "game.h"

typedef uintptr_t(__fastcall* PFN_Bink4)(void*, uintptr_t, uintptr_t, uintptr_t);
static PFN_Bink4 o_DoFrame = nullptr, o_DoFrameAsync = nullptr, o_DoFramePlane = nullptr, o_Close = nullptr;

struct Vid { void* h; unsigned w, h2; volatile ULONGLONG last; };
static Vid g_vid[8];
static SRWLOCK g_vidLock = SRWLOCK_INIT;
static unsigned g_seenBig = 0;

static void Note(void* h) {
    if (!h || !game::Readable(h, 8)) return;
    unsigned w = ((unsigned*)h)[0], hh = ((unsigned*)h)[1];
    if (w < 16 || hh < 16 || w > 16384 || hh > 16384) return;
    ULONGLONG now = ModTick64();
    AcquireSRWLockExclusive(&g_vidLock);
    Vid* slot = nullptr;
    for (auto& v : g_vid) if (v.h == h) { slot = &v; break; }
    if (!slot) {
        for (auto& v : g_vid) if (!v.h || now - v.last > 5000) { slot = &v; break; }
        if (slot) { slot->h = h; slot->w = w; slot->h2 = hh; LOGI("video: Bink video %ux%u playing", w, hh); }
    }
    if (slot) { slot->w = w; slot->h2 = hh; slot->last = now; }
    ReleaseSRWLockExclusive(&g_vidLock);
}
static uintptr_t __fastcall H_DoFrame(void* h, uintptr_t a, uintptr_t b, uintptr_t c) { Note(h); return o_DoFrame(h, a, b, c); }
static uintptr_t __fastcall H_DoFrameAsync(void* h, uintptr_t a, uintptr_t b, uintptr_t c) { Note(h); return o_DoFrameAsync(h, a, b, c); }
static uintptr_t __fastcall H_DoFramePlane(void* h, uintptr_t a, uintptr_t b, uintptr_t c) { Note(h); return o_DoFramePlane(h, a, b, c); }
static uintptr_t __fastcall H_Close(void* h, uintptr_t a, uintptr_t b, uintptr_t c) {
    AcquireSRWLockExclusive(&g_vidLock);
    for (auto& v : g_vid) if (v.h == h) { v.h = nullptr; v.last = 0; }
    ReleaseSRWLockExclusive(&g_vidLock);
    return o_Close(h, a, b, c);
}

void VideoInstall() {
    HMODULE m = GetModuleHandleW(L"bink2w64.dll");
    if (!m) m = LoadLibraryW(L"bink2w64.dll");
    if (!m) { LOGW("video: bink2w64.dll not loaded - video cutscenes are not detected"); return; }
    struct { const char* n; void* d; PFN_Bink4* o; } hs[] = {
        { "BinkDoFrame", (void*)H_DoFrame, &o_DoFrame }, { "BinkDoFrameAsync", (void*)H_DoFrameAsync, &o_DoFrameAsync },
        { "BinkDoFramePlane", (void*)H_DoFramePlane, &o_DoFramePlane }, { "BinkClose", (void*)H_Close, &o_Close } };
    int ok = 0;
    for (auto& h : hs) {
        void* p = (void*)GetProcAddress(m, h.n);
        if (p && MH_CreateHook(p, h.d, (void**)h.o) == MH_OK && MH_EnableHook(p) == MH_OK) ok++;
        else if (p) LOGW("video: %s hook failed", h.n);
    }
    LOGI("video: %d Bink hooks in place (full-size videos show the flat screen)", ok);
}

// a video at least minW wide (and at least a third as high) decoded in the last 400 ms
bool VideoActive(unsigned minW) {
    ULONGLONG now = ModTick64();
    bool any = false;
    AcquireSRWLockShared(&g_vidLock);
    for (auto& v : g_vid) if (v.h && now - v.last < 400 && v.w >= minW && v.h2 * 3 >= v.w) any = true;
    ReleaseSRWLockShared(&g_vidLock);
    if (any) g_seenBig++;
    return any;
}
