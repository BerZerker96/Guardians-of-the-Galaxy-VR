#include "modtime.h"
// 100 ms housekeeping thread: hotkeys, trigger files (<game>\GOTGVR\*.trigger), periodic stats.
#include <windows.h>
#include <string>
#include <cctype>
#include <cstdlib>
#include "log.h"
#include "camera.h"
#include "config.h"
#include "settings.h"
#include "firstperson.h"

extern std::wstring g_modDir, g_gameDir;
extern volatile LONG g_presents;
void XrReport();
void XrRequestRecenter();
void XrSetMode(int mode);
void MenuNoteFps(float fps);
void MenuSetOpen(bool open);
void ScreenshotRequest();
void SettingsApplyGame();

static bool Trigger(const wchar_t* name) {
    std::wstring p = g_modDir + L"\\" + name;
    if (GetFileAttributesW(p.c_str()) == INVALID_FILE_ATTRIBUTES) return false;
    DeleteFileW(p.c_str());
    return true;
}

// "F11", "SPACE", "INSERT", "A", "5", "NONE", "0x7A" -> virtual key (0 = none)
static int KeyFromName(std::string n) {
    for (auto& c : n) c = (char)toupper((unsigned char)c);
    if (n.empty() || n == "NONE" || n == "OFF") return 0;
    if (n[0] == 'F' && n.size() >= 2 && n.size() <= 3 && isdigit((unsigned char)n[1])) { int f = atoi(n.c_str() + 1); if (f >= 1 && f <= 24) return VK_F1 + f - 1; }
    struct { const char* n; int vk; } t[] = { { "SPACE", VK_SPACE }, { "INSERT", VK_INSERT }, { "HOME", VK_HOME }, { "END", VK_END },
        { "PAGEUP", VK_PRIOR }, { "PAGEDOWN", VK_NEXT }, { "DELETE", VK_DELETE }, { "PAUSE", VK_PAUSE }, { "SCROLLLOCK", VK_SCROLL },
        { "PRINTSCREEN", VK_SNAPSHOT }, { "TAB", VK_TAB }, { "BACKSPACE", VK_BACK }, { "ENTER", VK_RETURN }, { "NUMPAD0", VK_NUMPAD0 } };
    for (auto& e : t) if (n == e.n) return e.vk;
    if (n.size() == 1 && isalnum((unsigned char)n[0])) return n[0];
    if (n.size() > 2 && n[0] == '0' && n[1] == 'X') return (int)strtol(n.c_str(), nullptr, 16);
    return 0;
}

// keys, polled every 5 ms, only while the game window is in front
static DWORD WINAPI KeyThread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_ABOVE_NORMAL);
    int vkRec = KeyFromName(g_set.recenterKey), vkShot = KeyFromName(g_set.screenshotKey), vkFp = KeyFromName(g_set.fpKey);
    if (vkRec == VK_F9) vkRec = 0;   // F9 recentres anyway
    LOGI("keys: recentre %s + F9, screenshot %s (left eye, PNG next to GoTG.exe), first person %s, F8 mode, F7 game HUD, F6 flat screen, Insert menu",
         g_set.recenterKey.c_str(), g_set.screenshotKey.c_str(), g_set.fpKey.c_str());
    int vk[7] = { VK_F8, VK_F9, vkRec, vkShot, VK_F7, VK_F6, vkFp }; bool was[7] = {};
    for (int i = 2; i < 7; i++) for (int j = 0; j < i; j++) if (vk[i] && vk[i] == vk[j] && !(i == 2 && j == 1)) {
        LOGW("keys: %s is used twice - the second use is off", i == 2 ? "recenter_key" : i == 3 ? "screenshot_key" : i == 6 ? "fp_key" : "a key"); vk[i] = 0; }
    for (;;) {
        Sleep(5);
        DWORD pid = 0; GetWindowThreadProcessId(GetForegroundWindow(), &pid);
        bool fg = pid == GetCurrentProcessId();
        for (int i = 0; i < 7; i++) {
            bool d = fg && vk[i] && (GetAsyncKeyState(vk[i]) & 0x8000);
            if (d && !was[i]) {
                if (i == 0) XrSetMode(g_cam.mode == VRMODE_SYNCED ? VRMODE_RECON : g_cam.mode == VRMODE_RECON ? VRMODE_STEREO : g_cam.mode == VRMODE_STEREO ? VRMODE_HEAD :
                                      g_cam.mode == VRMODE_HEAD ? VRMODE_SCREEN : VRMODE_SYNCED);
                else if (i == 1 || i == 2) XrRequestRecenter();
                else if (i == 3) ScreenshotRequest();
                else if (i == 5) { g_cam.flatHold = !g_cam.flatHold; LOGI("keys: flat screen %s (F6)", g_cam.flatHold ? "held" : "released"); }
                else if (i == 6) fp::Toggle();
                else { g_set.hideHud = !g_set.hideHud; SettingsApplyGame(); }
            }
            was[i] = d;
        }
    }
}

void ModTick() {
    static bool keys = false;
    if (!keys) { keys = true; CreateThread(nullptr, 0, KeyThread, nullptr, 0, nullptr); }
    static DWORD last = (DWORD)ModTick64();
    static LONG lastPresents = 0;
    if (Trigger(L"mode_head.trigger")) XrSetMode(VRMODE_HEAD);
    if (Trigger(L"mode_screen.trigger")) XrSetMode(VRMODE_SCREEN);
    if (Trigger(L"mode_stereo.trigger")) XrSetMode(VRMODE_STEREO);
    if (Trigger(L"mode_synced.trigger")) XrSetMode(VRMODE_SYNCED);
    if (Trigger(L"mode_recon.trigger")) XrSetMode(VRMODE_RECON);
    if (Trigger(L"recenter.trigger")) XrRequestRecenter();
    if (Trigger(L"flat_hold.trigger")) g_cam.flatHold = !g_cam.flatHold;
    if (Trigger(L"first_person.trigger")) fp::Toggle();
    if (Trigger(L"screenshot.trigger")) ScreenshotRequest();
    if (Trigger(L"menu_open.trigger")) MenuSetOpen(true);
    if (Trigger(L"menu_close.trigger")) MenuSetOpen(false);
    DWORD now = (DWORD)ModTick64();
    if (now - last >= 10000) {
        LONG p = g_presents;
        float fps = (float)((p - lastPresents) * 1000.0 / (now - last));
        LOGI("stats: %.1f presents/s (%.1f per eye in stereo)", fps, (IsStereoMode(g_cam.mode) && g_cam.mode != VRMODE_RECON) ? fps * 0.5f : fps);
        MenuNoteFps(fps);
        lastPresents = p; last = now;
        XrReport();
    }
}
