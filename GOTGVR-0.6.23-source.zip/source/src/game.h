#pragma once
// Marvel's Guardians of the Galaxy (GOTG.exe, Eidos-Montreal Dawn engine = the Deus Ex: Mankind Divided engine,
// D3D12, x64). Everything is located by byte pattern at run time and checked before use; a build where a pattern does
// not match turns that feature off instead of crashing. Addresses in comments are RVAs of the Steam exe of
// 2023-01-26 (link date 0x63D20AF5, the build IGCS GotGCameraTools 1.0.2 targets).
#include <windows.h>
#include <cstdint>

namespace game {

extern uintptr_t g_base;
extern size_t g_size;

bool Init(bool quiet = false);      // false: code not readable yet - call again later
bool InCode(uintptr_t a);
bool Readable(const void* p, size_t n);
void ReadableStats(long long& calls, long long& hits);   // VirtualQuery calls / cache hits since the last call

// --- ZRenderGraphNodeCamera (render side camera, RTTI .?AVZRenderGraphNodeCamera@@, vtable exe+2571C98) ----------
// slot 9 = per-frame view update (exe+990CB0; rcx = node, r8 = view being built). Same function as DXMD's
// exe+5A5FC0. It builds the view (and culling) from the node's own copy of the camera transform:
//   node+0x24  SMatrix43: rows right / up / back (camera looks along -z) + translation, 12 floats  (DXMD: same)
//   node+0xC0  4x4 projection, row-vector right-handed D3D form ([11] = -1)                    (DXMD: +0xB0)
//   node+0x1A8 / +0x1AC  render width / height (TAA jitter scale)
//   node+0x1D0 / +0x1D4  near / far
// projection getter exe+972270 (node, float out[16], bool keepDepth): copies node+0xC0, rebuilds the depth rows
// (rows 2/3, which ZEROES the off-axis terms [8] / [9]) and adds the TAA jitter (exe+979FE0) to [8] / [9].
extern void* g_nodeUpdate;
extern void* g_getProj;
extern uintptr_t kNodeTransform, kNodeProj, kNodeW, kNodeH;

// --- patches (from Otis_Inf's IGCS GotGCameraTools 1.0.2 AOBs, same sites) ------------------------------------------
bool ApplyExactRenderSize(bool on);   // 0.6.15: no rounding of the internal render size down to 64 px
bool ApplyNoBlackBars(bool on);          // cutscene letter- / pillarbox (exe+960D7F, exe+960DD5: jbe -> jmp)
bool ApplyRunInBackground(bool on);      // "Win32 Gameloop Pause" / OnGameLostFocus skipped (exe+CBC2F je -> jmp)
bool HudFlagFound();
void SetNearClip(float units);
uintptr_t VtableByRtti(const char* typeName);
uintptr_t Scan(const char* name, const char* pattern);   // unique byte pattern in the main code section, 0 = none / ambiguous
bool InCode(uintptr_t a);   // vtable of a class by its MSVC RTTI name, 0 = not found          // 0 = the game's near plane
extern volatile float* g_nearOverride;

// --- game clock (synchronized-sequential stereo) ---------------------------------------------------------------
// exe+42E890 TimerUpdate(timer, bool paused): the per-frame game clock step, called once a frame by the main loop
// (exe+D23C0) for the game timer exe+3C2CDF8 (the struct IGCS's timestop / game speed works on):
//   +0x20 time, +0x28 previous time, +0x30 delta, +0x38 previous delta, +0x50 raw frame delta, +0x68 / +0x6C speed
//   scales, +0x78 "updated this frame" guard. delta = speed x raw >> 20, time += delta.
extern void* g_timerUpdate;
extern uintptr_t g_gameTimer;
// --- TAA: exe+305A116 = the renderer's "temporal AA / jitter on" flag (read by the jitter exe+979FE0 and the
// projection exe+97262B). Kept at 0 only with game_aa = off.
extern volatile unsigned char* g_taaFlag;
void SetHudHidden(bool hide);            // the game's HUD flag (exe+BD5619 movzx eax, byte [flag])

// --- render options: the game's option table (exe+3DE1C70, ids: 0x4BE AntiAliasing, 0x51B DynResType = upscaling /
// dynamic resolution (0 off), 0x51A ResScale in %). Set through the game's own setters on the game thread, as its
// options menu does; the PC settings block (exe+3E603A0) is only read, never written, so nothing is saved.
bool RenderOptionsFound();
void RenderOptionsLog();
void RenderOptionsApply(bool native, int aa);   // native: upscaling off + 100 %; aa: -1 the game's own, 0 off, 1 on

} // namespace game
