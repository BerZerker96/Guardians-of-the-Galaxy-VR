#pragma once
#define GOTGVR_VERSION "0.6.23-alpha"
