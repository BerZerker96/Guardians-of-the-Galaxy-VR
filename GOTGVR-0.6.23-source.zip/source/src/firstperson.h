#pragma once
#include "vrmath.h"

// First person (End key): the VR camera sits in Star-Lord's head instead of behind his shoulder. See firstperson.cpp.
namespace fp {
void Install();                          // after game::Init: signatures, RTTI
bool Available();                        // everything needed was found
void GameTick();                         // game thread, once per frame (the game clock hook)
// render thread: `cam` (the game camera after decoupled pitch) -> the eye base at the head. false = not now (first
// person off, player not found, a cutscene / scripted camera): use `cam`.
bool EyeBase(const Frame& cam, Frame& out);
void Toggle();
const char* Status();                    // one line for the menu / log
void Report();
} // namespace fp
