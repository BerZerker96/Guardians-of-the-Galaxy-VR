#include "modtime.h"
// GOTGVR - Marvel's Guardians of the Galaxy VR mod (built on DXMDVR, the Deus Ex: Mankind Divided VR mod: same Dawn
// engine). Loaded as winmm.dll (the game imports it, so the copy next to GOTG.exe is loaded first) or GOTGVR.asi
// through an ASI loader.
#include <windows.h>
#include <psapi.h>
#include <string>
#include "log.h"
#include "config.h"
#include "MinHook.h"
#include "game.h"
#include "settings.h"
#include "firstperson.h"
#include "version.h"

void ProxyLoad(HMODULE self);
extern std::wstring g_proxyName;

std::wstring g_gameDir;      // folder of GOTG.exe
std::wstring g_modDir;       // <game>\GOTGVR (host, logs, triggers)
HMODULE g_self = nullptr;

static LONG WINAPI CrashFilter(EXCEPTION_POINTERS* ep) {
    auto* er = ep->ExceptionRecord; auto* c = ep->ContextRecord;
    HMODULE m = nullptr; char mod[MAX_PATH] = "?";
    if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,
                           (LPCSTR)er->ExceptionAddress, &m)) GetModuleFileNameA(m, mod, MAX_PATH);
    LOGE("CRASH code %08lx at %p (%s+%llx)", er->ExceptionCode, er->ExceptionAddress, strrchr(mod, '\\') ? strrchr(mod, '\\') + 1 : mod,
         (unsigned long long)((char*)er->ExceptionAddress - (char*)m));
    LOGE("  rax %llx rbx %llx rcx %llx rdx %llx rsi %llx rdi %llx rbp %llx rsp %llx", c->Rax, c->Rbx, c->Rcx, c->Rdx, c->Rsi, c->Rdi, c->Rbp, c->Rsp);
    uintptr_t* sp = (uintptr_t*)c->Rsp; int n = 0;
    for (int i = 0; i < 1024 && n < 16; i++) {
        if (!game::Readable(sp + i, 8)) break;
        uintptr_t v = sp[i];
        if (game::g_base && v >= game::g_base + 0x1000 && v < game::g_base + game::g_size) { LOGE("  stack+%04x exe+%llx", i * 8, (unsigned long long)(v - game::g_base)); n++; }
        else {
            HMODULE mm = nullptr;
            if (GetModuleHandleExA(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS | GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT, (LPCSTR)v, &mm) && mm == g_self) {
                LOGE("  stack+%04x gotgvr+%llx", i * 8, (unsigned long long)(v - (uintptr_t)g_self)); n++;
            }
        }
    }
    LogFlushDisk();
    return EXCEPTION_CONTINUE_SEARCH;
}

void D3DHooksInstall();
bool CameraInstall();
void ModTick();
void ResolutionStart();
void SettingsApplyGame();

static DWORD WINAPI FlushThread(LPVOID) {
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_BELOW_NORMAL);
    for (;;) { Sleep(1000); LogFlushDisk(); }
}

static bool g_gamePending = false;
// the swap-chain hooks, once: from the first game factory call (dxgi.dll proxy) or the init thread, whichever is first
static SRWLOCK g_d3dHookLock = SRWLOCK_INIT; static bool g_d3dHooked = false, g_modReady = false;
static thread_local bool t_inHookInstall = false;
static void D3DHooksOnce() {
    // re-entrant on the installing thread: the install creates a D3D12 device, and d3d12 makes a DXGI factory of its
    // own - that call comes back here through the dxgi.dll proxy (it must not wait for the lock this thread holds)
    if (t_inHookInstall) return;
    t_inHookInstall = true;
    AcquireSRWLockExclusive(&g_d3dHookLock);
    if (!g_d3dHooked) { g_d3dHooked = true; D3DHooksInstall(); }
    ReleaseSRWLockExclusive(&g_d3dHookLock);
    t_inHookInstall = false;
}
void ProxyBeforeFactory() { if (g_modReady) D3DHooksOnce(); }
static DWORD WINAPI InitThread(LPVOID) {
    D3DHooksOnce();
    if (g_gamePending) {   // a protected build may decrypt its code after the loader ran us
        DWORD t0 = (DWORD)ModTick64(); bool ok = false;
        for (int i = 0; (DWORD)ModTick64() - t0 < 120000; i++) { Sleep(50); if (game::Init(true)) { ok = true; break; } if (i & 1) ModTick(); }
        if (ok) { LOGI("game: code readable after %lu ms", (DWORD)ModTick64() - t0); SettingsApplyGame(); }
        else LOGE("game: the code never became readable - VR camera and game patches off");
        g_gamePending = false;
        if (!ok) { for (;;) { Sleep(100); ModTick(); } }
    }
    CreateThread(nullptr, 0, [](LPVOID) -> DWORD {   // another camera mod moving the same camera fights the VR pose
        Sleep(15000);
        HMODULE mods[512]; DWORD need = 0;
        if (EnumProcessModules(GetCurrentProcess(), mods, sizeof mods, &need))
            for (DWORD i = 0; i < need / sizeof(HMODULE) && i < 512; i++) {
                wchar_t n[MAX_PATH]; if (!GetModuleBaseNameW(GetCurrentProcess(), mods[i], n, MAX_PATH)) continue;
                for (wchar_t* c = n; *c; c++) *c = towlower(*c);
                if (wcsstr(n, L"headtracking") || wcsstr(n, L"opentrack") || wcsstr(n, L"gotgcameratools") || wcsstr(n, L"igcs"))
                    LOGE("CONFLICT: %ls is loaded - another camera mod also moves the game camera. Remove it while using GOTGVR.", n);
            }
        return 0;
    }, nullptr, 0, nullptr);
    if (ConfigBool("camera_hooks", true)) CameraInstall(); else LOGI("camera: hooks off (camera_hooks = false)");
    { extern void VideoInstall(); if (ConfigBool("video_hooks", true)) VideoInstall(); }
    { extern void PostFxInstall(); if (ConfigBool("postfx_hooks", true)) PostFxInstall(); }
    if (ConfigBool("first_person_hooks", true)) fp::Install(); else LOGI("firstperson: off (first_person_hooks = false)");
    for (;;) { Sleep(100); ModTick(); }
}

static const char* kDefaultConfig =
    "# Guardians of the Galaxy VR (GOTGVR) settings. Lines: key = value. Delete this file to get the defaults back.\n"
    "# Most of these are also in the in-headset menu (Insert, or hold L3 + R3 on an Xbox pad).\n"
    "\n"
    "# synced = 3D, both eyes drawn from the SAME game tick (UEVR's synchronized sequential: the game clock is held\n"
    "#          for the second eye; world motion updates every second frame)\n"
    "# recon  = 3D, stereo reconstruction: one eye drawn per frame, the other reconstructed from that frame's picture\n"
    "#          and depth - both eyes new every frame, the same moment, full frame rate\n"
    "# aer    = 3D, alternate-eye rendering: one eye per game frame, every frame a new game tick\n"
    "# head   = head-tracked single image, screen = flat virtual screen. F8 cycles them.\n"
    "vr_mode = synced\n"
    "# synced: pair = the headset gets both eyes of a tick together | each = every eye as soon as it is drawn\n"
    "sync_submit = pair\n"
    "# synced: render frames behind the game clock: -1 = automatic, 0..2 = fixed\n"
    "sync_lag = -1\n"
    "recon_gap_reach = 132\n"
    "# recon: 1 = tint the hidden areas, 2 = picture grey and the UI in colour\n"
    "recon_debug = 0\n"
    "\n"
    "# flat virtual screen while the game is paused (pause menu, settings, map, gear ...; photo mode stays 3D once\n"
    "# its camera moves) and for pre-rendered video cutscenes at least flat_video_min_width wide. F6 holds the flat\n"
    "# screen. Title and loading screens (no 3D view) are always flat.\n"
    "flat_pause_menus = true\n"
    "flat_videos = true\n"
    "flat_video_min_width = 1280\n"
    "\n"
    "# start the game directly, without its launcher window (adds -nolauncher)\n"
    "skip_launcher = true\n"
    "# always windowed (the game's Fullscreen / Exclusive Fullscreen settings are read as off, nothing is written):\n"
    "# the window, and the rendering, become the headset's per-eye size and shape - beyond the monitor if needed\n"
    "force_windowed = true\n"
    "\n"
    "# per-eye render size and shape: auto = whatever headset you use - its recommended size and shape x render_scale (read from the VR runtime at start),\n"
    "# WxH (e.g. 2400x2400), or game (keep the window size)\n"
    "render_resolution = auto\n"
    "render_scale = 1.00\n"
    "render_max_side = 8192\n"
    "\n"
    "world_scale = 1.00\n"
    "units_per_metre = 1.0\n"
    "\n"
    "# stereo\n"
    "swap_eyes = false\n"
    "# Presents between a frame's camera setup and its Present: 0 = automatic. Try 1 if both eyes look the same.\n"
    "aer_frame_delay = 0\n"
    "ipd_scale = 1.00\n"
    "# the older eye is turned with the game camera by the host (test option)\n"
    "camera_reprojection = false\n"
    "cull_margin = 1.10\n"
    "\n"
    "# camera: decoupled_pitch keeps the horizon level (your head pitches the view); offsets in metres\n"
    "decoupled_pitch = true\n"
    "# game camera shake / bob filter (0 off .. 1 strong); your head is never filtered\n"
    "camera_stabilize = 0.35\n"
    "# metres the game still draws in front of your eyes (0 = the game's own, 0.05-0.15); lower = lean closer before things are cut\n"
    "near_clip = 0.05\n"
    "camera_offset_x = 0.00\n"
    "camera_offset_y = 0.00\n"
    "camera_offset_z = 0.00\n"
    "# rows of the render camera matrix that are right, up, back (only change if head movement goes the wrong way)\n"
    "camera_axes = +0+1+2\n"
    "\n"
    "# first person (fp_key, End): the camera in Star-Lord's head. fp_offset_* = metres from the head bone (right, up,\n"
    "# forward) - first person only; camera_offset_* above are third person only. fp_smooth = head bob filter (0..1),\n"
    "# fp_hide_body hides the body while in his head, fp_max_distance: a game camera farther away = cutscene (waits)\n"
    "first_person = false\n"
    "fp_offset_x = -0.75\n"
    "fp_offset_y = 0.22\n"
    "fp_offset_z = -0.45\n"
    "fp_smooth = 0.60\n"
    "fp_hide_body = true\n"
    "fp_max_distance = 6.0\n"
    "\n"
    "# UI: eyes = moved onto each eye's centre of view, scaled by ui_scale, at ui_depth metres | flat = kept in the picture's middle, scaled by ui_scale\n"
    "ui_mode = flat\n"
    "ui_scale = 0.42\n"
    "ui_depth = 1.3\n"
    "ui_offset_y = -0.03\n"
    "# where the UI starts in the final image: auto | count (after hud_scene_draws draws) | all\n"
    "hud_split = all\n"
    "hud_scene_draws = 1\n"
    "hide_hud = false\n"
    "no_black_bars = true\n"
    "run_in_background = true\n"
    "\n"
    "# fps_limit: headset = at most the headset's own refresh rate - never the half rate motion smoothing / ASW runs the\n"
    "# app at (kept per headset in GOTGVR\\refresh.txt) | a number | 0 = off\n"
    "# post effects: depth of field off everywhere (gameplay and cutscenes), motion blur, radial (dash / sprint) blur,\n"
    "# film grain - true = off\n"
    "dof_off = true\n"
    "motion_blur_off = true\n"
    "radial_blur_off = true\n"
    "film_grain_off = true\n"
    "fps_limit = headset\n"
    "# true = no frame cap at all: the game runs beyond the headset's refresh rate (the newest frame is shown)\n"
    "fps_unlocked = false\n"
    "# the headset's refresh rate if it is reported wrongly (0 = automatic)\n"
    "headset_refresh_hz = 0\n"
    "# headset_smoothing - none of them ever slows the game, which always runs at the headset's full rate:\n"
    "# full = a fresh image every headset frame, never late: the headset's motion smoothing (Pimax Smart Smoothing,\n"
    "# SteamVR Motion Smoothing, Meta ASW, Virtual Desktop SSW, WMR, OpenXR Toolkit) never switches on;\n"
    "# runtime = when the game is slower than the headset, the headset's own smoothing fills in; repeat = newest frame\n"
    "headset_smoothing = full\n"
    "paced_timeout_ms = 100\n"
    "vsync_off = true\n"
    "sharpen = 0.00\n"
    "# HDR output of the game is converted to SDR for the headset: auto | off | pq | scrgb (HDR off in the game is better)\n"
    "hdr_input = off\n"
    "hdr_paper_white = 200\n"
    "# monitor: left = the left eye only (no flicker) | game = what the game draws (alternates)\n"
    "mirror = left\n"
    "# frames the CPU may queue ahead of the GPU (1-2 = freshest head pose; 0 = the game's own)\n"
    "max_frame_latency = 2\n"
    "# fixed foveated rendering (D3D12 VRS tier 2): off | quality | balanced | performance | custom\n"
    "fov_mode = off\n"
    "\n"
    "# flat screen (screen mode, loading screens, videos) and the VR menu panel\n"
    "screen_distance = 2.7\n"
    "screen_width = 3.1\n"
    "menu_distance = 1.05\n"
    "menu_panel_width = 1.10\n"
    "menu_width = 0.80\n"
    "menu_opacity = 0.8\n"
    "recenter_key = SPACE\n"
    "# Delete: the left eye as the headset shows it, PNG next to GoTG.exe (screenshot_view = headset | full)\n"
    "screenshot_key = DELETE\n"
    "screenshot_view = headset\n"
    "fp_key = END\n"
    "\n"
    "# troubleshooting\n"
    "camera_hooks = true\n"
    "ui_hooks = true\n"
    "xr_output = true\n"
    "config_version = 9\n"
    "\n"
    "# more settings (all of them are in the VR panel)\n"
    "fov_inner = 0.60\n"
    "fov_outer = 1.00\n"
    "fov_wide = 1.25\n"
    "fov_debug = false\n"
    "panel_layers = auto\n"
    "\n"
    "game_aa = game\n"
    "game_upscaling = game\n"
    "render_density = headset\n"
    "\n"
    "offset_step_cm = 15\n"
    "\n"
    "ui_pick = 0\n"
    "\n"
    "recon_depth = auto\n"
    "recon_parallax = 1.00\n"
    "recon_align_h = 0.0\n"
    "recon_align_v = 0.0\n"
    "aer_align_h = 0.0\n"
    "aer_align_v = 0.0\n"
    "view_width = 1.00\n"
    "view_height = 1.00\n"
    "\n"
    "exact_render_size = true\n"
    "edge_fill = true\n"
    "\n"
    "symmetric_view = false\n"
    "ui_layers = one\n"
    "\n"
    "camera_settle = 1.00\n"
    "wide_cull = true\n";

static void SchedulingTweaks() {
    // VR: the game window does not have focus (the headset software has it) - no EcoQoS / power throttling for it
    typedef BOOL(WINAPI * PFN_SPI)(HANDLE, int, LPVOID, DWORD);
    PFN_SPI spi = (PFN_SPI)GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "SetProcessInformation");
    struct { ULONG Version, ControlMask, StateMask; } pt = { 1, 1, 0 };
    bool eco = spi && spi(GetCurrentProcess(), 4 /* ProcessPowerThrottling */, &pt, sizeof pt);
    LOGI("cpu: power throttling %s", eco ? "off" : "unchanged");
}

static void Init() {
    wchar_t exe[MAX_PATH]; GetModuleFileNameW(nullptr, exe, MAX_PATH);
    g_gameDir = exe; g_gameDir = g_gameDir.substr(0, g_gameDir.find_last_of(L'\\'));
    g_modDir = g_gameDir + L"\\GOTGVR";
    CreateDirectoryW(g_modDir.c_str(), nullptr);
    LogInit((g_modDir + L"\\gotgvr.log").c_str());
    std::wstring cfg = g_gameDir + L"\\gotgvr_config.txt";
    if (GetFileAttributesW(cfg.c_str()) == INVALID_FILE_ATTRIBUTES) {
        HANDLE f = CreateFileW(cfg.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, 0, nullptr);
        if (f != INVALID_HANDLE_VALUE) { DWORD w; WriteFile(f, kDefaultConfig, (DWORD)strlen(kDefaultConfig), &w, nullptr); CloseHandle(f); }
    }
    ConfigLoad(cfg.c_str());
    int cfgVer = ConfigInt("config_version", 1);
    if (cfgVer < 9) {   // 0.6.3: stereo reconstruction is the default; 0.6.4: recon draws the left eye (game TAA kept)
        std::string txt; char b[4096]; size_t n;
        if (FILE* f = _wfopen(cfg.c_str(), L"rb")) { while ((n = fread(b, 1, sizeof b, f)) > 0) txt.append(b, n); fclose(f); }
        auto setKey = [&](const char* key, const char* val) {
            size_t p = 0; std::string k = key;
            while ((p = txt.find(k, p)) != std::string::npos) {
                bool lineStart = p == 0 || txt[p - 1] == '\n';
                size_t e = txt.find('\n', p); if (e == std::string::npos) e = txt.size();
                size_t eq = txt.find('=', p);
                if (lineStart && eq != std::string::npos && eq < e && txt.find_first_not_of(" \t", p + k.size()) == eq) {
                    std::string line = k + " = " + val; if (e > 0 && txt[e - 1] == '\r') line += '\r';
                    txt.replace(p, e - p, line); return true;
                }
                p = e;
            }
            txt += std::string("\n") + key + " = " + val + "\n"; return false;
        };
        if (cfgVer < 2) { setKey("vr_mode", "recon"); LOGI("config: stereo reconstruction is now the default stereo method (vr_mode = recon)"); }
        // 0.6.5: the mod changes no game effect on its own - the old automatic switches go back to the game's
        if (cfgVer < 4) {
            setKey("motion_blur_off", "false"); setKey("radial_blur_off", "false");
            LOGI("config: updated to version 4 - motion blur / radial blur back to the game's own setting; anti-aliasing and upscaling are only changed when you choose game_aa / game_upscaling");
        }
        // 0.6.8: reconstruction draws the head-centre view (0.6.4 had set "left" once)
        if (cfgVer < 5 && ConfigStr("recon_eye", "left") == std::string("left")) { setKey("recon_eye", "centre"); LOGI("config: recon_eye left -> centre (the faster centre view)"); }
        // 0.6.8: UI scale default 60 % (an untouched old default 0.62 follows)
        if (cfgVer < 5 && fabsf(ConfigFloat("ui_scale", 0.62f) - 0.62f) < 0.001f) { setKey("ui_scale", "0.60"); LOGI("config: ui_scale 0.62 (the old default) -> 0.60"); }
        // 0.6.9: the per-eye reconstruction views (left / alternate) showed misaligned eyes on canted headsets - the
        // centre view (both eyes rebuilt, each with its own orientation) is used; left / alternate stay selectable
        if (cfgVer < 6 && ConfigStr("recon_eye", "centre") != std::string("centre")) { setKey("recon_eye", "centre"); LOGI("config: recon_eye -> centre (both eyes rebuilt from the head-centre view: aligned)"); }
        // 0.6.14: picture width / height were set above 1 to make up for the game's own field of view leaking into the
        // render (fixed now: the node projection carries the headset's) - kept above 1 they would squeeze the picture
        if (cfgVer < 7 && (fabsf(ConfigFloat("view_width", 1.f) - 1.f) > 0.001f || fabsf(ConfigFloat("view_height", 1.f) - 1.f) > 0.001f)) {
            setKey("view_width", "1.00"); setKey("view_height", "1.00");
            LOGI("config: picture width / height back to 1.00 (the game's field of view no longer leaks into the picture - the old setting would squeeze it)");
        }
        // 0.6.16: the per-eye (asymmetric) frustum made the engine's culling pop objects / shading at the outer sides
        if (cfgVer < 8 && !ConfigBool("symmetric_view", true)) { setKey("symmetric_view", "true"); LOGI("config: symmetric_view -> true (objects and shading no longer pop in at the sides)"); }
        // 0.6.17: symmetric view rendered 1.4x wider than the headset (slow) - off again, wide_cull fixes the side pop-in
        if (cfgVer < 9 && ConfigBool("symmetric_view", false)) { setKey("symmetric_view", "false"); LOGI("config: symmetric_view -> false (headset size again; wide_cull stops the side pop-in)"); }
        // 0.6.17: the UI picker only lists full-screen layers now - an old number points at something else
        if (cfgVer < 9 && ConfigInt("ui_pick", 0) != 0) { setKey("ui_pick", "0"); setKey("ui_pick_sig", ""); LOGI("config: ui_pick -> 0 (automatic: every full-screen UI layer is scaled; the picker list changed)"); }
        setKey("config_version", "9");
        if (FILE* f = _wfopen(cfg.c_str(), L"wb")) { fwrite(txt.data(), 1, txt.size(), f); fclose(f); }
        ConfigLoad(cfg.c_str());
    }
    char pn[64]; WideCharToMultiByte(CP_UTF8, 0, g_proxyName.c_str(), -1, pn, 64, nullptr, nullptr);
    LOGI("GOTGVR %s loaded as %s (pid %lu)", GOTGVR_VERSION, pn, GetCurrentProcessId());
    SetUnhandledExceptionFilter(CrashFilter);
    if (MH_Initialize() != MH_OK) LOGE("MH_Initialize failed");
    SettingsLoad();
    { extern void SettingsApplyCamera(); extern void XrSetMode(int); SettingsApplyCamera();
      extern int ModeFromString(const std::string&); XrSetMode(ModeFromString(g_set.vrMode)); }
    { extern void StartupInstall(); StartupInstall(); }   // before the exe's CRT reads the command line / settings
    SchedulingTweaks();
    if (game::Init()) SettingsApplyGame(); else g_gamePending = true;
    ResolutionStart();
    CreateThread(nullptr, 0, FlushThread, nullptr, 0, nullptr);
    g_modReady = true;   // from here a game factory call installs the D3D hooks itself
    CreateThread(nullptr, 0, InitThread, nullptr, 0, nullptr);
}

BOOL WINAPI DllMain(HINSTANCE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        g_self = h;
        DisableThreadLibraryCalls(h);
        ProxyLoad(h);
        wchar_t exe[MAX_PATH]; GetModuleFileNameW(nullptr, exe, MAX_PATH);
        const wchar_t* base = wcsrchr(exe, L'\\'); base = base ? base + 1 : exe;
        if (_wcsicmp(base, L"gotg.exe") != 0) return TRUE;   // other processes (launcher, the VR host): proxy only
        wchar_t mx[64]; wsprintfW(mx, L"Local\\GOTGVR_%lu", GetCurrentProcessId());
        HANDLE m = CreateMutexW(nullptr, TRUE, mx);
        if (m && GetLastError() == ERROR_ALREADY_EXISTS) return TRUE;
        Init();
    }
    return TRUE;
}
