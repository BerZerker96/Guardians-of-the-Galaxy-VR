#include <windows.h>
#include <cstdio>
// what the MSVC CRT start-up of GOTG.exe does after all DLLs are initialised: ucrtbase builds argv from its command line
int main() {
    timeGetTime();
    HMODULE u = LoadLibraryW(L"ucrtbase.dll");
    typedef int(__cdecl * PC)(int); typedef int* (__cdecl * PI)(); typedef char*** (__cdecl * PV)(); typedef char* (__cdecl * PW)();
    PC conf = (PC)GetProcAddress(u, "_configure_narrow_argv"); PI pc = (PI)GetProcAddress(u, "__p___argc"); PV pv = (PV)GetProcAddress(u, "__p___argv");
    PW wm = (PW)GetProcAddress(u, "_get_narrow_winmain_command_line");
    int r = conf ? conf(1) : -1;
    printf("ucrt _configure_narrow_argv %d, argc %d:", r, pc ? *pc() : -1);
    if (pv) for (int i = 0; i < *pc(); i++) printf(" [%s]", (*pv())[i]);
    printf("\nWinMain command line: [%s]\n", wm ? wm() : "?");
    return 0;
}
