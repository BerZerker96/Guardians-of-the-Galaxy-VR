// startup.cpp under Wine: -nolauncher reaches every way the game can read its command line, and the game's
// Fullscreen / ExclusiveFullscreen registry values read as 0 (only under "Eidos Montreal", nothing written).
#include <windows.h>
#include <shellapi.h>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include "MinHook.h"
#include "settings.h"
void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
VrSettings g_set;
void StartupInstall();
static int bad = 0;
static void Check(bool c, const char* w) { printf("%-4s %s\n", c ? "OK" : "FAIL", w); if (!c) bad++; }
static DWORD ReadW(HKEY k, const wchar_t* n, LSTATUS* rs = nullptr) { DWORD v = 777, t = 0, cb = 4; LSTATUS r = RegQueryValueExW(k, n, nullptr, &t, (BYTE*)&v, &cb); if (rs) *rs = r; return v; }
static DWORD ReadA(HKEY k, const char* n) { DWORD v = 777, t = 0, cb = 4; RegQueryValueExA(k, n, nullptr, &t, (BYTE*)&v, &cb); return v; }
int main() {
    MH_Initialize();
    HKEY k, o; DWORD one = 1;
    RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\Eidos Montreal\\GOTGVR Test\\Graphics", 0, nullptr, 0, KEY_ALL_ACCESS, nullptr, &k, nullptr);
    RegCreateKeyExW(HKEY_CURRENT_USER, L"Software\\GOTGVR Other", 0, nullptr, 0, KEY_ALL_ACCESS, nullptr, &o, nullptr);
    RegSetValueExW(k, L"Fullscreen", 0, REG_DWORD, (BYTE*)&one, 4); RegSetValueExW(k, L"FullscreenWidth", 0, REG_DWORD, (BYTE*)&one, 4);
    RegDeleteValueW(k, L"ExclusiveFullscreen");
    RegSetValueExW(o, L"Fullscreen", 0, REG_DWORD, (BYTE*)&one, 4);
    Check(ReadW(k, L"Fullscreen") == 1, "before: Fullscreen = 1");
    StartupInstall();
    // command line
    Check(wcsstr(GetCommandLineW(), L" -nolauncher") != nullptr, "GetCommandLineW has -nolauncher");
    Check(strstr(GetCommandLineA(), " -nolauncher") != nullptr, "GetCommandLineA has -nolauncher");
    typedef char** (__cdecl * PA)(); HMODULE u = GetModuleHandleW(L"ucrtbase.dll"); if (!u) u = LoadLibraryW(L"ucrtbase.dll");
    PA pa = u ? (PA)GetProcAddress(u, "__p__acmdln") : nullptr;
    printf("     ucrtbase _acmdln: %s\n", pa && pa() && *pa() ? *pa() : "(n/a)");
    int argc = 0; wchar_t** argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    Check(argc >= 2 && !wcscmp(argv[argc - 1], L"-nolauncher"), "argv ends with -nolauncher");
    // registry
    LSTATUS r;
    Check(ReadW(k, L"Fullscreen") == 0, "game key Fullscreen = 1 -> 0 (W)");
    Check(ReadA(k, "Fullscreen") == 0, "game key Fullscreen -> 0 (A)");
    Check(ReadW(k, L"ExclusiveFullscreen", &r) == 0 && r == ERROR_SUCCESS, "missing ExclusiveFullscreen -> 0 (first start)");
    Check(ReadW(k, L"FullscreenWidth") == 1, "other values untouched");
    Check(ReadW(o, L"Fullscreen") == 1, "non-game key untouched");
    DWORD v = 5, cb = 4; RegGetValueW(HKEY_CURRENT_USER, L"Software\\Eidos Montreal\\GOTGVR Test\\Graphics", L"Fullscreen", RRF_RT_REG_DWORD, nullptr, &v, &cb);
    Check(v == 0, "RegGetValueW -> 0");
    HKEY k2; RegOpenKeyExW(HKEY_CURRENT_USER, L"Software\\Eidos Montreal\\GOTGVR Test\\Graphics", 0, KEY_READ, &k2);
    MH_DisableHook(MH_ALL_HOOKS);
    Check(ReadW(k2, L"Fullscreen") == 1, "nothing written: the stored value is still 1");
    RegCloseKey(k); RegCloseKey(o); RegCloseKey(k2);
    RegDeleteTreeW(HKEY_CURRENT_USER, L"Software\\Eidos Montreal\\GOTGVR Test"); RegDeleteTreeW(HKEY_CURRENT_USER, L"Software\\GOTGVR Other");
    printf(bad ? "%d FAILED\n" : "all passed\n", bad);
    return bad;
}
