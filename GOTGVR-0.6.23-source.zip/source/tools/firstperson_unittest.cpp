// First person: the maths (fpmath.h) and, with the real GOTG.exe mapped, that fp::Install finds everything.
// Also the screenshot crop and PNG writer (shot.cpp).
//   wine firstperson_unittest.exe [GOTG.exe]
#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include <cmath>
#include <string>
#include <vector>
#include "fpmath.h"
#include "camera.h"
#include "settings.h"
#include "game.h"
#include "firstperson.h"

void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
CamState g_cam; VrSettings g_set;
bool PngWriteBgr24(const wchar_t* path, const uint8_t* bgr, unsigned w, unsigned h);
void ShotCrop(const float img[4], const float eye[4], unsigned W, unsigned H, unsigned& x0, unsigned& y0, unsigned& w, unsigned& h);

static int g_bad = 0;
static void Check(bool c, const char* what) { printf("%-4s %s\n", c ? "OK" : "FAIL", what); if (!c) g_bad++; }
static bool Near(V3 a, V3 b, float e = 1e-3f) { return Len(a - b) < e; }

static Frame Cam(float yawDeg, float pitchDeg, V3 pos) {   // Z up; camera looks along -back
    float y = yawDeg * 0.0174533f, p = pitchDeg * 0.0174533f;
    V3 fwd = { cosf(p) * cosf(y), cosf(p) * sinf(y), sinf(p) };
    V3 right = Norm(Cross(fwd, V3{ 0, 0, 1 })), up = Cross(right, fwd);
    Frame f; f.axis[0] = right; f.axis[1] = up; f.axis[2] = fwd * -1.f; f.pos = pos; return f;
}

int main(int argc, char** argv) {
    // --- AtHead: offsets along the heading, level, regardless of pitch
    {
        float off[3] = { 0.f, 0.07f, 0.1f };
        V3 head = { 10, 20, 1.7f };
        Frame c = Cam(90.f, 0.f, { 10, 17, 2.f });   // looking along +y
        Frame e = fpm::AtHead(c, head, off, 1.f);
        Check(Near(e.pos, V3{ 10, 20.1f, 1.77f }), "eye = head + 0.1 forward (+y) + 0.07 up");
        Frame cp = Cam(90.f, -40.f, { 10, 17, 2.f });   // looking down 40 degrees: same eye point
        Check(Near(fpm::AtHead(cp, head, off, 1.f).pos, e.pos), "pitch does not move the eye point");
        Check(Near(fpm::AtHead(cp, head, off, 1.f).axis[2], cp.axis[2]), "orientation stays the camera's");
        float offx[3] = { 0.2f, 0, 0 };
        Check(Near(fpm::AtHead(c, head, offx, 1.f).pos, V3{ 10.2f, 20, 1.7f }), "X offset = camera right (+x when looking +y)");
        Check(Near(fpm::AtHead(c, head, off, 100.f).pos, V3{ 10, 30, 8.7f }, 1e-2f), "offsets scale with units_per_metre");
        Frame down = Cam(0.f, -89.9f, { 0, 0, 5 });
        Frame ed = fpm::AtHead(down, head, off, 1.f);
        Check(FrameValid(ed) && fabsf(ed.pos.z - 1.77f) < 1e-3f, "straight down: still a valid eye at head height");
    }
    // --- FollowsPlayer: the third-person camera behind him yes, a cutscene camera far away / facing elsewhere no
    {
        V3 head = { 0, 0, 1.7f };
        Check(fpm::FollowsPlayer(Cam(0.f, -10.f, { -2.5f, 0.4f, 2.0f }), head, 6.f), "over-the-shoulder camera follows the player");
        Check(!fpm::FollowsPlayer(Cam(0.f, 0.f, { -9.f, 0, 2.f }), head, 6.f), "camera 9 m away: suspended");
        Check(!fpm::FollowsPlayer(Cam(180.f, 0.f, { -2.f, 0, 1.8f }), head, 6.f), "camera looking away from him: suspended");
        Check(fpm::FollowsPlayer(Cam(37.f, 0.f, head), head, 6.f), "camera already in the head: follows");
    }
    // --- BobFilter: walking at 5 m/s is not delayed; a 4 cm, 2 Hz bob is cut down a lot
    {
        fpm::BobFilter b; float dt = 1.f / 90.f, maxErrTravel = 0.f, bobIn = 0.f, bobOut = 0.f;
        for (int i = 0; i < 900; i++) {
            float t = i * dt;
            V3 root = { 5.f * t, 0, 0 };
            float bob = 0.04f * sinf(2.f * 3.14159f * 2.f * t);
            V3 head = root + V3{ 0, 0, 1.65f + bob };
            V3 o = b.Step(root, head, i ? dt : 0.f, 0.6f);
            if (i > 180) {
                maxErrTravel = fmaxf(maxErrTravel, fabsf(o.x - head.x));
                bobIn = fmaxf(bobIn, fabsf(bob)); bobOut = fmaxf(bobOut, fabsf(o.z - 1.65f));
            }
        }
        printf("     travel error %.4f m, bob %.3f -> %.3f m\n", maxErrTravel, bobIn, bobOut);
        Check(maxErrTravel < 1e-4f, "running 5 m/s: no lag behind the head");
        Check(bobOut < bobIn * 0.35f, "head bob reduced to under a third");
        V3 o = b.Step({ 100, 0, 0 }, { 100, 0, 1.65f }, dt, 0.6f);   // teleport
        Check(Near(o, V3{ 100, 0, 1.65f }, 0.03f), "teleport (root jump): followed at once");
        fpm::BobFilter off; V3 h = { 1, 2, 3 };
        off.Step({ 0, 0, 0 }, h, 0.f, 0.f);
        Check(Near(off.Step({ 0, 0, 0 }, h + V3{ 0, 0, 0.05f }, dt, 0.f), h + V3{ 0, 0, 0.05f }), "fp_smooth 0: raw head");
    }
    // --- screenshot crop: image frustum = eye FOV widened to 1:1 + margin; the crop is the eye FOV, 1:1 pixels
    {
        float eye[4] = { -1.0f, 0.9f, 1.1f, -1.2f };            // l r u d (asymmetric, like a real headset)
        float img[4] = { -1.2f, 1.1f, 1.2f, -1.3f };            // what was rendered (wider)
        unsigned x0, y0, w, h; ShotCrop(img, eye, 2300, 2500, x0, y0, w, h);
        printf("     crop %u,%u %ux%u of 2300x2500\n", x0, y0, w, h);
        Check(x0 == 200 && y0 == 100 && w == 1900 && h == 2300, "crop = the headset's FOV (pixel exact)");
        float px = (float)w / (eye[1] - eye[0]), py = (float)h / (eye[2] - eye[3]);
        Check(fabsf(px - py) < 1.f, "square pixels (1:1)");
        unsigned a, b2, c2, d2; ShotCrop(eye, eye, 1000, 1000, a, b2, c2, d2);
        Check(a == 0 && b2 == 0 && c2 == 1000 && d2 == 1000, "image = FOV: whole image");
    }
    // --- PNG
    {
        unsigned W = 64, H = 32; std::vector<uint8_t> bgr(W * H * 3);
        for (unsigned y = 0; y < H; y++) for (unsigned x = 0; x < W; x++) { uint8_t* p = &bgr[(y * W + x) * 3]; p[0] = (uint8_t)(x * 4); p[1] = (uint8_t)(y * 8); p[2] = 200; }
        wchar_t path[MAX_PATH]; GetTempPathW(MAX_PATH, path); wcscat(path, L"gotgvr_shot_test.png");
        bool ok = PngWriteBgr24(path, bgr.data(), W, H);
        HANDLE f = CreateFileW(path, GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
        unsigned char sig[24] = {}; DWORD n = 0;
        if (f != INVALID_HANDLE_VALUE) { ReadFile(f, sig, 24, &n, nullptr); CloseHandle(f); }
        unsigned w = (sig[16] << 24) | (sig[17] << 16) | (sig[18] << 8) | sig[19], h = (sig[20] << 24) | (sig[21] << 16) | (sig[22] << 8) | sig[23];
        Check(ok && n == 24 && sig[1] == 'P' && sig[2] == 'N' && sig[3] == 'G' && w == W && h == H, "PNG written (signature, IHDR size)");
        if (argc > 2) { CopyFileW(path, std::wstring(argv[2], argv[2] + strlen(argv[2])).c_str(), FALSE); }
        DeleteFileW(path);
    }
    // --- the real exe: everything first person needs is found
    if (argc > 1) {
        HMODULE m = LoadLibraryExA(argv[1], nullptr, DONT_RESOLVE_DLL_REFERENCES);
        if (!m) { printf("map failed %lu\n", GetLastError()); return 2; }
        game::g_base = (uintptr_t)m;
        DWORD t0 = GetTickCount();
        fp::Install();
        printf("     install %lu ms\n", GetTickCount() - t0);
        Check(fp::Available(), "fp::Install on GOTG.exe: available");
        g_cam.firstPerson = true;
        Frame c = Cam(0, 0, { 0, 0, 2 }), o;
        fp::GameTick();
        Check(!fp::EyeBase(c, o), "no player yet (game not running): the game camera is used, nothing touched");
        printf("     status: %s\n", fp::Status());
    }
    printf(g_bad ? "%d FAILED\n" : "all passed\n", g_bad);
    return g_bad;
}
