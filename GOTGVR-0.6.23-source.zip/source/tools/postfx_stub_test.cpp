#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include "MinHook.h"
#include "settings.h"
VrSettings g_set;
void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
// stand-ins for the game's IsActive(this, rdx, ctx): true, and record their arguments
static void* seen[3];
extern "C" __attribute__((noinline)) bool FakeActive(void* a, void* b, void* c) { seen[0] = a; seen[1] = b; seen[2] = c; return true; }
static void* vtables[5][3];
namespace game { uintptr_t g_base = 0; static int n = 0; uintptr_t VtableByRtti(const char*) { vtables[n][0] = (void*)FakeActive; return n++ == 0 ? (uintptr_t)vtables[0] : 0; }
  bool InCode(uintptr_t) { return true; } }
void PostFxInstall(); void PostFxApply();
int main() {
    MH_Initialize();
    g_set.dofOff = true; PostFxInstall();
    typedef bool (*F)(void*, void*, void*);
    F f = (F)FakeActive; int bad = 0;
    seen[0] = seen[1] = seen[2] = nullptr;
    bool r = f((void*)1, (void*)2, (void*)3);
    printf("%s dof_off = true : IsActive -> %d (game function %s)\n", !r && !seen[0] ? "OK  " : "FAIL", r, seen[0] ? "ran" : "skipped"); bad += r || seen[0];
    g_set.dofOff = false; PostFxApply();
    r = f((void*)0x11, (void*)0x22, (void*)0x33);
    bool args = seen[0] == (void*)0x11 && seen[1] == (void*)0x22 && seen[2] == (void*)0x33;
    printf("%s dof_off = false: IsActive -> %d, arguments passed through %s\n", r && args ? "OK  " : "FAIL", r, args ? "intact" : "WRONG"); bad += !r || !args;
    g_set.dofOff = true; PostFxApply(); r = f(0, 0, 0);
    printf("%s switched back on live: IsActive -> %d\n", !r ? "OK  " : "FAIL", r); bad += r;
    return bad;
}
