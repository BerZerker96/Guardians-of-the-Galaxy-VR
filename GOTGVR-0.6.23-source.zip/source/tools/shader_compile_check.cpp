#include <windows.h>
#include <d3dcompiler.h>
#include <cstdio>
#include <cstring>
typedef HRESULT(WINAPI* PFN)(LPCVOID, SIZE_T, LPCSTR, const D3D_SHADER_MACRO*, ID3DInclude*, LPCSTR, LPCSTR, UINT, UINT, ID3DBlob**, ID3DBlob**);
int main(int argc, char** argv) {
    HMODULE m = LoadLibraryA(".\\d3dcompiler_47.dll"); if (!m) { printf("no dll\n"); return 2; }
    PFN c = (PFN)GetProcAddress(m, "D3DCompile");
    FILE* f = fopen(argv[1], "rb"); static char buf[1 << 20]; size_t n = fread(buf, 1, sizeof buf, f); fclose(f);
    int bad = 0;
    for (int i = 2; i + 1 < argc; i += 2) {
        ID3DBlob* b = nullptr, * e = nullptr;
        HRESULT hr = c(buf, n, argv[1], nullptr, nullptr, argv[i], argv[i + 1], 1 << 15 /*OPT3*/, 0, &b, &e);
        printf("%s %s: %s (%zu bytes)\n%s", argv[i], argv[i + 1], SUCCEEDED(hr) ? "OK" : "FAILED", b ? b->GetBufferSize() : 0, e ? (const char*)e->GetBufferPointer() : "");
        if (FAILED(hr)) bad++;
    }
    return bad;
}
