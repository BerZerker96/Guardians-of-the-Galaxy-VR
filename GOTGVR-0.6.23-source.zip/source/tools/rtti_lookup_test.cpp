#include <windows.h>
#include <cstdio>
#include <cstdarg>
#include "game.h"
void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
int main(int argc, char** argv) {
    HMODULE m = LoadLibraryExA(argv[1], nullptr, DONT_RESOLVE_DLL_REFERENCES);
    if (!m) { printf("map failed %lu\n", GetLastError()); return 2; }
    game::g_base = (uintptr_t)m;
    struct { const char* n; unsigned want; } c[] = {
        { ".?AVZRenderPostfilterPassDOF@@", 0x8da090 }, { ".?AVZRenderPostfilterPassHexDOF@@", 0x90c210 },
        { ".?AVZRenderPostfilterPassMotionBlur@@", 0x90c2a0 }, { ".?AVZRenderPostfilterPassRadialBlur@@", 0x90c2e0 },
        { ".?AVZRenderPostfilterPassFilmGrain@@", 0x90c0f0 }, { ".?AVZRenderGraphNodeCamera@@", 0 } };
    int bad = 0;
    for (auto& x : c) {
        DWORD t0 = GetTickCount();
        uintptr_t vt = game::VtableByRtti(x.n);
        unsigned f = vt ? (unsigned)(*(uintptr_t*)vt - game::g_base) : 0;
        bool ok = x.want ? f == x.want : vt != 0;
        if (!ok) bad++;
        printf("%-4s %-42s vtable exe+%llx slot0 exe+%x (%lu ms)\n", ok ? "OK" : "FAIL", x.n, vt ? (unsigned long long)(vt - game::g_base) : 0ull, f, GetTickCount() - t0);
    }
    return bad;
}
