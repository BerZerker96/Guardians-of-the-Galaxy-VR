// Unit test of src/camera.cpp: its real hook bodies driven by a fake renderer (view update calls the projection
// getter like exe+990D32 and a post filter like exe+8C6491), fake headset poses and a fake game clock.
#include <windows.h>
#include <cstdio>
#include <cmath>
#include <cstring>
#include "MinHook.h"
#include "camera.h"
#include "settings.h"
#include "game.h"
#include "vrmath.h"
#include "xrbridge/client.h"
#include <utility>
#include "fpmath.h"
#include "firstperson.h"
// first person: the game side (player / head bone) is faked - the head is where the test puts it
static V3 s_head = { 0, 0, 0 }; static bool s_headOk = false; static int s_gameTicks = 0;
namespace fp {
void GameTick() { s_gameTicks++; }
bool EyeBase(const Frame& cam, Frame& out) {
    if (!g_cam.firstPerson || !s_headOk || !fpm::FollowsPlayer(cam, s_head, g_cam.fpMaxDist * g_cam.unitsPerMetre)) return false;
    out = fpm::AtHead(cam, s_head, g_cam.fpOffset, g_cam.unitsPerMetre); return true;
}
}
VrSettings g_set;
volatile LONG g_presents = 0; DWORD g_presentThread = 0;
void LogWrite(const char* l, const char* f, ...) { va_list a; va_start(a, f); printf("   [%s] ", l); vprintf(f, a); printf("\n"); va_end(a); }
static char s_nodeUpd, s_getProj, s_timer;   // fake function addresses
namespace game { void* g_nodeUpdate = &s_nodeUpd; void* g_getProj = &s_getProj; void* g_timerUpdate = &s_timer; uintptr_t g_gameTimer = 0;
  volatile unsigned char* g_taaFlag = nullptr; uintptr_t kNodeTransform = 0x24, kNodeProj = 0xC0, kNodeW = 0x1A8, kNodeH = 0x1AC;
  bool Readable(const void*, size_t) { return true; }
  bool RenderOptionsFound() { return false; } void RenderOptionsApply(bool, int) {}
  volatile float* g_nearOverride = nullptr; float g_nearSet = -1.f; void SetNearClip(float u) { g_nearSet = u; } }
static xrb::IpcPose s_pose[2]; static xrb::IpcFov s_fov[2];
namespace xrb {
bool ClientHostConnected() { return true; }
bool ClientGetLatestPoses(IpcPose* p, IpcFov* f, int64_t* t) { p[0] = s_pose[0]; p[1] = s_pose[1]; f[0] = s_fov[0]; f[1] = s_fov[1]; *t = 7; return true; }
}
typedef uintptr_t(__fastcall* PNode)(void*, void*, void*, uintptr_t);
typedef float*(__fastcall* PProj)(void*, float*, uintptr_t);
typedef void(__fastcall* PTimer)(void*, uintptr_t);
static PNode hNode; static PProj hProj; static PTimer hTimer;
static float g_jit[2] = {};
bool VideoActive(unsigned) { return false; }
static float s_lastProj[16], s_postProj[16]; static float s_seenT[12]; static float s_nodeProjSeen[16];
static float* __fastcall FakeGetProj(void* node, float* out, uintptr_t keep) {
    memset(out, 0, 64); out[0] = 1.2f; out[5] = 1.5f; out[11] = -1.f; out[10] = 0.0001f; out[14] = 0.1f;   // reverse Z
    out[8] = g_jit[0]; out[9] = g_jit[1]; return out;
}
static uintptr_t __fastcall FakeNodeOrig(void* node, void*, void*, uintptr_t) {   // the renderer: reads node+0x24, the getter
    memcpy(s_seenT, (char*)node + 0x24, 48);
    memcpy(s_nodeProjSeen, (char*)node + 0xC0, 64);   // what the render-view setup (exe+98DC70) copies directly
    hProj(node, s_lastProj, 0);   // view update (keepDepth 0)
    hProj(node, s_postProj, 1);   // a post filter (keepDepth 1)
    return 0;
}
static void __fastcall FakeTimerOrig(void* t, uintptr_t) {   // advance 1/60 s
    char* p = (char*)t; long long* time = (long long*)(p + 0x20); long long* d = (long long*)(p + 0x30);
    *d = 166666; *time += *d;
}
MH_STATUS WINAPI MH_CreateHook(LPVOID t, LPVOID d, LPVOID* o) {
    if (t == &s_nodeUpd) { hNode = (PNode)d; *o = (void*)FakeNodeOrig; }
    else if (t == &s_getProj) { hProj = (PProj)d; *o = (void*)FakeGetProj; }
    else if (t == &s_timer) { hTimer = (PTimer)d; *o = (void*)FakeTimerOrig; }
    return MH_OK;
}
MH_STATUS WINAPI MH_EnableHook(LPVOID) { return MH_OK; }


// ---- the reconstruction's own matrix maths (copied from recon.cpp) for the centre-view geometry check
static void RMul(const double* a, const double* b, double* o) { for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) { double v = 0; for (int k = 0; k < 4; k++) v += a[i * 4 + k] * b[k * 4 + j]; o[i * 4 + j] = v; } }
static bool RInv(const double* m, double* o) {
    double a[4][8]; for (int i = 0; i < 4; i++) for (int j = 0; j < 8; j++) a[i][j] = j < 4 ? m[i * 4 + j] : (j - 4 == i ? 1 : 0);
    for (int c = 0; c < 4; c++) { int p = c; for (int r = c + 1; r < 4; r++) if (fabs(a[r][c]) > fabs(a[p][c])) p = r;
        if (fabs(a[p][c]) < 1e-12) return false; for (int j = 0; j < 8; j++) { double t = a[c][j]; a[c][j] = a[p][j]; a[p][j] = t; }
        double d = a[c][c]; for (int j = 0; j < 8; j++) a[c][j] /= d;
        for (int r = 0; r < 4; r++) if (r != c) { double f = a[r][c]; for (int j = 0; j < 8; j++) a[r][j] -= f * a[c][j]; } }
    for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) o[i * 4 + j] = a[i][j + 4]; return true;
}
static bool RView(const float* T, double* V) { double W[16] = { T[0], T[1], T[2], 0, T[3], T[4], T[5], 0, T[6], T[7], T[8], 0, T[9], T[10], T[11], 1 }; return RInv(W, V); }
static void RProj(const float* tan, double* P) {
    for (int i = 0; i < 16; i++) P[i] = 0; double w = tan[1] - tan[0], h = tan[2] - tan[3];
    P[0] = 2 / w; P[5] = 2 / h; P[8] = (tan[1] + tan[0]) / w; P[9] = (tan[2] + tan[3]) / h; P[10] = 0.0; P[11] = -1; P[14] = 1.0;
}
// where a world point lands in an image (u from the left, 0..1) drawn from node T with frustum tan
static double RUv(const float* T, const float* tan, const double* pw) {
    double V[16], P[16], VP[16]; RView(T, V); RProj(tan, P); RMul(V, P, VP);
    double c[4] = {}; double p[4] = { pw[0], pw[1], pw[2], 1 };
    for (int j = 0; j < 4; j++) for (int k = 0; k < 4; k++) c[j] += p[k] * VP[k * 4 + j];
    return c[0] / c[3] * 0.5 + 0.5;
}
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { fails++; printf("  FAIL %s: ", #c); printf(__VA_ARGS__); printf("\n"); } } while (0)
alignas(16) static char g_node[0x400]; alignas(16) static char g_timerObj[0x100];
static float gameT[12];
static void SetGameCam(float yaw, float x) {   // looking along +x turned by yaw, Z up; rows right, up, back, pos
    float c = cosf(yaw), s = sinf(yaw);
    float fwd[3] = { c, s, 0 }, up[3] = { 0, 0, 1 }, right[3] = { s, -c, 0 };
    float T[12] = { right[0], right[1], right[2], up[0], up[1], up[2], -fwd[0], -fwd[1], -fwd[2], x, 0, 170 };
    memcpy(gameT, T, 48); memcpy(g_node + 0x24, T, 48);
}
static float Dist(const float* a, const float* b) { return sqrtf((a[9] - b[9]) * (a[9] - b[9]) + (a[10] - b[10]) * (a[10] - b[10]) + (a[11] - b[11]) * (a[11] - b[11])); }

int main() {
    *(unsigned*)(g_node + 0x1A8) = 2000; *(unsigned*)(g_node + 0x1AC) = 2000;
    { float P[16] = {}; P[0] = 1.2f; P[5] = 1.5f; P[11] = -1.f; P[10] = 0.0001f; P[14] = 0.1f; memcpy(g_node + 0xC0, P, 64); }   // the game's own
    game::g_gameTimer = (uintptr_t)g_timerObj;
    for (int e = 0; e < 2; e++) {   // Quest-3-like FOV, 64 mm IPD, head 1.6 m up, slightly turned
        s_fov[e] = { e ? -0.87f : -0.95f, e ? 0.95f : 0.87f, 0.82f, -0.92f };
        s_pose[e] = { e ? 0.032f : -0.032f, 0.f, 0.f, 0.f, 0.f, 0.f, 1.f };
    }
    CameraInstall();
    g_cam.unitsPerMetre = 100.f; g_cam.worldScale = 1.f; g_cam.ipdScale = 1.f; g_cam.decoupledPitch = true; g_cam.stabilize = 0.f;
    g_cam.cullMargin = 1.f; g_cam.frameDelay = 0; g_cam.syncPairSubmit = true; g_cam.syncLag = -1; g_cam.reconShared = true; g_cam.reconAlternate = true; g_cam.reconCentre = false;
    const char* names[] = { "screen", "head", "aer", "synced", "recon" };
    for (int mode : { (int)VRMODE_SCREEN, (int)VRMODE_HEAD, (int)VRMODE_STEREO, (int)VRMODE_SYNCED, (int)VRMODE_RECON, 99, 98 }) {
        bool leftOnly = mode == 99; if (leftOnly) { mode = VRMODE_RECON; g_cam.reconAlternate = false; g_jit[0] = 0.0007f; g_jit[1] = -0.0004f; }
        bool centre = mode == 98; if (centre) { mode = VRMODE_RECON; g_cam.reconAlternate = false; g_cam.reconCentre = true; }
        printf("== %s%s\n", names[mode], leftOnly ? " (left only, jitter)" : centre ? " (centre view, both eyes rebuilt)" : "");
        g_cam.mode = mode;
        int eyes[2] = {}, pairs = 0, held = 0, n = 0; long lastSeq = -1;
        RenderedEye prev; bool havePrev = false;
        for (int f = 0; f < 240; f++) {
            hTimer(g_timerObj, 0);                       // main loop: game clock
            SetGameCam(0.003f * f, 10.f * f);            // the game moves its camera every frame
            hNode(g_node, nullptr, nullptr, 0);          // render thread: view update
            CameraOnPresent(2000, 2000);                 // Present
            RenderedEye re; bool got = CameraTakeRendered(re);
            g_presents++;
            if (f < 4) continue;                          // main node selection settles
            if (mode == VRMODE_SCREEN) { CHECK(!got, "frame %d", f); CHECK(!memcmp(s_seenT, gameT, 48), "renderer saw a changed camera"); continue; }
            CHECK(got, "no frame at %d", f); if (!got) continue;
            n++; eyes[re.eye & 1]++;
            CHECK(re.seq > lastSeq, "seq"); lastSeq = re.seq;
            // the camera the renderer saw = the composed eye pose (position: game camera + eye offset in metres x 100)
            float off = Dist(s_seenT, gameT);
            const float* t = mode == VRMODE_HEAD ? g_cam.monoTan : CameraDrawTan(re.eye);
            float w = t[1] - t[0], h = t[2] - t[3];
            CHECK(fabsf(s_lastProj[0] - 2.f / w) < 1e-4f && fabsf(s_lastProj[5] - 2.f / h) < 1e-4f, "proj scale");
            CHECK(fabsf(s_lastProj[8] - (g_jit[0] + (t[1] + t[0]) / w)) < 1e-4f, "proj x shift %f", s_lastProj[8]);
            CHECK(!memcmp(s_lastProj, s_postProj, 64), "post filter projection differs");
            // 0.6.14: the node's own projection carries the same frustum (the render path that copies it directly)
            CHECK(fabsf(s_nodeProjSeen[0] - 2.f / w) < 1e-4f && fabsf(s_nodeProjSeen[5] - 2.f / h) < 1e-4f &&
                  fabsf(s_nodeProjSeen[8] - (t[1] + t[0]) / w) < 1e-4f && fabsf(s_nodeProjSeen[14] - 0.1f) < 1e-6f, "node projection = the eye frustum, depth rows kept (%f %f)", s_nodeProjSeen[0], 2.f / w);
            if (mode == VRMODE_HEAD) { CHECK(off < 0.01f, "head offset %f", off); CHECK(re.mono, "mono"); }
            else if (mode != VRMODE_SYNCED || true) {
                if (mode != VRMODE_SYNCED && !centre) CHECK(fabsf(off - 3.2f) < 0.01f, "eye offset %f cm", off);
            }
            if (mode == VRMODE_STEREO && havePrev) CHECK(re.eye != prev.eye, "AER alternation f%d", f);
            if (centre && re.centre) {
                // 0.6.12: the centre view's two rebuilt eyes must each see a far point where the eye itself would:
                // eye 0 = the left eye (its node to the left, its own frustum), eye 1 = the right eye
                const float* T = re.nodeD;
                double fwd[3] = { -T[6], -T[7], -T[8] }, rt[3] = { T[0], T[1], T[2] }, pos[3] = { T[9], T[10], T[11] };
                for (double side : { -0.4, 0.0, 0.5 }) {
                    double pw[3]; for (int k = 0; k < 3; k++) pw[k] = pos[k] + fwd[k] * 100000.0 + rt[k] * side * 100000.0;
                    for (int e = 0; e < 2; e++) {
                        const float* No = e ? re.nodeO1 : re.nodeO; const float* to = e ? re.tanO1 : re.tanO;
                        double u = RUv(No, to, pw);
                        double expect = (side - to[0]) / (to[1] - to[0]);   // far point: the eye's offset does not matter
                        CHECK(fabs(u - expect) < 2e-3, "centre view: eye %d sees a far point (tan %.2f) at u %.3f, expected %.3f", e, side, u, expect);
                    }
                }
                double lx = (re.nodeO[9] - T[9]) * rt[0] + (re.nodeO[10] - T[10]) * rt[1] + (re.nodeO[11] - T[11]) * rt[2];
                double rx = (re.nodeO1[9] - T[9]) * rt[0] + (re.nodeO1[10] - T[10]) * rt[1] + (re.nodeO1[11] - T[11]) * rt[2];
                CHECK(lx < 0 && rx > 0, "centre view: eye 0 left of the head (%.2f), eye 1 right (%.2f)", lx, rx);
                CHECK(re.tanO[0] <= re.tanO1[0] + 1e-5f && re.tanO[1] <= re.tanO1[1] + 1e-5f, "centre view: eye 0 has the left eye's frustum");
            }
            if (mode == VRMODE_SYNCED) {
                if (re.eye == 1) { held++; CHECK(re.pairEnd, "second eye pairEnd"); }
                else CHECK(!re.pairEnd, "first eye of a pair is held");
                static float firstT[12];
                if (re.eye == 0) memcpy(firstT, s_seenT, 48);
                if (havePrev && re.eye == 1 && prev.eye == 0) {
                    pairs++;   // same base camera: the two eyes are exactly one IPD apart although the game moved 10 units
                    CHECK(fabsf(Dist(firstT, s_seenT) - 6.4f) < 0.01f, "synced pair from one camera: %f", Dist(firstT, s_seenT));
                }
            }
            if (mode == VRMODE_RECON && centre) {
                CHECK(re.recon && re.centre && re.projOk && !re.mono, "centre record");
                CHECK(!memcmp(re.nodeD, s_seenT, 48), "centre: nodeD = the camera the renderer saw");
                CHECK(fabsf(Dist(re.nodeD, re.nodeO) - 3.2f) < 0.01f && fabsf(Dist(re.nodeD, re.nodeO1) - 3.2f) < 0.01f, "centre: each eye half the IPD away (%f %f)", Dist(re.nodeD, re.nodeO), Dist(re.nodeD, re.nodeO1));
                CHECK(fabsf(Dist(re.nodeO, re.nodeO1) - 6.4f) < 0.01f, "centre: the eyes 6.4 apart");
                CHECK(!memcmp(re.tanO, g_cam.eyeTan[0], 16) && !memcmp(re.tanO1, g_cam.eyeTan[1], 16), "centre: each eye's own frustum");
                CHECK(fabsf(re.tanD[0] + re.tanD[1]) < 1e-5f && fabsf(re.tanD[2] + re.tanD[3]) < 1e-5f, "centre view symmetric");
                for (int e = 0; e < 2; e++) CHECK(re.tanD[0] <= g_cam.eyeTan[e][0] && re.tanD[1] >= g_cam.eyeTan[e][1] && re.tanD[2] >= g_cam.eyeTan[e][2] && re.tanD[3] <= g_cam.eyeTan[e][3], "centre view covers eye %d", e);
                {   // exactly the eyes' extents (+2 %), not padded to the eye image's shape
                    const float (*t)[4] = g_cam.eyeTan;
                    float hx = fmaxf(fmaxf(-t[0][0], t[0][1]), fmaxf(-t[1][0], t[1][1])) * 1.02f, hy = fmaxf(fmaxf(t[0][2], -t[0][3]), fmaxf(t[1][2], -t[1][3])) * 1.02f;
                    CHECK(fabsf(re.tanD[1] - hx) < 1e-5f && fabsf(re.tanD[2] - hy) < 1e-5f, "centre view = the eyes' extents (%f %f vs %f %f)", re.tanD[1], re.tanD[2], hx, hy);
                }
            } else if (mode == VRMODE_RECON) {
                CHECK(re.recon && re.projOk, "recon record");
                CHECK(!memcmp(re.proj, s_lastProj, 64), "captured projection = the view update's");
                CHECK(!memcmp(re.nodeD, s_seenT, 48), "nodeD = the camera the renderer saw");
                CHECK(fabsf(Dist(re.nodeD, re.nodeO) - 6.4f) < 0.01f, "eye separation %f", Dist(re.nodeD, re.nodeO));
                CHECK(re.poseO.px == s_pose[re.physEye ^ 1].px, "other pose");
                CHECK(!memcmp(re.tanO, g_cam.eyeTan[re.physEye ^ 1], 16), "other frustum");
                CHECK(re.tanD[0] <= g_cam.eyeTan[re.physEye][0] && re.tanD[1] >= g_cam.eyeTan[re.physEye][1] &&
                      re.tanD[0] <= g_cam.eyeTan[re.physEye ^ 1][0] && re.tanD[1] >= g_cam.eyeTan[re.physEye ^ 1][1], "shared frustum covers both");
                {   // 0.6.6: the engine always draws a symmetric frustum (it rebuilds the off-centre terms itself)
                    CHECK(fabsf(re.tanD[0] + re.tanD[1]) < 1e-5f && fabsf(re.tanD[2] + re.tanD[3]) < 1e-5f, "shared frustum symmetric");
                    const float* a = g_cam.eyeTan[0]; const float* b = g_cam.eyeTan[1];
                    CHECK(re.tanD[2] >= fmaxf(a[2], b[2]) && re.tanD[3] <= fminf(a[3], b[3]), "shared frustum covers both eyes vertically");
                }
                CHECK(re.pairEnd && !re.synced, "recon flags");
                if (leftOnly) CHECK(re.eye == 0, "left only"); else if (havePrev) CHECK(re.eye != prev.eye, "recon alternation");
            }
            prev = re; havePrev = true;
        }
        if (mode == VRMODE_SYNCED) {
            printf("   synced: %d frames, held (second eye) %d, pairs %d\n", n, held, pairs);
            CHECK(held > n / 3, "the clock was held for second eyes");
        }
        if (mode != VRMODE_SCREEN) printf("   frames %d, left %d right %d\n", n, eyes[0], eyes[1]);
        g_jit[0] = g_jit[1] = 0; g_cam.reconCentre = false;
    }

    // ---------------- VR panel 3D settings, through the real hooks
    printf("== settings\n");
    g_cam.mode = VRMODE_STEREO; g_jit[0] = g_jit[1] = 0;
    auto frame = [&](float pitch) {   // one frame; the game camera pitched by `pitch` (rad) looking along +x
        hTimer(g_timerObj, 0);
        float c = cosf(pitch), sp = sinf(pitch);
        float fwd[3] = { c, 0, sp }, up[3] = { -sp, 0, c }, right[3] = { 0, -1, 0 };
        float T[12] = { right[0], right[1], right[2], up[0], up[1], up[2], -fwd[0], -fwd[1], -fwd[2], 500, 0, 170 };
        memcpy(gameT, T, 48); memcpy(g_node + 0x24, T, 48);
        hNode(g_node, nullptr, nullptr, 0); CameraOnPresent(2000, 2000);
        RenderedEye re; bool ok = CameraTakeRendered(re); g_presents++; return std::make_pair(ok, re);
    };
    auto sepFrom = [&](float pitch) { auto a = frame(pitch); float A[12]; memcpy(A, s_seenT, 48); auto b = frame(pitch); return std::make_pair(Dist(A, s_seenT), b.second); };
    g_cam.decoupledPitch = false;
    // world scale: eyes 6.4 cm x 100 units/m x scale apart
    for (float ws : { 0.5f, 1.f, 2.f }) { g_cam.worldScale = ws; float d = sepFrom(0).first; printf("   world_scale %.1f: rendered eye separation %.2f units\n", ws, d); CHECK(fabsf(d - 6.4f * ws) < 0.02f, "world scale %f -> %f", ws, d); }
    g_cam.worldScale = 1.f;
    // ipd scale: rendered separation scales, the pose sent to the headset stays the real eye
    g_cam.ipdScale = 1.5f; { auto r = sepFrom(0); printf("   ipd_scale 1.5: rendered %.2f units, pose sent x=%.4f m (real %.4f)\n", r.first, r.second.pose.px, s_pose[r.second.eye].px);
      CHECK(fabsf(r.first - 9.6f) < 0.02f, "ipd scale rendered"); CHECK(r.second.pose.px == s_pose[r.second.eye].px, "ipd scale: real pose sent to the headset"); }
    g_cam.ipdScale = 1.f;
    // camera offsets: metres of the game world, the same at any world scale
    for (float ws : { 1.f, 2.f }) {
        g_cam.worldScale = ws; g_cam.camOffset[2] = 0.5f;   // 0.5 m forward
        frame(0); auto r = frame(0);
        // eye position minus the eye offset, along the camera's forward (+x here)
        float eyeX = s_seenT[9], ex = 0.f;   // the eyes are offset sideways (y), not along x
        printf("   camera_offset_z 0.5 m at world_scale %.0f: camera moved %.1f units forward\n", ws, eyeX - 500.f + ex);
        CHECK(fabsf(eyeX - 550.f) < 0.05f, "offset independent of world scale (%f)", eyeX);
        g_cam.camOffset[2] = 0.f; (void)r;
    }
    g_cam.worldScale = 1.f;
    // decoupled pitch: the game camera looks 30 deg down; on: rendered up axis = world up, off: tilted
    g_cam.decoupledPitch = true; frame(-0.52f); frame(-0.52f);
    printf("   decoupled pitch on : rendered up = (%.2f %.2f %.2f)\n", s_seenT[3], s_seenT[4], s_seenT[5]);
    CHECK(fabsf(s_seenT[5] - 1.f) < 1e-3f, "decoupled pitch keeps the horizon level");
    g_cam.decoupledPitch = false; frame(-0.52f); frame(-0.52f);
    printf("   decoupled pitch off: rendered up = (%.2f %.2f %.2f)\n", s_seenT[3], s_seenT[4], s_seenT[5]);
    CHECK(fabsf(s_seenT[5] - cosf(0.52f)) < 1e-3f, "decoupled pitch off follows the game");
    // swap eyes: the left image is drawn from the right eye
    g_cam.swapEyes = true; { auto r = frame(0); float lat = s_seenT[10];   // y = sideways (right axis is -y)
        printf("   swap_eyes: image %d drawn %.2f units sideways\n", r.second.eye, lat);
        CHECK((r.second.eye == 0 && lat < 0) || (r.second.eye == 1 && lat > 0), "swap: image eye drawn from the other eye (y %f)", lat); }
    g_cam.swapEyes = false; { auto r = frame(0); float lat = s_seenT[10];
        CHECK((r.second.eye == 0 && lat > 0) || (r.second.eye == 1 && lat < 0), "no swap: left eye on the left (y %f)", lat); }
    // cull margin: wider frustum, same aspect; the projection follows
    float w0 = g_cam.eyeTan[0][1] - g_cam.eyeTan[0][0];
    g_cam.cullMargin = 1.2f; CameraUpdateFrustum(); float w1 = g_cam.eyeTan[0][1] - g_cam.eyeTan[0][0];
    printf("   cull_margin 1.2: frustum width %.3f -> %.3f\n", w0, w1); CHECK(fabsf(w1 / w0 - 1.2f) < 1e-3f, "cull margin");
    frame(0); { auto r = frame(0); const float* t = CameraDrawTan(r.second.eye); CHECK(fabsf(s_lastProj[0] - 2.f / (t[1] - t[0])) < 1e-4f, "projection follows the cull margin"); }
    g_cam.cullMargin = 1.f; CameraUpdateFrustum();
    // canted eyes (0.6.10): each eye turned 6 deg outwards about the up axis - the head-centre view must cover both
    // turned frusta (wider than the unturned max), and go back when the eyes are parallel again
    {
        float m0 = g_cam.monoTan[1];
        xrb::IpcPose sp[2] = { g_cam.pose[0], g_cam.pose[1] };
        float h = 0.5f * 6.f / 57.2957795f;
        // yaw about the view's up axis (y): left eye turns left (+), right eye right (-)
        g_cam.pose[0].qx = 0; g_cam.pose[0].qy = sinf(h); g_cam.pose[0].qz = 0; g_cam.pose[0].qw = cosf(h);
        g_cam.pose[1].qx = 0; g_cam.pose[1].qy = -sinf(h); g_cam.pose[1].qz = 0; g_cam.pose[1].qw = cosf(h);
        CameraUpdateFrustum(); float m1 = g_cam.monoTan[1];
        float outer = fmaxf(-g_cam.eyeTan[0][0], g_cam.eyeTan[1][1]);
        float expect = tanf(atanf(outer) + 6.f / 57.2957795f) * 1.02f;
        printf("   canted 2 x 6 deg: head view half width %.3f -> %.3f (expected %.3f)\n", m0, m1, expect);
        CHECK(fabsf(m1 - expect) < 0.01f, "canted eyes covered by the centre view");
        g_cam.pose[0] = sp[0]; g_cam.pose[1] = sp[1]; CameraUpdateFrustum();
        CHECK(fabsf(g_cam.monoTan[1] - m0) < 1e-4f, "parallel eyes: centre view back");
    }
    // 0.6.11: symmetric view - one frustum for every stereo method, its shape = the render size's shape
    {
        bool sv = g_cam.symmetricView; g_cam.symmetricView = true; CameraUpdateFrustum();
        const float* m = g_cam.monoTan; const float* d0 = CameraDrawTan(0); const float* d1 = CameraDrawTan(1);
        bool same = true; for (int i = 0; i < 4; i++) same = same && m[i] == d0[i] && m[i] == d1[i];
        CHECK(same, "symmetric view: every method draws the same frustum");
        CHECK(m[1] >= g_cam.eyeTan[0][1] && -m[0] >= -g_cam.eyeTan[0][0] && m[1] >= g_cam.eyeTan[1][1] && -m[0] >= -g_cam.eyeTan[1][0], "symmetric view covers both eyes");
        float gx, gy; CameraStableGrowthXY(gx, gy);
        printf("   symmetric view: +-%.3f x +-%.3f, render growth %.3f x %.3f\n", m[1], m[2], gx, gy);
        g_cam.symmetricView = sv; CameraUpdateFrustum();
    }
    // near clip: set while VR frames are made (metres x units), the game's own otherwise
    g_cam.nearClip = 0.05f; frame(0); printf("   near_clip 0.05 m: override %.2f units\n", game::g_nearSet); CHECK(game::g_nearSet == 0.f, "0.6.20: the getter's near override is never set (the node near is)");
    g_cam.nearClip = 0.f; frame(0); CHECK(game::g_nearSet == 0.f, "near clip off -> the game's");
    // camera axes: a permuted axis map reads / writes the same rows back (round trip)
    // (the default +0+1+2 is the render node's layout - right, up, back - confirmed from exe+990D40)
    // stabilizer: a 1 cm shake at 60 Hz is reduced, a 3 m cut is taken at once
    g_cam.stabilize = 1.f; g_cam.decoupledPitch = false;
    { float worst = 0; for (int k = 0; k < 60; k++) { float sh = (k & 1) ? 1.f : -1.f;
        float T[12] = { 0, -1, 0, 0, 0, 1, -1, 0, 0, 500, 0, 170 + sh }; memcpy(g_node + 0x24, T, 48); memcpy(gameT, T, 48);
        hTimer(g_timerObj, 0); hNode(g_node, nullptr, nullptr, 0); CameraOnPresent(2000, 2000); RenderedEye re; CameraTakeRendered(re); g_presents++;
        if (k > 30) worst = fmaxf(worst, fabsf(s_seenT[11] - 170.f)); Sleep(16); }
      printf("   camera_stabilize 1.0: +-1.0 unit shake -> +-%.2f\n", worst); CHECK(worst < 0.6f, "shake reduced");
      float T[12] = { 0, -1, 0, 0, 0, 1, -1, 0, 0, 800, 0, 170 }; memcpy(g_node + 0x24, T, 48);
      hNode(g_node, nullptr, nullptr, 0); CHECK(fabsf(s_seenT[9] - 800.f) < 0.5f, "cut taken at once (%f)", s_seenT[9]); }
    g_cam.stabilize = 0.f;
    // first person: the eye base at the head + fp offsets (camera offsets ignored), the head's motion never lagged by
    // the camera stabilizer, a camera far away = suspended (game camera), the game thread called once per tick
    printf("== first person\n");
    {
        g_cam.decoupledPitch = true; g_cam.firstPerson = true; g_cam.fpMaxDist = 6.f;
        g_cam.fpOffset[0] = 0.f; g_cam.fpOffset[1] = 0.07f; g_cam.fpOffset[2] = 0.1f; g_cam.camOffset[2] = 0.5f;
        s_headOk = true; s_head = { 750, 0, 165 };   // 2.5 m in front of the camera at x 500 (looking +x)
        int t0 = s_gameTicks;
        auto r = frame(0); r = frame(0);
        float cx = s_seenT[9], cy = s_seenT[10], cz = s_seenT[11];   // one eye: +-3.2 units sideways (y)
        printf("   eye at (%.1f %.1f %.1f), head (750 0 165) + 10 cm forward + 7 cm up\n", cx, cy, cz);
        CHECK(fabsf(cx - 760.f) < 0.05f && fabsf(fabsf(cy) - 3.2f) < 0.05f && fabsf(cz - 172.f) < 0.05f, "first-person eye position");
        CHECK(s_gameTicks > t0, "game-thread tick called from the clock hook");
        // the stabilizer is on: the head moving 30 units in one frame is followed exactly (no lag)
        g_cam.stabilize = 1.f; frame(0); s_head = { 780, 0, 165 }; frame(0);
        printf("   stabilizer on, head moved 30 units: eye x %.2f (want 790)\n", s_seenT[9]);
        CHECK(fabsf(s_seenT[9] - 790.f) < 0.05f, "head not lagged by the stabilizer");
        g_cam.stabilize = 0.f;
        // cutscene: the head 9 m from the camera: the game camera (+ camera_offset_z 0.5 m) is used
        s_head = { 1400, 0, 165 }; frame(0); frame(0);
        printf("   head 9 m away: eye x %.1f (game camera 500 + 50)\n", s_seenT[9]);
        CHECK(fabsf(s_seenT[9] - 550.f) < 0.05f && !g_cam.fpActive, "suspended in cutscenes: game camera with its offsets");
        g_cam.firstPerson = false; s_head = { 750, 0, 165 }; frame(0); frame(0);
        CHECK(fabsf(s_seenT[9] - 550.f) < 0.05f, "first person off: third person");
        g_cam.camOffset[2] = 0.f; s_headOk = false;
    }
    printf("eyeTan L %.3f %.3f %.3f %.3f | shared L %.3f %.3f %.3f %.3f\n", g_cam.eyeTan[0][0], g_cam.eyeTan[0][1], g_cam.eyeTan[0][2], g_cam.eyeTan[0][3],
           g_cam.reconTan[0][0], g_cam.reconTan[0][1], g_cam.reconTan[0][2], g_cam.reconTan[0][3]);
    printf(fails ? "%d FAILURES\n" : "camera unit test: all checks passed\n", fails);
    return fails ? 1 : 0;
}
