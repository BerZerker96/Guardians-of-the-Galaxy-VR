#include "refresh.h"
#include <cstdio>
static int fails = 0;
static void T(double repHz, double knownHz, double wantHz, const char* what, const char* name = "") {
    bool d; int64_t p = RefreshUndivide((int64_t)(1e9 / repHz), knownHz ? (int64_t)(1e9 / knownHz) : 0, &d, RefreshMinNative(name));
    double got = p ? 1e9 / (double)p : 0;
    bool ok = fabs(got - wantHz) < 0.6;
    if (!ok) fails++;
    printf("%-4s reported %6.2f Hz, known %5.1f -> cap %6.2f Hz (want %5.1f)%s  %s\n", ok ? "OK" : "FAIL", repHz, knownHz, got, wantHz, d ? " [divided]" : "", what);
}
int main() {
    T(90, 0, 90, "Quest / Index / G2 at 90, no smoothing");
    T(45, 0, 90, "ASW / SSW / Smart Smoothing at half of 90");
    T(36, 0, 72, "Quest at 72, ASW forced");
    T(40, 0, 80, "Quest at 80 / Index at 80, half");
    T(60, 0, 120, "120 Hz headset, smoothing forced (Quest 3 / Vive Pro 2 / Index)");
    T(72, 0, 72, "Quest at 72 native");
    T(72, 144, 72, "Index at 144 half-rate reports 72: >= 66, kept (saved 144 still caps at 144 in the limiter)");
    T(48, 144, 144, "144 Hz headset at a third (48)");
    T(30, 90, 90, "90 Hz headset at a third, known 90");
    T(30, 0, 90, "third of 90, nothing known");
    T(37.5, 75, 75, "Pimax 75 Hz mode at half");
    T(72, 0, 144, "Valve Index at 144 Hz, motion smoothing forced", "Valve Index");
    T(80, 0, 80, "Valve Index at 80 native", "Valve Index");
    T(45, 0, 90, "Reverb G2 half rate", "HP Reverb G2");
    T(60, 0, 120, "Vive Pro 2 at 120, half", "VIVE Pro 2");
    T(72, 0, 72, "Pimax Crystal 72 native", "Pimax Crystal");
    T(120, 0, 120, "120 native");
    T(144, 0, 144, "144 native");
    printf(fails ? "%d FAILURES\n" : "refresh inference: all checks passed\n", fails);
    return fails;
}
