#!/usr/bin/env python3
# Checks a GOTG.exe against every code signature GOTGVR uses (the same rules as src/game.cpp).
# Usage: python verify_signatures.py "C:\...\Marvel's Guardians of the Galaxy\bin\GOTG.exe"
# Only the Python standard library is needed. "OK" lines = the feature will be active with this exe.
import re, struct, sys

def load(path):
    data = open(path, "rb").read()
    pe = struct.unpack_from("<I", data, 0x3C)[0]
    nsec = struct.unpack_from("<H", data, pe + 6)[0]
    optsz = struct.unpack_from("<H", data, pe + 20)[0]
    secs = []
    for i in range(nsec):
        o = pe + 24 + optsz + i * 40
        name = data[o:o + 8].rstrip(b"\0").decode(errors="replace")
        vsz, va, rsz, rptr, ch = struct.unpack_from("<IIII", data, o + 8) + (struct.unpack_from("<I", data, o + 36)[0],)
        secs.append((name, va, vsz, rptr, rsz, ch))
    return data, secs

def to_re(p):
    out = b""
    for t in p.split():
        out += b"." if t in ("??", "?") else re.escape(bytes([int(t, 16)]))
    return re.compile(out, re.S)

def main():
    if len(sys.argv) < 2:
        print(__doc__ or "usage: verify_signatures.py GOTG.exe"); return 2
    data, secs = load(sys.argv[1])
    code = [s for s in secs if (s[5] & 0x20000000) and 0x100000 < s[2] < 0x10000000]
    def rva_to_off(rva):
        for n, va, vsz, rp, rs, ch in secs:
            if va <= rva < va + max(vsz, rs): return rp + rva - va
        return None
    def scan(pat):
        r = to_re(pat); hits = []
        for n, va, vsz, rp, rs, ch in code:
            for m in r.finditer(data, rp, rp + rs):
                hits.append(va + m.start() - rp)
                if len(hits) > 1: return hits
        return hits
    ok_all = True
    def report(name, hits, extra=""):
        nonlocal ok_all
        if len(hits) == 1: print("OK    %-22s exe+%x %s" % (name, hits[0], extra))
        else: print("FAIL  %-22s %s" % (name, "not found" if not hits else "ambiguous")); ok_all = False
        return hits[0] if len(hits) == 1 else None

    upd = report("NodeViewUpdate", scan("48 8B C4 44 89 48 20 48 89 50 10 48 89 48 08 55 56 57 41 54 41 55 41 56 48 8D A8 ?? ?? FF FF 48 81 EC ?? ?? 00 00"))
    if upd is not None:
        f = data[rva_to_off(upd):rva_to_off(upd) + 0x400]
        at = next((i for i in range(0x180) if f[i] == 0x0F and f[i + 1] == 0x10 and f[i + 2] == 0x66), -1)
        print("      node transform offset: %s" % (hex(f[at + 3]) if at >= 0 else "NOT FOUND (default 0x24)"))
        body = bytes.fromhex("48895C24084889742410574883EC300F1081")
        gp, g = None, b""
        for i in range(0x100):   # first call whose target is the getter (an E8 byte may be inside another instruction)
            if f[i] != 0xE8: continue
            t = upd + i + 5 + struct.unpack_from("<i", f, i + 1)[0]
            o = rva_to_off(t)
            if o is not None and data[o:o + len(body)] == body: gp, g = t, data[o:o + 32]; break
        if gp and g[:len(body)] == body and g[22] == 0x48:
            print("OK    %-22s exe+%x (node projection +%x)" % ("ProjectionGetter", gp, struct.unpack_from("<I", g, 18)[0]))
        else:
            print("FAIL  %-22s does not match - per-eye projection off" % "ProjectionGetter"); ok_all = False
        w = h = None
        for i in range(0x300):
            if f[i] == 0x8B and f[i + 1] == 0x86 and f[i + 4] == 0 and f[i + 5] == 0:
                for k in range(6, 18):
                    if f[i + k] == 0x8B and f[i + k + 1] == 0x96 and f[i + k + 4] == 0 and f[i + k + 5] == 0:
                        w = struct.unpack_from("<I", f, i + 2)[0]; h = struct.unpack_from("<I", f, i + k + 2)[0]; break
                if w: break
        print("      render size fields: %s" % ("+%x / +%x" % (w, h) if w else "not found (defaults +1a8 / +1ac)"))
    report("NoBlackBars1", scan("76 42 44 0F 28 C7 F3 44 0F 59 C0"))
    report("NoBlackBars2", scan("76 31 F3 0F 59 F1 0F 2F F7 73 28"))
    report("PauseOnFocusLoss", scan("0F 84 72 02 00 00 48 8B 0D ?? ?? ?? ?? 4C 8D 0D ?? ?? ?? ?? 41 B0 01"))
    report("HudFlag", scan("0F B6 05 ?? ?? ?? ?? 38 83 ?? ?? 00 00 74 14"))
    t = report("TimerUpdate", scan("80 79 78 00 44 0F B6 CA 4C 8B C1 0F 85 ?? ?? ?? ?? F3 0F 10 0D"))
    c = report("GameTimerCall", scan("48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 8B 0D ?? ?? ?? ?? 41 B8 01 00 00 00 BA 04 00 00 00"))
    if t is not None and c is not None:
        o = rva_to_off(c); tgt = c + 12 + struct.unpack_from("<i", data, o + 8)[0]
        print("      game clock exe+%x, call %s" % (c + 7 + struct.unpack_from("<i", data, o + 3)[0], "matches" if tgt == t else "DOES NOT MATCH"))
        if tgt != t: ok_all = False
    report("TaaJitter", scan("80 3D ?? ?? ?? ?? 00 4C 8B D2 4C 8B C9 0F 84"))
    w64 = scan("F3 48 0F 2A C8 83 E2 C0"); h64 = scan("F3 48 0F 2C C9 83 E1 C0")
    if len(w64) == 1 and len(h64) == 1: print("OK    RenderSizeRound64      exe+%x / exe+%x (exact render size: patched in memory)" % (w64[0], h64[0]))
    elif len(scan("F3 48 0F 2A C8 90 90 90")) == 1: print("OK    RenderSizeRound64      already removed in this exe (FuckTAA resolution fix)")
    else: print("--    RenderSizeRound64      not found - the internal render size stays rounded to 64 px")
    # render options (game.cpp FindRenderOptions): AntiAliasing setter sequence, then the int / float setters checked
    # against the same settings block and option table
    def rd32(rva): o = rva_to_off(rva); return struct.unpack_from("<i", data, o)[0]
    def rip(insn, d, ln): return insn + ln + rd32(insn + d)
    def scan_all(pat):
        r = to_re(pat); hits = []
        for n, va, vsz, rp, rs, ch in code:
            for m in r.finditer(data, rp, rp + rs): hits.append(va + m.start() - rp)
        return hits
    aa = report("OptAntiAliasing", scan("44 0F B6 05 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? BA BE 04 00 00 E8"))
    if aa is not None:
        blk = rip(aa, 4, 8) - 0x60; table = rip(aa + 8, 3, 7)
        si = [c for c in scan_all("44 8B 05 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? BA 1B 05 00 00 E8") if rip(c, 3, 7) == blk + 0x24 and rip(c + 7, 3, 7) == table]
        sf = [c for c in scan_all("F3 0F 10 15 ?? ?? ?? ?? 48 8D 0D ?? ?? ?? ?? BA 1A 05 00 00 E8") if rip(c, 4, 8) == blk + 0x38 and rip(c + 8, 3, 7) == table]
        report("OptUpscaling", si, "settings exe+%x table exe+%x" % (blk, table))
        report("OptResScale", sf)
    report("NearOverride", scan("F3 0F 10 2D ?? ?? ?? ?? 0F 57 C0 0F 2F E8 77 08 F3 0F 10 AF D0 01 00 00"))
    # post effect classes by RTTI (postfx.cpp): type descriptor -> complete object locator -> vtable -> IsActive
    import re as _re
    base = 0x140000000
    def off_to_rva(o):
        for n, va, vsz, rp, rs, ch in secs:
            if rp <= o < rp + rs: return va + (o - rp)
        return None
    def vt_by_rtti(name):
        b = name.encode() + b"\0"
        o = data.find(b)
        if o < 0: return None
        td = off_to_rva(o) - 16
        for m in _re.finditer(_re.escape(struct.pack("<I", td)), data):
            col_off = m.start() - 12
            if struct.unpack_from("<I", data, col_off)[0] != 1 or struct.unpack_from("<I", data, col_off + 4)[0] != 0: continue
            col = off_to_rva(col_off)
            if col is None or struct.unpack_from("<I", data, col_off + 20)[0] != col: continue
            q = data.find(struct.pack("<Q", base + col))
            if q < 0: continue
            vt = off_to_rva(q) + 8
            return vt, struct.unpack_from("<Q", data, q + 8)[0] - base
        return None
    for cls in ("DOF", "HexDOF", "MotionBlur", "RadialBlur", "FilmGrain"):
        r = vt_by_rtti(".?AVZRenderPostfilterPass%s@@" % cls)
        if r: print("OK    %-22s vtable exe+%x IsActive exe+%x" % ("Postfilter" + cls, r[0], r[1]))
        else: print("FAIL  %-22s not found - that post effect switch is off" % ("Postfilter" + cls)); ok_all = False
    # first person (firstperson.cpp)
    def q(rva): o = rva_to_off(rva); return struct.unpack_from("<Q", data, o)[0] if o is not None else 0
    def b(rva, n): o = rva_to_off(rva); return data[o:o + n] if o is not None else b""
    glc = report("GetLocalCharacter", scan("48 89 5C 24 10 48 89 6C 24 18 56 57 41 56 48 83 EC 50 33 FF 4C 8D 71 18 48 8D 44 24 20 48 89 7C 24 20 48 8B F2 8B CF 49 3B C6"))
    glh = report("GetLocalHero", scan("48 89 5C 24 08 57 48 83 EC 50 48 8B DA 48 8D 54 24 40 E8 ?? ?? ?? ?? 48 8B 7C 24 40 48 85 FF 0F 84"))
    if glh is not None and glc is not None:
        tgt = glh + 23 + rd32(glh + 19)
        print("      GetLocalHero calls GetLocalCharacter: %s" % ("yes" if tgt == glc else "NO (exe+%x)" % tgt))
    bqv = report("BoneWorldTransformQV", scan("48 89 5C 24 10 57 48 83 EC 60 48 83 B9 48 03 00 00 00 48 8B FA 48 8B D9 0F 84 ?? ?? ?? ?? 41 8B D0 48 8D 0D"))
    report("GetLocalPlayer", scan("40 55 57 41 57 48 83 EC 30 48 8B 2D ?? ?? ?? ?? 33 FF 48 89 39 4C 8B F9 48 89 79 08 48 85 ED 0F 84 ?? ?? ?? ?? 48 89 5C 24 50 8B 9D 80 00 00 00"))
    pms = report("PlayerManagerInit", scan("4C 8D 35 ?? ?? ?? ?? 49 8B CE E8 ?? ?? ?? ?? 48 8B 4B 40 4C 89 74 24 78"))
    pmv = vt_by_rtti(".?AVZPlayerManager@@")
    if pms is not None:
        inst = pms + 7 + struct.unpack_from("<i", b(pms + 3, 4))[0]
        print("      player manager instance exe+%x, vtable %s" % (inst, ("exe+%x" % pmv[0]) if pmv else "NOT FOUND"))
        if not pmv: ok_all = False
    zc = vt_by_rtti(".?AVZCharacter@@")
    if zc:
        qi = q(zc[0] + 4 * 8) - base; qb = b(qi, 14)
        ti = qi + 14 + struct.unpack_from("<i", qb, 10)[0] if qb[:3] == b"\x48\x8d\x05" and qb[7:10] == b"\x4c\x8d\x05" else None
        ga = q(zc[0] + 80 * 8) - base
        ok = ti is not None and b(ga, 9) == bytes.fromhex("40534883EC20488B81")
        print("%s  %-22s vtable exe+%x, type info %s, slot 80 exe+%x" % ("OK  " if ok else "FAIL", "ZCharacter", zc[0], ("exe+%x" % ti) if ti else "?", ga))
        ok_all &= ok
    else: print("FAIL  ZCharacter             not found"); ok_all = False
    ae = vt_by_rtti(".?AVZAnimatedEntity@@")
    if ae:
        sv = q(ae[0] + 76 * 8) - base
        ok = b(sv, 15) == bytes.fromhex("885424105348" "83EC40488BD938512C")
        print("%s  %-22s vtable exe+%x, slot 76 SetVisible exe+%x" % ("OK  " if ok else "FAIL", "ZAnimatedEntity", ae[0], sv)); ok_all &= ok
    import zlib
    j = data.find(b"jntbd_head\0")
    print("      head bone id 0x%08X (crc32 of 'jntbd_head'; joint name %s)" % (zlib.crc32(b"jntbd_head"), "present" if j >= 0 else "MISSING"))
    print("all signatures match" if ok_all else "some signatures do not match: those features are off with this exe")
    return 0 if ok_all else 1

if __name__ == "__main__":
    sys.exit(main())
