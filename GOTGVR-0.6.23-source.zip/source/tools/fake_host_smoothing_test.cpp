// Fake XrBridge host for the limiter test: speaks the mod's shared memory protocol (v6), reports a headset period that
// changes like a runtime turning its motion smoothing / ASW on and off (and, while "smoothing", runs its own loop at
// the divided rate, as xrWaitFrame would).
#include <windows.h>
#include <cstdio>
#include <cstring>
#include <string>
#include "xrbridge/ipc.h"
#include "xrbridge/names.h"
using namespace xrb;
int wmain(int argc, wchar_t** argv) {
    std::string name = "GOTGVR";
    for (int i = 1; i + 1 < argc; i++) if (!wcscmp(argv[i], L"--name")) { char b[64]; WideCharToMultiByte(CP_UTF8, 0, argv[i + 1], -1, b, 64, 0, 0); name = b; }
    HANDLE m = nullptr;
    for (int i = 0; i < 100 && !m; i++) { m = OpenFileMappingW(FILE_MAP_ALL_ACCESS, FALSE, ShmName(name.c_str()).c_str()); if (!m) Sleep(50); }
    if (!m) return 1;
    IpcShared* s = (IpcShared*)MapViewOfFile(m, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(IpcShared));
    const char* sys = getenv("FAKE_SYSTEM") ? getenv("FAKE_SYSTEM") : "Meta Quest 3";
    double fullHz = getenv("FAKE_HZ") ? atof(getenv("FAKE_HZ")) : 90.0;
    int divFrom = getenv("FAKE_DIV_FROM") ? atoi(getenv("FAKE_DIV_FROM")) : 6, divTo = getenv("FAKE_DIV_TO") ? atoi(getenv("FAKE_DIV_TO")) : 16;
    strncpy(s->systemName, sys, 63); strncpy(s->runtimeName, "FakeXR", 63);
    s->recWidth = 512; s->recHeight = 512; s->hostPid = GetCurrentProcessId();
    for (int e = 0; e < 2; e++) { s->eyePose[e] = { e ? 0.032f : -0.032f, 0, 0, 0, 0, 0, 1 }; s->eyeFov[e] = { -0.9f, 0.9f, 0.9f, -0.9f }; }
    s->hostState = HOST_FOCUSED;
    ULONGLONG t0 = GetTickCount64();
    for (;;) {
        double t = (GetTickCount64() - t0) / 1000.0;
        if (t > 40) break;
        bool smoothing = t >= divFrom && t < divTo;
        double hz = smoothing ? fullHz / 2 : fullHz;
        s->displayPeriodNs = (int64_t)(1e9 / hz);
        s->hostHeartbeat = s->hostHeartbeat + 1;
        Sleep((DWORD)(1000.0 / hz));
    }
    return 0;
}
