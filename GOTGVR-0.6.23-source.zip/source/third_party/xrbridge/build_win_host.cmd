@echo off
rem Builds dist\XrBridgeHost.exe (64-bit) with the local MSVC Build Tools (alternative to build.sh on Linux).
setlocal
set VCVARS=C:\Program Files (x86)\Microsoft Visual Studio\18\BuildTools\VC\Auxiliary\Build\vcvars64.bat
call "%VCVARS%" >nul || (echo vcvars64 failed & exit /b 1)
cd /d "%~dp0"
if not exist build\x64msvc mkdir build\x64msvc
cl /nologo /O2 /Zi /MT /EHsc /W3 /std:c++17 /utf-8 /D_CRT_SECURE_NO_WARNINGS /DNOMINMAX ^
   /DXR_USE_PLATFORM_WIN32 /DXR_USE_GRAPHICS_API_D3D11 /Iinclude /I%OPENXR_SDK%\include ^
   /Fobuild\x64msvc\ /Fdbuild\x64msvc\vc.pdb /Fe..\..\build\XrBridgeHost.exe ^
   src\host\main.cpp src\common\log.cpp src\common\config.cpp ^
   /link /DEBUG /PDB:..\..\build\XrBridgeHost.pdb /SUBSYSTEM:WINDOWS %OPENXR_SDK%\lib\openxr_loader_static.lib ^
   user32.lib gdi32.lib d3d11.lib dxgi.lib dxguid.lib advapi32.lib shlwapi.lib pathcch.lib ole32.lib shell32.lib d3dcompiler.lib
if errorlevel 1 (echo BUILD FAILED & exit /b 1)
echo BUILD OK
